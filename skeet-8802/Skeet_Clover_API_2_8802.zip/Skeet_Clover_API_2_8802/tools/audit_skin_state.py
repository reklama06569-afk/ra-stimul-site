#!/usr/bin/env python3
"""Pin recovered native Skinchanger fields to the bundled core, read-only."""
from pathlib import Path
import hashlib,struct,json
ROOT=Path(__file__).resolve().parents[1];B=0x43310000;data=(ROOT/'source/skeet/Binary/skeet_cv.bin').read_bytes()
def bytes_at(va,hex_):assert data[va-B:va-B+len(bytes.fromhex(hex_))]==bytes.fromhex(hex_),hex(va)
bytes_at(0x4333ffcc,'c1e60403b730010000')
bytes_at(0x43490323,'b810040000c74608ec8f21b66689460cc6460e06')
bytes_at(0x4334c8ac,'568b7170578b7974')
assert struct.unpack_from('<I',data,0x43470684-B+5*4)[0]==0x4334c8ac
knives=[struct.unpack_from('<I',data,0x43467fd0-B+i*32)[0] for i in range(19)]
assert knives==[500,505,506,507,508,509,515,512,516,514,519,520,522,523,503,517,518,521,525]
r={'passed':True,'core_sha256':hashlib.sha256(data).hexdigest(),'skin_tab_vtable':'0x43470684','skin_tab_bytes':0x158,'native_records_pointer_field':'0x130','record_node_hash':'0xb6218fec','record_node_type':6,'record_count':65,'record_bytes':16,'record_fields':{'enabled':0,'stattrak':1,'quality_percent':4,'seed':8,'paint_kit':12},'native_bind_function':'0x4333ff8d','native_bind_knife_slots':{'T':59,'CT':42},'knife_index_to_definition':knives,'knife_enabled_fields':['0xc8','0xcc'],'knife_model_fields':['0xd0','0xd4'],'glove_enabled_fields':['0xa8','0xac'],'glove_definition_fields':['0xb0','0xb4'],'glove_paint_fields':['0xb8','0xbc'],'agent_enabled_fields':['0xc0','0xc4'],'agent_combo_fields':['0x110','0x114'],'agent_value_field':'0x5c','native_config_complete_callback':'0x4334c8ac','config_hook_bytes':8,'filter_by_weapon_changes_snapshot':False,'paint_origin_weapon_used_as_model':False,'game_tested':False}
(ROOT/'data/native_skin_layout_audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
