from pathlib import Path
import sys
from capstone import *
from capstone.x86 import X86_OP_IMM
ROOT=Path(__file__).resolve().parents[1];BASE=0x43310000;DATA=(ROOT/'source/skeet/Binary/skeet_cv.bin').read_bytes();MD=Cs(CS_ARCH_X86,CS_MODE_32);MD.detail=True
def cfg(start,limit=0x10000):
 todo=[start];out={}
 while todo:
  a=todo.pop()
  if a in out or not start<=a<start+limit or not BASE<=a<BASE+len(DATA):continue
  i=next(MD.disasm(DATA[a-BASE:a-BASE+15],a,count=1),None)
  if not i:continue
  out[a]=i
  if i.group(CS_GRP_RET) or i.mnemonic in ['int3','ud2','hlt']:continue
  if i.group(CS_GRP_JUMP):
   if i.operands[0].type==X86_OP_IMM:todo.append(i.operands[0].imm)
   if i.mnemonic=='jmp':continue
  todo.append(a+i.size)
 return out
if __name__=='__main__':
 for arg in sys.argv[1:]:
  a=int(arg,0);nodes=cfg(a);p=ROOT/'reverse'/('function_'+arg.replace('0x','')+'.asm');p.write_text('\n'.join(f'{x:08x} {i.mnemonic:8} {i.op_str}' for x,i in sorted(nodes.items()))+'\n');print(p,len(nodes))
