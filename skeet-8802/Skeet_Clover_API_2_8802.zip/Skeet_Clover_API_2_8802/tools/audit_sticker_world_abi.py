"""Read-only ABI audit of the supplied 8802 modules. No module code is loaded."""
from pathlib import Path
import hashlib,struct,json,sys
import pefile
ROOT=Path(__file__).resolve().parents[1]
def main(client,engine,materials):
 c=Path(client).read_bytes();e=Path(engine).read_bytes()
 assert hashlib.sha256(c).hexdigest()=='183d42fac8a4ecc24dc02edf5f09122f37fe9e7533ca093a867718b25cfdeb03'
 assert hashlib.sha256(e).hexdigest()=='bcca98731eab8b72d1ef34fa5fe420f26ac98e8dd1d91698171d0ecd9935faa6'
 c=pefile.PE(data=c).get_memory_mapped_image();e=pefile.PE(data=e).get_memory_mapped_image()
 assert c[0x6bce60:0x6bce6f]==bytes.fromhex('8b91f401000033c00b81f8010000c3')
 assert c[0x7169bd:0x7169c3]==bytes.fromhex('8b8610020000')
 assert c[0x716a0a:0x716a10]==bytes.fromhex('3b8e08020000')
 assert struct.unpack_from('<I',c,0xcaa8b4+14*4)[0]==0x106bce60
 assert e[0x137780:0x13778d]==bytes.fromhex('558bec81ec3401000056578bf9')
 assert e[0x137851:0x137853]==bytes.fromhex('b001') and e[0x137859:0x13785b]==bytes.fromhex('32c0')
 core=(ROOT/'source/skeet/Binary/skeet_cv.bin').read_bytes();b=0x43310000
 assert struct.unpack_from('<I',core,0x4346f46c-b+26*4)[0]==0x433ed99e
 assert core[0x433ed9c0-b:0x433ed9d2-b]==bytes.fromhex('0fb6c35068ae0000008b1151ff92e4000000')
 m=Path(materials).read_bytes();assert hashlib.sha256(m).hexdigest()=='011e6fb57fa1856ae946a442a2aa2c930d5b15447b03c7e67a64337571f92cce'
 m=pefile.PE(data=m).get_memory_mapped_image()
 for slot,rva in [(86,0x15b10),(87,0x15b40),(88,0x15b50),(89,0x15b60)]:assert struct.unpack_from('<I',m,0x9a80c+slot*4)[0]==0x10000000+rva
 assert m[0x15b10:0x15b19]==bytes.fromhex('568bf157bfffff0000')
 assert m[0x15b50:0x15b56]==bytes.fromhex('b8ffff0000c3')
 # CMenu::Render returns after the forward tab loop without flushing the
 # renderer command buffer, so the separate popup pass can append safely.
 assert core[0x433ac628-b:0x433ac62b-b]==bytes.fromhex('c20400')
 r={'passed':True,'scope':'Static module bytes; execution cases are separate closed Unicorn fixtures.','client_item_id_getter_rva':'0x6bce60','client_soc_getter_rva':'0x7169b0','item_view_high_low_account_offsets':['0x200','0x204','0x208'],'engine_load_named_sky_rva':'0x137780','sky_name_register':'ECX','sky_returns_success_in_al':True,'native_backend_scissor_rva':'0x0dd99e','d3d_scissor_render_state':174,'scissor_false_disables':True,'game_tested':False}
 r.update(material_enumeration_slots=[86,87,88,89],material_invalid_handle=65535,materialsystem_sha256='011e6fb57fa1856ae946a442a2aa2c930d5b15447b03c7e67a64337571f92cce',menu_render_return_rva='0x9c628',popup_submission_after_native_tabs=True)
 (ROOT/'build/sticker_world_abi_audit.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
if __name__=='__main__':main(*sys.argv[1:])
