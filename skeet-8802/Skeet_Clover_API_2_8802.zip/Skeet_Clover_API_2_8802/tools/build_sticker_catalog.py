"""Generate Legacy-only sticker IDs/names; inputs are schema/localization files."""
from pathlib import Path
import sys,json,hashlib
from build_skin_rarity import kv
ROOT=Path(__file__).resolve().parents[1]
def generate(schema,english):
 raw=Path(schema).read_bytes();game=kv(raw)['items_game'];loc=kv(Path(english).read_bytes());loc=next(iter(loc.values()));loc={k.lower():v for k,v in loc.get('Tokens',loc.get('tokens',{})).items()}
 for slot in range(4):
  for field,offset in [('id',0),('wear',1),('scale',2),('rotation',3)]:assert game['attributes'][str(113+4*slot+offset)]['name']==f'sticker slot {slot} {field}'
 rows=[]
 for k,v in game['sticker_kits'].items():
  n=v.get('name','');tag=v.get('item_name','').lstrip('#')
  if not k.isdecimal() or int(k)==0 or n.startswith(('patch','stockh2021_teampatch','spray')) or n.endswith('graffiti') or not v.get('sticker_material'):continue
  rows.append({'id':int(k),'name':loc.get(tag.lower(),n),'material':v['sticker_material']})
 rows.sort(key=lambda x:(x['name'].lower(),x['id']))
 out=['#pragma once','namespace sticker_catalog {','struct Kit {int id;const char* name;};','inline constexpr Kit kits[]={{0,"None"},']
 out += ['{%d,%s},'%(x['id'],json.dumps(x['name'],ensure_ascii=True)) for x in rows];out+=['};','inline bool valid(int id){if(!id)return true;for(const auto& k:kits)if(k.id==id)return true;return false;}','}']
 (ROOT/'source/skeet/sticker_catalog.h').write_text('\n'.join(out)+'\n')
 meta={'source_repository':'SteamDatabase/GameTracking-CSGO','source_commit':'e63fc7fdb8dfb4f1873f0db214c0cc16613d5beb','schema_sha256':hashlib.sha256(raw).hexdigest(),'legacy_slots':4,'attributes':list(range(113,129)),'kits':rows}
 (ROOT/'data/sticker_catalog.json').write_text(json.dumps(meta,indent=2)+'\n');print(len(rows),'Legacy stickers')
if __name__=='__main__':generate(*sys.argv[1:])
