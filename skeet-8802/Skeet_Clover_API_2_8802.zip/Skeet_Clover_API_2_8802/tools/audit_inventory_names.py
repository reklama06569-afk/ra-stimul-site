#!/usr/bin/env python3
"""Verify pinned client RecvProp initializers without starting client code."""
from pathlib import Path
import hashlib,json,struct
ROOT=Path(__file__).resolve().parents[1]
p=Path('/workspace/game-8802-modules/client.mapped.bin').read_bytes()
def word(at):return struct.unpack_from('<I',p,at)[0]
fields=[('m_AttributeManager',0x60c00,0x2d90),('m_Item',0x5fe9e,0x40),('m_iItemDefinitionIndex',0x621ab,0x1ea),('m_szCustomName',0x62524,0x27c),('m_szCustomName buffer bytes',0x62542,161)]
rows=[]
for name,rva,value in fields:
 assert p[rva:rva+2]==b'\xc7\x05' and word(rva+6)==value
 rows.append({'name':name,'initializer_rva':hex(rva),'value':hex(value),'instruction':p[rva:rva+10].hex()})
assert p[0x1e2543:0x1e2545]==b'\x6a\x40' and p[0x1e254e]==0x68 and word(0x1e254f)==0x2e08
assert p[0x1e46e0]==0x68 and word(0x1e46e1)==0x14c
assert word(0xcad6a8+4*4)==0x106d16b0 and word(0xcad6a8+27*4)==0x106d1720
core=(ROOT/'source/skeet/Binary/skeet_cv.bin').read_bytes()
assert core[0x43344b4d-0x43310000:0x43344b4d-0x43310000+5]==bytes.fromhex('568b742408')
report={'passed':True,'client_sha256':hashlib.sha256(Path('/workspace/game-8802-modules/client.dll').read_bytes()).hexdigest(),'recvprop_initializers':rows,'custom_name_absolute_offset':'0x304c','custom_name_buffer_bytes':161,'weapon_definition_absolute_offset':'0x2fba','weapon_handles_offset':'0x2e08','weapon_handle_count':64,'owner_handle_offset':'0x14c','schema_vtable_rva':'0xcad6a8','schema_definition_getter_rva':'0x6d16b0','schema_attribute_getter_rva':'0x6d1720','native_textbox_input':'0x43344b4d','game_tested':False}
(ROOT/'data/inventory_name_layout_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
