#include "../source/skeet/precision_patch.h"
#include <fstream>
#include <iterator>
#include <vector>
#include <iostream>
int main(int argc,char** argv) {
    if(argc!=4)return 2;
    std::ifstream input(argv[1],std::ios::binary);
    std::vector<std::uint8_t> image((std::istreambuf_iterator<char>(input)),{});
    if(!scan_patch::matches_original(image.data(),image.size()))return 3;
    const auto address=std::uint32_t(std::stoul(argv[3],nullptr,0));
    const auto old=scan_patch::make_plan(address+0x1000,0x23b000,0x23b004);
    std::memcpy(image.data()+scan_patch::guard_call,old.guard,sizeof(old.guard));
    std::memcpy(image.data()+scan_patch::threshold_call,old.threshold,sizeof(old.threshold));
    precision_patch::Plan plan{};
    if(!precision_patch::make_plan(image.data(),image.size(),address,0x23b008,0x23b004,plan))return 4;
    for(const auto& edit:plan.edits) {
        image[edit.offset]^=1;
        precision_patch::Plan invalid{};
        if(precision_patch::make_plan(image.data(),image.size(),address,0x23b008,0x23b004,invalid))return 5;
        image[edit.offset]^=1;
    }
    static_assert(sizeof(old)==139);
    static_assert(sizeof(precision_patch::Edit)==32);
    static_assert(sizeof(plan)==1248);
    std::ofstream output(argv[2],std::ios::binary);
    output.write(reinterpret_cast<const char*>(&old),sizeof(old));
    output.write(reinterpret_cast<const char*>(&plan),sizeof(plan));
    std::cout<<"Precision plan and 7 incompatible-site rejections passed.\n";
}
