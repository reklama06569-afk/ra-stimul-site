#include "../source/skeet/skin_rarity.h"
#include <cassert>
#include <fstream>
#include <iostream>
int main(int argc,char** argv) {
    using namespace skin_rarity;
    assert(tier(344,L"Dragon Lore",11)==6);
    assert(tier(344,L"История о драконе",std::wcslen(L"История о драконе"))==6);
    assert(tier(180,L"Fire Serpent",12)==6);
    assert(tier(415,L"Doppler",7)==6);
    assert(tier(12,L"Crimson Web",11)==0);
    assert(tier(12,L"Crimson Web",11,63)==3);
    assert(tier(12,L"Crimson Web",11,507)==6);
    assert(tier(99999,L"Crimson Web",11,507)==6);
    assert(tier(344,L"unknown item",12)==0);
    assert(tier(5,L"Dragon Lore",11)==6); // native ordinal, resolved by name
    assert(tier(5,L"\aFFFFFFFF  Dragon Lore  ",24)==6);
    assert(tier(-1,L"Doppler",7)==6);
    assert(color(344,L"Dragon Lore",11)==0xff4b4bebU);
    assert(color(12,L"Crimson Web",11,255,63)==0xffff694bU);
    assert(color(-1,L"Unknown",7)==0xff808080U);
    assert(color(344,L"Dragon Lore",11,80)==0x504b4bebU);
    WeaponCandidates a;a.add(12);assert(!a.weapon());a.add(573);assert(a.weapon()==500);
    WeaponCandidates b;b.add(344);assert(b.weapon()==9);b.add(180);assert(!b.weapon());
    WeaponCandidates c;c.add(-1);assert(!c.initialized&&!c.weapon());
    if(argc>1) {
        std::ofstream out(argv[1]);
        for(const auto& e:skin_rarity_data::entries) {
            auto p=std::lower_bound(std::begin(skin_rarity_data::id_aliases),std::end(skin_rarity_data::id_aliases),e.id,[](auto a,int b){return a.id<b;});
            assert(p!=std::end(skin_rarity_data::id_aliases)&&p->id==e.id);
            out<<e.id<<' '<<tier(e.id,p->name,std::wcslen(p->name))<<' '<<color(e.id,p->name,std::wcslen(p->name))<<'\n';
        }
    }
    std::cout<<"Legacy rarity anchors, contextual grades, ordinal/unknown safeguards: PASS\n";
}
