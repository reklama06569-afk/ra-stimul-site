#!/usr/bin/env python3
"""Closed x86 native config-node reader and real record binding/init slices."""
from pathlib import Path
import json,struct,hashlib
import pefile
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
ROOT=Path(__file__).resolve().parents[1];BUILD=ROOT/'build';CORE=0x43310000;MEM=0x200000;SP=MEM+0xf0000;STOP=0x100000
image=(ROOT/'source/skeet/Binary/skeet_cv.bin').read_bytes();u=Uc(UC_ARCH_X86,UC_MODE_32);u.mem_map(CORE,len(image));u.mem_write(CORE,image);u.mem_map(MEM,0x100000);u.mem_map(STOP,0x1000);u.mem_map(0x130000,0x10000)
pe=pefile.PE(str(BUILD/'skin_state_probe.dll'));BASE=pe.OPTIONAL_HEADER.ImageBase;u.mem_map(BASE,pe.OPTIONAL_HEADER.SizeOfImage);u.mem_write(BASE,pe.get_memory_mapped_image())
def word(a):return struct.unpack('<I',u.mem_read(a,4))[0]
def put(a,x):u.mem_write(a,struct.pack('<I',x&0xffffffff))
exports={s.name.decode().lstrip('_'):BASE+s.address for s in pe.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
def exp(name):return next(v for k,v in exports.items() if name in k)
imports={}
for lib in pe.DIRECTORY_ENTRY_IMPORT:
 for item in lib.imports:
  a=0x130000+16*len(imports);put(item.address,a);imports[a]=item.name.decode()
def cstring(a):
 b=bytearray()
 while bytes(u.mem_read(a+len(b),1))!=b'\0':b.extend(u.mem_read(a+len(b),1))
 return bytes(b)
def finish(result=0,cleanup=4):
 sp=u.reg_read(UC_X86_REG_ESP);u.reg_write(UC_X86_REG_EAX,result&0xffffffff);u.reg_write(UC_X86_REG_EIP,word(sp));u.reg_write(UC_X86_REG_ESP,sp+cleanup)
def hook(u,a,size,user):
 sp=u.reg_read(UC_X86_REG_ESP)
 if a in imports:
  fn=imports[a]
  if fn=='VirtualQuery':
   p,out,n=[word(sp+k) for k in [4,8,12]];assert n==28
   for lo,hi,perm in u.mem_regions():
    if lo<=p<=hi:u.mem_write(out,struct.pack('<IIIIIII',lo,lo,0x40,hi-lo+1,0x1000,0x40,0x20000));finish(28,16);break
   else:finish(0,16)
  elif fn in ['memcpy','memmove']:
   dst,src,n=[word(sp+k) for k in [4,8,12]];u.mem_write(dst,bytes(u.mem_read(src,n)));finish(dst)
  elif fn=='memset':
   dst,c,n=[word(sp+k) for k in [4,8,12]];u.mem_write(dst,bytes([c&255])*n);finish(dst)
  elif fn=='strcmp':
   a,b=[cstring(word(sp+k)) for k in [4,8]];finish((a>b)-(a<b))
  else:raise AssertionError(fn)
 elif a in [0x132000,0x434084f0,0x43385ae4]:finish()
 elif a==STOP:u.emu_stop()
u.hook_add(UC_HOOK_CODE,hook)
def call(address,args=(),this=0):
 for n,v in enumerate([STOP,*args]):put(SP+4*n,v)
 u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,this);u.emu_start(address,STOP+1,count=2000000);assert u.reg_read(UC_X86_REG_EIP)==STOP,hex(u.reg_read(UC_X86_REG_EIP));return u.reg_read(UC_X86_REG_EAX)
tab=MEM+0x10000;nodes=MEM+0x20000;out=MEM+0x50000;put(tab,0x43470684)
fields=[(0xc8,0xd347bc87,1,1,1),(0xcc,0xd4f2a320,1,1,1),(0xd0,0xe0bda969,4,3,4),(0xd4,0xb3c4b6ca,4,3,4),
 (0xa8,0x3a8ef907,1,1,1),(0xac,0xe5249ca0,1,1,1),(0xb0,0x7439e8b5,4,3,5030),(0xb4,0x5101537e,4,3,5030),(0xb8,0xe13f61e0,4,3,10038),(0xbc,0x7cfd0011,4,3,10038),
 (0xc0,0x191a5a61,1,1,1),(0xc4,0x6caf4832,1,1,1),(0x110,0x3eb3f20b,4,3,4619),(0x114,0x8191d9bc,4,3,4680)]
payloads={}
for i,(field,hash_,n,type_,v) in enumerate(fields):
 node=nodes+i*0x100;put(node+8,hash_);u.mem_write(node+12,struct.pack('<HBB',n,type_,0));put(node+16,v);payloads[field]=node+16
 if field in [0x110,0x114]:control=MEM+0x40000+i*0x100;put(tab+field,control);u.mem_write(control+0x19,b'\4');put(control+0x5c,node+16)
 else:put(tab+field,node+16)
record_node=nodes+0x1000;records=record_node+16;put(tab+0x130,records)
# Execute the actual native constructor's config metadata + 65-record defaults.
u.reg_write(UC_X86_REG_ESI,record_node);u.reg_write(UC_X86_REG_ESP,SP);u.emu_start(0x43490323,0x4349035c,count=10000)
assert word(record_node+8)==0xb6218fec and bytes(u.mem_read(record_node+12,3))==b'\x10\x04\x06'
for w in range(65):assert struct.unpack('<BB2xi ii',u.mem_read(records+w*16,16))==(0,0,100,0,0)
def record(w,paint,on=1,quality=100,seed=0,stat=0):u.mem_write(records+w*16,struct.pack('<BB2xiii',on,stat,quality,seed,paint))
for w,p in [(7,282),(9,344),(42,1043),(59,1043)]:record(w,p)
record(28,1043,0)
size=call(exp('skin_native_spec_size_probe'));assert size==164

def snapshot():
 count=call(exp('skin_native_snapshot_probe'),[tab,out,96]);assert count not in [0xffffffff,0xfffffffe],hex(count)
 result=[]
 for i in range(count):
  p=out+i*size;weapon,paint,seed,wear,rarity=struct.unpack('<iiifI',u.mem_read(p,20));source,teams,flags=struct.unpack('<III',u.mem_read(p+152,12));result.append((weapon,paint,source,teams,flags))
 return sorted(result)
rows=snapshot();assert len(rows)==6,rows
assert (508,1043,0x10000,12,1) in rows and not any(w==28 for w,*_ in rows)
assert any(w==4619 and key==0x30002 and teams==4 and flags==2 for w,p,key,teams,flags in rows)
assert any(w==4680 and key==0x30003 and teams==8 and flags==2 for w,p,key,teams,flags in rows)
assert any(w==5030 and teams==12 for w,p,key,teams,flags in rows)
# Filter by weapon changes the displayed list only; all configured profiles remain.
u.mem_write(0x4346a498,b'\1');assert snapshot()==rows;u.mem_write(0x4346a498,b'\0');assert snapshot()==rows
# Native current-profile binding: actual 0x4333ff8d maps a knife to 42/59,
# then binds enabled/stat/quality/seed/paint to +0/+1/+4/+8/+12.
vt=MEM+0x42000;put(vt+20,0x132000)
for i,field in enumerate([0x11c,0x120,0x124,0x128,0x12c]):control=MEM+0x43000+i*0x100;put(control,vt);u.mem_write(control+0x19,b'\3');put(tab+field,control)
for weapon,team,slot,key in [(508,3,42,0x10003),(515,2,59,0x10002),(7,2,7,7)]:
 call(0x4333ff8d,[weapon,team],tab)
 assert [word(word(tab+field)+0x5c) for field in [0x11c,0x120,0x124,0x128,0x12c]]==[records+16*slot+x for x in [0,1,4,8,12]]
 assert call(exp('skin_native_active_probe'),[tab])==key
# Malformed node header is rejected before touching live data.
put(record_node+8,0);assert call(exp('skin_native_snapshot_probe'),[tab,out,96])==0xffffffff;put(record_node+8,0xb6218fec)
put(payloads[0xd0],99);assert call(exp('skin_native_snapshot_probe'),[tab,out,96])==0xffffffff
report={'passed':True,'native_record_defaults_executed':65,'native_profile_binding_executed':True,'native_record_offsets':[0,1,4,8,12],'all_config_profiles_read_without_opening_skin_tab':True,'m9_devtexture_stays_m9':True,'filter_toggle_preserves_inventory_snapshot':True,'agent_and_glove_team_settings_read':True,'identical_team_items_merged':True,'bad_node_and_model_rejected':True,'source_sha256':hashlib.sha256(image).hexdigest(),'game_startup_executed':False,'game_tested':False,'scope':'Native record initialization and binding executed in closed x86 fixture; schema/UI event boundaries mocked.'}
(BUILD/'skin_native_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
