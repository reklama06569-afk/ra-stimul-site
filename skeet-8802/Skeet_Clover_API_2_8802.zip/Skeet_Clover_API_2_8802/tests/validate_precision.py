#!/usr/bin/env python3
"""Execute production-generated x86 and original generator/caller blocks.
The engine spread calculation and traces are bounded mocks; no game is run.
"""
from pathlib import Path
import json,struct,subprocess,math,itertools,hashlib
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
ROOT=Path(__file__).resolve().parents[1];BUILD=ROOT/'build';BUILD.mkdir(exist_ok=True)
IMAGE=(ROOT/'source/skeet/Binary/skeet_cv.bin').read_bytes()
BASE=0x43310000;MEM=0x200000;STOP=0x100000
FLAGS=0x23b000
tool=BUILD/'precision_plan'
subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/precision_plan.cpp'),'-o',str(tool)],check=True)
def word(u,a):return struct.unpack('<I',u.mem_read(a,4))[0]
def store(u,a,v):u.mem_write(a,struct.pack('<I',v&0xffffffff))
def vec(u,a,v):u.mem_write(a,struct.pack('<fff',*v))
def fbits(v):return struct.unpack('<I',struct.pack('<f',v))[0]
def run(u,start,stop,count=100000):
    finished=[]
    def end(u,address,size,user):
        if address==stop:finished.append(True);u.emu_stop()
    h=u.hook_add(UC_HOOK_CODE,end)
    try:u.emu_start(start,STOP+0x800,count=count)
    except Exception as exc:raise RuntimeError(hex(u.reg_read(UC_X86_REG_EIP))) from exc
    u.hook_del(h);assert finished,hex(u.reg_read(UC_X86_REG_EIP))
def machine(location,blob,history=1,strict=1,precise=1):
    u=Uc(UC_ARCH_X86,UC_MODE_32)
    u.mem_map(BASE,len(IMAGE));u.mem_write(BASE,IMAGE)
    u.mem_map(location,0x2000);u.mem_write(location,blob[139:139+1024]);u.mem_write(location+0x1000,blob[:128])
    u.mem_map(MEM,0x40000);u.mem_map(STOP,0x1000)
    u.mem_write(BASE+0x1ffb1,blob[128:133]);u.mem_write(BASE+0x20178,blob[133:139])
    for i in range(7):
        at=139+1024+i*32;offset=struct.unpack_from('<I',blob,at)[0];size=blob[at+4]
        before,after=blob[at+5:at+5+size],blob[at+17:at+17+size]
        assert bytes(u.mem_read(BASE+offset,size))==before
        u.mem_write(BASE+offset,after)
    for i,value in enumerate((history,strict,precise)):store(u,FLAGS+4*i,value)
    return u
setup_cases=generator_cases=threshold_cases=loop_cases=guard_cases=0
seeds=IMAGE[0x15fc50:0x15fcd0]
assert len(set(seeds))==128 and set(seeds[::4])<set(seeds)
for location in [0x10000000,0x60000000,0xf0000000]:
    out=BUILD/f'precision_plan_{location:x}.bin'
    subprocess.run([str(tool),str(ROOT/'source/skeet/Binary/skeet_cv.bin'),str(out),hex(location)],check=True)
    blob=out.read_bytes();assert len(blob)==1387
    for precise in [0,1]:
        u=machine(location,blob,precise=precise)
        n=128 if precise else 32
        # Capture one count at native entry, respecting its 16-byte alignment.
        for alignment in [0,4,8,12]:
            sp=MEM+0x2a000+alignment
            u.reg_write(UC_X86_REG_ESP,sp);u.reg_write(UC_X86_REG_EBP,0x12345678)
            u.reg_write(UC_X86_REG_ECX,0xabcdef01);u.reg_write(UC_X86_REG_EDX,0xabcdef02)
            run(u,0x4332fd2b,0x4332fd37)
            expected=((sp-4)&~15)-0x4a38
            assert u.reg_read(UC_X86_REG_ESP)==expected
            assert u.reg_read(UC_X86_REG_ECX)==0xabcdef01 and u.reg_read(UC_X86_REG_EDX)==0xabcdef02
            assert word(u,expected+0x758)==n
            setup_cases+=1

        for weapon,flags in [(9,0),(64,0),(64,2),(64,6)]:
            sp=MEM+0x10000;shooter=MEM+0x18000
            u.reg_write(UC_X86_REG_ESP,sp);u.reg_write(UC_X86_REG_ESI,shooter)
            store(u,sp+0x760,n)
            # Flip the live menu flag: the direction count must remain captured.
            store(u,FLAGS+8,1-precise)
            store(u,shooter+0xd8,weapon);store(u,shooter+0xb0,3);store(u,shooter+0x7c,flags)
            store(u,shooter+0xc4,fbits(.01));store(u,shooter+0xd0,fbits(.02));store(u,shooter+0x100,fbits(1))
            vec(u,sp+0x58,(1,0,0));vec(u,sp+0x88,(0,1,0));vec(u,sp+0x94,(0,0,1))
            u.mem_write(sp+0x160,b'\xa5'*(128*12));store(u,sp+0x15c,0xa5a5a5a5)
            u.mem_write(sp+0x770,b'\x5a'*32)
            seen=[]
            def spread(u,address,size,user):
                if address!=0x433adb4f:return
                frame=u.reg_read(UC_X86_REG_ESP);seed=word(u,frame+4)
                assert word(u,frame+12)==1
                seen.append(seed)
                x=((seed%16)-8)/1000;y=((seed//16)-8)/1000
                ret=word(u,frame);u.reg_write(UC_X86_REG_ESP,frame+16)
                u.reg_write(UC_X86_REG_XMM0,fbits(x));u.reg_write(UC_X86_REG_XMM1,fbits(y))
                u.reg_write(UC_X86_REG_EIP,ret)
            h=u.hook_add(UC_HOOK_CODE,spread)
            run(u,0x43330000,0x43330023)
            u.hook_del(h)
            expected=list(seeds if precise else seeds[::4])
            assert seen==expected,(precise,seen,expected)
            for i,seed in enumerate(seen):
                x=((seed%16)-8)/1000;y=((seed//16)-8)/1000
                length=math.sqrt(1+x*x+y*y)
                actual=struct.unpack('<fff',u.mem_read(sp+0x160+12*i,12))
                assert max(abs(a-b) for a,b in zip(actual,(1/length,x/length,y/length)))<2e-6,actual
            assert word(u,sp+0x15c)==0xa5a5a5a5 and word(u,sp+0x760)==n
            assert bytes(u.mem_read(sp+0x770,32))==b'\x5a'*32
            if not precise:assert bytes(u.mem_read(sp+0x160+32*12,96*12))==b'\xa5'*(96*12)
            assert u.reg_read(UC_X86_REG_ESP)==sp
            generator_cases+=1

        for strict in [0,1]:
            store(u,FLAGS+4,strict)
            sp=MEM+0x10000;target=MEM+0x18000
            result={}
            def threshold_end(u,address,size,user):
                if address in [0x433300c8,0x4333018d]:
                    result['accepted']=address==0x4333018d;u.emu_stop()
            h=u.hook_add(UC_HOOK_CODE,threshold_end)
            for percent in range(101):
                required=max(1,math.ceil(percent*n/100) if strict else percent*n//100)
                for successes in range(n+1):
                    u.reg_write(UC_X86_REG_ESP,sp);u.reg_write(UC_X86_REG_EDI,target)
                    store(u,sp+0x760,n);store(u,target+0x848,percent);store(u,sp+0xc,successes)
                    result.clear();u.emu_start(0x4333016c,STOP+0x800,count=150)
                    assert result.get('accepted')==(successes>=required),(n,strict,percent,successes,result)
                    threshold_cases+=1
            u.hook_del(h)

            # Execute the original entire trace loop, with bounded engine calls.
            for percent in [0,1,50,80,99,100]:
                required=max(1,math.ceil(percent*n/100) if strict else percent*n//100)
                for successes in sorted(set([0,max(0,required-1),required,n])):
                    sp=MEM+0x10000;bp=MEM+0x16000;target=MEM+0x18000;shooter=MEM+0x1a000
                    u.reg_write(UC_X86_REG_ESP,sp);u.reg_write(UC_X86_REG_EBP,bp);u.reg_write(UC_X86_REG_EDI,target)
                    store(u,bp+8,shooter);store(u,bp+12,0xabcdef01);store(u,bp+20,MEM+0x1c000)
                    store(u,sp+0x24,sp+0x58);store(u,sp+0x760,n);store(u,sp+0xc,0)
                    store(u,shooter,0);store(u,target+0x848,percent)
                    counts={'trace':0,'qualify':0};result.clear()
                    def trace(u,address,size,user):
                        if address not in [0x43364cec,0x4331fbdb]:return
                        frame=u.reg_read(UC_X86_REG_ESP);ret=word(u,frame)
                        if address==0x43364cec:
                            assert word(u,frame+4)==sp+0x160+counts['trace']*12
                            counts['trace']+=1
                            ok=counts['trace']<=successes
                            u.reg_write(UC_X86_REG_ESP,frame+16)
                            # Model a menu toggle between samples.
                            store(u,FLAGS+8,counts['trace']%2)
                        else:
                            counts['qualify']+=1;ok=True;u.reg_write(UC_X86_REG_ESP,frame+8)
                        u.reg_write(UC_X86_REG_EAX,int(ok));u.reg_write(UC_X86_REG_EIP,ret)
                    h1=u.hook_add(UC_HOOK_CODE,trace);h2=u.hook_add(UC_HOOK_CODE,threshold_end)
                    u.emu_start(0x433300de,STOP+0x800,count=10000)
                    assert result.get('accepted')==(successes>=required),(n,strict,percent,successes,result)
                    assert counts=={'trace':n,'qualify':successes},counts
                    assert u.reg_read(UC_X86_REG_ESP)==sp
                    assert word(u,sp+0x760)==n
                    u.hook_del(h1);u.hook_del(h2);loop_cases+=1

    # A failed native empty-history application must clean up the relocated
    # scope object once and return through the unchanged function epilogue.
    for history_enabled in [0,1]:
        u=machine(location,blob,history=history_enabled)
        sp=MEM+0x10000;bp=MEM+0x16000;target=MEM+0x18000;table=MEM+0x19000;history=MEM+0x1a000
        u.reg_write(UC_X86_REG_ESP,sp);u.reg_write(UC_X86_REG_EBP,bp)
        u.reg_write(UC_X86_REG_EAX,100);u.reg_write(UC_X86_REG_ESI,0x12345678);u.reg_write(UC_X86_REG_EDI,0x23456789)
        store(u,sp,0x34567890);store(u,sp+4,0x45678901);store(u,bp,0x56789012);store(u,bp+4,STOP);store(u,bp+8,target)
        store(u,sp+0x770,target);store(u,target+8,table);store(u,table+0x28,STOP+0x100)
        store(u,0x434797bc+12,history);store(u,history+0x5d8,0)
        store(u,0x4346a338,MEM+0x1b000);store(u,MEM+0x1b000,fbits(1/64))
        calls={'cleanup':0};outcome=[]
        def guard(u,address,size,user):
            frame=u.reg_read(UC_X86_REG_ESP)
            if address in [STOP+0x100,0x4336630d]:
                if address==0x4336630d:
                    assert u.reg_read(UC_X86_REG_ECX)==sp+0x770;calls['cleanup']+=1
                else:u.reg_write(UC_X86_REG_EAX,3)
                ret=word(u,frame);u.reg_write(UC_X86_REG_ESP,frame+4);u.reg_write(UC_X86_REG_EIP,ret)
            elif address in [0x4332ffb6,STOP]:
                outcome.append('continue' if address==0x4332ffb6 else 'reject');u.emu_stop()
        u.hook_add(UC_HOOK_CODE,guard);u.emu_start(0x4332ff9f,STOP+0x800,count=1000)
        assert outcome==(['reject'] if history_enabled else ['continue'])
        assert calls['cleanup']==history_enabled
        assert u.reg_read(UC_X86_REG_ESP)==(bp+24 if history_enabled else sp)
        guard_cases+=1

report={'passed':True,'core_sha256':hashlib.sha256(IMAGE).hexdigest(),
        'frame_setup_cases':setup_cases,'native_generator_cases':generator_cases,
        'threshold_cases':threshold_cases,'full_sample_loop_cases':loop_cases,
        'relocated_scope_guard_cases':guard_cases,'distinct_seeds':[32,128],
        'scope':'Original x86 generator and caller blocks, relocated scopes, production-generated thunks; engine spread and tracing are mocked.',
        'game_tested':False}
(BUILD/'precision_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
