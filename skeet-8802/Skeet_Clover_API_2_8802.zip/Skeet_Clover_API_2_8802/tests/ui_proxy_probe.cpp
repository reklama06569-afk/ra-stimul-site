#include "../source/skeet/native_ui_proxy.h"
#include "../source/skeet/native_ui_names.h"
extern "C" __declspec(dllexport) void* create_proxy_probe(native_ui_proxy::Api* api,void* child,void* source,const wchar_t* name) {
    return native_ui_proxy::create(*api,child,source,name);
}
extern "C" __declspec(dllexport) int decode_name_probe(void* source,wchar_t* out,unsigned size) {
    return native_ui_names::decode(source,out,size);
}
