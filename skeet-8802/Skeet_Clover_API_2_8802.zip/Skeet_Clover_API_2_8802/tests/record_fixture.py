"""Restricted native-core fixture shared by the record consistency checks."""
from pathlib import Path
import struct,math
from unicorn import Uc,UC_ARCH_X86,UC_MODE_32,UC_HOOK_CODE
from unicorn.x86_const import *
ROOT=Path(__file__).resolve().parents[1]
IMAGE=(ROOT/'source/skeet/Binary/skeet_cv.bin').read_bytes()
BASE=0x43310000;MEM=0x200000;STOP=0x100000
HISTORY=0x220000;ACTOR=0x224000;CONTEXT=0x226000;SCOPE=0x240000
NEW=0x270000;OLD=0x272000
SP=0x260000
def word(u,a):return struct.unpack('<I',u.mem_read(a,4))[0]
def store(u,a,v):u.mem_write(a,struct.pack('<I',v&0xffffffff))
def floats(u,a,*v):u.mem_write(a,struct.pack('<'+'f'*len(v),*v))
def scalar(u,a):return struct.unpack('<f',u.mem_read(a,4))[0]
def fbits(v):return struct.unpack('<I',struct.pack('<f',v))[0]
def matrix(u,a,x):floats(u,a,1,0,0,x,0,1,0,0,0,0,1,0)
def fixture(new_tick=100,old_tick=94,new_x=100,old_x=94):
    u=Uc(UC_ARCH_X86,UC_MODE_32)
    u.mem_map(BASE,len(IMAGE));u.mem_write(BASE,IMAGE)
    u.mem_map(MEM,0x100000);u.mem_map(STOP,0x1000);u.mem_map(0x77500000,0x10000)
    u.mem_map(0x774f0000,0x10000)
    floats(u,HISTORY+0x13c,new_x,0,0)
    store(u,HISTORY+0x5d4,0);store(u,HISTORY+0x5d8,2)
    for i,(record,tick,x) in enumerate([(NEW,new_tick,new_x),(OLD,old_tick,old_x)]):
        store(u,HISTORY+0x5dc+i*4,record);store(u,record+0x4c,tick);store(u,record+0x5c,4)
        floats(u,record+0x28,0);floats(u,record+0x30,x,0,0)
        for bone in [0,3]:matrix(u,record+0x230+bone*48,x)
    store(u,SCOPE,ACTOR)
    store(u,ACTOR+8,MEM+0x1000);store(u,MEM+0x1028,STOP+0x100)
    store(u,0x434797bc+12,HISTORY)
    store(u,0x4346a338,MEM+0x2000);floats(u,MEM+0x2000,1/64)
    store(u,0x43467eb8,MEM+0x2004);floats(u,MEM+0x2004,100/64)
    floats(u,0x43476928,2/64);floats(u,CONTEXT+0x198,.1)
    def helpers(u,address,size,user):
        if address not in [0x7750c6d0,0x7750a770,0x775090b0,0x77509ee0,STOP+0x100,0x433e41ca,0x774fd4a0]:return
        sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp)
        if address in [0x7750c6d0,0x7750a770,0x775090b0]:
            value=struct.unpack('<f',struct.pack('<I',u.reg_read(UC_X86_REG_XMM0)&0xffffffff))[0]
            out=math.sin(value) if address==0x7750c6d0 else (math.cos(value) if address==0x7750a770 else math.acos(max(-1.,min(1.,value))))
            u.reg_write(UC_X86_REG_XMM0,fbits(out))
        elif address==0x77509ee0:
            y=struct.unpack('<d',struct.pack('<Q',u.reg_read(UC_X86_REG_XMM0)&0xffffffffffffffff))[0]
            x=struct.unpack('<d',struct.pack('<Q',u.reg_read(UC_X86_REG_XMM1)&0xffffffffffffffff))[0]
            u.reg_write(UC_X86_REG_XMM0,struct.unpack('<Q',struct.pack('<d',math.atan2(y,x)))[0])
        elif address==STOP+0x100:u.reg_write(UC_X86_REG_EAX,3)
        elif address==0x774fd4a0:
            dst,src,count=[word(u,sp+i) for i in [4,8,12]]
            u.mem_write(dst,bytes(u.mem_read(src,count)));u.reg_write(UC_X86_REG_EAX,dst)
        u.reg_write(UC_X86_REG_ESP,sp+4);u.reg_write(UC_X86_REG_EIP,ret)
    u.hook_add(UC_HOOK_CODE,helpers)
    return u
def run_until(u,start,stop,count=20000):
    ended=[]
    def hook(u,address,size,user):
        if address==stop:ended.append(True);u.emu_stop()
    h=u.hook_add(UC_HOOK_CODE,hook)
    try:u.emu_start(start,STOP+0x800,count=count)
    except Exception as exc:raise RuntimeError(hex(u.reg_read(UC_X86_REG_EIP))) from exc
    u.hook_del(h);assert ended,hex(u.reg_read(UC_X86_REG_EIP))
def get_pose(u,tick):
    for i,value in enumerate([STOP,0,MEM+0x3000,MEM+0x3100]):store(u,SP+i*4,value)
    u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,HISTORY);u.reg_write(UC_X86_REG_EDX,tick)
    run_until(u,0x433eedff,STOP)
    return u.reg_read(UC_X86_REG_EAX),scalar(u,MEM+0x3000),scalar(u,MEM+0x3100+12)
def get_applied_copy(u,tick):
    for i,value in enumerate([STOP,CONTEXT,tick,0]):store(u,SP+i*4,value)
    u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,SCOPE)
    run_until(u,0x43344c0c,0x43345b83)
    return word(u,SCOPE+0x10+0x4c),scalar(u,SCOPE+0x10+0x30)
def setup_selector_model(u):
    holder,header=MEM+0x10000,MEM+0x11000
    cell_a,cell_b=MEM+0x2100,MEM+0x2104
    store(u,0x43467e8c,cell_a);store(u,cell_a,0x32e4daf1^0x100);store(u,0x43467900,0)
    store(u,ACTOR+0x100,holder);store(u,holder,header)
    store(u,0x43468240,cell_b);store(u,cell_b,0xc2b6fb10^0x104);store(u,0x4346a84c,0)
    store(u,ACTOR+0x104,0);store(u,header+0xb0,0x100)
    store(u,header+0x104,4);store(u,header+0x108,0x20)
    floats(u,header+0x120+8,0,0,0,0,0,0)
def select_pose(u,low=94,high=100,bone=0):
    setup_selector_model(u)
    direction,source=MEM+0x4000,MEM+0x4100
    length=math.sqrt(98**2+10**2)
    floats(u,direction,98/length,-10/length,0);floats(u,source,0,10,0)
    best,score=MEM+0x4200,MEM+0x4204
    store(u,best,-1);floats(u,score,-1)
    for i,value in enumerate([STOP,ACTOR,HISTORY,bone,low,high,best,score]):store(u,SP+i*4,value)
    u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,source);u.reg_write(UC_X86_REG_EDX,direction)
    saved={UC_X86_REG_EBX:0x12345678,UC_X86_REG_ESI:0x23456789,UC_X86_REG_EDI:0x34567890,UC_X86_REG_EBP:0x45678901}
    for register,value in saved.items():u.reg_write(register,value)
    u.reg_write(UC_X86_REG_XMM0,fbits(10000))
    run_until(u,0x433983bb,STOP)
    assert u.reg_read(UC_X86_REG_ESP)==SP+32
    for register,value in saved.items():assert u.reg_read(register)==value
    return word(u,best),scalar(u,score)
if __name__=='__main__':
    for tick in [94,95,98,100]:
        u=fixture();print('tick',tick,'getter',get_pose(u,tick),'applied',get_applied_copy(u,tick))
    u=fixture();print('native selector:',select_pose(u))
