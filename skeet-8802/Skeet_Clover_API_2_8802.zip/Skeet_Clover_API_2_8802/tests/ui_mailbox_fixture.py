"""Native x86 mailbox registration, real SDK Call vector dispatch, no Lua/FFI."""
def check_mailbox(ns):
 globals().update(ns)
 u=fixture();pe,exp=load(u,'visuals_binding_probe.dll')
 menu,tabs,tab,children,child,elements,values,callvec=[MEM+0x10000+i*0x1000 for i in range(8)]
 store(u,menu+0x54,tabs);store(u,menu+0x58,tabs+36);store(u,tabs+32,tab)
 store(u,tab+0x70,children);store(u,tab+0x74,children+4);store(u,children,child)
 store(u,child+0x80,elements);store(u,child+0x84,elements+42*4)
 rows=[]
 for i in range(42):
  at=MEM+0x30000+i*0x300;rows.append(at);store(u,elements+4*i,at);store(u,at+0x5c,values+4*i);u.mem_write(at+0x19,bytes([3 if i==0 else 5]))
  name='Clover bridge request 8802' if i==0 else 'Clover bridge ready 8802' if i==1 else 'Clover bridge in '+str(i-2) if i<34 else 'Clover bridge out '+str(i-34)
  encrypted=at+0x100;data=name.encode('utf-16le');store(u,at+0x38,encrypted);u.mem_write(encrypted,struct.pack('<HH',0,len(data))+data)
 store(u,rows[0]+0x40,callvec);store(u,rows[0]+0x44,callvec);store(u,rows[0]+0x48,callvec+64)
 call(u,exp('mailbox_frame_probe'),[menu]);assert word(u,values+4)==8802 and word(u,rows[0]+0x44)==callvec+8
 sequence=[0]
 def run(op,args=[]):
  store(u,values+8,op)
  for i in range(1,7):store(u,values+(i+2)*4,args[i-1] if i<=len(args) else 0)
  sequence[0]+=1;store(u,values+33*4,sequence[0])
  # Original Checkbox callback dispatcher executes the registered fastcall ABI.
  call(u,0x4334e09f,[],rows[0])
  assert word(u,values+41*4)==sequence[0]
  return word(u,values+34*4)
 assert run(0)==8802
 assert run(3,[1,85,0x735a50,0x917d73])==1 and call(u,exp('mailbox_night_probe'))==85
 assert run(3,[0,85,0x735a50,0x917d73])==1 and call(u,exp('mailbox_night_probe'))==0xffffffff
 for slot in range(4):
  assert run(7,[9,slot,6026,3000,15000,-600000])==1
  assert run(8,[9,slot])==1 and word(u,values+35*4)==6026 and word(u,values+36*4)==3000 and word(u,values+37*4)==15000
 assert run(7,[9,0,0,0,10000,0])==1 and run(8,[9,0])==1 and word(u,values+35*4)==0
 assert run(7,[508,0,6026,0,10000,0])==0 and run(8,[9,4])==0
 assert run(2,[15])==1
 call(u,exp('mailbox_frame_probe'),[menu]);assert word(u,rows[0]+0x44)==callvec+8
 store(u,rows[0]+0x44,callvec);store(u,values+4,0);call(u,exp('mailbox_frame_probe'),[menu]);assert word(u,rows[0]+0x44)==callvec+8 and word(u,values+4)==8802
 assert run(0)==8802
 store(u,child+0x84,elements);call(u,exp('mailbox_frame_probe'),[menu]);before=word(u,values+41*4);sequence[0]+=1;store(u,values+33*4,sequence[0]);call(u,0x4334e09f,[],rows[0]);assert word(u,values+41*4)==before
 return {'passed':True,'native_x86_callback_abi':True,'ui_control_discovery':42,'night_mode_settings_through_real_callback':True,'four_sticker_slots_roundtrip':True,'none_and_invalid_inputs_checked':True,'rebind_after_callback_reset':True,'no_duplicate_callback':True,'retired_controls_disabled':True,'game_tested':False}
