"""Per-weapon HC callbacks and visible preview using a cloned native renderer."""
def check_override_preview(ns):
 globals().update(ns)
 handlers={'towlower':lambda u,s:(ord(chr(word(u,s+4)).lower()),4),'GetForegroundWindow':lambda u,s:(0x1234,4),'GetCurrentProcessId':lambda u,s:(50,4),'GetWindowThreadProcessId':lambda u,s:(store(u,word(u,s+8),50) or 51,12),'GetAsyncKeyState':lambda u,s:(0x8000,8),'GetEnvironmentVariableW':lambda u,s:(0,16),'EnumWindows':lambda u,s:(0,12)}
 def cursor(u,s):
  out=word(u,s+4);store(u,out,1000);store(u,out+4,500);return 1,8
 def client_cursor(u,s):
  out=word(u,s+8);store(u,out,word(u,out)-700);store(u,out+4,word(u,out+4)-200);return 1,12
 handlers['GetCursorPos']=cursor;handlers['ScreenToClient']=client_cursor
 u=fixture();pe,exp=load(u,'visuals_binding_probe.dll',handlers);u.mem_map(0x140000,0x1000)
 root,scope=MEM+0x10000,MEM+0x12000;store(u,root+0x848,75)
 setting=lambda hc,key,mode=1:1|(hc<<1)|(key<<8)|(mode<<16)
 call(u,exp('hc_setting_probe'),[0,0]);call(u,exp('hc_setting_probe'),[9,setting(90,5)])
 store(u,scope+0xd8,9);assert call(u,exp('hc_capture_probe'),[root,scope])==90
 store(u,scope+0xd8,40);assert call(u,exp('hc_capture_probe'),[root,scope])==75
 call(u,exp('hc_setting_probe'),[40,setting(35,6)]);assert call(u,exp('hc_capture_probe'),[root,scope])==35
 call(u,exp('hc_setting_probe'),[40,0]);assert call(u,exp('hc_capture_probe'),[root,scope])==75
 at=MEM+0x13000;call(u,exp('rage_cursor_probe'),[at]);assert (word(u,at),word(u,at+4))==(300,300)
 # Native config array profile is exact ID, checked against linked-list metadata.
 node,next,prev=MEM+0x14000,MEM+0x15000,MEM+0x16000;store(u,node,next);store(u,node+4,prev);store(u,next+4,node);store(u,prev,node);u.mem_write(node+12,struct.pack('<HH',260,6))
 for i in range(65):store(u,node+16+4*i,75)
 for id in [0,9,40,64]:assert call(u,exp('hc_array_profile_probe'),[node+16+4*id])==id
 store(u,node+16,101);assert call(u,exp('hc_array_profile_probe'),[node+16+4*9])==0xffffffff
 for text,id in [('SSG 08',40),('SSG08',40),('M4A1-S',60),('Global',0)]:
  at=MEM+0x17000;u.mem_write(at,(text+'\0').encode('utf-16le'));assert call(u,exp('hc_weapon_name_probe'),[at])==id
 # A copied vtable with Text intercepted by Lua is still a valid renderer.
 r,vt,data=MEM+0x18000,MEM+0x19000,MEM+0x1a000
 u.mem_write(vt,bytes(u.mem_read(0x43472a80,44*4)));store(u,vt+4*4,0x140800);store(u,vt+8*4,0x140820);store(u,vt+7*4,0x140840);store(u,vt+15*4,0x140880)
 store(u,r,vt);store(u,r+4,0x4346f46c);store(u,r+8,data);store(u,data+0xf4,1920);store(u,data+0xf0,1080);floats(u,r+0x7c,.2,1)
 assert call(u,exp('renderer_supported_probe'),[r])==1;assert call(u,exp('renderer_install_probe'),[r])==1
 # A Lua layer installed later can chain the saved hook. Reinstall must leave
 # that table alone rather than replacing the original delegate with itself.
 installed=word(u,r);foreign=MEM+0x1b000;u.mem_write(foreign,bytes(u.mem_read(installed,44*4)));saved_text=word(u,installed+15*4)
 u.mem_write(0x140900,b'\xb8'+struct.pack('<I',saved_text)+b'\xff\xe0');store(u,foreign+15*4,0x140900);store(u,r,foreign)
 assert call(u,exp('renderer_install_probe'),[r])==1 and word(u,r)==foreign

 ctx,menu,children,controls,tabs,visuals,misc,origin=[MEM+0x20000+i*0x1000 for i in range(8)]
 store(u,ctx,1);store(u,ctx+0x10,menu);store(u,menu+0xc,12);store(u,menu+0x10,13);store(u,menu+0x14,1312);store(u,menu+0x18,640);store(u,menu+0x34,1);store(u,menu+0x64,3);store(u,menu+0x54,tabs);store(u,menu+0x58,tabs+36)
 for i in range(9):store(u,tabs+4*i,MEM+0x30000+0x100*i)
 store(u,tabs+12,visuals);store(u,tabs+16,misc);lua=word(u,tabs+32);store(u,lua+0x70,MEM+0x32000);store(u,lua+0x74,MEM+0x32008);store(u,MEM+0x32004,1)
 store(u,visuals+0x70,children);store(u,visuals+0x74,children+48);floats(u,0x4346d490,1)
 for i in range(12):store(u,children+i*4,MEM+0x40000+i*0x200)
 for i in range(6):store(u,controls+i*4,MEM+0x44000+i*0x100)
 # Simulate the *actual* D3D scissor state, initially confined to Category.
 # A command outside Category is visible only after disabling scissor.
 store(u,r+0x69,1);u.mem_write(r+0x6c,struct.pack('<4i',112,38,1047,96))
 draws=[];texts=[];callbacks=[]
 def clipped(x,y):return bool(bytes(u.mem_read(r+0x69,1))[0]) and not (112<=x<1047 and 38<=y<96)
 def mock(u,a,size,user):
  if a not in [0x140700,0x140720,0x140800,0x140820,0x140840,0x140880,0x140a00,0x140a20,0x433ab0fa]:return
  sp=u.reg_read(UC_X86_REG_ESP);cleanup=4
  if a==0x140700:pass
  elif a in [0x140a00,0x140a20]:callbacks.append((a,u.reg_read(UC_X86_REG_ECX)))
  elif a==0x140720:cleanup=12
  elif a==0x140800:
   values=[word(u,sp+4*i) for i in range(1,6)]
   if not clipped(values[0],values[1]):draws.append(values)
   cleanup=24
  elif a==0x140820:cleanup=24
  elif a==0x140840:cleanup=28
  elif a==0x140880:
   if not clipped(word(u,sp+4),word(u,sp+8)):texts.append(wide(u,word(u,sp+20)))
   cleanup=28
  elif a==0x433ab0fa:u.reg_write(UC_X86_REG_EAX,0);cleanup=8
  u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+cleanup)
 u.hook_add(UC_HOOK_CODE,mock)
 call(u,exp('category_setup_probe'),[ctx,children,controls,0x140700]);call(u,exp('preview_surface_setup_probe'),[0x140720]);category=word(u,children+44);store(u,origin,12);store(u,origin+4,13)
 call(u,exp('preview_surface_draw_probe'),[r,origin],category,limit=12000000)
 assert call(u,exp('preview_surface_state_probe'))==1 and 'Enemy ESP preview' in texts
 assert any(12<=x<1324 and 13<=y<653 and 150<=w<=300 and h>=400 for x,y,w,h,c in draws)
 # Geometry is prepared before native drawing, then input is consumed once
 # inside Category. A click must survive that complete two-stage path.
 pos=(1290&65535)|(50<<16)
 assert call(u,exp('input_probe'),[0x201,0,pos])==1
 call(u,exp('preview_prepare_geometry_probe'),[r]);call(u,exp('preview_surface_draw_probe'),[r,origin],category,limit=12000000)
 assert call(u,exp('preview_settings_open_probe'))==1
 call(u,exp('input_probe'),[0x202,0,pos]);call(u,exp('preview_prepare_geometry_probe'),[r]);call(u,exp('preview_surface_draw_probe'),[r,origin],category,limit=12000000)
 assert call(u,exp('input_probe'),[0x100,27,0])==1
 call(u,exp('preview_prepare_geometry_probe'),[r]);call(u,exp('preview_surface_draw_probe'),[r,origin],category,limit=12000000)
 assert call(u,exp('preview_settings_open_probe'))==0

 # Relocation hides presentation proxies only; the original ESP model and
 # callbacks remain authoritative for config files and the in-game renderer.
 source,proxy,svt,value,nm=MEM+0x50000,MEM+0x51000,MEM+0x52000,MEM+0x53000,MEM+0x54000
 for i in range(13):store(u,svt+4*i,0x140700)
 store(u,svt+20,0x140a00);store(u,svt+28,0x140a20)
 for obj in [source,proxy]:store(u,obj,svt);u.mem_write(obj+0x14,bytes([1,1,0,1,0,3]));store(u,obj+0x5c,value)
 u.mem_write(value,b'\1')
 moved=['Bounding box','Name','Health bar','Ammo','Skeleton','Weapon icon','Weapon text','Distance','Flags','Money']
 for title in moved+['Dormant','Off-screen arrow','Visualize aimbot']:
  u.mem_write(nm,(title+'\0').encode('utf-16le'))
  assert bool(call(u,exp('preview_managed_probe'),[nm]))==(title in moved)
  u.mem_write(proxy+0x15,b'\1')
  call(u,exp('preview_binding_setup_probe'),[source,proxy,nm,nm]);call(u,exp('preview_sync_probe'))
  assert bool(bytes(u.mem_read(proxy+0x15,1))[0])==(title not in moved)
  assert bytes(u.mem_read(source+0x15,1))==b'\1' and bytes(u.mem_read(value,1))==b'\1'
 # The hidden color companion is edited through its original four-byte RGBA
 # model; exactly the native config and value callbacks fire once each.
 u.mem_write(nm,('Bounding box\0').encode('utf-16le'))
 u.mem_write(source+0x19,b'\x0c');u.mem_write(proxy+0x19,b'\x0c');store(u,value,0xff112233)
 call(u,exp('preview_binding_setup_probe'),[source,proxy,nm,nm]);callbacks.clear()
 assert call(u,exp('preview_color_probe'),[nm,0x88776655])==1
 assert word(u,value)==0x88776655 and callbacks==[(0x140a00,source),(0x140a20,source)]
 assert bytes(u.mem_read(source+0x15,1))==b'\1' and bytes(u.mem_read(proxy+0x15,1))==b'\0'
 u.mem_write(source+0x14,b'\0');assert call(u,exp('preview_color_probe'),[nm,0])==0 and word(u,value)==0x88776655

 return {'esp_element_rows_moved_to_preview_only':len(moved),'unrelated_esp_controls_retained':3,'original_esp_models_remain_visible_and_unchanged':True,'preview_rgba_forwards_original_callbacks_once':True,'noneditable_rgba_unchanged':True,'rage_windowed_cursor_without_preview_open':True,'per_weapon_capture_cases':4,'native_profile_mapping_cases':8,'cloned_renderer_supported_and_chained':True,'later_lua_hook_not_rewrapped':True,'preview_title_drawn_with_live_child_renderer':True,'preview_inside_menu':True,'preview_visible_outside_native_category_scissor':True,'preview_click_survives_geometry_then_draw':True,'preview_escape_closes_settings':True,'game_tested':False}
