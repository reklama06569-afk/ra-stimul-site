#include "../source/skeet/menu_interaction_design.h"
#include <cassert>
#include <iostream>
int main(){
 using namespace menu_interaction;using namespace cs2_visuals;
 assert(Helper==4&&Danger==5&&helper_control(L"Aim at location")&&helper_control(L"Aim at locations"));
 assert(!helper_control(L"Other helper switch"));
 Transition t;t.observe(0,-1,0);assert(t.cover(0)==0);t.observe(3,0,100);assert(t.cover(100)==1&&t.cover(175)>.49f&&t.cover(250)==0);t.observe(3,1,0xfffffff0);assert(t.cover(59)>.49f&&t.cover(134)==0);
 unsigned cases=0;
 for(int width:{400,480,660,1312})for(float dpi:{.5f,1.f,1.5f,2.f,3.f}){auto p=preview({10,20,width,560},1920,1080,dpi);auto l=layout(width,560,dpi,31,p.reserved);assert(p.area.x>=10&&p.area.x+p.area.w<=10+width);assert(l.panels[EnemyESP].w>0&&l.panels[EnemyModels].w>0);cases++;}

 for(int side=0;side<4;side++)for(float along:{0.f,.15f,.5f,1.f})for(float dpi:{.5f,1.f,1.5f,2.f,3.f}){
  Placement original{Side(side),along,true};auto p=Placement::unpack(original.pack());assert(p.side==original.side&&p.custom&&std::fabs(p.along-along)<.00002f);
  Rect b{100,150,100,250};const auto r=placed(b,30,12,p,0,dpi);assert(r.w==30&&r.h==12);
  if(side==Right)assert(r.x>b.x+b.w);if(side==Left)assert(r.x+r.w<b.x);if(side==Top)assert(r.y+r.h<b.y);if(side==Bottom)assert(r.y>b.y+b.h);cases++;
 }
 Rect box{100,100,100,200};assert(dropped(box,205,150).side==Right);assert(dropped(box,95,150).side==Left);assert(dropped(box,150,90).side==Top);assert(dropped(box,150,310).side==Bottom);
 for(int i=0;i<flag_count;i++)assert(flag(samples[i])==i);assert(flag(L"Remove fog")==-1&&flag(L"SCOPE OVERLAY")==-1);
 Candidate actors[]={{{100,100,100,200},true},{{300,100,100,200},false}};assert(owner(actors,2,205,120)==0);assert(owner(actors,2,405,120)==-1);assert(owner(actors,2,205,500)==-1);
 actors[1]={{101,100,100,200},true};assert(owner(actors,2,205,120)==-1);
 for(auto [sw,sh]:{std::pair{1920,1080},std::pair{1280,720},std::pair{800,600}})for(float dpi:{1.f,1.5f,2.f})for(int mx:{0,100,500}){
  auto p=preview({mx,30,660,560},sw,sh,dpi);assert(p.area.w>0&&p.area.h>0&&p.model.w>0&&p.model.h>0);if(p.reserved){auto l=layout(660,560,dpi,31,p.reserved);assert(l.panels[EnemyModels].x+l.panels[EnemyModels].w<=660-p.reserved);}
  cases++;
 }
 assert(detail(L"Quick stop options")==1&&detail(L"Maximum peek distance")==2&&detail(L"Double tap hit chance")==3);assert(detail(L"Minimum damage")==-1);
 std::cout<<cases<<" placement/dpi/preview cases, transition wrap, routing and ambiguous-owner checks passed\n";
}
