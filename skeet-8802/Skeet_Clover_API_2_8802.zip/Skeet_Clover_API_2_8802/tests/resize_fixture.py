"""Original Child resize/DPI dispatch through tables installed by production code."""
def check_resize(ns):
    globals().update(ns)
    cases=0
    for kind,dpi in itertools.product([0,1],[.75,1.,1.25,1.5,2.,3.]):
        u=fixture();pe,exp=load(u,'visuals_binding_probe.dll');API=0x140000;u.mem_map(API,0x1000)
        ctx,menu,tabs,tab,vec,elem_vec,elem,evt=[MEM+0x10000+i*0x1000 for i in range(8)]
        store(u,ctx+0x10,menu);store(u,menu+0x14,int(800*dpi));store(u,menu+0x18,int(700*dpi))
        store(u,menu+0x54,tabs);store(u,menu+0x58,tabs+36);store(u,tabs+5*4,tab)
        store(u,tab+0x70,vec);store(u,tab+0x74,vec);store(u,tab+0x78,vec+128)
        floats(u,0x4346d490,dpi);floats(u,0x4346eeb0,10);floats(u,0x434724a8,5)
        floats(u,0x43472788,0)
        allocated=[];events=[]
        def mock(u,a,size,user):
            if a not in [API+0x100,API+0x120,API+0x140,API+0x200,API+0x220,API+0x240,API+0x260]:return
            sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp);this=u.reg_read(UC_X86_REG_ECX);cleanup=4;result=0
            if a==API+0x100:
                assert this==0xc8;result=MEM+0x30000+len(allocated)*0x1000;allocated.append(result)
            elif a==API+0x120:
                assert word(u,sp+4)==tab;store(u,this,0x4347072c);store(u,this+0x10,tab);u.mem_write(this+0x19,b'\7')
                for off,v in [(0x28,250),(0x2c,600),(0x30,250),(0x34,600)]:store(u,this+off,v)
                cleanup=24
            elif a==API+0x140:
                assert this==tab;end=word(u,tab+0x74);store(u,end,word(u,sp+4));store(u,tab+0x74,end+4);cleanup=8
            else:assert this==elem;events.append(a)
            u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,ret)
        u.hook_add(UC_HOOK_CODE,mock)
        child=call(u,exp('resize_create_probe'),[ctx,tab,API+0x100,API+0x120,API+0x140,kind]);assert child
        vt=word(u,child)
        original=[word(u,0x4347072c+4*i) for i in range(13)]
        copied=[word(u,vt+4*i) for i in range(13)]
        for i in range(13):
            assert copied[i] and (copied[i]==original[i] if i not in [4,8,9,10] else copied[i]!=original[i]),(kind,i,hex(copied[i]))
        store(u,child+0x80,elem_vec);store(u,child+0x84,elem_vec+4);store(u,child+0x88,elem_vec+4);store(u,elem_vec,elem)
        store(u,elem,evt);u.mem_write(elem+0x15,b'\0')
        for i,a in [(6,API+0x260),(9,API+0x200),(10,API+0x220),(11,API+0x240)]:store(u,evt+4*i,a)
        for width,height in [(800,700),(1200,900),(700,600),(800,700)]:
            store(u,menu+0x14,int(width*dpi));store(u,menu+0x18,int(height*dpi));events.clear()
            saved={UC_X86_REG_EBX:0x12345678,UC_X86_REG_ESI:0x23456789,UC_X86_REG_EDI:0x34567890,UC_X86_REG_EBP:0x45678901}
            for slot,event in [(9,API+0x200),(10,API+0x220)]:
                for r,v in saved.items():u.reg_write(r,v)
                call(u,word(u,vt+slot*4),ecx=child)
                assert event in events and u.reg_read(UC_X86_REG_ESP)==SP+4
                for r,v in saved.items():assert u.reg_read(r)==v
                # The old bridge stored pixels in DefSize and scaled them again.
                width_now,height_now=[word(u,child+off) for off in [0x28,0x2c]]
                base_w,base_h=[word(u,child+off) for off in [0x30,0x34]]
                assert abs(width_now-base_w*dpi)<=2 and abs(height_now-base_h*dpi)<=2,(kind,dpi,width_now,height_now,base_w,base_h)
                assert bytes(u.mem_read(child+0xb0,2))==b'\0\0'
                cases+=1
        # Reuse the same live native child across a DPI change and restoration.
        original_size=tuple(word(u,child+off) for off in [0x20,0x24,0x28,0x2c])
        for changed in [.75,3.,1.,dpi]:
            floats(u,0x4346d490,changed);store(u,menu+0x14,int(800*changed));store(u,menu+0x18,int(700*changed))
            call(u,word(u,vt+10*4),ecx=child)
            current=[word(u,child+off) for off in [0x28,0x2c]];base=[word(u,child+off) for off in [0x30,0x34]]
            assert all(abs(a-b*changed)<=2 for a,b in zip(current,base))
            cases+=1
        assert tuple(word(u,child+off) for off in [0x20,0x24,0x28,0x2c])==original_size
    return cases
