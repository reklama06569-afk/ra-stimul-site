"""Execute original x86 popup mouse selection and model callback; no game process."""
from record_fixture import *
u=fixture();key,popup,info,variants,msg,point=[MEM+0x10000+i*0x1000 for i in range(6)]
store(u,popup,0x4346fab0);store(u,popup+0x10,key);store(u,key+0x5c,info)
store(u,key+0x20,400);store(u,key+0x24,200)
store(u,popup+0x20,0);store(u,popup+0x24,12);store(u,popup+0x28,120);store(u,popup+0x2c,80)
store(u,popup+0x60,20);store(u,popup+0x70,0x4331ffe8)
store(u,popup+0x74,variants);store(u,popup+0x78,variants+32)
# Native handlers use coordinates relative to their child; all four native modes.
for mode in range(4):
 u.mem_write(popup+0x64,b'\1\0');store(u,point,410);store(u,point+4,212+mode*20+10)
 for message in [0x201,0x202]:
  store(u,msg+4,message)
  for i,v in enumerate([STOP,msg,point]):store(u,SP+i*4,v)
  u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,popup)
  run_until(u,0x433afc02,STOP,10000)
 assert word(u,info+0x14)==mode
 assert word(u,popup+0x6c)==mode
 assert bytes(u.mem_read(popup+0x64,1))==b'\0'
print('PASS: native mouse down/up selects all four modes and writes shared hotkey model.')
