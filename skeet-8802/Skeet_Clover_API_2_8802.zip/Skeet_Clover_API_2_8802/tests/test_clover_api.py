from lupa.luajit21 import LuaRuntime
from pathlib import Path
r=Path(__file__).resolve().parents[1];l=LuaRuntime(unpack_returned_tuples=True)
l.execute('''local v=false; local cb;ui={reference=function(t,s,n) if n=='missing' then error('unknown') end return 'ref','key' end,get=function(ref) return v end,set=function(ref,value) v=value end,set_visible=function() end,set_callback=function(ref,f) cb=f end};client={set_event_callback=function(name,f) cb=f end};renderer={text=function() end};entity={};globals={};database={}''')
api=l.execute((r/'source/lua/clover_api.lua').read_text());l.globals().api=api
l.execute('''assert(api.available('renderer','text'));assert(not api.available('client','unset_event_callback'));local a,b=api.settings.reference('RAGE','Aimbot','Enabled');assert(a=='ref' and b=='key');assert(api.settings.get(a)==false);assert(api.settings.set(a,true)==true and api.settings.get(a)==true);local x,e=api.settings.reference('RAGE','Aimbot','missing');assert(x==nil and e:find('unknown'));local x,e=api.events.off('paint',function() end);assert(x==nil and e:find('unavailable'));assert(api.events.on('paint',function() end)==true);assert(api.settings.on_change(a,function() end)==true)''')
print('PASS: multi-reference, false values, writes, callbacks and missing/error APIs')
