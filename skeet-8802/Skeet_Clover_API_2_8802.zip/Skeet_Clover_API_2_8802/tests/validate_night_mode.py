"""Exercise bounded Night mode state on fake materials, without engine execution."""
from pathlib import Path
import subprocess,json,hashlib
ROOT=Path(__file__).resolve().parents[1];BUILD=ROOT/'build'
subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/night_mode_plan.cpp'),'-o',str(BUILD/'night_mode_plan')],check=True)
subprocess.run([str(BUILD/'night_mode_plan')],check=True)
report={'passed':True,'material_fixture_count':200,'max_material_operations_per_frame':64,'only_world_and_static_props_modified':True,'intensity_zero_preserves_original':True,'palette_update_bounded':True,'rescan_deduplicates_materials':True,'retained_references_balanced':True,'map_reset_restores_then_recaptures':True,'disable_restores_owned_modulation':True,'later_external_modulation_preserved_on_disable':True,'source_sha256':hashlib.sha256((ROOT/'source/skeet/night_mode.h').read_bytes()).hexdigest(),'game_tested':False}
(BUILD/'night_mode_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
