#!/usr/bin/env python3
"""Execute production callbacks, native pose blending, selector and apply prefix.

Closed x86 fixtures only. TLS, memcpy and engine hull tracing are controlled
substitutes. No DLL entry point, protected startup or game process is run.
"""
from pathlib import Path
import os,sys,struct,json,subprocess,math,hashlib,itertools
import pefile
from unicorn import UC_HOOK_CODE
from unicorn.x86_const import *
from record_fixture import *
BUILD=ROOT/'build';BUILD.mkdir(exist_ok=True)
env=os.environ.copy();env.setdefault('ZIG_GLOBAL_CACHE_DIR','/workspace/skeet-motion-bt-8802/.cache/global');env['ZIG_LOCAL_CACHE_DIR']=str(ROOT/'.cache/local')
subprocess.run([sys.executable,'-m','ziglang','c++','-target','x86-windows-gnu','-std=c++17','-O2','-shared',
    str(ROOT/'tests/motion_probe.cpp'),'-o',str(BUILD/'motion_probe.dll')],env=env,check=True)
subprocess.run(['g++','-std=c++17','-O2',str(ROOT/'tests/motion_plan.cpp'),'-o',str(BUILD/'motion_plan')],check=True)
PE=pefile.PE(str(BUILD/'motion_probe.dll'));PB=PE.OPTIONAL_HEADER.ImageBase
EXPORTS={s.name.decode():PB+s.address for s in PE.DIRECTORY_ENTRY_EXPORT.symbols if s.name}
def export(name):return next(v for k,v in EXPORTS.items() if name==k or name in k)
SCRATCH=export('probe_scratch');SWEEP=STOP+0x500
plans={}
def plan_for(location):
    if location not in plans:
        path=BUILD/f'motion_plan_{location:x}.bin'
        subprocess.run([str(BUILD/'motion_plan'),str(ROOT/'source/skeet/Binary/skeet_cv.bin'),str(path),
            hex(location),hex(export('begin_probe')),hex(export('apply_probe')),hex(export('getter_probe'))],check=True)
        plans[location]=path.read_bytes()
    return plans[location]
def call(u,entry,args=(),ecx=0,edx=0,limit=200000):
    for i,v in enumerate([STOP,*args]):store(u,SP+i*4,v)
    u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,ecx);u.reg_write(UC_X86_REG_EDX,edx&0xffffffff)
    run_until(u,entry,STOP,limit)
    return u.reg_read(UC_X86_REG_EAX)
def full_record(u,record,t,x,y=0,z=0,flags=4,yaw=0):
    store(u,record+0x4c,t);store(u,record+0x5c,flags);floats(u,record+0x28,yaw);floats(u,record+0x30,x,y,z)
    for s in range(4):
        floats(u,record+0x220+s*0x3a0,yaw,11,22,33)
        for b in range(19):
            co,si=math.cos(math.radians(yaw)),math.sin(math.radians(yaw))
            floats(u,record+0x230+s*0x3a0+b*48,co,-si,0,x+b*.1*co,si,co,0,y+b*.1*si,0,0,1,z+b)
            floats(u,record+0x230+s*0x3a0+b*48+44,z+b)
class Case:
    def __init__(self,location=0x50000000,records=((100,100,0,0),(94,94,0,0)),now=102,dt=1/64,flags=4):
        self.u=u=fixture();self.location=location;self.sweeps=[];self.wall=None;self.solid=False
        u.mem_map(PB,PE.OPTIONAL_HEADER.SizeOfImage);u.mem_write(PB,PE.get_memory_mapped_image())
        u.mem_map(location,8192);plan=plan_for(location);u.mem_write(location,plan[:8192]);offset=8192
        for i in range(4):
            site,length=struct.unpack_from('<II',plan,offset);offset+=8
            u.mem_write(BASE+site,plan[offset:offset+length]);offset+=length
        assert offset==len(plan)
        self.imports={}
        for lib in PE.DIRECTORY_ENTRY_IMPORT:
            for item in lib.imports:
                target=STOP+0x600+len(self.imports)*0x10
                self.imports[target]=item.name.decode() if item.name else str(item.ordinal)
                store(u,item.address,target)
        assert max(self.imports)<STOP+0x1000
        def hook(u,a,size,user):
            if a!=SWEEP and a not in self.imports:return
            sp=u.reg_read(UC_X86_REG_ESP);ret=word(u,sp);cleanup=4;result=0
            if a==SWEEP:
                actor=word(u,sp+4);assert actor==ACTOR
                start=struct.unpack('<fff',u.mem_read(sp+8,12));end=struct.unpack('<fff',u.mem_read(sp+20,12))
                self.sweeps.append((start,end))
                result=int(not self.solid and (self.wall is None or end[0]<self.wall))
            else:
                name=self.imports[a]
                if name=='TlsGetValue':assert word(u,sp+4)==7;result=SCRATCH;cleanup=8
                elif name in ['memcpy','memmove']:
                    dst,src,n=[word(u,sp+i) for i in [4,8,12]]
                    u.mem_write(dst,bytes(u.mem_read(src,n)));result=dst
                elif name=='memset':
                    dst,value,n=[word(u,sp+i) for i in [4,8,12]]
                    u.mem_write(dst,bytes([value&255])*n);result=dst
                else:raise AssertionError(('unexpected import',name,hex(a)))
            u.reg_write(UC_X86_REG_EAX,result);u.reg_write(UC_X86_REG_ESP,sp+cleanup);u.reg_write(UC_X86_REG_EIP,ret)
        u.hook_add(UC_HOOK_CODE,hook)
        for i,(t,x,y,z) in enumerate(records):
            p=NEW+i*0x2000;store(u,HISTORY+0x5dc+i*4,p);full_record(u,p,t,x,y,z,flags)
        store(u,HISTORY+0x5d8,len(records));store(u,HISTORY+0x5d4,0)
        floats(u,HISTORY+0x13c,*records[0][1:]);floats(u,0x200000+0x2000,dt);floats(u,0x200000+0x2004,now*dt)
        floats(u,CONTEXT+0x198,0);floats(u,0x43476928,0);store(u,0x43468230,200)
        call(u,export('initialize_probe'),[location+0x800,SWEEP]);self.options()
    def options(self,consistent=1,interpolation=1,gap=8,extrapolation=1,horizon=2):
        call(self.u,export('options_probe'),[consistent,interpolation,gap,extrapolation,horizon])
    def begin(self,low=94,high=100,first=True):
        args=MEM+0x6000
        for i,v in enumerate([0x4332ff6b if first else 0x4332ff97,ACTOR,HISTORY,0,low,high,MEM+0x4200,MEM+0x4204]):store(self.u,args+i*4,v)
        call(self.u,export('configured_begin_probe'),[CONTEXT,args]);return word(self.u,args+16),word(self.u,args+20)
    def point(self,tick,bone=0):
        u=self.u
        result=call(u,export('getter_probe'),[bone,MEM+0x3000,MEM+0x3100],HISTORY,tick)
        return result,tuple(struct.unpack('<fff',u.mem_read(MEM+0x3000,12))),bytes(u.mem_read(MEM+0x3100,48))
    def applied(self,tick):
        u=self.u;seen=[]
        def stop_before_engine(u,address,size,user):
            if address==0x43345b83:seen.append(True);u.emu_stop()
        h=u.hook_add(UC_HOOK_CODE,stop_before_engine)
        for i,v in enumerate([STOP,CONTEXT,tick,0]):store(u,SP+i*4,v)
        u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,SCOPE)
        try:u.emu_start(0x43344c0c,STOP,count=200000)
        except Exception as e:raise RuntimeError(hex(u.reg_read(UC_X86_REG_EIP))) from e
        u.hook_del(h)
        if not seen:
            assert u.reg_read(UC_X86_REG_EIP)==STOP
            return None
        return bytes(u.mem_read(SCOPE+16,0x10a0))
    def dispatcher(self,low=94,high=100,bone=0,first=True):
        u=self.u;setup_selector_model(u)
        source,direction=MEM+0x4100,MEM+0x4000
        length=math.sqrt(98**2+10**2);floats(u,direction,98/length,-10/length,0);floats(u,source,0,10,0)
        best,score=MEM+0x4200,MEM+0x4204;store(u,best,-1);floats(u,score,-1)
        stop=0x4332ff6b if first else 0x4332ff97
        for i,v in enumerate([stop,ACTOR,HISTORY,bone,low,high,best,score]):store(u,SP+4*i,v)
        u.reg_write(UC_X86_REG_ESP,SP);u.reg_write(UC_X86_REG_ECX,source);u.reg_write(UC_X86_REG_EDX,direction)
        u.reg_write(UC_X86_REG_XMM0,fbits(10000));u.reg_write(UC_X86_REG_EBP,SP+0x1000);store(u,SP+0x1008,CONTEXT)
        run_until(u,self.location,stop,500000)
        assert u.reg_read(UC_X86_REG_ESP)==SP+32 and u.reg_read(UC_X86_REG_EBP)==SP+0x1000
        return word(u,best)

def equal_pose(c,t,bone=0):
    result,origin,mat=c.point(t,bone);assert result==t,(t,result)
    applied=c.applied(t);assert applied is not None,t
    assert struct.unpack_from('<I',applied,0x4c)[0]==t
    assert struct.unpack_from('<fff',applied,0x30)==origin
    assert applied[0x230+bone*48:0x230+(bone+1)*48]==mat
    return origin,applied

checks={'coherent_pose':0,'native_selector':0,'forecast':0,'rejections':0,'bounds':0,'toggle_snapshot':0}
for location in [0x50000000,0x60000000,0xf0000000]:
    for flags in [4,0x84]:
        for gap in [1,2,4,6,8,16]:
            c=Case(location,((100,100,0,0),(100-gap,100-gap,0,0)),flags=flags)
            c.options(gap=16);c.begin(100-gap,100)
            for t in sorted({100,100-gap,100-gap//2}):
                for bone in [0,3,18]:
                    origin,applied=equal_pose(c,t,bone)
                    assert abs(origin[0]-t)<1e-5
                    for s in range(4 if flags&0x80 else 1):
                        for b in range(19):
                            assert abs(struct.unpack_from('<f',applied,0x230+s*0x3a0+b*48+12)[0]-(t+b*.1))<2e-5
                    checks['coherent_pose']+=1
            assert c.dispatcher(100-gap,100) in range(100-gap,103);checks['native_selector']+=1
    # Reproduce the original 98-versus-94 problem through the actual dispatch.
    c=Case(location);chosen=c.dispatcher();assert chosen==98,chosen
    equal_pose(c,chosen);checks['native_selector']+=1
    # Two-tick prediction beyond the newest record is a real translated pose.
    c=Case(location,((100,100,0,0),(98,98,0,0),(96,96,0,0)))
    assert c.begin(94,100)==(94,102)
    for t in [101,102]:
        origin,_=equal_pose(c,t,18);assert origin==(float(t),0.,0.);checks['forecast']+=1
    assert c.point(103)[0]==0xffffffff;checks['rejections']+=1
    # Production selector stays inside history with extrapolation removed.
    c=Case(location,((100,96,0,0),(98,94,0,0),(96,92,0,0)))
    assert c.dispatcher(94,100)==100;equal_pose(c,100);assert c.point(102)[0]==0xffffffff;checks['native_selector']+=1

# Full native interpolation remains available without both alternate pose flags.
for fa,fb in [(4,0x84),(0x84,4)]:
    c=Case(flags=fa);store(c.u,OLD+0x5c,fb);c.begin();origin,p=equal_pose(c,98)
    assert not struct.unpack_from('<I',p,0x5c)[0]&0x80;checks['coherent_pose']+=1

# Internal policy boundaries, exact ticks, high latency and native windows.
rotation_checks=0
for newer_yaw,older_yaw,expected in [(30,-30,0),(90,0,45),(179,-179,180),(-90,0,-45)]:
    c=Case(flags=0x84)
    full_record(c.u,NEW,100,100,flags=0x84,yaw=newer_yaw)
    full_record(c.u,OLD,94,94,flags=0x84,yaw=older_yaw)
    c.begin();origin,p=equal_pose(c,97,3)
    yaw=struct.unpack_from('<f',p,0x28)[0]
    assert abs((yaw-expected+180)%360-180)<1e-3,(newer_yaw,older_yaw,yaw)
    assert origin==(97.,0.,0.)
    for s in range(4):
        matrix_=struct.unpack_from('<12f',p,0x230+s*0x3a0+3*48)
        assert abs(matrix_[0]-math.cos(math.radians(expected)))<1e-3
        assert abs(matrix_[4]-math.sin(math.radians(expected)))<1e-3
    rotation_checks+=1
for dt in [1/64,1/128]:
    for low in [0,50,80,90,99,100]:
        c=Case(now=100,dt=dt);lo,hi=c.begin(low,100)
        assert lo==low and hi==100,(dt,low,lo,hi);checks['bounds']+=1
    for correction in [0,.1,.15,.2,.3, float('nan')]:
        c=Case(now=104,dt=dt);floats(c.u,0x43476928,correction)
        low,high=c.begin(94,100)
        if not math.isfinite(correction) or correction>=.3:assert high==100
        assert high<=104;checks['bounds']+=1
# The removed 200 ms depth cap must no longer suppress an otherwise native
# candidate 16 ticks old at 64 tick. The caller still owns the lower window.
c=Case(records=((100,100,0,0),(84,84,0,0)),now=100)
assert c.begin(50,100)==(50,100)
equal_pose(c,84);checks['bounds']+=1
for gap in [0,1,5,6,16]:
    c=Case();c.options(gap=gap);c.begin()
    assert (c.point(98)[0]==98)==(gap>=6);equal_pose(c,100);checks['bounds']+=1
for head in [1,17,31,0xffffffff]:
    c=Case();u=c.u;u.mem_write(HISTORY+0x5dc,bytes(128));store(u,HISTORY+0x5d4,head)
    for i,p in enumerate([NEW,OLD]):store(u,HISTORY+0x5dc+((head+i)&31)*4,p)
    c.begin();equal_pose(c,98);checks['coherent_pose']+=1
c=Case(records=tuple((100-i*2,100-i*2,0,0) for i in range(32)))
c.begin();equal_pose(c,99);checks['coherent_pose']+=1

# Unknown headers remain byte-for-byte intact when forecasting; only proven
# root position, timestamp and all valid world-matrix translations are changed.
c=Case(records=((100,100,0,0),(98,98,0,0),(96,96,0,0)),flags=0x84);c.begin()
origin,p=equal_pose(c,102)
for s in range(4):
    assert p[0x220+s*0x3a0:0x230+s*0x3a0]==bytes(c.u.mem_read(NEW+0x220+s*0x3a0,16))
    for b in range(19):assert abs(struct.unpack_from('<f',p,0x230+s*0x3a0+b*48+12)[0]-(102+b*.1))<1e-5
checks['forecast']+=1

mutations=[
    ('wall',lambda c:setattr(c,'wall',101.5),102),
    ('start solid',lambda c:setattr(c,'solid',True),101),
    ('history discontinuity',lambda c:floats(c.u,OLD+0x30,0,0,0),102),
    ('boundary marker',lambda c:store(c.u,NEW+0x5c,0x204),101),
    ('missing bones',lambda c:store(c.u,NEW+0x5c,0),101),
    ('nonfinite',lambda c:floats(c.u,NEW+0x30,float('nan'),0,0),101),
    ('current discontinuity',lambda c:floats(c.u,HISTORY+0x13c,200,0,0),100),
    ('reversed direction',lambda c:floats(c.u,NEW+0x4000+0x30,102,0,0),101),
    ('stale sample gap',lambda c:store(c.u,OLD+0x4c,70),101),
]
for label,mutation,t in mutations:
    c=Case(records=((100,100,0,0),(98,98,0,0),(96,96,0,0)))
    mutation(c);c.begin();assert c.point(t)[0]==0xffffffff,label;checks['rejections']+=1
# Hitting a wall at tick 2 preserves a clear shorter forecast at tick 1.
c=Case(records=((100,100,0,0),(98,98,0,0),(96,96,0,0)));c.wall=101.5;c.begin()
assert c.point(102)[0]==0xffffffff;equal_pose(c,101);checks['forecast']+=1
# A turn invalidates even a one-tick forecast.
c=Case(records=((100,100,0,0),(98,98,0,0),(96,96,-2,0)));c.begin()
assert c.point(102)[0]==0xffffffff and c.point(101)[0]==0xffffffff;checks['rejections']+=1
# A captured UI change takes effect at the next HC invocation, not half a shot.
c=Case();c.begin();equal_pose(c,98)
c.options(consistent=1,interpolation=0,gap=0,extrapolation=0,horizon=0)
c.begin(first=False);equal_pose(c,98)
c.begin();assert c.point(98)[0]==0xffffffff;equal_pose(c,100);checks['toggle_snapshot']+=1
assert call(c.u,export('production_extrapolation_probe'))==0
# Test-only policy cannot turn off the actual production dispatcher.
c=Case();c.options(consistent=0,interpolation=0,extrapolation=0)
assert c.dispatcher()==98
equal_pose(c,98);checks['toggle_snapshot']+=1
# Production x86 switch addresses are immutable PE data, all fixed at one.
for n in range(3):
    address=call(c.u,export('fixed_flag_probe'),[n]);assert word(c.u,address)==1
    section=PE.get_section_by_rva(address-PB);assert section and not section.Characteristics&0x80000000

# The real EngineTrace adapter receives the expected swept standing hull,
# mask and two-slot filter ABI. Only the engine TraceRay implementation is mocked.
trace_checks=0
for fraction,all_solid,start_solid,expected in [(1.,0,0,1),(.5,0,0,0),(1.,1,0,0),(1.,0,1,0),(float('nan'),0,0,0),(2.,0,0,0)]:
    c=Case();u=c.u;engine=MEM+0x15000;vtable=MEM+0x15100;trace_call=STOP+0x400
    store(u,engine,vtable);store(u,vtable+20,trace_call);call(u,export('trace_engine_probe'),[engine])
    seen=[]
    def trace_mock(u,address,size,user):
        if address!=trace_call:return
        sp=u.reg_read(UC_X86_REG_ESP);assert u.reg_read(UC_X86_REG_ECX)==engine
        ray,mask,filter_,trace=[word(u,sp+i) for i in [4,8,12,16]]
        assert mask==0x200400b
        assert struct.unpack('<4f',u.mem_read(ray,16))==(100.,10.,36.,0.)
        assert struct.unpack('<4f',u.mem_read(ray+16,16))==(2.,1.,-1.,0.)
        assert struct.unpack('<4f',u.mem_read(ray+32,16))==(0.,0.,-36.,0.)
        assert struct.unpack('<4f',u.mem_read(ray+48,16))==(16.,16.,36.,0.)
        assert word(u,ray+64)==0 and bytes(u.mem_read(ray+68,2))==b'\0\1'
        assert word(u,filter_+4)==ACTOR
        floats(u,trace+44,fraction);u.mem_write(trace+54,bytes([all_solid,start_solid]));seen.append(filter_)
        u.reg_write(UC_X86_REG_ESP,sp+20);u.reg_write(UC_X86_REG_EIP,word(u,sp))
    h=u.hook_add(UC_HOOK_CODE,trace_mock)
    assert call(u,export('trace_probe'),[ACTOR,*map(fbits,[100,10,0,102,11,-1])])==expected
    u.hook_del(h);assert len(seen)==1
    # Copy while still intact: its lifetime ended when sweep returned, and
    # subsequent calls are allowed to reuse that stack area.
    filter_=MEM+0x15200;u.mem_write(filter_,bytes(u.mem_read(seen[0],8)));vf=word(u,filter_)
    assert call(u,word(u,vf),[ACTOR,0],filter_)&255==0
    assert call(u,word(u,vf),[ACTOR+0x100,0],filter_)&255==1
    assert call(u,word(u,vf+4),[],filter_)==0
    trace_checks+=1

# Vertical acceleration is inferred from actual samples; no hardcoded change
# to an unproven velocity field or regeneration of enemy animations is used.
c=Case(records=((100,100,0,10),(98,98,0,11.609375),(96,96,0,12.4375)));c.begin()
origin,_=equal_pose(c,102);assert origin==(102.,0.,7.609375);checks['forecast']+=1
# Test the model limits independently of the fixed production policy.
for horizon in range(9):
    c=Case(records=((100,100,0,0),(92,92,0,0),(84,84,0,0),(76,76,0,0)),now=110)
    c.options(horizon=horizon);assert c.begin(94,100)[1]==100+horizon
    for t in range(101,110):assert (c.point(t)[0]==t)==(t<=100+horizon),(horizon,t)
    checks['bounds']+=1
# A second sample cannot establish movement confidence. Acceleration and stops
# also reject a forecast without disabling native exact-tick candidates.
for records in [((100,100,0,0),(98,98,0,0)),
                ((100,100,0,0),(98,98,0,0),(96,97.9,0,0)),
                ((100,100,0,0),(98,100,0,0),(96,98,0,0)),
                ((100,100,0,0),(98,98,0,0),(96,96,0,-20))]:
    c=Case(records=records);c.begin()
    assert c.point(101)[0]==0xffffffff and c.point(102)[0]==0xffffffff
    equal_pose(c,100);checks['rejections']+=1
# Invalid captures fail closed in the intercepted selector.
for count in [0,33,0xffffffff]:
    c=Case();store(c.u,HISTORY+0x5d8,count);c.begin();assert c.point(100)[0]==0xffffffff;checks['rejections']+=1
# A history update invalidates prepared data rather than applying an old cache.
c=Case();c.begin();equal_pose(c,98);store(c.u,NEW+0x4c,101)
assert c.point(98)[0]==0xffffffff and c.applied(98) is None;checks['rejections']+=1

report={'passed':True,'checks':checks,'native_blend_call_relocations':34,'native_bones_per_pose':19,
    'engine_trace_adapter_cases':trace_checks,
    'native_rotation_blend_cases':rotation_checks,
    'pose_sets':4,'production_policy':{'extrapolation_enabled':False,'extrapolation_ticks':0,'interpolation_gap_ticks':8,'new_menu_controls':0,'minimum_forecast_samples':3,'direction_cosine_squared_min':.94},
    'custom_backtrack_depth_removed':True,'native_lower_window_preserved':True,
    'mismatch_fixed':{'requested_tick':98,'native_applied_tick_before':94,'prepared_applied_tick_after':98},
    'core_sha256':hashlib.sha256(IMAGE).hexdigest(),
    'scope':__doc__,'game_tested':False,'real_network_ping_tested':False}
(BUILD/'motion_validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
