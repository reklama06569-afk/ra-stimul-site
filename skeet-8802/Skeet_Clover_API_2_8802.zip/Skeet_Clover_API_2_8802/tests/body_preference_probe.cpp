#include "../source/skeet/pch.h"
#include "../source/skeet/body_preference.h"
extern "C" __declspec(dllexport) void __fastcall body_bridge_probe(unsigned char* stack,const void* shooter) {
    body_preference::bridge(stack,shooter);
}
