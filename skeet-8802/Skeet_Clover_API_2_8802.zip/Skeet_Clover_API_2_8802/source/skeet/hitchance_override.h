#pragma once
#include <atomic>
#include <algorithm>
#include <cstdint>
#include <cstring>
namespace hitchance_override {
inline constexpr unsigned profiles=65;
struct Setting {
 bool enabled=false;unsigned chance=75,key=0,mode=1;
 unsigned pack()const{return unsigned(enabled)|(std::min(chance,100u)<<1)|((key<=255?key:0u)<<8)|((mode&3)<<16);}
 static Setting unpack(unsigned v){return {bool(v&1),std::min((v>>1)&127,100u),(v>>8)&255,(v>>16)&3};}
};
inline std::atomic<unsigned> settings[profiles]{},keys[profiles]{};
inline bool initialized=[](){for(auto& v:settings)v=Setting{}.pack();return true;}();
// One lock-free transition per key edge, shared by parallel HC workers. The
// token excludes the percentage so moving its slider does not flip Toggle.
inline bool active(std::atomic<unsigned>& state,unsigned config,bool down,bool focused){
 const auto s=Setting::unpack(config);const unsigned token=(config&0x3ff01u)<<2;
 unsigned before=state.load(std::memory_order_relaxed),after;
 do {const unsigned old=(before&~3u)==token?before:token;bool toggle=(old&2)!=0;if(s.mode==2&&down&&!(old&1))toggle=!toggle;after=token|unsigned(down)|(unsigned(toggle)<<1);}
 while(!state.compare_exchange_weak(before,after,std::memory_order_relaxed));
 if(!s.enabled||!focused)return false;if(s.mode==0)return true;if(!s.key)return false;
 return s.mode==1?down:s.mode==2?bool(after&2):!down;
}
inline unsigned effective_profile(unsigned weapon){if(weapon>0&&weapon<profiles&&(settings[weapon].load(std::memory_order_relaxed)&1))return weapon;return 0;}
#ifdef _WIN32
inline int __fastcall capture(const void* native,const void* scope){
 if(!native||!scope)return 0;
 int original=0;std::memcpy(&original,static_cast<const unsigned char*>(native)+0x848,4);
 unsigned weapon=0;std::memcpy(&weapon,static_cast<const unsigned char*>(scope)+0xd8,4);
 if(!weapon||weapon>=profiles)return original;
 const unsigned id=effective_profile(weapon),packed=settings[id].load(std::memory_order_relaxed);if(!(packed&1))return original;
 const auto s=Setting::unpack(packed);DWORD pid=0;const auto window=GetForegroundWindow();if(window)GetWindowThreadProcessId(window,&pid);const bool focused=pid==GetCurrentProcessId();
 const bool down=s.key&&focused&&(GetAsyncKeyState(int(s.key))&0x8000);
 return active(keys[id],packed,down,focused)?int(s.chance):original;
}
#endif
}
