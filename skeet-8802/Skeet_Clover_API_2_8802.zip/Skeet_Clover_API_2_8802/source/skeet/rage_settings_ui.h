#pragma once
// Included inside cs2_visuals. Native source controls/models/config handlers
// stay owned by the original menu; only fresh presentation views are created.
namespace rage_settings {
using menu_interaction::Rect;
struct Pane {Child* child=nullptr;void* vt[13]{};NativeChildDraw draw=nullptr;NativeLayout layout=nullptr,resize=nullptr,dpi=nullptr;int id=0;};
struct View {PElement source=nullptr,proxy=nullptr;Pane* pane=nullptr;unsigned char observed[8]{};};
struct Gear {Button* button=nullptr;void* vt[13]{};PElement anchor=nullptr;int id=-1;Rect last{};};
inline constexpr int group_count=7,pane_count=group_count+2;
inline Pane panes[pane_count]{};inline Gear gears[group_count]{},closers[group_count]{};inline View views[256]{};inline unsigned used=0;
inline Child* sources[2]{};inline bool original_visible[2]{true,true};inline int popup=-1;inline bool attached=false,busy=false,attempted=false;
inline std::uint64_t captured=0,failed=0;inline View* pending=nullptr;inline unsigned opened_at=0;
inline bool previous_down=false,suppress_until_release=false;
inline POINT cursor_point();
inline IRenderer* last_renderer=nullptr;
inline Pane* own(Child* p){for(auto& pane:panes)if(pane.child==p)return &pane;return nullptr;}
inline std::uint64_t topology(CMenu* m){
 if(!m||m->Tabs.size()!=9||!m->Tabs[RAGE]||m->Tabs[RAGE]->Childs.size()>64)return 0;
 std::uint64_t h=0xcbf29ce484222325ull;const auto add=[&](std::uintptr_t n){h=(h^n)*0x100000001b3ull;};
 for(auto* c:m->Tabs[RAGE]->Childs)if(c&&!own(c)){if(c->Elements.size()>1024)return 0;add(reinterpret_cast<std::uintptr_t>(c));add(c->Elements.size());for(auto* e:c->Elements){if(!e)return 0;add(reinterpret_cast<std::uintptr_t>(e));const int type=e->GetAs<Checkbox>()->Header.Type;add(type);if(native_ui_proxy::supported(type)&&type!=UiLabel)add(reinterpret_cast<std::uintptr_t>(native_ui_proxy::pointer(e,0x5c)));}}
 return h;
}
inline unsigned model(View& v,unsigned char* out){auto* c=v.source->GetAs<Checkbox>();const auto t=c->Header.Type;auto* p=native_ui_proxy::pointer(c,0x5c);if(!p||t==UiLabel||t==UiButton)return 0;const unsigned n=t==UiCheckbox?1:t==UiHotkey?8:4;std::memcpy(out,static_cast<unsigned char*>(p)+(t==UiHotkey?16:0),n);if(t==UiHotkey)out[0]&=~3u;return n;}
inline void close(){if(popup>=0)for(auto& v:views)if(v.proxy&&v.pane&&v.pane->id>=2)v.proxy->GetAs<Checkbox>()->ResetInputState();popup=-1;for(int i=2;i<pane_count;i++)if(panes[i].child)panes[i].child->Header.Flags.Visible=false;for(int i=0;i<2;i++)if(panes[i].child)panes[i].child->Header.Flags.AllowMouseInput=true;}
inline void invalidate(){attached=false;close();for(auto& v:views)if(v.proxy){auto* c=v.proxy->GetAs<Checkbox>();c->Header.Flags.Visible=c->Header.Flags.Editable=c->Header.Flags.AllowMouseInput=false;c->Calls.clear();if(native_ui_proxy::supported(c->Header.Type))*reinterpret_cast<void**>(reinterpret_cast<char*>(c)+0x5c)=nullptr;c->ResetInputState();}for(auto& p:panes)if(p.child)p.child->Header.Flags.Visible=false;}
inline void __fastcall changed(void* p,void*){
 if(busy||!attached)return;auto* m=context?context->Menu:nullptr;if(topology(m)!=captured){invalidate();return;}auto* v=static_cast<View*>(p);if(!v||!v->source)return;
 if(v->source->GetAs<Checkbox>()->Header.Type!=UiButton)v->source->GetAs<Checkbox>()->OnConfigLoad();if(topology(m)!=captured){invalidate();return;}
 v->source->GetAs<Checkbox>()->OnValueSet();if(topology(m)!=captured){invalidate();return;}model(*v,v->observed);
}
inline void link(void* out,void* source){if(!pending||pending->source!=source)throw std::runtime_error("Rage view source mismatch");pending->proxy=static_cast<PElement>(out);static_cast<Checkbox*>(out)->Calls.emplace_back(pending,&changed);}
inline void __fastcall open(void* which,void*){const int id=int(reinterpret_cast<std::intptr_t>(which));if(!attached||id<0||id>=group_count){close();return;}if(popup==id){close();return;}close();popup=id;opened_at=GetTickCount();}
inline void __fastcall close_click(void*,void*){close();}
inline void __fastcall glyph(Button* b,void*,IRenderer* r,const Vec2* origin){
 if(!r||!origin||!attached)return;Gear* g=nullptr;for(auto& candidate:gears)if(candidate.button==b)g=&candidate;for(auto& candidate:closers)if(candidate.button==b)g=&candidate;if(!g)return;
 Rect rect{origin->x+b->Pos.x,origin->y+b->Pos.y,b->Size.x,b->Size.y};g->last=rect;menu_paint::Paint p{r,scale()};
 const POINT cursor=cursor_point();const bool hover=menu_interaction::inside(rect,cursor.x,cursor.y);
 if(hover)p.fill(rect,0xff252525u);
 if(g->id<0){const int d=p.s(5);r->Line(rect.x+d,rect.y+d,rect.x+rect.w-d,rect.y+rect.h-d,0xffaaaaaau);r->Line(rect.x+rect.w-d,rect.y+d,rect.x+d,rect.y+rect.h-d,0xffaaaaaau);}
 else p.gear(rect,hover?menu_paint::accent():0xffaaaaaau);
}
inline void setup_gear(Gear& g,Pane& p,int id){
 g={};g.id=id;g.button=static_cast<Button*>(add_button(p.child,true,L" ",reinterpret_cast<void*>(std::intptr_t(id)),reinterpret_cast<void*>(id<0?&close_click:&open)));
 if(!g.button)throw std::bad_alloc();auto** vt=*reinterpret_cast<void***>(g.button);std::memcpy(g.vt,vt,sizeof(g.vt));g.vt[4]=reinterpret_cast<void*>(&glyph);*reinterpret_cast<void***>(g.button)=g.vt;
 native_layout_state::size(g.button,std::max(12,int(17*scale())),std::max(12,int(17*scale())),scale());
}
inline void geometry(Pane& p){
 auto* m=context?context->Menu:nullptr;if(!m||!p.child)return;const float s=scale();
 if(p.id<2){auto* source=sources[p.id];if(!source)return;native_layout_state::fixed(p.child,source->Pos.x,source->Pos.y,source->Size.x,source->Size.y,s);}
 else {auto& gear=gears[p.id-2];int x=m->Size.x-int(265*s),y=int(110*s);if(gear.last.w){x=gear.last.x-m->Pos.x+int(24*s);y=gear.last.y-m->Pos.y-int(8*s);}const int w=std::min(int(245*s),m->Size.x-int(120*s)),h=std::clamp(int((panes[p.id].child->Elements.size()*28+40)*s),int(100*s),std::max(int(100*s),m->Size.y-int(90*s)));
 x=std::clamp(x,int(92*s),std::max(int(92*s),m->Size.x-w-int(12*s)));y=std::clamp(y,int(30*s),std::max(int(30*s),m->Size.y-h-int(14*s)));native_layout_state::fixed(p.child,x,y,w,h,s);}
}
inline void place_gears(Pane& p){const float s=scale();for(auto& g:gears)if(g.button&&g.button->Header.Parent==p.child&&g.anchor){auto* a=g.anchor->GetAs<Checkbox>();g.button->Header.Flags.Visible=a->Header.Flags.Visible;g.button->Header.Flags.Editable=true;g.button->Header.Flags.AllowMouseInput=false;int measured[2]{};auto* renderer=context?context->IRenderer:nullptr;const wchar_t* title=menu_interaction::anchors[g.id];if(renderer&&esp_layout_runtime::supported_renderer(renderer))renderer->MeasureText(measured,title,std::wcslen(title),0);const int text_width=measured[0]>0?measured[0]:int(std::wcslen(title)*6*s);const int label=a->Pos.x+(a->Header.Type==UiCheckbox?int(18*s):0);const int limit=p.child->Size.x-int((g.id>=5?28:64)*s);g.button->Pos={std::max(0,std::min(label+text_width+int(9*s),limit)),a->Pos.y-int(2*s)};native_layout_state::size(g.button,int(17*s),int(17*s),s);}if(p.id>=2&&closers[p.id-2].button){auto* b=closers[p.id-2].button;b->Header.Flags.AllowMouseInput=false;b->Pos={p.child->Size.x-int(22*s),0};native_layout_state::size(b,int(14*s),int(14*s),s);}}
inline void __fastcall layout(Child* c,void*){if(auto* p=own(c)){geometry(*p);if(p->layout)p->layout(c);place_gears(*p);}}
inline void __fastcall resize(Child* c,void*){if(auto* p=own(c)){geometry(*p);if(p->resize)p->resize(c);layout(c,nullptr);}}
inline void __fastcall dpi(Child* c,void*){if(auto* p=own(c)){geometry(*p);if(p->dpi)p->dpi(c);layout(c,nullptr);}}
inline void __fastcall draw(Child* c,void*,IRenderer* r,const Vec2* origin){if(!attached)return;if(auto* p=own(c)){if(r&&esp_layout_runtime::supported_renderer(r))last_renderer=r;if(p->id>=2)return;geometry(*p);place_gears(*p);p->draw(c,r,origin);if(p->id==8&&r&&origin)r->Text(0,origin->x+c->Pos.x+int(15*scale()),origin->y+c->Pos.y+c->Size.y-int(18*scale()),0xff999999u,c->Size.x-int(24*scale()),hitchance_ui::profile_caption,std::wcslen(hitchance_ui::profile_caption));}}
// CMenu::Render (0x433ac5e2) returns after the complete tab render loop;
// the renderer command buffer is still open. Popovers must be submitted here,
// not as ordinary Childs that share the underlying panels' clipping/depth.
inline void paint_overlay(CMenu* m,IRenderer* renderer=nullptr){
 if(!attached||!m||m->CurrentTab!=RAGE||!(m->MenuStatus&MenuOpened)||popup<0||popup>=group_count)return;
 if(topology(m)!=captured){invalidate();return;}
 auto* r=renderer&&esp_layout_runtime::supported_renderer(renderer)?renderer:last_renderer;
 if(!r||!esp_layout_runtime::supported_renderer(r))return;
 auto& p=panes[popup+2];if(!p.child||!p.child->Header.Flags.Visible||!p.draw)return;
 geometry(p);place_gears(p);RendererOverlayScope overlay(r);
 // Native hotkey/combo menus draw at Z=0.15; keep the containing pane behind them.
 r->SetZBuff(0.2f);
 const Vec2 origin=m->Pos;p.draw(p.child,r,&origin);
 if(p.id==8)r->Text(0,m->Pos.x+p.child->Pos.x+int(15*scale()),m->Pos.y+p.child->Pos.y+p.child->Size.y-int(18*scale()),0xff999999u,p.child->Size.x-int(24*scale()),hitchance_ui::profile_caption,std::wcslen(hitchance_ui::profile_caption));
}
inline void create(Pane& p,CTab* tab,int id,const wchar_t* name){
 if(p.child)return;p.id=id;p.child=static_cast<Child*>(native.allocate(sizeof(Child)));if(!p.child)throw std::bad_alloc();child_ctor(p.child,tab,name,int(0xff000000u),0,false);p.child->Header.Flags.Visible=false;
 auto** vt=*reinterpret_cast<void***>(p.child);std::memcpy(p.vt,vt,sizeof(p.vt));p.draw=reinterpret_cast<NativeChildDraw>(vt[4]);p.layout=reinterpret_cast<NativeLayout>(vt[8]);p.resize=reinterpret_cast<NativeLayout>(vt[9]);p.dpi=reinterpret_cast<NativeLayout>(vt[10]);p.vt[4]=reinterpret_cast<void*>(&draw);p.vt[8]=reinterpret_cast<void*>(&layout);p.vt[9]=reinterpret_cast<void*>(&resize);p.vt[10]=reinterpret_cast<void*>(&dpi);*reinterpret_cast<void***>(p.child)=p.vt;append_child(tab,p.child);
}
inline void clear(){close();for(auto& p:panes)if(p.child){for(auto* e:p.child->Elements)if(e){auto* c=e->GetAs<Checkbox>();c->Calls.clear();if(native_ui_proxy::supported(c->Header.Type))*reinterpret_cast<void**>(reinterpret_cast<char*>(e)+0x5c)=nullptr;c->ResetInputState();destroy(e);}p.child->Elements.clear();p.child->Header.Flags.Visible=false;}used=0;for(auto& v:views)v={};for(auto& g:gears)g={};for(auto& g:closers)g={};}
inline bool rebuild(CMenu* m){
 auto* tab=m->Tabs[RAGE];Child* found[2]{};for(auto* c:tab->Childs)if(c&&!own(c)){wchar_t name[128]{};native_ui_names::decode(c->Name.get(),name,128);if(eq(name,L"Aimbot"))found[0]=c;else if(eq(name,L"Other"))found[1]=c;}
 if(!found[0]||!found[1])return false;for(int i=0;i<2;i++){if(sources[i]!=found[i])original_visible[i]=found[i]->Header.Flags.Visible;sources[i]=found[i];}
 create(panes[0],tab,0,L"Aimbot");create(panes[1],tab,1,L"Other");for(int i=0;i<group_count;i++)create(panes[i+2],tab,i+2,menu_interaction::anchors[i]);clear();busy=true;
 struct Row {PElement source;wchar_t name[128];int column,detail;};Row rows[256]{};unsigned count=0;bool present[group_count]{};PElement anchors[group_count]{},caption_anchor[group_count]{};Pane* caption_pane[group_count]{};
 for(int col=0;col<2;col++){if(sources[col]->Elements.size()>128){busy=false;return false;}int previous=-1,previous_anchor=-1;for(auto* e:sources[col]->Elements){if(!e||count>=256){busy=false;return false;}auto* c=e->GetAs<Checkbox>();if(c->Header.Type!=UiButton&&!native_ui_proxy::supported(c->Header.Type)){busy=false;return false;}auto& row=rows[count++];row.source=e;row.column=col;native_ui_names::decode(c->Name.get(),row.name,128);bool blank=!row.name[0];row.detail=(blank||c->Header.Type==UiColorPicker)?previous:menu_interaction::detail(row.name);if(c->Header.Type==UiSlider||c->Header.Type==UiHotkey){if(eq(row.name,L"Minimum damage override"))row.detail=5;if(eq(row.name,L"Minimum hit chance override"))row.detail=6;}if(blank&&(c->Header.Type==UiMultiselect||c->Header.Type==UiCombobox||c->Header.Type==UiSlider||c->Header.Type==UiHotkey)&&previous_anchor>=0)row.detail=previous_anchor;if(!blank&&c->Header.Type!=UiColorPicker){previous=row.detail;previous_anchor=-1;for(int a=0;a<group_count;a++)if(eq(row.name,menu_interaction::anchors[a]))previous_anchor=a;}
  for(int j=0;j<group_count;j++)if(eq(row.name,menu_interaction::anchors[j])&&(j<5||c->Header.Type!=UiSlider))anchors[j]=e;if(row.detail>=0)present[row.detail]=true;}}
 for(unsigned i=0;i<count;i++){auto& row=rows[i];const int detail=row.detail>=0&&anchors[row.detail]?row.detail:-1;auto& p=panes[detail>=0?detail+2:row.column];auto& v=views[used];v.source=row.source;v.pane=&p;pending=&v;if(detail>=5&&row.source==anchors[detail]&&row.source->GetAs<Checkbox>()->Header.Type==UiHotkey){auto& main=panes[row.column];auto* label=static_cast<Label*>(native.allocate(sizeof(Label)));if(!label){busy=false;return false;}native.label(label,main.child,row.name);native.insert(main.child,false,label);caption_anchor[detail]=reinterpret_cast<PElement>(label);caption_pane[detail]=&main;}
  if(row.source->GetAs<Checkbox>()->Header.Type==UiButton)v.proxy=static_cast<PElement>(add_button(p.child,row.source->GetAs<Checkbox>()->Header.Flags.SameLine,row.name,&v,reinterpret_cast<void*>(&changed)));
  else {const int type=row.source->GetAs<Checkbox>()->Header.Type;const wchar_t* caption=row.name;
   if(detail>=0&&type==UiHotkey){auto* label=static_cast<Label*>(native.allocate(sizeof(Label)));if(!label){busy=false;return false;}native.label(label,p.child,L"Bind");native.insert(p.child,false,label);}
   if(detail==5&&type==UiSlider)caption=L"Override damage";if(detail==6&&type==UiSlider)caption=L"Override hit chance";
   auto api=native;api.link=&link;v.proxy=static_cast<PElement>(native_ui_proxy::create(api,p.child,row.source,caption));}pending=nullptr;if(!v.proxy){busy=false;return false;}model(v,v.observed);used++;}
 for(int i=0;i<group_count;i++)if(present[i]&&anchors[i]){if(caption_anchor[i]){setup_gear(gears[i],*caption_pane[i],i);gears[i].anchor=caption_anchor[i];setup_gear(closers[i],panes[i+2],-1);continue;}for(unsigned j=0;j<used;j++)if(views[j].source==anchors[i]){setup_gear(gears[i],*views[j].pane,i);gears[i].anchor=views[j].proxy;setup_gear(closers[i],panes[i+2],-1);break;}}
 captured=topology(m);busy=false;attached=true;for(int i=0;i<2;i++){sources[i]->Header.Flags.Visible=false;panes[i].child->Header.Flags.Visible=original_visible[i];}for(auto& p:panes)layout(p.child,nullptr);return true;
}
inline void restore(CMenu* m){for(auto* c:m->Tabs[RAGE]->Childs)for(int i=0;i<2;i++)if(c==sources[i])c->Header.Flags.Visible=original_visible[i];}
inline bool native_editor_open(){if(popup<0)return false;for(unsigned i=0;i<used;i++){auto& v=views[i];if(!v.proxy||v.pane->id!=popup+2)continue;auto* h=v.proxy->GetAs<Checkbox>();if(h->Header.Type==UiHotkey){auto* k=v.proxy->GetAs<Hotkey>();if(k->SettingKey||(k->Popup&&*(reinterpret_cast<const unsigned char*>(k->Popup)+0x64)))return true;}if(h->Header.Type==UiCombobox&&*(reinterpret_cast<unsigned char*>(h)+0x70))return true;if(h->Header.Type==UiMultiselect&&v.proxy->GetAs<Multiselect>()->Popup)return true;}return false;}
inline POINT cursor_point(){POINT p{};GetCursorPos(&p);HWND hwnd=ui_preview_input::window.load();if(!hwnd){DWORD pid=0;auto active=GetForegroundWindow();if(active){GetWindowThreadProcessId(active,&pid);if(pid==GetCurrentProcessId())hwnd=active;}}if(hwnd)ScreenToClient(hwnd,&p);return p;}
inline void frame(CMenu* m){
 if(!m||m->Tabs.size()!=9||!m->Tabs[RAGE])return;
 const auto revision=topology(m);if(!revision)return;
 if(attached&&revision==captured&&(m->CurrentTab!=RAGE||!(m->MenuStatus&MenuOpened))){close();return;}
 if(!attached&&m->CurrentTab!=RAGE)return;
 if(!attached||revision!=captured){if(revision==failed)return;invalidate();try{if(!rebuild(m)){restore(m);failed=topology(m);return;}}catch(...){busy=false;invalidate();restore(m);failed=topology(m);return;}}
 // Poll before CMenu::HandleInput. A native checkbox covers the entire row
 // and consumes a gear click before the appended Button can see it.
 const bool down=(GetAsyncKeyState(VK_LBUTTON)&0x8000)!=0;
 const bool pressed=down&&!previous_down;previous_down=down;
 if(!down)suppress_until_release=false;
 const POINT point=cursor_point();
 const auto hit=[&](Gear& g){return g.button&&g.button->Header.Flags.Visible&&g.last.w>0&&menu_interaction::inside(g.last,point.x,point.y);};
 bool gear_click=false;
 if(pressed){
  bool over_popup=false;
  if(popup>=0){auto* c=panes[popup+2].child;Rect box{m->Pos.x+c->Pos.x,m->Pos.y+c->Pos.y,c->Size.x,c->Size.y};over_popup=menu_interaction::inside(box,point.x,point.y);
   if(hit(closers[popup])){close();gear_click=true;}}
  // An open popup owns its rectangle. A gear behind a clamped popup must not
  // steal clicks from its native slider, bind, combo or multiselect editor.
  if(!gear_click&&!over_popup)for(auto& g:gears)if(hit(g)){open(reinterpret_cast<void*>(std::intptr_t(g.id)),nullptr);gear_click=true;break;}
  if(gear_click)suppress_until_release=true;
 }
 if(popup>=0&&!gear_click){auto& p=panes[popup+2];Rect box{m->Pos.x+p.child->Pos.x,m->Pos.y+p.child->Pos.y,p.child->Size.x,p.child->Size.y};
  if((GetAsyncKeyState(VK_ESCAPE)&1)||(pressed&&GetTickCount()-opened_at>100&&!native_editor_open()&&!menu_interaction::inside(box,point.x,point.y))){close();if(down)suppress_until_release=true;}}
 busy=true;for(unsigned i=0;i<used;i++){
  auto& v=views[i];auto* out=v.proxy->GetAs<Checkbox>();auto* source=v.source->GetAs<Checkbox>();
  out->Header.Flags.Visible=v.pane->id>=7?true:source->Header.Flags.Visible;
  out->Header.Flags.Editable=source->Header.Flags.Editable;
  const bool blocked=v.pane->id<2?(popup>=0||suppress_until_release):(v.pane->id!=popup+2||suppress_until_release);
  out->Header.Flags.AllowMouseInput=source->Header.Flags.AllowMouseInput&&!blocked;
  if(blocked)out->ResetInputState();
  unsigned char now[8]{};const auto n=model(v,now);if(n&&std::memcmp(now,v.observed,n)){std::memcpy(v.observed,now,n);out->OnConfigLoad();}}
 for(int i=0;i<2;i++)sources[i]->Header.Flags.Visible=false;
 for(auto& p:panes){p.child->Header.Flags.Visible=p.id<2?original_visible[p.id]:p.id==popup+2;p.child->Header.Flags.AllowMouseInput=p.id>=2||!(popup>=0||suppress_until_release);layout(p.child,nullptr);}
 busy=false;
}
}
