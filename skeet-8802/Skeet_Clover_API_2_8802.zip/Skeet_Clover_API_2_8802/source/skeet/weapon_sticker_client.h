#pragma once
#include "local_weapon_names.h"
namespace weapon_sticker_client {
using namespace local_inventory_client;
struct Saved {unsigned handle=0;void* object=nullptr;unsigned original[3]{};std::uint64_t assigned=0;};
inline std::array<Saved,64> saved{};
inline bool layout(){if(!local_weapon_names::layout())return false;
 // I_EconItemInterface::GetItemID (secondary this = view + 12) reads high at
 // +0x1f4, low at +0x1f8. GetSOCData checks view+0x208 account first.
 constexpr unsigned char id[]={0x8b,0x91,0xf4,1,0,0,0x33,0xc0,0x0b,0x81,0xf8,1,0,0,0xc3};
 constexpr unsigned char soc[]={0x55,0x8b,0xec,0x83,0xe4,0xf0,0x83,0xec,0x18,0x56,0x8b,0xf1,0x57,0x8b,0x86,0x10,2,0,0};
 return !std::memcmp(base+0x6bce60,id,sizeof(id))&&!std::memcmp(base+0x7169b0,soc,sizeof(soc));
}
inline std::uint64_t id(void* view){return (std::uint64_t(read32(view,0x200))<<32)|read32(view,0x204);}
inline void fields(void* view,const unsigned* values){std::memcpy(static_cast<unsigned char*>(view)+0x200,values,12);}
inline void apply(local_inventory::Inventory& inv){
 bool configured=false,tracked=false;
 for(int w=1;w<65&&!configured;w++)configured=sticker_state::active(w);
 for(const auto& state:saved)if(state.handle){tracked=true;break;}
 if(!configured&&!tracked)return; // No engine/entity queries in the default path.
 if(!layout()||!inv.current.inventory)return;
 // GetSOCData dereferences the client's engine interface and local inventory.
 // They can disappear briefly across disconnect/account changes.
 if(!memory(base+0x533478c,4)||!local_client_interfaces::method(pointer(base+0x533478c,0),26)||!memory(base+0x52a92f8,4)||pointer(base+0x52a92f8,0)!=inv.current.inventory)return;
 auto* engine=local_client_interfaces::core_interface(0x4346a514);auto* entities=local_client_interfaces::core_interface(0x4346a890);
 auto* loc=local_client_interfaces::method(engine,12);auto* ent=local_client_interfaces::method(entities,3);auto* handle_fn=local_client_interfaces::method(entities,4);if(!loc||!ent||!handle_fn)return;
 using Local=int(__thiscall*)(void*);using Entity=void*(__thiscall*)(void*,unsigned);using SOC=void*(__thiscall*)(void*);
 const int idx=reinterpret_cast<Local>(loc)(engine);if(idx<1||idx>64){saved={};return;}
 auto* player=reinterpret_cast<Entity>(ent)(entities,unsigned(idx));if(!memory(player,0x2f08))return;
 const local_inventory::Item* items[65]{};
 for(auto& item:inv.items)if(item.object&&sticker_state::active(item.spec.weapon)&&contains(inv.current,item.object,item.id))items[item.spec.weapon]=&item;
 std::array<bool,64> seen{};
 for(unsigned n=0;n<64;n++){
  const auto h=read32(player,0x2e08+n*4);if(!h||h==0xffffffffu)continue;
  auto* object=reinterpret_cast<Entity>(handle_fn)(entities,h);if(!memory(object,0x30ed,true))continue;
  const auto owner=read32(object,0x14c);if(!owner||owner==0xffffffffu||reinterpret_cast<Entity>(handle_fn)(entities,owner)!=player)continue;
  auto* view=static_cast<unsigned char*>(object)+0x2dd0;
  const auto weapon=*reinterpret_cast<unsigned short*>(view+0x1ea);const auto* item=weapon<65?items[weapon]:nullptr;
  unsigned index=64;for(unsigned i=0;i<64;i++)if(saved[i].handle==h&&saved[i].object==object){index=i;break;}
  if(index==64)for(unsigned i=0;i<64;i++)if(!saved[i].handle){index=i;saved[i].handle=h;saved[i].object=object;break;}
  if(index==64)continue;seen[index]=true;auto& old=saved[index];
  const auto current=id(view);
  if(!item){if(old.assigned&&current==old.assigned)fields(view,old.original);old={};continue;}
  // Never replace an embedded non-SO item or keep a borrowed SO pointer.
  if(read32(view,0x210))continue;
  if(!old.assigned||current!=old.assigned)std::memcpy(old.original,view+0x200,12);
  const unsigned next[]={unsigned(item->id>>32),unsigned(item->id),inv.current.account};fields(view,next);
  if(reinterpret_cast<SOC>(base+0x7169b0)(view)!=item->object){fields(view,old.original);old.assigned=0;continue;}
  old.assigned=item->id;
 }
 // Weapon slots reorder during pickups. Saved IDs follow the full entity
 // handle, including its serial, and are never restored onto a new owner.
 for(unsigned i=0;i<64;i++)if(saved[i].handle&&!seen[i]){auto& old=saved[i];auto* object=reinterpret_cast<Entity>(handle_fn)(entities,old.handle);
  if(object==old.object&&memory(object,0x30ed,true)){auto* view=static_cast<unsigned char*>(object)+0x2dd0;const auto owner=read32(object,0x14c);if(owner&&owner!=0xffffffffu&&reinterpret_cast<Entity>(handle_fn)(entities,owner)==player&&old.assigned&&id(view)==old.assigned)fields(view,old.original);}old={};}
}
}
