#pragma once
// Native command 13 forwards its boolean unchanged to D3DRS_SCISSORTESTENABLE
// (backend 0x433ed99e, SetRenderState(174, value)). False disables clipping.
// Keep the rectangle and enable bit independently; category rendering is clipped.
struct RendererOverlayScope {
 SkeetSDK::IRenderer* r;float alpha=1,depth=0;int bounds[4]{};bool enabled=false;
 explicit RendererOverlayScope(SkeetSDK::IRenderer* renderer):r(renderer){
  std::memcpy(&alpha,reinterpret_cast<const char*>(r)+0x80,4);if(!std::isfinite(alpha)||alpha<0||alpha>1)alpha=1;
  depth=r->GetZBuff();enabled=r->IsBoundsPresent();r->GetBounds(bounds);r->ResetBounds(false);r->SetZBuff(0);r->SetAlpha(1);
 }
 ~RendererOverlayScope(){r->SetBounds(bounds);r->ResetBounds(enabled);r->SetZBuff(depth);r->SetAlpha(alpha);}
};
