#pragma once
#include "body_preference.h"
#include "scan_patch.h"
namespace body_preference_patch {
inline constexpr unsigned site=0x50774,code_size=96;
inline constexpr unsigned char original[]={0x8b,0x7c,0x24,0x5c,0x33,0xc9,0x41};
struct Plan {unsigned char code[code_size]{};unsigned char jump[sizeof(original)]{};};
inline bool make(const unsigned char* image,std::size_t size,unsigned location,unsigned callback,Plan& out) {
    if(!image||size!=scan_patch::image_size||std::memcmp(image+site,original,sizeof(original)))return false;
    Plan p{};unsigned n=0;
    const auto byte=[&](unsigned char b){p.code[n++]=b;};
    const auto dword=[&](unsigned v){std::memcpy(p.code+n,&v,4);n+=4;};
    // Preserve integer flags/registers and the complete native x87/SSE state.
    // ESI (callee-saved) retains the pre-alignment stack pointer across the helper.
    const unsigned char save[]={0x9c,0x60,0x89,0xe6,0x81,0xec,0x10,0x02,0,0,0x83,0xe4,0xf0,0x0f,0xae,0x04,0x24,
        0x8d,0x4e,0x24,0x8b,0x55,0x08,0xb8};
    std::memcpy(p.code,save,sizeof(save));n=sizeof(save);dword(callback);
    const unsigned char restore[]={0xff,0xd0,0x0f,0xae,0x0c,0x24,0x89,0xf4,0x61,0x9d};
    std::memcpy(p.code+n,restore,sizeof(restore));n+=sizeof(restore);
    std::memcpy(p.code+n,original,sizeof(original));n+=sizeof(original);
    byte(0xe9);dword(scan_patch::image_base+site+sizeof(original)-(location+n+4));
    std::memset(p.jump,0x90,sizeof(p.jump));p.jump[0]=0xe9;
    scan_patch::put32(p.jump+1,location-(scan_patch::image_base+site+5));out=p;return true;
}
#ifdef _WIN32
inline bool apply(unsigned char* image,std::size_t size) {
    if(reinterpret_cast<std::uintptr_t>(image)!=scan_patch::image_base)return false;
    auto* code=static_cast<unsigned char*>(VirtualAlloc(nullptr,4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));if(!code)return false;
    Plan p{};
    if(!make(image,size,reinterpret_cast<unsigned>(code),reinterpret_cast<unsigned>(&body_preference::bridge),p)) {
        VirtualFree(code,0,MEM_RELEASE);SetLastError(ERROR_REVISION_MISMATCH);return false;
    }
    std::memcpy(code,p.code,sizeof(p.code));DWORD old=0;
    if(!VirtualProtect(code,4096,PAGE_EXECUTE_READ,&old)||!FlushInstructionCache(GetCurrentProcess(),code,sizeof(p.code))) {
        const auto error=GetLastError();VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;
    }
    std::memcpy(image+site,p.jump,sizeof(p.jump));
    if(!FlushInstructionCache(GetCurrentProcess(),image+site,sizeof(p.jump))) {
        const auto error=GetLastError();std::memcpy(image+site,original,sizeof(original));FlushInstructionCache(GetCurrentProcess(),image+site,sizeof(original));
        VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;
    }
    return true;
}
#endif
}
