#pragma once
#include "scan_patch.h"
#include "motion_blend_sites.h"
#include <initializer_list>
namespace motion_plan {
inline constexpr unsigned code_size=8192,blend_entry=0x800,blend_body=0x1000;
struct Edit {unsigned offset,length;unsigned char before[9],after[9];};
struct Plan {unsigned char code[code_size]{};Edit edits[4]{};};
struct Emit {
    unsigned char* p;unsigned address,pos=0;
    void bytes(std::initializer_list<unsigned char> a){for(auto b:a)p[pos++]=b;}
    void value(unsigned v){scan_patch::put32(p+pos,v);pos+=4;}
    void jump(unsigned target){bytes({0xe9});value(target-(address+pos+4));}
    void call(unsigned target){bytes({0xe8});value(target-(address+pos+4));}
    unsigned conditional(unsigned opcode){bytes({0x0f,static_cast<unsigned char>(opcode)});unsigned at=pos;value(0);return at;}
    void fix(unsigned at,unsigned target){scan_patch::put32(p+at,target-(address+at+4));}
    // All eight XMM registers and pushad's general registers are preserved.
    void save(){bytes({0x60,0x81,0xec,0x80,0,0,0});for(unsigned i=0;i<8;i++){bytes({0x0f,0x11,static_cast<unsigned char>(0x84+(i<<3)),0x24});value(i*16);}}
    void restore(){for(unsigned i=0;i<8;i++){bytes({0x0f,0x10,static_cast<unsigned char>(0x84+(i<<3)),0x24});value(i*16);}bytes({0x81,0xc4,0x80,0,0,0,0x61});}
    void frame(){bytes({0x8d,0x84,0x24,0xa0,0,0,0});}
};
inline bool make_plan(const unsigned char* image,std::size_t size,unsigned address,
                     unsigned begin_callback,unsigned apply_callback,unsigned getter_callback,Plan& plan) {
    if(!image||size!=scan_patch::image_size)return false;
    constexpr unsigned base=scan_patch::image_base;
    constexpr unsigned sites[]={0x4332ff66,0x4332ff92,0x43398505,0x43344d4e};
    constexpr unsigned lengths[]={5,5,5,9};
    constexpr unsigned char originals[4][9]={
        {0xe8,0x50,0x84,0x06,0},{0xe8,0x24,0x84,0x06,0},
        {0xe8,0xf5,0x68,0x05,0},{0x3b,0x4e,0x4c,0x0f,0x85,0x2c,0x0e,0,0}};
    for(unsigned i=0;i<4;i++)if(std::memcmp(image+sites[i]-base,originals[i],lengths[i]))return false;
    constexpr unsigned char body_prefix[]={0x8b,0x0d,0x38,0xa3,0x46,0x43,0x0f,0x57,0xd2};
    if(std::memcmp(image+blend_begin-base,body_prefix,sizeof(body_prefix)))return false;
    for(unsigned off:blend_calls)if(image[blend_begin-base+off]!=0xe8)return false;
    plan=Plan{};
    // Both selector callers pass the root clock context from the main HC frame.
    Emit dispatch{plan.code,address};dispatch.save();dispatch.frame();
    dispatch.bytes({0x83,0xec,8,0x50,0xff,0x75,8});dispatch.call(begin_callback);
    dispatch.bytes({0x83,0xc4,16});dispatch.restore();dispatch.jump(0x433983bb);
    if(dispatch.pos>=0x200)return false;
    // The actual apply prefix has already acquired and validated the history.
    // Replace its ambiguous intermediate-tick branch using the same cached pose.
    Emit apply{plan.code+0x200,address+0x200};apply.save();apply.frame();
    apply.bytes({0x83,0xec,8,0x55,0x50});apply.call(apply_callback);apply.bytes({0x83,0xc4,16,0x85,0xc0});
    const auto legacy=apply.conditional(0x84),failure=apply.conditional(0x88);
    apply.restore();apply.bytes({0x8b,0x74,0x24,0x50,0x8b,0x7c,0x24,0x58});apply.jump(0x43345b83);
    apply.fix(legacy,apply.address+apply.pos);apply.restore();apply.bytes({0x3b,0x4e,0x4c});
    const auto unequal=apply.conditional(0x85);apply.jump(0x43344d57);apply.fix(unequal,0x43345b83);
    apply.fix(failure,apply.address+apply.pos);apply.restore();apply.jump(0x43345eae);
    if(apply.pos>=0x600)return false;
    // Standalone __cdecl blend(newer, older, requestedTick, outputScope).
    // Match the native aligned 0x178 frame and its two saved registers exactly.
    Emit blend{plan.code+blend_entry,address+blend_entry};
    blend.bytes({0x55,0x8b,0xec,0x83,0xe4,0xf0,0x81,0xec,0x78,1,0,0,0x56,0x57,
        0x8b,0x75,8,0x8b,0x55,12,0x8b,0x45,16,0x8b,0x7d,20,
        0x89,0x7c,0x24,0x58,0x83,0xc7,16,0x89,0x7c,0x24,0x50,
        0x89,0x74,0x24,0x5c,0x89,0x54,0x24,0x78,0x0f,0x57,0xe4});
    blend.jump(address+blend_body);
    constexpr auto body_length=blend_end-blend_begin;
    static_assert(blend_body+body_length+7<code_size);
    std::memcpy(plan.code+blend_body,image+blend_begin-base,body_length);
    for(unsigned off:blend_calls) {
        unsigned displacement=0;std::memcpy(&displacement,image+blend_begin-base+off+1,4);
        const unsigned target=blend_begin+off+5+displacement;
        scan_patch::put32(plan.code+blend_body+off+1,target-(address+blend_body+off+5));
    }
    Emit epilogue{plan.code+blend_body+body_length,address+blend_body+body_length};
    epilogue.bytes({0x5f,0x5e,0x8b,0xe5,0x5d,0xc3});
    for(unsigned i=0;i<4;i++) {
        auto& e=plan.edits[i];e.offset=sites[i]-base;e.length=lengths[i];
        std::memcpy(e.before,originals[i],e.length);std::memset(e.after,0x90,e.length);
        e.after[0]=i==3?0xe9:0xe8;
        const unsigned target=i==3?address+0x200:(i==2?getter_callback:address);
        scan_patch::put32(e.after+1,target-(sites[i]+5));
    }
    return true;
}
}
