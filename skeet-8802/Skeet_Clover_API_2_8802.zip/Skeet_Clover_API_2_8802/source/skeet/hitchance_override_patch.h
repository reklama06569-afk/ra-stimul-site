#pragma once
#include "precision_patch.h"
#include "hitchance_override.h"
namespace hitchance_override_patch {
// Reserve one unused dword between the precision sample-count and snapshot.
inline constexpr unsigned snapshot=0x764,sites[]={0x1fd43,0x20098,0x2016c};
inline constexpr unsigned lengths[]={10,6,6};
inline constexpr unsigned char originals[3][10]={{0x89,0x4c,0x24,0x1c,0x8d,0x88,0x74,1,0,0},{0x39,0x8f,0x48,8,0,0},{0x8b,0x87,0x48,8,0,0}};
struct Plan{unsigned char code[256]{};unsigned char edits[3][10]{};};
inline bool make(const unsigned char* image,std::size_t size,unsigned address,unsigned callback,Plan& out){
 if(!image||size!=scan_patch::image_size)return false;
 for(unsigned i=0;i<3;i++)if(std::memcmp(image+sites[i],originals[i],lengths[i]))return false;
 // This snapshot is valid only with the already installed 128-sample frame.
 if(image[0x1fd31]!=0xe9||image[0x20172]!=0xe8)return false;
 Plan p{};unsigned n=0;const auto put=[&](unsigned v){std::memcpy(p.code+n,&v,4);n+=4;};const auto byte=[&](unsigned char v){p.code[n++]=v;};
 const auto raw=[&](const unsigned char* b,unsigned len){std::memcpy(p.code+n,b,len);n+=len;};
 raw(originals[0],4);
 const unsigned char save[]={0x9c,0x60,0x89,0xe6,0x81,0xec,0x10,2,0,0,0x83,0xe4,0xf0,0x0f,0xae,4,0x24,0x8b,0x55,8,0xb8};raw(save,sizeof(save));put(callback);
 byte(0xff);byte(0xd0);byte(0x89);byte(0x86);put(36+snapshot-4); // entry has pushed ESI; EDI follows.
 const unsigned char restore[]={0x0f,0xae,0x0c,0x24,0x89,0xf4,0x61,0x9d};raw(restore,sizeof(restore));raw(originals[0]+4,6);byte(0xe9);put(scan_patch::image_base+sites[0]+10-(address+n+4));
 n=0x80;const unsigned char compare[]={0x39,0x8c,0x24};raw(compare,3);put(snapshot);byte(0xe9);put(scan_patch::image_base+sites[1]+6-(address+n+4));
 n=0xa0;const unsigned char load[]={0x8b,0x84,0x24};raw(load,3);put(snapshot);byte(0xe9);put(scan_patch::image_base+sites[2]+6-(address+n+4));
 const unsigned entries[]={0,0x80,0xa0};for(unsigned i=0;i<3;i++){std::memset(p.edits[i],0x90,lengths[i]);p.edits[i][0]=0xe9;scan_patch::put32(p.edits[i]+1,address+entries[i]-(scan_patch::image_base+sites[i]+5));}out=p;return true;
}
#ifdef _WIN32
inline bool apply(unsigned char* image,std::size_t size){
 auto* code=static_cast<unsigned char*>(VirtualAlloc(nullptr,4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));if(!code)return false;Plan plan{};
 if(reinterpret_cast<std::uintptr_t>(image)!=scan_patch::image_base||!make(image,size,reinterpret_cast<unsigned>(code),reinterpret_cast<unsigned>(&hitchance_override::capture),plan)){VirtualFree(code,0,MEM_RELEASE);SetLastError(ERROR_REVISION_MISMATCH);return false;}
 std::memcpy(code,plan.code,sizeof(plan.code));DWORD old=0;if(!VirtualProtect(code,4096,PAGE_EXECUTE_READ,&old)||!FlushInstructionCache(GetCurrentProcess(),code,sizeof(plan.code))){const auto error=GetLastError();VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;}
 for(unsigned i=0;i<3;i++)std::memcpy(image+sites[i],plan.edits[i],lengths[i]);
 if(!FlushInstructionCache(GetCurrentProcess(),image,size)){const auto error=GetLastError();for(unsigned i=0;i<3;i++)std::memcpy(image+sites[i],originals[i],lengths[i]);FlushInstructionCache(GetCurrentProcess(),image,size);VirtualFree(code,0,MEM_RELEASE);SetLastError(error);return false;}return true;
}
#endif
}
