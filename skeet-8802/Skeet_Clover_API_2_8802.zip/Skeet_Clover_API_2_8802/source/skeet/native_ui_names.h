#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>
namespace native_ui_names {
inline bool decode(const void* source,wchar_t* out,std::size_t capacity) {
    if(!out||!capacity)return false;out[0]=0;if(!source)return false;
    auto* p=static_cast<const unsigned char*>(source);std::uint16_t key,size;
    std::memcpy(&key,p,2);std::memcpy(&size,p+2,2);
    if((size&1)||size/2>=capacity||size>1024)return false;
    for(unsigned i=0;i<size/2;i++) {
        out[i]=wchar_t((p[4+i*2]^(key&255))|(unsigned(p[5+i*2])<<8));
        key=std::uint16_t((key>>1)|(key<<15));
    }
    out[size/2]=0;return true;
}
}
