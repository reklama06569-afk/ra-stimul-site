local ffi = require('ffi')
local vector = require('vector')
local color = require('gamesense/color')
local easing = require('gamesense/easing')

local menu = {}
do
    menu.dpi_scale_ref = ui.reference('Misc', 'Settings', 'DPI scale')
    menu.dpi_scale = '100%'
    ui.set_callback(menu.dpi_scale_ref, function(ref)
        menu.dpi_scale = ui.get(ref)
    end)

    menu.watermark = ui.new_checkbox('LUA', 'A', 'Watermark')
    menu.watermark_color = ui.new_color_picker('LUA', 'A', 'Color', 159, 202, 43, 255)
    menu.watermark_elements = ui.new_multiselect('LUA', 'A', 'Elements', {
        'Logo', 'Username', 'FPS', 'Frametime variance', 'Ping', 'Server IP', 'Speed', 'K/D ratio', 'Clock', 'Clock (24h)'
    })

    local function update_visibility(ref)
        local state = ui.get(ref)
        ui.set_visible(menu.watermark_color, state)
        ui.set_visible(menu.watermark_elements, state)
    end
    ui.set_callback(menu.watermark, update_visibility)
    update_visibility(menu.watermark)

    menu.color = color()
    local function update_color(ref)
        menu.color = color(ui.get(ref))
    end
    ui.set_callback(menu.watermark_color, update_color)
    update_color(menu.watermark_color)

    local watermark_elements = {}
    local update_block = false
    local function update_elements(ref)
        if update_block then return end
        local value = ui.get(ref)
        local selected = {}
        for i = 1, #value do
            selected[value[i]] = true
        end
        if selected['Clock'] and selected['Clock (24h)'] then
            local to_remove = watermark_elements['Clock'] and 'Clock' or 'Clock (24h)'
            local t = {}
            local selected_filtered = {}
            for i = 1, #value do
                local v = value[i]
                if v ~= to_remove then
                    table.insert(t, v)
                    selected_filtered[v] = true
                end
            end
            update_block = true
            ui.set(menu.watermark_elements, unpack(t))
            update_block = false
            selected = selected_filtered
        end
        watermark_elements = selected
    end
    ui.set_callback(menu.watermark_elements, update_elements)
    update_elements(menu.watermark_elements)

    function menu.has(name)
        return watermark_elements[name] == true
    end
end

ffi.cdef[[
    typedef void*(__thiscall* get_net_channel_info_t)(void*);
    typedef const char*(__thiscall* get_address_t)(void*);
]]

local rawivengineclient = client.create_interface('engine.dll', 'VEngineClient014')
local ivengineclient = ffi.cast(ffi.typeof('void***'), rawivengineclient)
local get_net_channel_info = ffi.cast('get_net_channel_info_t', ivengineclient[0][78])

local watermark = {}
do
    watermark.screen_size = vector(client.screen_size())
    watermark.username = panorama.open().MyPersonaAPI.GetName
    watermark.is_connected = false
    watermark.is_local_server = false
    watermark.data = {
        fps = { accumulated = 0, value = 0, previous = 0, warning = 64, danger = 45, spike_warning = 20, spike_danger = 40, inverse = true },
        ping = { value = 0, previous = 0, warning = 70, danger = 120, spike_warning = 25, spike_danger = 50 },
        delay = { value = 0, previous = 0, warning = 3, danger = 6, spike_warning = 2, spike_danger = 4 }
    }
    watermark.updates = {}
    watermark.settings = {
        brand_gap = 20,
        stat_gap = 15,
        warning_color = color(255, 213, 61),
        danger_color = color(255, 80, 80)
    }
    watermark.elements = {}
    watermark.animations = {}
    watermark.logo_active = false
    watermark.groups = 0

    function watermark:push(text, clr, small, pos, max_width)
        local font = small == true and 'd-' or 'd'
        text = tostring(text)
        table.insert(self.elements, {
            text = text,
            color = clr or color(255, 255, 255, 220),
            font = font,
            pos = pos or vector(),
            width = max_width,
            full_width = renderer.measure_text(font, text)
        })
    end

    function watermark:get_width(element)
        if element.width == nil or element.width == 0 then
            return element.full_width
        end
        return math.min(element.width, element.full_width)
    end

    function watermark:pad(width)
        table.insert(self.elements, {pad = width})
    end

    function watermark:separator(progress)
        if #self.elements == 0 then return end
        progress = progress or 1
        local gap = self.logo_active and self.groups == 0 and self.settings.brand_gap or self.settings.stat_gap
        self:pad(gap * progress)
        self.groups = self.groups + 1
    end

    function watermark:update(name, delay, callback)
        local now = client.unix_time()
        local state = self.updates[name]
        if not state then
            state = { timer = now }
            self.updates[name] = state
        end
        if now >= state.timer + delay then
            state.timer = now
            callback()
        end
    end

    function watermark:animate(name, visible, duration)
        local now = globals.realtime()
        local target = visible and 1 or 0
        local state = self.animations[name]
        if not state then
            state = { value = target, from = target, target = target, started = now }
            self.animations[name] = state
        end
        if state.target ~= target then
            state.from = state.value
            state.target = target
            state.started = now
        end
        local time = math.min(now - state.started, duration)
        state.value = easing.sine_in_out(time, state.from, state.target - state.from, duration)
        return state.value
    end

    function watermark:get_status_color(data)
        local value = data.value
        local previous = data.previous
        if data.inverse then
            if value <= data.danger then return self.settings.danger_color end
            if value <= data.warning then return self.settings.warning_color end
            if previous > 0 then
                local drop = previous - value
                if data.spike_danger and drop >= data.spike_danger then return self.settings.danger_color end
                if data.spike_warning and drop >= data.spike_warning then return self.settings.warning_color end
            end
        else
            if value >= data.danger then return self.settings.danger_color end
            if value >= data.warning then return self.settings.warning_color end
            if previous > 0 then
                local spike = value - previous
                if data.spike_danger and spike >= data.spike_danger then return self.settings.danger_color end
                if data.spike_warning and spike >= data.spike_warning then return self.settings.warning_color end
            end
        end
        return menu.color
    end

    local function draw_background(x, y, w, h, clr)
        local r, g, b, a = clr:unpack()
        local fade_width = 30
        local line_height = 1
        -- main background
        renderer.rectangle(x + fade_width, y, w - fade_width * 2, h - line_height, r, g, b, a)
        -- left fade
        renderer.gradient(x, y, fade_width, h - line_height, r, g, b, 0, r, g, b, a, true)
        -- right fade
        renderer.gradient(x + w - fade_width, y, fade_width, h - line_height, r, g, b, a, r, g, b, 0, true)
        -- right top fade
        renderer.gradient(x + w - fade_width, y - line_height, fade_width, line_height, r, g, b, 150, r, g, b, 0, true)
        -- left top fade
        renderer.gradient(x, y - line_height, fade_width, line_height, r, g, b, 0, r, g, b, 150, true)
        -- main top background
        renderer.rectangle(x + fade_width, y - line_height, w - fade_width * 2, line_height, r, g, b, 150)
        -- right bottom fade
        renderer.gradient(x + w - fade_width, y + h - line_height, fade_width, line_height, r, g, b, 150, r, g, b, 0, true)
        -- left bottom fade
        renderer.gradient(x, y + h - line_height, fade_width, line_height, r, g, b, 0, r, g, b, 150, true)
        -- main bottom background
        renderer.rectangle(x + fade_width, y + h - line_height, w - fade_width * 2, line_height, r, g, b, 150)
    end

    function watermark:render_text(pos)
        for i = 1, #self.elements do
            local element = self.elements[i]
            if element.pad then
                pos.x = pos.x + element.pad
            else
                local r, g, b, a = element.color:unpack()
                local width = self:get_width(element)
                renderer.text(pos.x + element.pos.x, pos.y + element.pos.y, r, g, b, a, element.font, element.width or 0, element.text)
                pos.x = pos.x + element.pos.x + width
            end
        end
    end

    function watermark:measure()
        local width = 0
        for i = 1, #self.elements do
            local element = self.elements[i]
            if element.pad then
                width = width + element.pad
            else
                width = width + element.pos.x + self:get_width(element)
            end
        end
        return width
    end

    function watermark:get_var()
        self.var = self.var or { frames = {}, index = 0 }
        local ft = globals.absoluteframetime()
        if ft > 0 then
            self.var.frames[self.var.index] = ft
            self.var.index = (self.var.index + 1) % 64
        end
        local values = {}
        local accumulated = 0
        local index = self.var.index
        for i = 0, 63 do
            index = index - 1
            if index < 0 then index = 63 end
            local frame_time = self.var.frames[index]
            if not frame_time then break end
            values[#values + 1] = frame_time
            accumulated = accumulated + frame_time
            if accumulated >= 0.5 then break end
        end
        local count = #values
        if count < 2 then return 0 end
        local mean = 0
        for i = 1, count do mean = mean + values[i] end
        mean = mean / count
        local variance = 0
        for i = 1, count do
            local diff = values[i] - mean
            variance = variance + diff * diff
        end
        variance = variance / count
        local deviation_ms = math.sqrt(variance) * 1000
        if deviation_ms < 0.5 then return 0 end
        return math.floor(deviation_ms + 0.5)
    end

    function watermark:get_ping()
        return math.floor(client.latency() * 1000 + 0.5)
    end

    function watermark:get_server_address()
        local channel = get_net_channel_info(ivengineclient)
        if channel == nil then return nil end
        local netchaninfo = ffi.cast('void***', channel)
        if netchaninfo == nil or netchaninfo[0] == nil then return nil end
        local address_fn = netchaninfo[0][1]
        if address_fn == nil then return nil end
        local get_address = ffi.cast('get_address_t', address_fn)
        local address = get_address(netchaninfo)
        if address == nil then return nil end
        address = ffi.string(address)
        if address == '' then return nil end
        if address == 'loopback' then return 'Local Server' end
        return address
    end

    function watermark:get_speed()
        local velocity = vector(entity.get_prop(entity.get_local_player(), 'm_vecVelocity'))
        local speed = velocity:length2d()
        -- desync
        if speed < 1.2 then
            speed = 0
        end
        return string.format('%d', speed)
    end

    function watermark:get_kd()
        local local_player = entity.get_local_player()
        local player_resource = entity.get_player_resource()
        if local_player == nil or player_resource == nil then return '0.0' end
        local kills = entity.get_prop(player_resource, 'm_iKills', local_player) or 0
        local deaths = entity.get_prop(player_resource, 'm_iDeaths', local_player) or 0
        if deaths == 0 then return string.format('%.1f', kills) end
        return string.format('%.1f', kills / deaths)
    end

    function watermark:get_time()
        local hour, minute, second = client.system_time()
        if menu.has('Clock') then
            local period = hour >= 12 and 'PM' or 'AM'
            hour = hour % 12
            hour = hour == 0 and 12 or hour
            return string.format('%d:%02d:%02d %s', hour, minute, second, period)
        elseif menu.has('Clock (24h)') then
            return string.format('%02d:%02d:%02d', hour, minute, second)
        end
    end

    function watermark:update_connection()
        local server = self:get_server_address()
        self.is_connected = server ~= nil and server ~= ''
        self.is_local_server = server == 'Local Server'
    end

    function watermark:build()
        self.elements = {}
        self.groups = 0
        self:update_connection()
        local clr = menu.color
        local y_text_small = 2
        if menu.dpi_scale == '125%' then
            y_text_small = 1
        elseif menu.dpi_scale == '150%' or menu.dpi_scale == '175%' then
            y_text_small = 4
        elseif menu.dpi_scale == '200%' then
            y_text_small = 5
        end
        self.logo_active = menu.has('Logo')
        if self.logo_active then
            self:push('game')
            self:push('sense', clr)
        end
        if menu.has('Username') then
            self:separator()
            self:push(self.username())
        end
        if menu.has('FPS') then
            self:separator()
            self.data.fps.accumulated = self.data.fps.accumulated + 1
            self:update('fps', 1, function()
                self.data.fps.previous = self.data.fps.value
                self.data.fps.value = self.data.fps.accumulated
                self.data.fps.accumulated = 0
            end)
            local fps_color = self:get_status_color(self.data.fps)
            self:push(self.data.fps.value, fps_color)
            self:push('FPS', color(255, 255, 255, 220), true, vector(1, y_text_small))
        end
        if menu.has('Frametime variance') then
            local current_var = self:get_var()
            self:update('delay', 1, function()
                self.data.delay.previous = self.data.delay.value
                self.data.delay.value = current_var
            end)
            local value = self.data.delay.value
            local value_text = tostring(value)
            local value_width = renderer.measure_text('d', value_text)
            local label_width = renderer.measure_text('d-', 'VAR')
            local full_width = value_width + 1 + label_width
            local progress = self:animate('var', value > 0, 0.15)
            local width = full_width * progress
            if width > 1 then
                self:separator(progress)
                local value_visible = math.min(value_width, width)
                local label_visible = math.min(label_width, math.max(width - value_width - 1, 0))
                local delay_color = self:get_status_color(self.data.delay)
                self:push(value_text, delay_color, false, nil, progress >= 0.99 and 0 or value_visible + 2)
                if label_visible > 0.5 then
                    self:push('VAR', color(255, 255, 255, 220), true, vector(1, y_text_small), progress >= 0.99 and 0 or label_visible + 2)
                end
            end
        end
        if menu.has('Ping') and self.is_connected and not self.is_local_server then
            self:separator()
            self:update('ping', 1, function()
                self.data.ping.previous = self.data.ping.value
                self.data.ping.value = self:get_ping()
            end)
            local ping_color = self:get_status_color(self.data.ping)
            self:push(self.data.ping.value, ping_color)
            self:push('PING', color(255, 255, 255, 220), true, vector(1, y_text_small))
        end
        if menu.has('Server IP') and self.is_connected then
            self:separator()
            local server = self:get_server_address()
            self:push(server)
        end
        if menu.has('Speed') and self.is_connected then
            local value = self:get_speed()
            local value_width = renderer.measure_text('d', value)
            local label_width = renderer.measure_text('d-', 'SPEED')
            local full_width = value_width + 1 + label_width
            local progress = self:animate('speed', value ~= '0', 0.15)
            local width = full_width * progress
            if width > 1 then
                self:separator(progress)
                local value_visible = math.min(value_width, width)
                local label_visible = math.min(label_width, math.max(width - value_width - 1, 0))
                self:push(value, nil, false, nil, progress >= 0.99 and 0 or value_visible + 2)
                if label_visible > 0.5 then
                    self:push('SPEED', color(255, 255, 255, 220), true, vector(1, y_text_small), progress >= 0.99 and 0 or label_visible + 2)
                end
            end
        end
        local kd = self:get_kd()
        if menu.has('K/D ratio') and self.is_connected and kd ~= '0.0' then
            self:separator()
            self:push(kd)
            self:push('K/D', color(255, 255, 255, 220), true, vector(1, y_text_small))
        end
        if menu.has('Clock') or menu.has('Clock (24h)') then
            self:separator()
            self:push(self:get_time())
        end
    end

    local dpi_scales = {
        ['100%'] = 1.00,
        ['125%'] = 1.25,
        ['150%'] = 1.50,
        ['175%'] = 1.75,
        ['200%'] = 2.00
    }

    client.set_event_callback('paint_ui', function()
        if not ui.get(menu.watermark) then return end
        watermark:build()
        if #watermark.elements == 0 then return end
        local scale = dpi_scales[menu.dpi_scale] or 1
        local factor = menu.dpi_scale == '100%' and 0.4 or 0.5
        local content_width = watermark:measure()
        local padding = 20 * scale
        local width = math.ceil(content_width + padding * 2)
        local height = math.ceil(20 * scale)
        local x = watermark.screen_size.x - math.ceil(10 * scale) - width
        local y = math.ceil(10 * scale)
        local _, text_height = renderer.measure_text('d', '0')
        local text_y = y + math.floor((height - text_height) * factor)
        draw_background(x, y, width, height, color(5, 5, 5, 90))
        watermark:render_text(vector(x + padding, text_y))
    end)
end
