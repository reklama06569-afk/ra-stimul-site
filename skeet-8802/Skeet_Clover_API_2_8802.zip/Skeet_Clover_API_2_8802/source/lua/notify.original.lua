local color = require('gamesense/color')
local easing = require('gamesense/easing')

local menu = {}
do
    menu.dpi_scale_ref = ui.reference('Misc', 'Settings', 'DPI scale')
    menu.dpi_scale = '100%'
    ui.set_callback(menu.dpi_scale_ref, function(ref)
        menu.dpi_scale = ui.get(ref)
    end)

    menu.notifications = ui.new_checkbox('LUA', 'A', 'Notifications')
    menu.events = ui.new_multiselect('LUA', 'A', 'Events', { 'Hit', 'Miss', 'Purchase' })
    menu.hit_color_label = ui.new_label('LUA', 'A', 'Hit color')
    menu.hit_color_picker = ui.new_color_picker('LUA', 'A', 'Hit color picker', 159, 202, 43, 255)
    menu.miss_color_label = ui.new_label('LUA', 'A', 'Miss color')
    menu.miss_color_picker = ui.new_color_picker('LUA', 'A', 'Miss color picker', 255, 80, 80, 255)
    menu.purchase_color_label = ui.new_label('LUA', 'A', 'Purchase color')
    menu.purchase_color_picker = ui.new_color_picker('LUA', 'A', 'Purchase color picker', 159, 202, 43, 255)

    menu.hit_color = color()
    menu.miss_color = color()
    menu.purchase_color = color()

    local selected = {}

    local function update_visibility()
        local state = ui.get(menu.notifications)
        ui.set_visible(menu.events, state)
        ui.set_visible(menu.hit_color_label, state and selected['Hit'] == true)
        ui.set_visible(menu.hit_color_picker, state and selected['Hit'] == true)
        ui.set_visible(menu.miss_color_label, state and selected['Miss'] == true)
        ui.set_visible(menu.miss_color_picker, state and selected['Miss'] == true)
        ui.set_visible(menu.purchase_color_label, state and selected['Purchase'] == true)
        ui.set_visible(menu.purchase_color_picker, state and selected['Purchase'] == true)
    end

    local function update_events(ref)
        selected = {}
        local value = ui.get(ref)
        for i = 1, #value do
            selected[value[i]] = true
        end
        update_visibility()
    end

    local function update_color(ref)
        local clr = color(ui.get(ref))
        if ref == menu.hit_color_picker then
            menu.hit_color = clr
        elseif ref == menu.miss_color_picker then
            menu.miss_color = clr
        else
            menu.purchase_color = clr
        end
    end

    ui.set_callback(menu.notifications, update_visibility)
    ui.set_callback(menu.events, update_events)
    ui.set_callback(menu.hit_color_picker, update_color)
    ui.set_callback(menu.miss_color_picker, update_color)
    ui.set_callback(menu.purchase_color_picker, update_color)

    update_events(menu.events)
    update_color(menu.hit_color_picker)
    update_color(menu.miss_color_picker)
    update_color(menu.purchase_color_picker)
    update_visibility()

    function menu.has(name)
        return selected[name] == true
    end
end

local notification = {}
do
    local function draw_background(x, y, w, h, clr)
        local r, g, b, a = clr:unpack()
        local fade_width = 30
        local line_height = 1
        -- main background
        renderer.rectangle(x + fade_width, y, w - fade_width * 2, h - line_height, r, g, b, a)
        -- left fade
        renderer.gradient(x, y, fade_width, h - line_height, r, g, b, 0, r, g, b, a, true)
        -- right fade
        renderer.gradient(x + w - fade_width, y, fade_width, h - line_height, r, g, b, a, r, g, b, 0, true)
        -- right top fade
        renderer.gradient(x + w - fade_width, y - line_height, fade_width, line_height, r, g, b, 150, r, g, b, 0, true)
        -- left top fade
        renderer.gradient(x, y - line_height, fade_width, line_height, r, g, b, 0, r, g, b, 150, true)
        -- main top background
        renderer.rectangle(x + fade_width, y - line_height, w - fade_width * 2, line_height, r, g, b, 150)
        -- right bottom fade
        renderer.gradient(x + w - fade_width, y + h - line_height, fade_width, line_height, r, g, b, 150, r, g, b, 0, true)
        -- left bottom fade
        renderer.gradient(x, y + h - line_height, fade_width, line_height, r, g, b, 0, r, g, b, 150, true)
        -- main bottom background
        renderer.rectangle(x + fade_width, y + h - line_height, w - fade_width * 2, line_height, r, g, b, 150)
    end

    notification.list = {}
    notification.fire_cache = {}
    notification.settings = {
        position = {x = 10, y = 10},
        lifetime = 7,
        reveal_time = 0.18,
        fade_time = 0.15,
        spacing = 6,
        background = color(5, 5, 5, 90),
        text = color(255, 255, 255, 220)
    }
    notification.hitgroups = {'generic', 'head', 'chest', 'stomach', 'left arm', 'right arm', 'left leg', 'right leg', 'neck', '?', 'gear'}
    notification.purchase_names = {
        ssg08 = 'SSG08', awp = 'AWP', scar20 = 'SCAR20', g3sg1 = 'G3SG1',
        deagle = 'Deagle', revolver = 'Revolver', flashbang = 'Flash',
        hegrenade = 'Grenade', smokegrenade = 'Smoke', molotov = 'Molotov',
        incgrenade = 'Molotov', decoy = 'Decoy', vest = 'Kevlar', vesthelm = 'Helmet'
    }
    notification.damage_types = {
        inferno = {'molotov', 'Molotov'},
        molotov = {'molotov', 'Molotov'},
        incgrenade = {'molotov', 'Molotov'},
        hegrenade = {'hegrenade', 'Grenade'},
        knife = {'knife', 'Knife'}
    }

    function notification:measure(parts)
        local width = 0
        for i = 1, #parts do
            width = width + renderer.measure_text('d', parts[i][1])
        end
        return width
    end

    function notification:add(parts, clr, meta)
        if #self.list >= 12 then
            table.remove(self.list, 1)
        end
        local now = globals.realtime()
        local item = {
            parts = parts,
            color = clr,
            meta = meta,
            time = now,
            reveal_from = 0,
            reveal_started = now
        }
        self.list[#self.list + 1] = item
        return item
    end

    function notification:find(callback)
        for i = #self.list, 1, -1 do
            local item = self.list[i]
            if callback(item) then return item end
        end
    end

    function notification:append(item, parts)
        for i = 1, #parts do
            item.parts[#item.parts + 1] = parts[i]
        end
        item.time = globals.realtime()
    end

    function notification:draw_text(x, y, item, alpha, max_width)
        local cr, cg, cb = item.color:unpack()
        local tr, tg, tb = self.settings.text:unpack()
        local remaining = max_width
        for i = 1, #item.parts do
            if remaining <= 0 then return end
            local part = item.parts[i]
            local width = renderer.measure_text('d', part[1])
            local r, g, b = tr, tg, tb
            if part[2] then r, g, b = cr, cg, cb end
            renderer.text(x, y, r, g, b, alpha, 'd', remaining < width and math.floor(remaining) or 0, part[1])
            x = x + width
            remaining = remaining - width
        end
    end

    function notification:get_width(item, width)
        local elapsed = globals.realtime() - item.reveal_started
        if elapsed >= self.settings.reveal_time then return width end
        return easing.sine_in_out(elapsed, item.reveal_from, width - item.reveal_from, self.settings.reveal_time)
    end

    function notification:get_alpha(item)
        local elapsed = globals.realtime() - item.time
        if elapsed <= self.settings.lifetime then return 1 end
        return easing.sine_in_out(math.min(elapsed - self.settings.lifetime, self.settings.fade_time), 1, -1, self.settings.fade_time)
    end

    function notification:purchase_parts(name, meta)
        local parts = {{name, true}, {' bought '}}
        for i = 1, #meta.order do
            local key = meta.order[i]
            local data = meta.items[key]
            if i > 1 then
                parts[#parts + 1] = {', '}
            end
            local text = data.name
            if data.count > 1 then
                text = string.format('%s[x%d]', text, data.count)
            end
            parts[#parts + 1] = {text, true}
        end
        return parts
    end

    function notification:update_purchase(player, weapon, name)
        local item = self:find(function(value)
            return value.meta ~= nil and value.meta.type == 'purchase' and value.meta.player == player
        end)
        if item == nil then return false end
        local old_width = self:measure(item.parts)
        local data = item.meta.items[weapon]
        if data then
            data.count = data.count + 1
        else
            item.meta.items[weapon] = {
                name = self.purchase_names[weapon] or weapon,
                count = 1
            }
            item.meta.order[#item.meta.order + 1] = weapon
        end
        item.parts = self:purchase_parts(name, item.meta)
        item.time = globals.realtime()
        item.reveal_from = old_width
        item.reveal_started = item.time
        return true
    end

    function notification:update_damage(target, weapon, label, damage, health, name)
        local now = globals.realtime()
        local item = self:find(function(value)
            return value.meta ~= nil and value.meta.type == 'damage' and value.meta.target == target and value.meta.weapon == weapon and now - value.meta.updated <= 1.5
        end)
        if item == nil then
            return self:add({
                {'Hit '}, {name, true}, {' with '}, {label, true}, {' for '}, {tostring(damage), true}, {' damage ('}, {tostring(health), true}, {' health remaining)'}
            }, menu.hit_color, {
                type = 'damage', target = target, weapon = weapon, damage = damage, updated = now
            })
        end
        item.meta.damage = item.meta.damage + damage
        item.meta.updated = now
        item.parts = {
            {'Hit '}, {name, true}, {' with '}, {label, true}, {' for '}, {tostring(item.meta.damage), true}, {' damage ('}, {tostring(health), true}, {' health remaining)'}
        }
        item.time = now
        return item
    end

    local dpi_scales = {
        ['100%'] = 1,
        ['125%'] = 1.25,
        ['150%'] = 1.5,
        ['175%'] = 1.75,
        ['200%'] = 2
    }

    function notification:render()
        if not ui.get(menu.notifications) then return end
        local scale = dpi_scales[menu.dpi_scale] or 1
        local factor = menu.dpi_scale == '100%' and 0.4 or 0.5
        local padding = 16 * scale
        local height = math.ceil(20 * scale)
        local offset = 0
        local _, text_height = renderer.measure_text('d', '0')
        local now = globals.realtime()
        for i = #self.list, 1, -1 do
            local item = self.list[i]
            if now - item.time > self.settings.lifetime + self.settings.fade_time then
                table.remove(self.list, i)
            else
                local text_width = self:measure(item.parts)
                local visible_width = self:get_width(item, text_width)
                local width = math.ceil(text_width + padding * 2)
                local x = self.settings.position.x
                local y = self.settings.position.y + offset
                local alpha = math.floor(self:get_alpha(item) * 255)
                local text_y = y + math.floor((height - text_height) * factor)
                draw_background(x, y, width, height, self.settings.background)
                self:draw_text(x + padding, text_y, item, alpha, visible_width)
                offset = offset + height + self.settings.spacing
            end
        end
    end

    client.set_event_callback('aim_fire', function(e)
        if not ui.get(menu.notifications) or not (menu.has('Hit') or menu.has('Miss')) then return end
        notification.fire_cache[e.id] = {
            damage = e.damage,
            hitgroup = notification.hitgroups[e.hitgroup + 1] or '?',
            hitchance = math.floor(e.hit_chance),
            history = globals.tickcount() - e.tick
        }
    end)

    client.set_event_callback('aim_hit', function(e)
        if not ui.get(menu.notifications) or not menu.has('Hit') then return end
        local fire = notification.fire_cache[e.id]
        notification.fire_cache[e.id] = nil
        if fire == nil then return end
        local name = entity.get_player_name(e.target)
        local hitgroup = notification.hitgroups[e.hitgroup + 1] or '?'
        local health = entity.get_prop(e.target, 'm_iHealth') or 0
        local item = notification:add({
            {'Hit '}, {name, true}, {' in the '}, {hitgroup, true}, {' for '}, {tostring(e.damage), true}, {' damage ('}, {tostring(health), true}, {' health remaining, '}, {tostring(fire.hitchance), true}, {'% hitchance, '}, {tostring(fire.history), true}, {'t history)'}
        }, menu.hit_color)
        if fire.damage ~= e.damage or fire.hitgroup ~= hitgroup then
            notification:append(item, {
                {' - '}, {'mismatch', true}, {' - (wanted: '}, {tostring(fire.damage), true}, {' damage, '}, {fire.hitgroup, true}, {')'}
            })
        end
    end)

    client.set_event_callback('aim_miss', function(e)
        if not ui.get(menu.notifications) or not menu.has('Miss') then return end
        local fire = notification.fire_cache[e.id]
        notification.fire_cache[e.id] = nil
        if fire == nil then return end
        local name = entity.get_player_name(e.target)
        local hitgroup = notification.hitgroups[e.hitgroup + 1] or '?'
        local item = notification:add({
            {'Missed '}, {name, true}, {' in the '}, {hitgroup, true}, {' due to '}, {e.reason, true}, {' (wanted: '}, {tostring(fire.damage), true}, {' damage, '}, {tostring(fire.hitchance), true}, {'% hitchance, '}, {tostring(fire.history), true}, {'t history)'}
        }, menu.miss_color)
        if fire.hitgroup ~= hitgroup then
            notification:append(item, {
                {' - '}, {'mismatch', true}, {' - (wanted: '}, {tostring(fire.damage), true}, {' damage, '}, {fire.hitgroup, true}, {')'}
            })
        end
    end)

    client.set_event_callback('player_hurt', function(e)
        if not ui.get(menu.notifications) or not menu.has('Hit') then return end
        local attacker = client.userid_to_entindex(e.attacker)
        if attacker ~= entity.get_local_player() then return end
        local target = client.userid_to_entindex(e.userid)
        local damage_type = notification.damage_types[e.weapon]
        if target == nil or target == 0 or damage_type == nil then return end
        notification:update_damage(target, damage_type[1], damage_type[2], e.dmg_health or 0, e.health or 0, entity.get_player_name(target))
    end)

    client.set_event_callback('item_purchase', function(e)
        if not ui.get(menu.notifications) or not menu.has('Purchase') then return end
        local player = client.userid_to_entindex(e.userid)
        if player == nil or not entity.is_enemy(player) or e.weapon == 'weapon_unknown' then return end
        local name = entity.get_player_name(player)
        local weapon = e.weapon:gsub('weapon_', '')
        if notification:update_purchase(player, weapon, name) then return end
        local meta = {
            type = 'purchase',
            player = player,
            order = {weapon},
            items = {
                [weapon] = {
                    name = notification.purchase_names[weapon] or weapon,
                    count = 1
                }
            }
        }
        notification:add(notification:purchase_parts(name, meta), menu.purchase_color, meta)
    end)

    client.set_event_callback('round_prestart', function()
        notification.list = {}
        notification.fire_cache = {}
    end)

    client.set_event_callback('paint_ui', function()
        notification:render()
    end)
end
