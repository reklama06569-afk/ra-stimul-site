-- Private dependencies for the supplied visuals; does not replace package.loaded.
local native_require = require
local color_mt = { __index = { unpack = function(self) return self[1], self[2], self[3], self[4] end } }
local function rgba(r,g,b,a) return setmetatable({r or 255,g or 255,b or 255,a or 255},color_mt) end
local easing = { sine_in_out = function(t,b,c,d) if d<=0 then return b+c end return -c*.5*(math.cos(math.pi*math.min(d,math.max(0,t))/d)-1)+b end }
local vec_mt = {__index={length2d=function(v) return math.sqrt(v.x*v.x+v.y*v.y) end}}
local function vec(x,y,z) return setmetatable({x=x or 0,y=y or 0,z=z or 0},vec_mt) end
local function require(name)
 if name=='gamesense/color' then return rgba end
 if name=='gamesense/easing' then return easing end
 if name=='vector' then return vec end
 return native_require(name)
end
-- Keep internal controls across "reload/unload all Lua" without changing global
-- ui or the user's own scripts. Explicit config loads still use native models.
local native_ui=ui
local ui=setmetatable({}, {__index=native_ui})
local ui_saved=database.read('clover.8802.ui.controls') or {}
if type(ui_saved)~='table' then ui_saved={} end
local ui_owned={}
for method,kind in pairs({new_checkbox='value',new_slider='value',new_color_picker='color',new_combobox='value',new_multiselect='multi',new_textbox='value'}) do
 local original=native_ui[method]
 if original then ui[method]=function(tab,group,name,...)
  local ref=original(tab,group,name,...);local key=method..':'..tab..':'..group..':'..name
  ui_owned[#ui_owned+1]={ref=ref,key=key,kind=kind}
  local saved=ui_saved[key]
  if type(saved)=='table' and saved.value~=nil then
   if kind=='multi' or kind=='color' then if type(saved.value)=='table' then pcall(native_ui.set,ref,unpack(saved.value)) end
   else pcall(native_ui.set,ref,saved.value) end
  end
  return ref
 end end
end
local function save_controls()
 local values={}
 for _,entry in ipairs(ui_owned) do
  local ok,a,b,c,d=pcall(native_ui.get,entry.ref)
  if ok then values[entry.key]={value=entry.kind=='color' and {a,b,c,d} or a} end
 end
 database.write('clover.8802.ui.controls',values)
end
client.set_event_callback('shutdown',save_controls)
client.set_event_callback('pre_config_save',save_controls)
