-- Legacy Source 1 world controls. No Source 2-only particles, keychains or skins.
local world={}
local function check(name) return ui.new_checkbox('VISUALS','Effects',name) end
local function slider(name,a,b,v,unit,scale) return ui.new_slider('VISUALS','Effects',name,a,b,v,true,unit or '',scale or 1) end
world.light=check('Override lighting')
world.light_color=ui.new_color_picker('VISUALS','Effects','Ambient light color',20,20,20,255)
world.fog=check('Override fog')
world.color=ui.new_color_picker('VISUALS','Effects','Fog color',170,185,205,255)
world.start=slider('Fog start',-1000,10000,0,'u')
world.finish=slider('Fog end',1,20000,1500,'u')
world.density=slider('Fog density',0,100,70,'%')
local fog_names={'fog_override','fog_start','fog_end','fog_maxdensity','fog_color','fog_enable','fog_enableskybox','fog_startskybox','fog_endskybox','fog_maxdensityskybox','fog_colorskybox'}
local originals,lighting_originals={},{}
local function save(name)
 local v=cvar[name];if not v then return end
 if originals[name]==nil then originals[name]=v:get_string() end
 return v
end
local function different(a,b) local x,y=tonumber(a),tonumber(b);if x and y then return math.abs(x-y)>.00001 end return a~=b end
local function put(name,value)
 local v=save(name);if v then
  value=tostring(value);if different(v:get_string(),value) then v:set_string(value) end
 end
end
local function restore_fog()
 for name,value in pairs(originals) do local v=cvar[name];if v then v:set_string(value) end end
 originals={}
end
local function visibility()
 ui.set_visible(world.light_color,ui.get(world.light))
 local fog=ui.get(world.fog);for _,ref in ipairs({world.color,world.start,world.finish,world.density}) do ui.set_visible(ref,fog) end
end
for _,ref in ipairs({world.light,world.fog}) do ui.set_callback(ref,visibility) end
visibility()
local legacy={}
for _,name in ipairs({'Remove fog'}) do local ok,ref=pcall(ui.reference,'VISUALS','Effects',name);if ok then legacy[name]={ref=ref} end end
local function own_legacy(name,on,off_value)
 local row=legacy[name];if not row then return end
 local value=ui.get(row.ref)
 if on then if not row.owned then row.old=value;row.owned=true end;if value~=off_value then pcall(ui.set,row.ref,off_value) end
 elseif row.owned then if value==off_value then pcall(ui.set,row.ref,row.old) end;row.owned=false end
end
local function release_legacy() for name,_ in pairs(legacy) do own_legacy(name,false,name=='Brightness adjustment' and 'Off' or false) end end
local last_update=-1
client.set_event_callback('paint_ui',function()
 local now=globals.realtime();if now-last_update<.1 then return end;last_update=now
 own_legacy('Remove fog',ui.get(world.fog),false)
 if ui.get(world.light) then
  local r,g,b=ui.get(world.light_color)
  for i,n in ipairs({'mat_ambient_light_r','mat_ambient_light_g','mat_ambient_light_b'}) do
   local v=cvar[n];if v then if lighting_originals[n]==nil then lighting_originals[n]=v:get_string() end;local value=tostring(({r,g,b})[i]/255);if different(v:get_string(),value) then v:set_string(value) end end
  end
 elseif next(lighting_originals) then for n,value in pairs(lighting_originals) do cvar[n]:set_string(value) end;lighting_originals={} end
 if ui.get(world.fog) then
  local r,g,b=ui.get(world.color);local rgb=string.format('%d %d %d',r,g,b)
  local start=ui.get(world.start);local finish=math.max(start+1,ui.get(world.finish));local density=ui.get(world.density)/100
  put('fog_override',1);put('fog_enable',1);put('fog_enableskybox',1)
  put('fog_start',start);put('fog_end',finish);put('fog_maxdensity',density);put('fog_color',rgb)
  put('fog_startskybox',start);put('fog_endskybox',finish);put('fog_maxdensityskybox',density);put('fog_colorskybox',rgb)
 else if next(originals) then restore_fog() end end
end)
client.set_event_callback('level_init',function() originals={};lighting_originals={};last_update=-1 end)
client.set_event_callback('shutdown',function() release_legacy();restore_fog();for n,value in pairs(lighting_originals) do cvar[n]:set_string(value) end end)
