433e7f74 mov      eax, dword ptr [0x434798bc]
433e7f79 mov      edx, 0x434798bc
433e7f7e jmp      0x433e7f87
433e7f80 cmp      dword ptr [eax + 8], ecx
433e7f83 je       0x433e7f8d
433e7f85 mov      eax, dword ptr [eax]
433e7f87 cmp      eax, edx
433e7f89 jne      0x433e7f80
433e7f8b xor      eax, eax
433e7f8d ret      
