4338a892 push     ecx
4338a893 sub      ecx, -0x80
4338a896 mov      dword ptr [esp], ecx
4338a899 mov      ecx, 0x9fe6b136
4338a89e push     edi
4338a89f call     0x433ae8b7
4338a8a4 mov      edi, eax
4338a8a6 test     edi, edi
4338a8a8 je       0x4338a931
4338a8ae mov      edx, dword ptr [edi]
4338a8b0 mov      ecx, edi
4338a8b2 push     ebx
4338a8b3 push     esi
4338a8b4 call     dword ptr [edx + 0xc]
4338a8b7 mov      ebx, eax
4338a8b9 xor      esi, esi
4338a8bb test     ebx, ebx
4338a8bd jle      0x4338a92f
4338a8bf push     ebp
4338a8c0 mov      ecx, dword ptr [edi]
4338a8c2 push     esi
4338a8c3 mov      edx, dword ptr [ecx + 0x24]
4338a8c6 mov      ecx, edi
4338a8c8 call     edx
4338a8ca mov      edx, eax
4338a8cc test     edx, edx
4338a8ce je       0x4338a929
4338a8d0 mov      ecx, edx
4338a8d2 lea      ebp, [ecx + 1]
4338a8d5 mov      al, byte ptr [ecx]
4338a8d7 inc      ecx
4338a8d8 test     al, al
4338a8da jne      0x4338a8d5
4338a8dc sub      ecx, ebp
4338a8de cmp      ecx, 0x13
4338a8e1 jbe      0x4338a929
4338a8e3 cmp      dword ptr [edx + 0xf], 0x6e6b5f76
4338a8ea jne      0x4338a929
4338a8ec mov      ecx, edx
4338a8ee call     0x43359c70
4338a8f3 mov      ebp, dword ptr [esp + 0x10]
4338a8f7 mov      edx, ebp
4338a8f9 lea      ecx, [ebp + 0x2a0]
4338a8ff cmp      ebp, ecx
4338a901 je       0x4338a929
4338a903 cmp      dword ptr [edx + 4], eax
4338a906 je       0x4338a911
4338a908 add      edx, 0x20
4338a90b cmp      edx, ecx
4338a90d jne      0x4338a903
4338a90f jmp      0x4338a929
4338a911 lea      eax, [esi + 1]
4338a914 mov      dword ptr [edx + 0x1c], esi
4338a917 add      eax, dword ptr [edx + 0x10]
4338a91a mov      dword ptr [edx + 0x14], eax
4338a91d lea      eax, [esi + 2]
4338a920 add      eax, dword ptr [edx + 0x10]
4338a923 add      esi, 2
4338a926 mov      dword ptr [edx + 0x18], eax
4338a929 inc      esi
4338a92a cmp      esi, ebx
4338a92c jl       0x4338a8c0
4338a92e pop      ebp
4338a92f pop      esi
4338a930 pop      ebx
4338a931 pop      edi
4338a932 pop      ecx
4338a933 ret      
