4331eb65 push     ecx
4331eb66 push     ebx
4331eb67 push     ebp
4331eb68 push     esi
4331eb69 push     edi
4331eb6a mov      edi, ecx
4331eb6c cmp      dword ptr [edi + 0x84], -1
4331eb73 je       0x4331ec98
4331eb79 mov      ecx, dword ptr [0x4346a514]
4331eb7f mov      eax, dword ptr [ecx]
4331eb81 call     dword ptr [eax + 0x68]
4331eb84 test     al, al
4331eb86 je       0x4331ec4e
4331eb8c mov      ebx, dword ptr [0x43475808]
4331eb92 test     ebx, ebx
4331eb94 je       0x4331ec4e
4331eb9a mov      eax, dword ptr [0x43468968]
4331eb9f mov      esi, dword ptr [eax]
4331eba1 xor      esi, dword ptr [0x43467ea0]
4331eba7 xor      esi, 0xe96443c6
4331ebad mov      ecx, dword ptr [esi + ebx]
4331ebb0 cmp      ecx, -1
4331ebb3 je       0x4331ec4e
4331ebb9 cmp      ecx, dword ptr [edi + 0x84]
4331ebbf jne      0x4331ec4e
4331ebc5 mov      eax, dword ptr [0x4346a890]
4331ebca push     ecx
4331ebcb mov      eax, dword ptr [eax]
4331ebcd mov      edx, dword ptr [eax + 0x10]
4331ebd0 mov      eax, esp
4331ebd2 mov      dword ptr [eax], ecx
4331ebd4 mov      ecx, dword ptr [0x4346a890]
4331ebda call     edx
4331ebdc mov      ebp, eax
4331ebde test     ebp, ebp
4331ebe0 je       0x4331ec4a
4331ebe2 mov      dword ptr [esp + 0x10], 0x94de6991
4331ebea mov      edx, ebp
4331ebec mov      eax, dword ptr [esp + 0x10]
4331ebf0 mov      ecx, dword ptr [ebp]
4331ebf3 add      eax, 0x5e246aed
4331ebf8 ror      eax, 0x11
4331ebfb push     0
4331ebfd push     ebx
4331ebfe mov      ecx, dword ptr [eax + ecx - 0x6a3f752d]
4331ec05 mov      dword ptr [esp + 0x18], ecx
4331ec09 call     0x433e533f
4331ec0e mov      dword ptr [esp + 0x10], 0xa008b771
4331ec16 mov      edx, ebp
4331ec18 mov      eax, dword ptr [esp + 0x10]
4331ec1c mov      ecx, dword ptr [ebp]
4331ec1f rol      eax, 0xf
4331ec22 add      eax, 0x2d432ffb
4331ec27 bswap    eax
4331ec29 sub      ecx, eax
4331ec2b push     ebx
4331ec2c mov      ecx, dword ptr [ecx]
4331ec2e call     0x433e533f
4331ec33 mov      eax, dword ptr [0x43468fec]
4331ec38 mov      eax, dword ptr [eax]
4331ec3a xor      eax, dword ptr [0x4346a3c4]
4331ec40 xor      eax, 0xa2a8247f
4331ec45 and      dword ptr [eax + ebx - 4], 0
4331ec4a or       dword ptr [esi + ebx], 0xffffffff
4331ec4e mov      ecx, dword ptr [edi + 0x84]
4331ec54 cmp      ecx, -1
4331ec57 je       0x4331ec91
4331ec59 mov      eax, dword ptr [0x4346a890]
4331ec5e push     ecx
4331ec5f mov      eax, dword ptr [eax]
4331ec61 mov      edx, dword ptr [eax + 0x10]
4331ec64 mov      eax, esp
4331ec66 mov      dword ptr [eax], ecx
4331ec68 mov      ecx, dword ptr [0x4346a890]
4331ec6e call     edx
4331ec70 test     eax, eax
4331ec72 je       0x4331ec91
4331ec74 mov      edx, dword ptr [eax]
4331ec76 mov      ecx, eax
4331ec78 call     dword ptr [edx + 0x10]
4331ec7b mov      esi, eax
4331ec7d test     esi, esi
4331ec7f je       0x4331ec91
4331ec81 mov      edx, dword ptr [esi]
4331ec83 mov      ecx, esi
4331ec85 push     1
4331ec87 call     dword ptr [edx + 0xc]
4331ec8a mov      edx, dword ptr [esi]
4331ec8c mov      ecx, esi
4331ec8e call     dword ptr [edx + 4]
4331ec91 or       dword ptr [edi + 0x84], 0xffffffff
4331ec98 pop      edi
4331ec99 pop      esi
4331ec9a pop      ebp
4331ec9b pop      ebx
4331ec9c pop      ecx
4331ec9d ret      
