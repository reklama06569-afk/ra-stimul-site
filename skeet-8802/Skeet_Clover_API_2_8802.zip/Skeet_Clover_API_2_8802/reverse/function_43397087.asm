43397087 push     ebp
43397088 mov      ebp, esp
4339708a push     ecx
4339708b mov      edx, dword ptr [0x4346a31c]
43397091 push     dword ptr [ebp + 8]
43397094 mov      dword ptr [ebp - 4], 0x1c932998
4339709b mov      eax, dword ptr [ebp - 4]
4339709e mov      ecx, dword ptr [edx]
433970a0 ror      eax, 0x1f
433970a3 add      eax, 0x432b67bf
433970a8 xor      eax, 0x7c51bac3
433970ad mov      ecx, dword ptr [eax + ecx]
433970b0 call     0x433e533f
433970b5 leave    
433970b6 ret      4
