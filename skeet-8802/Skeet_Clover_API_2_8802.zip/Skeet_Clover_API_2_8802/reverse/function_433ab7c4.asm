433ab7c4 push     ebp
433ab7c5 mov      ebp, esp
433ab7c7 push     ebx
433ab7c8 push     esi
433ab7c9 mov      esi, ecx
433ab7cb xor      ecx, ecx
433ab7cd mov      bl, cl
433ab7cf mov      eax, dword ptr [esi + 0x10c]
433ab7d5 mov      eax, dword ptr [eax + 0x5c]
433ab7d8 test     eax, eax
433ab7da je       0x433ab7de
433ab7dc mov      bl, byte ptr [eax]
433ab7de mov      eax, dword ptr [ebp + 8]
433ab7e1 dec      eax
433ab7e2 push     ecx
433ab7e3 sub      eax, 1
433ab7e6 je       0x433ab814
433ab7e8 sub      eax, 1
433ab7eb je       0x433ab7fe
433ab7ed mov      ecx, dword ptr [esi + 0x114]
433ab7f3 call     0x433e000b
433ab7f8 mov      byte ptr [ebp + 8], 0
433ab7fc jmp      0x433ab822
433ab7fe mov      ecx, dword ptr [esi + 0x110]
433ab804 call     0x433e000b
433ab809 mov      ecx, dword ptr [esi + 0x114]
433ab80f mov      byte ptr [ebp + 8], bl
433ab812 jmp      0x433ab828
433ab814 mov      ecx, dword ptr [esi + 0x114]
433ab81a call     0x433e000b
433ab81f mov      byte ptr [ebp + 8], bl
433ab822 mov      ecx, dword ptr [esi + 0x110]
433ab828 push     dword ptr [ebp + 8]
433ab82b call     0x433e000b
433ab830 pop      esi
433ab831 pop      ebx
433ab832 pop      ebp
433ab833 ret      4
