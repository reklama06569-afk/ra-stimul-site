43367633 push     ebp
43367634 mov      ebp, esp
43367636 sub      esp, 0x10
43367639 movaps   xmm2, xmm0
4336763c ucomiss  xmm2, xmm2
4336763f lahf     
43367640 test     ah, 0x44
43367643 jnp      0x4336764a
43367645 movaps   xmm0, xmm1
43367648 leave    
43367649 ret      
4336764a ucomiss  xmm1, xmm1
4336764d lahf     
4336764e test     ah, 0x44
43367651 jp       0x43367695
43367653 xorps    xmm3, xmm3
43367656 xorps    xmm0, xmm0
43367659 cvtss2sd xmm3, xmm2
4336765d cvtss2sd xmm0, xmm1
43367661 movsd    qword ptr [ebp - 0x10], xmm3
43367666 mov      eax, dword ptr [ebp - 0xc]
43367669 movsd    qword ptr [ebp - 8], xmm0
4336766e mov      ecx, dword ptr [ebp - 4]
43367671 shr      ecx, 0x1f
43367674 shr      eax, 0x1f
43367677 cmp      al, cl
43367679 je       0x4336768e
4336767b movsd    qword ptr [ebp - 0x10], xmm3
43367680 test     dword ptr [ebp - 0xc], 0x80000000
43367687 jne      0x43367692
43367689 movaps   xmm2, xmm1
4336768c jmp      0x43367692
4336768e minss    xmm2, xmm1
43367692 movaps   xmm0, xmm2
43367695 leave    
43367696 ret      
