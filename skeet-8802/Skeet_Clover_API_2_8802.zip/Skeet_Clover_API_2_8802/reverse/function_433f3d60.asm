433f3d60 and      al, 8
433f3d62 push     esi
433f3d63 call     0x43434771
433f3d68 pop      ecx
433f3d69 cmp      eax, 4
433f3d6c jl       0x433f3dbe
433f3d6e push     4
433f3d70 pop      edx
433f3d71 mov      ecx, esi
433f3d73 call     0x433e8dc7
433f3d78 test     eax, eax
433f3d7a je       0x433f3dbe
433f3d7c push     ebx
433f3d7d push     ebp
433f3d7e push     edi
433f3d7f push     1
433f3d81 push     esi
433f3d82 call     0x43425031
433f3d87 push     2
433f3d89 push     esi
433f3d8a mov      edi, eax
433f3d8c call     0x43425031
433f3d91 push     3
433f3d93 push     esi
433f3d94 mov      ebx, eax
433f3d96 call     0x43425031
433f3d9b push     4
433f3d9d push     esi
433f3d9e mov      ebp, eax
433f3da0 call     0x43425031
433f3da5 mov      ecx, dword ptr [0x43475a20]
433f3dab add      esp, 0x20
433f3dae test     ecx, ecx
433f3db0 je       0x433f3dbb
433f3db2 push     eax
433f3db3 push     ebp
433f3db4 push     ebx
433f3db5 push     edi
433f3db6 call     0x433f2ae2
433f3dbb pop      edi
433f3dbc pop      ebp
433f3dbd pop      ebx
433f3dbe xor      eax, eax
433f3dc0 pop      esi
433f3dc1 ret      
