433ce4bb sub      esp, 0x1c
433ce4bf mov      eax, dword ptr [0x434757dc]
433ce4c4 push     esi
433ce4c5 mov      esi, dword ptr [ecx + 0x104]
433ce4cb inc      esi
433ce4cc mov      dword ptr [esp + 0x1c], edx
433ce4d0 mov      eax, dword ptr [eax]
433ce4d2 add      eax, esi
433ce4d4 mov      dword ptr [esp + 0x18], ecx
433ce4d8 mov      esi, ecx
433ce4da mov      dword ptr [edx + 0x1e0], eax
433ce4e0 mov      eax, dword ptr [esi + 0x104]
433ce4e6 cmp      eax, dword ptr [esi + 0xfc]
433ce4ec jl       0x433ce4f6
433ce4ee mov      eax, dword ptr [esi + 0xf4]
433ce4f4 jmp      0x433ce4f8
433ce4f6 xor      eax, eax
433ce4f8 mov      ecx, dword ptr [esp + 0x1c]
433ce4fc mov      dword ptr [edx + 0x1d4], eax
433ce502 mov      eax, dword ptr [edx + 0xc8]
433ce508 mov      dword ptr [edx + 0x1d8], eax
433ce50e mov      dword ptr [edx + 0xcc], eax
433ce514 mov      eax, dword ptr [edx + 0xac]
433ce51a push     edi
433ce51b mov      edi, dword ptr [esi + 0x14]
433ce51e shl      edi, 0x19
433ce521 xor      edi, dword ptr [edx]
433ce523 and      edi, 0x40000000
433ce529 xor      edi, dword ptr [edx]
433ce52b mov      dword ptr [edx], edi
433ce52d sub      eax, dword ptr [esi + 0x128]
433ce533 cdq      
433ce534 xor      eax, edx
433ce536 sub      eax, edx
433ce538 cmp      eax, 0xa
433ce53b jge      0x433ce545
433ce53d or       edi, 0x8000000
433ce543 mov      dword ptr [ecx], edi
433ce545 cmp      dword ptr [esi + 0xf4], 0
433ce54c je       0x433ce86b
433ce552 movd     xmm0, dword ptr [0x43468290]
433ce55a xorps    xmm6, xmm6
433ce55d movss    xmm3, dword ptr [0x434720f8]
433ce565 cvtdq2ps xmm0, xmm0
433ce568 movss    xmm4, dword ptr [0x43470514]
433ce570 divss    xmm0, xmm3
433ce574 movaps   xmm2, xmm0
433ce577 movss    dword ptr [esp + 0xc], xmm0
433ce57d movaps   xmm0, xmm6
433ce580 maxss    xmm2, xmm0
433ce584 movaps   xmm0, xmm4
433ce587 minss    xmm2, xmm0
433ce58b call     0x43385d57
433ce590 mov      esi, eax
433ce592 call     0x4340c3fa
433ce597 add      esi, eax
433ce599 movss    xmm5, dword ptr [0x43472240]
433ce5a1 mov      eax, dword ptr [0x4346a338]
433ce5a6 mov      edx, dword ptr [esp + 0x20]
433ce5aa divss    xmm2, dword ptr [eax]
433ce5ae addss    xmm2, xmm5
433ce5b2 cvttss2si ecx, xmm2
433ce5b6 add      esi, ecx
433ce5b8 mov      dword ptr [edx + 0x1d8], esi
433ce5be mov      esi, dword ptr [esp + 0x1c]
433ce5c2 mov      eax, dword ptr [esi + 0xfc]
433ce5c8 mov      dword ptr [esp + 0x18], eax
433ce5cc cmp      dword ptr [esi + 0x104], eax
433ce5d2 jl       0x433ce6eb
433ce5d8 mov      eax, dword ptr [edx + 0xc]
433ce5db mov      dword ptr [esp + 0xc], eax
433ce5df test     eax, eax
433ce5e1 je       0x433ce6eb
433ce5e7 movd     xmm2, dword ptr [0x43468290]
433ce5ef movaps   xmm0, xmm6
433ce5f2 cvtdq2ps xmm2, xmm2
433ce5f5 divss    xmm2, xmm3
433ce5f9 movaps   xmm3, xmm2
433ce5fc movss    dword ptr [esp + 0x10], xmm2
433ce602 maxss    xmm3, xmm0
433ce606 movaps   xmm0, xmm4
433ce609 minss    xmm3, xmm0
433ce60d call     0x4340c3fa
433ce612 mov      esi, eax
433ce614 mov      eax, dword ptr [0x4346a338]
433ce619 movss    xmm4, dword ptr [eax]
433ce61d call     0x43385d57
433ce622 movaps   xmm0, xmm3
433ce625 movss    dword ptr [esp + 8], xmm2
433ce62b divss    xmm0, xmm4
433ce62f add      eax, esi
433ce631 mov      dword ptr [esp + 0x14], eax
433ce635 addss    xmm0, xmm5
433ce639 cvttss2si ecx, xmm0
433ce63d mov      dword ptr [esp + 0x10], ecx
433ce641 call     0x43385d57
433ce646 divss    xmm3, xmm4
433ce64a lea      edx, [esi + 1]
433ce64d mov      esi, dword ptr [esp + 0x28]
433ce651 add      edx, eax
433ce653 addss    xmm3, xmm5
433ce657 cvttss2si ecx, xmm3
433ce65b sub      ecx, dword ptr [esp + 0x18]
433ce65f add      edx, ecx
433ce661 mov      dword ptr [esp + 0x18], edx
433ce665 test     esi, esi
433ce667 jne      0x433ce675
433ce669 jnp      0x433ce6b1
433ce66b mov      ecx, es
433ce66d mov      bl, 0xe9
433ce66f jo       0x433ce5f1
433ce671 cli      
433ce672 stosd    dword ptr es:[edi], eax
433ce673 test     al, 0x65
433ce675 mov      eax, dword ptr [0x4346a80c]
433ce67a mov      edx, dword ptr [esp + 0x10]
433ce67e dec      edx
433ce67f mov      ecx, dword ptr [eax]
433ce681 mov      eax, dword ptr [esp + 0x14]
433ce685 xor      ecx, dword ptr [0x43469208]
433ce68b add      eax, edx
433ce68d mov      edx, dword ptr [esp + 0x18]
433ce691 xor      ecx, 0xde530a8b
433ce697 movd     xmm1, eax
433ce69b cvtdq2ps xmm1, xmm1
433ce69e mulss    xmm1, xmm4
433ce6a2 comiss   xmm1, dword ptr [ecx + esi]
433ce6a6 jb       0x433ce6e3
433ce6a8 movd     xmm0, edx
433ce6ac cvtdq2ps xmm0, xmm0
433ce6af mulss    xmm0, xmm4
433ce6b1 pop      ecx
433ce6b2 les      ecx, ptr [edi]
433ce6b3 comiss   xmm0, dword ptr [ecx + esi]
433ce6b4 das      
433ce6b5 add      al, 0x31
433ce6b7 jae      0x433ce6e3
433ce6b9 mov      eax, dword ptr [0x43467a50]
433ce6be mov      ecx, dword ptr [esp + 0xc]
433ce6c2 mov      eax, dword ptr [eax]
433ce6c4 xor      eax, dword ptr [0x4346a458]
433ce6ca xor      eax, 0xf71ce331
433ce6cf comiss   xmm1, dword ptr [eax + ecx]
433ce6d3 jb       0x433ce6e3
433ce6d5 mov      edx, dword ptr [esp + 0x20]
433ce6d9 or       edi, 0x4000000
433ce6df mov      dword ptr [edx], edi
433ce6e1 jmp      0x433ce6e7
433ce6e3 mov      edx, dword ptr [esp + 0x20]
433ce6e7 mov      esi, dword ptr [esp + 0x1c]
433ce6eb cmp      dword ptr [esi + 0xf4], 2
433ce6f2 jne      0x433ce7a8
433ce6f8 mov      eax, dword ptr [esi + 0x104]
433ce6fe cmp      eax, dword ptr [esi + 0xfc]
433ce704 jl       0x433ce7a8
433ce70a test     edi, 0x20000000
433ce710 jne      0x433ce7a8
433ce716 mov      eax, dword ptr [edx + 0xd8]
433ce71c cmp      eax, 0x31
433ce71f je       0x433ce7a8
433ce725 cmp      eax, 0x40
433ce728 je       0x433ce7a8
433ce72a cmp      byte ptr [edx + 0x124], 9
433ce731 je       0x433ce7a8
433ce733 mov      eax, dword ptr [esi + 0x14]
433ce736 or       eax, 0x10
433ce739 mov      ecx, dword ptr [esi + 0x114]
433ce73f mov      dword ptr [esi + 0x14], eax
433ce742 mov      dword ptr [esp + 0x28], eax
433ce746 mov      eax, dword ptr [0x43467eb8]
433ce74b movss    xmm0, dword ptr [eax]
433ce74f mov      eax, dword ptr [0x4346a338]
433ce754 divss    xmm0, dword ptr [eax]
433ce758 addss    xmm0, xmm5
433ce75c cvttss2si edi, xmm0
433ce760 lea      eax, [edi + 2]
433ce763 cmp      eax, ecx
433ce765 jg       0x433ce784
433ce767 sub      ecx, edi
433ce769 cmp      ecx, 0x10
433ce76c jge      0x433ce784
433ce76e mov      eax, dword ptr [0x43475b2c]
433ce773 mov      ecx, dword ptr [esi + 0x108]
433ce779 cmp      ecx, dword ptr [eax]
433ce77b jne      0x433ce784
433ce77d test     byte ptr [esp + 0x28], 2
433ce782 jne      0x433ce7a8
433ce784 mov      eax, dword ptr [0x434759c0]
433ce789 mov      edi, dword ptr [esp + 0x2c]
433ce78d and      eax, 0xfffffbff
433ce792 or       eax, 0x200
433ce797 mov      dword ptr [0x434759c0], eax
433ce79c test     byte ptr [edx + 0x44], 1
433ce7a0 je       0x433ce7ac
433ce7a2 and      dword ptr [edi + 0x30], 0xfffffffe
433ce7a6 jmp      0x433ce7ac
433ce7a8 mov      edi, dword ptr [esp + 0x2c]
433ce7ac cmp      dword ptr [esi + 0xf4], 3
433ce7b3 jne      0x433ce867
433ce7b9 mov      eax, dword ptr [esi + 0x104]
433ce7bf cmp      eax, dword ptr [esi + 0xfc]
433ce7c5 jl       0x433ce867
433ce7cb call     0x433df22c
433ce7d0 test     al, al
433ce7d2 jne      0x433ce867
433ce7d8 mov      eax, dword ptr [esi + 0x14]
433ce7db test     al, 0x20
433ce7dd jne      0x433ce803
433ce7df test     dword ptr [edx], 0x20000000
433ce7e5 jne      0x433ce803
433ce7e7 or       eax, 0x10
433ce7ea mov      dword ptr [esi + 0x14], eax
433ce7ed mov      eax, dword ptr [0x434759c0]
433ce7f2 and      eax, 0xfffffbff
433ce7f7 or       eax, 0x200
433ce7fc mov      dword ptr [0x434759c0], eax
433ce801 jmp      0x433ce867
433ce803 mov      eax, dword ptr [edi + 4]
433ce806 lea      ecx, [esi + 0x138]
433ce80c cdq      
433ce80d xor      eax, edx
433ce80f mov      dword ptr [edi + 0xc], 0x42b20000
433ce816 and      dword ptr [ecx + 4], 0
433ce81a sub      eax, edx
433ce81c neg      eax
433ce81e mov      dword ptr [ecx], eax
433ce820 call     0x43387e35
433ce825 movd     xmm0, eax
433ce829 cvtdq2pd xmm0, xmm0
433ce82d mulsd    xmm0, qword ptr [0x4346fb70]
433ce835 cvtpd2ps xmm1, xmm0
433ce839 cvtps2pd xmm0, xmm1
433ce83c comisd   xmm0, xmmword ptr [0x4346fed8]
433ce844 jbe      0x433ce84e
433ce846 movss    xmm1, dword ptr [0x4346f980]
433ce84e addss    xmm1, xmm6
433ce852 mulss    xmm1, dword ptr [0x43471f88]
433ce85a subss    xmm1, dword ptr [0x434725e4]
433ce862 movss    dword ptr [edi + 0x10], xmm1
433ce867 mov      ecx, dword ptr [esp + 0x20]
433ce86b cmp      dword ptr [ecx + 0x1d4], 2
433ce872 pop      edi
433ce873 jne      0x433ce8ab
433ce875 mov      eax, dword ptr [esi + 0x104]
433ce87b cmp      eax, dword ptr [esi + 0xfc]
433ce881 jl       0x433ce8a4
433ce883 test     dword ptr [ecx], 0x20000000
433ce889 jne      0x433ce8a4
433ce88b mov      eax, dword ptr [ecx + 0xd8]
433ce891 cmp      eax, 0x31
433ce894 je       0x433ce8a4
433ce896 cmp      eax, 0x40
433ce899 je       0x433ce8a4
433ce89b cmp      byte ptr [ecx + 0x124], 9
433ce8a2 jne      0x433ce8ab
433ce8a4 and      dword ptr [ecx + 0x1d4], 0
433ce8ab pop      esi
433ce8ac add      esp, 0x1c
433ce8af ret      8
