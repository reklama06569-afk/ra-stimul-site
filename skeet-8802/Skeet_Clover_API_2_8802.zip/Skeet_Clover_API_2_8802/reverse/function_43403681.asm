43403681 push     ebp
43403682 mov      ebp, esp
43403684 and      esp, 0xfffffff8
43403687 sub      esp, 0x68
4340368a push     esi
4340368b push     edi
4340368c mov      edi, edx
4340368e mov      dword ptr [esp + 0x10], ecx
43403692 mov      dword ptr [esp + 0x18], edi
43403696 test     edi, edi
43403698 jne      0x434036a6
4340369a pushfd   
4340369b movsd    dword ptr es:[edi], dword ptr [esi]
4340369c xor      byte ptr [edi - 0xe], 0xe8
434036a0 mov      ebp, 0x8feb4d5a
434036a5 retf     0x74a1
434036a6 mov      eax, dword ptr [0x43467a74]
434036ab mov      eax, dword ptr [eax]
434036ad xor      eax, dword ptr [0x434678c0]
434036b3 xor      eax, 0xcd812654
434036b8 mov      esi, dword ptr [eax + edi]
434036bb cmp      esi, -1
434036be je       0x434037b3
434036c4 mov      eax, dword ptr [0x4346a890]
434036c9 push     ecx
434036ca mov      eax, dword ptr [eax]
434036cc mov      edx, dword ptr [eax + 0x10]
434036cf mov      eax, esp
434036d1 mov      dword ptr [eax], esi
434036d3 mov      ecx, dword ptr [0x4346a890]
434036d9 call     edx
434036db mov      esi, eax
434036dd test     esi, esi
434036df je       0x434037af
434036e5 mov      ecx, dword ptr [0x4346a340]
434036eb mov      ecx, dword ptr [ecx]
434036ed xor      ecx, dword ptr [0x43467dd8]
434036f3 xor      ecx, 0x1aa449d
434036f9 cmp      dword ptr [ecx + esi], 2
434036fd jne      0x434037af
43403703 mov      eax, dword ptr [0x43468d48]
43403708 mov      ecx, edi
4340370a mov      eax, dword ptr [eax]
4340370c xor      eax, dword ptr [0x43467e94]
43403712 xor      eax, 0xc6c78c82
43403717 push     dword ptr [eax + esi]
4340371a call     0x43342dd7
4340371f mov      dword ptr [esp + 0x48], eax
43403723 test     eax, eax
43403725 je       0x434037af
4340372b mov      ecx, dword ptr [0x43468a98]
43403731 mov      ecx, dword ptr [ecx]
43403733 xor      ecx, dword ptr [0x43467e78]
43403739 xor      ecx, 0xa116369a
4340373f mov      ecx, dword ptr [ecx + eax]
43403742 cmp      ecx, -1
43403745 je       0x434037af
43403747 mov      eax, dword ptr [0x4346a890]
4340374c push     ecx
4340374d mov      eax, dword ptr [eax]
4340374f mov      edx, dword ptr [eax + 0x10]
43403752 mov      eax, esp
43403754 mov      dword ptr [eax], ecx
43403756 mov      ecx, dword ptr [0x4346a890]
4340375c call     edx
4340375e test     eax, eax
43403760 je       0x434037af
43403762 cmp      esi, eax
43403764 jne      0x434037af
43403766 mov      eax, dword ptr [0x43467abc]
4340376b mov      ecx, dword ptr [esp + 0x48]
4340376f mov      eax, dword ptr [eax]
43403771 xor      eax, dword ptr [0x4346a56c]
43403777 xor      eax, 0xa25d8271
4340377c cmp      dword ptr [eax + ecx], 0
43403780 jl       0x434037af
43403782 push     dword ptr [eax + ecx]
43403785 call     0x433880f9
4340378a cmp      eax, 0xb7
4340378f je       0x43403798
43403791 cmp      eax, 0x1fa
43403796 jne      0x434037af
43403798 mov      ecx, dword ptr [0x4346828c]
4340379e mov      ecx, dword ptr [ecx]
434037a0 xor      ecx, dword ptr [0x43468d2c]
434037a6 xor      ecx, 0x9e2078a1
434037ac mov      dword ptr [ecx + esi], eax
434037af mov      ecx, dword ptr [esp + 0x10]
434037b3 cmp      dword ptr [ebp + 8], 0
434037b7 jne      0x4340380a
434037b9 cmp      dword ptr [0x4347c9ec], 2
434037c0 je       0x4340380a
434037c2 mov      eax, dword ptr [ecx + 0x50]
434037c5 mov      esi, 0x96
434037ca mov      edx, esi
434037cc or       edi, 0xffffffff
434037cf mov      dword ptr [eax], edi
434037d1 lea      eax, [eax + 0xc]
434037d4 sub      edx, 1
434037d7 jne      0x434037cf
434037d9 mov      eax, dword ptr [ecx + 0x54]
434037dc mov      dword ptr [eax], edi
434037de lea      eax, [eax + 0x90]
434037e4 sub      esi, 1
434037e7 jne      0x434037dc
434037e9 and      dword ptr [ecx + 0x2c], esi
434037ec and      dword ptr [ecx + 0x30], esi
434037ef and      dword ptr [ecx + 0x34], esi
434037f2 and      dword ptr [ecx + 0x38], esi
434037f5 mov      dword ptr [ecx + 0x28], 0x3f800000
434037fc mov      dword ptr [ecx + 0x48], edi
434037ff mov      dword ptr [0x43467114], edi
43403805 jmp      0x43405c5d
4340380a test     edi, edi
4340380c jne      0x4340381a
4340381a mov      eax, dword ptr [0x43468e78]
4340381f mov      eax, dword ptr [eax]
43403821 xor      eax, dword ptr [0x434684e4]
43403827 xor      eax, 0x9d920e35
4340382c cmp      byte ptr [eax + edi], 0
43403830 jne      0x43405c5d
43403836 mov      ecx, dword ptr [ecx + 0x1c]
43403839 mov      eax, dword ptr [ecx]
4340383b call     dword ptr [eax + 0x334]
43403841 mov      ecx, dword ptr [0x43475794]
43403847 mov      dword ptr [esp + 0x20], eax
4340384b sub      eax, dword ptr [ecx]
4340384d mov      dword ptr [esp + 0x28], eax
43403851 test     edi, edi
43403853 jne      0x43403861
43403855 ja       0x43403879
43403857 cmp      ecx, esp
43403859 fnsave   dword ptr [edx]
4340385b fbstp    tbyte ptr [ecx]
4340385d dec      dl
4340385f sub      al, byte ptr [eax - 0x5f]
43403861 mov      eax, dword ptr [0x434682b8]
43403862 mov      eax, 0x8b434682
43403866 mov      eax, dword ptr [eax]
43403867 add      byte ptr [ebx], dh
43403868 xor      eax, dword ptr [0x43467d90]
43403869 add      eax, 0x43467d90
4340386e xor      eax, 0x1bae1168
43403873 add      eax, edi
43403875 mov      dword ptr [esp + 0x54], eax
43403879 movss    xmm0, dword ptr [eax]
4340387d movss    dword ptr [esp + 0x5c], xmm0
43403883 test     edi, edi
43403885 jne      0x43403893
43403887 xchg     ecx, eax
43403888 or       dword ptr [ebx + esi*2 + 5], ebx
4340388c lodsd    eax, dword ptr [esi]
4340388d sub      dword ptr [edi + 0x58b3f5a3], edx
43403893 mov      edx, dword ptr [esp + 0x10]
43403897 mov      eax, dword ptr [edx + 0x3c]
4340389a mov      dword ptr [esp + 0x2c], eax
4340389e mov      eax, dword ptr [0x434693d8]
434038a3 mov      eax, dword ptr [eax]
434038a5 xor      eax, dword ptr [0x43468bc4]
434038ab xor      eax, 0x3d10b94c
434038b0 mov      ecx, dword ptr [eax + edi]
434038b3 mov      dword ptr [esp + 0x3c], ecx
434038b7 test     edi, edi
434038b9 jne      0x434038c7
434038bb aas      
434038bc fisubr   dword ptr [esi]
434038be ja       0x4340392e
434038c0 dec      edx
434038c1 or       eax, 0xae874611
434038c6 fsub     dword ptr [ecx + 0x4346791c]
434038c7 mov      eax, dword ptr [0x4346791c]
434038cc movss    xmm0, dword ptr [edx + 0x28]
434038d1 mov      byte ptr [esp + 0xf], 1
434038d6 mov      eax, dword ptr [eax]
434038d8 xor      eax, dword ptr [0x43467bd4]
434038de xor      eax, 0x7f5ed2d0
434038e3 ucomiss  xmm0, dword ptr [eax + edi]
434038e7 lahf     
434038e8 test     ah, 0x44
434038eb jp       0x434038f2
434038ed mov      byte ptr [esp + 0xf], 0
434038f2 cmp      dword ptr [esp + 0x28], 0
434038f7 mov      esi, 0x96
434038fc movss    xmm3, dword ptr [0x43470340]
43403904 movss    xmm1, dword ptr [0x4346f628]
4340390c movss    xmm2, dword ptr [0x4346dd4c]
43403914 movss    xmm5, dword ptr [0x4346ff6c]
4340391c movss    xmm4, dword ptr [0x434723ec]
43403924 mov      dword ptr [esp + 0x48], 3
4340392c mov      dword ptr [esp + 0x58], esi
4340392e and      al, 0x58
43403930 jg       0x4340393c
43403932 cmp      dword ptr [esp + 0x2c], ecx
43403936 je       0x43404ccf
4340393c mov      eax, dword ptr [esp + 0x20]
43403940 cdq      
43403941 idiv     esi
43403943 mov      eax, dword ptr [esp + 0x10]
43403947 mov      edi, dword ptr [esp + 0x20]
4340394b imul     ecx, edx, 0x90
43403951 xor      edx, edx
43403953 add      ecx, dword ptr [eax + 0x54]
43403956 cmp      dword ptr [ecx], edi
43403958 lea      eax, [ecx + 4]
4340395b mov      edi, dword ptr [esp + 0x18]
4340395f cmove    edx, eax
43403962 mov      dword ptr [esp + 0x1c], edx
43403966 test     edx, edx
43403968 je       0x43404ccf
4340396e test     edi, edi
43403970 jne      0x4340397e
43403972 sbb      dword ptr [edi - 0x3efb47b3], eax
43403978 sub      eax, 0xfce247c7
4340397d xchg     edx, eax
4340397e mov      eax, dword ptr [esp + 0x3c]
43403982 cmp      dword ptr [edx], eax
43403984 je       0x43404ccf
4340398a cmp      dword ptr [esp + 0x28], 0
4340398f jg       0x43403b77
43403995 mov      ecx, dword ptr [esp + 0x2c]
43403999 cmp      ecx, eax
4340399b je       0x43403b77
434039a1 test     edi, edi
434039a3 jne      0x434039b1
434039a5 xchg     dword ptr [eax + eax*8], edx
434039a8 aam      0x7f
434039aa or       al, 0x4f
434039ac sbb      eax, 0xe3ba430f
434039b1 sub      eax, ecx
434039b3 mov      dword ptr [esp + 0x38], eax
434039b7 dec      eax
434039b8 cmp      eax, 0xe
434039bb ja       0x43404c7e
434039c1 mov      ecx, dword ptr [edx + 0x58]
434039c4 cmp      ecx, -1
434039c7 je       0x43403b4b
434039cd mov      eax, dword ptr [0x4346a890]
434039d2 push     ecx
434039d3 mov      eax, dword ptr [eax]
434039d5 mov      edx, dword ptr [eax + 0x10]
434039d8 mov      eax, esp
434039da mov      dword ptr [eax], ecx
434039dc mov      ecx, dword ptr [0x4346a890]
434039e2 call     edx
434039e4 mov      edx, eax
434039e6 mov      dword ptr [esp + 0x44], edx
434039ea test     edx, edx
434039ec je       0x43403b47
434039f2 mov      ecx, dword ptr [0x4346a620]
434039f8 mov      eax, dword ptr [0x43467b44]
434039fd mov      edi, dword ptr [esp + 0x1c]
43403a01 mov      esi, dword ptr [ecx]
43403a03 mov      eax, dword ptr [eax]
43403a05 xor      esi, dword ptr [0x434671e4]
43403a0b xor      eax, dword ptr [0x4346a774]
43403a11 xor      esi, 0xd2563274
43403a17 mov      ecx, dword ptr [0x43467eb8]
43403a1d add      esi, edx
43403a1f mov      edi, dword ptr [edi]
43403a21 xor      eax, 0x6777c9ce
43403a26 add      eax, edx
43403a28 mov      dword ptr [esp + 0x24], edi
43403a2c cmp      dword ptr [esp + 0x38], 0
43403a31 mov      edx, ecx
43403a33 movss    xmm0, dword ptr [esi]
43403a37 mov      edi, dword ptr [esp + 0x18]
43403a3b movss    xmm1, dword ptr [eax]
43403a3f movss    xmm2, dword ptr [edx]
43403a43 mov      dword ptr [esp + 0x4c], esi
43403a47 movss    dword ptr [esp + 0x34], xmm0
43403a4d mov      dword ptr [esp + 0x50], eax
43403a51 movss    dword ptr [esp + 0x30], xmm1
43403a57 mov      dword ptr [esp + 0x54], edx
43403a5b movss    dword ptr [esp + 0x14], xmm2
43403a61 jle      0x43403b3b
43403a67 mov      edx, dword ptr [esp + 0x1c]
43403a6b mov      edi, dword ptr [esp + 0x38]
43403a6f add      edx, 0x10
43403a72 mov      esi, dword ptr [esp + 0x44]
43403a76 mov      eax, dword ptr [esp + 0x24]
43403a7a mov      dword ptr [esp + 0x40], edx
43403a7e movd     xmm0, eax
43403a82 mov      eax, dword ptr [0x4346a338]
43403a87 cvtdq2ps xmm0, xmm0
43403a8a mulss    xmm0, dword ptr [eax]
43403a8e movss    dword ptr [ecx], xmm0
43403a92 mov      ecx, dword ptr [esp + 0x1c]
43403a96 lea      ecx, [ecx + 0x1c]
43403a99 call     0x4336b421
43403a9e mov      dword ptr [esp + 0x44], 0xf2a1d15c
43403aa6 mov      edx, esi
43403aa8 mov      eax, dword ptr [esp + 0x44]
43403aac mov      ecx, dword ptr [esi]
43403aae ror      eax, 4
43403ab1 bswap    eax
43403ab3 xor      eax, 0x57883dd6
43403ab8 mov      ecx, dword ptr [eax + ecx - 0x42950f89]
43403abf mov      dword ptr [esp + 0x44], ecx
43403ac3 call     0x433e533f
43403ac8 mov      eax, dword ptr [0x43467b44]
43403acd mov      ecx, dword ptr [esp + 0x1c]
43403ad1 mov      eax, dword ptr [eax]
43403ad3 xor      eax, dword ptr [0x4346a774]
43403ad9 xor      eax, 0x6777c9ce
43403ade mov      eax, dword ptr [eax + esi]
43403ae1 mov      dword ptr [ecx + 0x44], eax
43403ae4 mov      eax, dword ptr [0x4346a620]
43403ae9 mov      eax, dword ptr [eax]
43403aeb xor      eax, dword ptr [0x434671e4]
43403af1 xor      eax, 0xd2563274
43403af6 mov      eax, dword ptr [eax + esi]
43403af9 mov      dword ptr [ecx + 0x64], eax
43403afc mov      eax, dword ptr [esp + 0x24]
43403b00 inc      eax
43403b01 mov      dword ptr [esp + 0x24], eax
43403b05 sub      edi, 1
43403b08 je       0x43403b19
43403b0a mov      ecx, dword ptr [0x43467eb8]
43403b10 mov      edx, dword ptr [esp + 0x40]
43403b14 jmp      0x43403a7e
43403b19 movss    xmm0, dword ptr [esp + 0x34]
43403b1f movss    xmm1, dword ptr [esp + 0x30]
43403b25 movss    xmm2, dword ptr [esp + 0x14]
43403b2b mov      edi, dword ptr [esp + 0x18]
43403b2f mov      esi, dword ptr [esp + 0x4c]
43403b33 mov      eax, dword ptr [esp + 0x50]
43403b37 mov      edx, dword ptr [esp + 0x54]
43403b3b movss    dword ptr [edx], xmm2
43403b3f movss    dword ptr [eax], xmm1
43403b43 movss    dword ptr [esi], xmm0
43403b47 mov      edx, dword ptr [esp + 0x1c]
43403b4b test     edi, edi
43403b4d jne      0x43403b5b
43403b4f sbb      eax, 0x13bb258e
43403b54 and      al, byte ptr [0x2625230c]
43403b5a dec      eax
43403b5b mov      eax, dword ptr [0x434693d8]
43403b60 mov      eax, dword ptr [eax]
43403b62 xor      eax, dword ptr [0x43468bc4]
43403b68 xor      eax, 0x3d10b94c
43403b6d mov      eax, dword ptr [eax + edi]
43403b70 mov      dword ptr [edx], eax
43403b72 jmp      0x43404c7e
43403b77 lea      esi, [edx + 4]
43403b7a test     edi, edi
43403b7c jne      0x43403b96
43403b7e pop      ds
43403b7f int1     
43403b80 sub      esp, dword ptr [edx + esi*4 - 0x79]
43403b84 or       ebx, 0x7ec0e48f
43403b8a popal    
43403b96 mov      eax, dword ptr [0x4346a390]
43403b9b xor      edx, edx
43403b9d push     3
43403b9f mov      ecx, esi
43403ba1 mov      eax, dword ptr [eax]
43403ba3 xor      eax, dword ptr [0x43468324]
43403ba9 xor      eax, 0x5ae32976
43403bae add      eax, edi
43403bb0 sub      eax, esi
43403bb2 pop      esi
43403bb3 movss    xmm0, dword ptr [eax + ecx]
43403bb8 subss    xmm0, dword ptr [ecx]
43403bbc andps    xmm0, xmm3
43403bbf comiss   xmm1, xmm0
43403bc2 jb       0x43403bcf
43403bc4 inc      edx
43403bc5 add      ecx, 4
43403bc8 cmp      edx, esi
43403bca jl       0x43403bb3
43403bcc xor      esi, esi
43403bce inc      esi
43403bcf mov      eax, dword ptr [esp + 0x1c]
43403bd3 add      eax, 0x10
43403bd6 mov      dword ptr [esp + 0x14], esi
43403bda mov      dword ptr [esp + 0x40], eax
43403bde test     edi, edi
43403be0 jne      0x43403bee
43403be2 ljmp     0x6dd1:0x4f91af6a
43403be9 adc      cl, byte ptr [eax]
43403beb dec      esp
43403bec mov      ah, 0x32
43403bee mov      edx, dword ptr [esp + 0x54]
43403bf2 xor      ecx, ecx
43403bf4 sub      edx, dword ptr [esp + 0x40]
43403bf8 movss    xmm0, dword ptr [edx + eax]
43403bfd subss    xmm0, dword ptr [eax]
43403c01 andps    xmm0, xmm3
43403c04 comiss   xmm1, xmm0
43403c07 jb       0x43403c14
43403c09 inc      ecx
43403c0a add      eax, 4
43403c0d cmp      ecx, 3
43403c10 jl       0x43403bf8
43403c12 jmp      0x43403c1b
43403c14 or       esi, 4
43403c17 mov      dword ptr [esp + 0x14], esi
43403c1b mov      ecx, dword ptr [esp + 0x1c]
43403c1f add      ecx, 0x1c
43403c22 mov      dword ptr [esp + 0x44], ecx
43403c26 test     edi, edi
43403c28 jne      0x43403c36
43403c2a inc      esp
43403c2b shr      dword ptr [ecx + 0x6bd4709e], 1
43403c31 jns      0x43403c79
43403c33 sub      al, 0x1a
43403c35 fisub    dword ptr [ecx + 0x43467f74]
43403c36 mov      eax, dword ptr [0x43467f74]
43403c3b xor      edx, edx
43403c3d mov      eax, dword ptr [eax]
43403c3f xor      eax, dword ptr [0x43467a64]
43403c45 xor      eax, 0x48442721
43403c4a add      eax, edi
43403c4c sub      eax, dword ptr [esp + 0x44]
43403c50 movss    xmm0, dword ptr [eax + ecx]
43403c55 subss    xmm0, dword ptr [ecx]
43403c59 andps    xmm0, xmm3
43403c5c comiss   xmm1, xmm0
43403c5f jb       0x43403c6c
43403c61 inc      edx
43403c62 add      ecx, 4
43403c65 cmp      edx, 3
43403c68 jl       0x43403c50
43403c69 out      0xeb, al
43403c6a jmp      0x43403c73
43403c6b pop      es
43403c6c or       esi, 8
43403c6f mov      dword ptr [esp + 0x14], esi
43403c73 mov      edx, dword ptr [esp + 0x1c]
43403c77 movss    xmm1, dword ptr [edx + 0x28]
43403c79 adc      byte ptr [edx + 0x28], cl
43403c7c test     edi, edi
43403c7e jne      0x43403c8c
43403c80 inc      ecx
43403c82 and      eax, 0xa9fa1373
43403c87 enter    -0xa61, 0x38
43403c8b cmp      ah, byte ptr [ecx + 0x43468a34]
43403c8c mov      eax, dword ptr [0x43468a34]
43403c91 mov      eax, dword ptr [eax]
43403c93 xor      eax, dword ptr [0x43468c00]
43403c99 xor      eax, 0xc246315e
43403c9e movss    xmm0, dword ptr [eax + edi + 8]
43403ca4 subss    xmm0, xmm1
43403ca8 andps    xmm0, xmm3
43403cab comiss   xmm2, xmm0
43403cae jae      0x43403cb7
43403cb0 or       esi, 0x10
43403cb3 mov      dword ptr [esp + 0x14], esi
43403cb7 test     edi, edi
43403cb9 jne      0x43403cc7
43403cbb sar      bl, cl
43403cbd fist     dword ptr [edx - 0x47]
43403cc0 push     esp
43403cc1 mov      eax, 0x8eb20484
43403cc6 js       0x43403c69
43403cc7 mov      eax, dword ptr [0x434670cc]
43403cc8 int3     
43403ccc mov      eax, dword ptr [eax]
43403cce xor      eax, dword ptr [0x43468bcc]
43403cd4 xor      eax, 0xa9ee6062
43403cd9 movss    xmm1, dword ptr [eax + edi]
43403cde movss    xmm2, dword ptr [eax + edi + 4]
43403ce4 subss    xmm2, dword ptr [edx + 0x30]
43403ce9 subss    xmm1, dword ptr [edx + 0x2c]
43403cee movss    xmm0, dword ptr [eax + edi + 8]
43403cf4 subss    xmm0, dword ptr [edx + 0x34]
43403cf9 mulss    xmm2, xmm2
43403cfd mulss    xmm1, xmm1
43403d01 mulss    xmm0, xmm0
43403d05 addss    xmm2, xmm1
43403d09 addss    xmm2, xmm0
43403d0d comiss   xmm2, xmm5
43403d10 jb       0x43403d19
43403d12 or       esi, 0x20
43403d15 mov      dword ptr [esp + 0x14], esi
43403d19 test     edi, edi
43403d1b jne      0x43403d29
43403d1d mov      bl, 0x12
43403d1f sbb      al, 0xa2
43403d21 pop      esi
43403d22 pushfd   
43403d23 scasd    eax, dword ptr es:[edi]
43403d24 inc      edx
43403d25 popfd    
43403d26 int3     
43403d29 mov      eax, dword ptr [0x4346a6dc]
43403d2e mov      ecx, dword ptr [eax]
43403d30 xor      ecx, dword ptr [0x43468bd8]
43403d36 mov      eax, dword ptr [edx + 0x3c]
43403d39 xor      ecx, 0x8cfc633a
43403d3f cmp      eax, dword ptr [ecx + edi]
43403d42 je       0x43403d4b
43403d44 or       esi, 0x40
43403d47 mov      dword ptr [esp + 0x14], esi
43403d4b movss    xmm1, dword ptr [edx + 0x4c]
43403d50 test     edi, edi
43403d52 jne      0x43403d60
43403d54 xor      al, dh
43403d56 sbb      al, 0xcd
43403d58 jo       0x43403d22
43403d5a cmp      eax, 0x30cbeb9c
43403d5f mov      byte ptr [ecx + 0x43468354], ah
43403d60 mov      eax, dword ptr [0x43468354]
43403d65 mov      eax, dword ptr [eax]
43403d67 xor      eax, dword ptr [0x4346852c]
43403d6d xor      eax, 0x66146802
43403d72 movss    xmm0, dword ptr [eax + edi]
43403d77 subss    xmm0, xmm1
43403d7b andps    xmm0, xmm3
43403d7e comiss   xmm4, xmm0
43403d81 jae      0x43403d8d
43403d83 or       esi, 0x400
43403d89 mov      dword ptr [esp + 0x14], esi
43403d8d test     edi, edi
43403d8f jne      0x43403d9d
43403d91 cwde     
43403d92 cli      
43403d94 and      esp, dword ptr cs:[eax]
43403d97 lds      edx, ptr [ecx - 0x7815faf3]
43403d9d mov      eax, dword ptr [0x43467a74]
43403da2 mov      eax, dword ptr [eax]
43403da4 xor      eax, dword ptr [0x434678c0]
43403daa xor      eax, 0xcd812654
43403daf mov      ecx, dword ptr [eax + edi]
43403db2 cmp      dword ptr [edx + 0x58], ecx
43403db5 je       0x43403dc2
43403db7 or       esi, 0x80
43403dbd jmp      0x43403ed7
43403dc2 cmp      ecx, -1
43403dc5 je       0x43403edb
43403dcb mov      eax, dword ptr [0x4346a890]
43403dd0 push     ecx
43403dd1 mov      eax, dword ptr [eax]
43403dd3 mov      edx, dword ptr [eax + 0x10]
43403dd6 mov      eax, esp
43403dd8 mov      dword ptr [eax], ecx
43403dda mov      ecx, dword ptr [0x4346a890]
43403de0 call     edx
43403de2 mov      edx, eax
43403de4 test     edx, edx
43403de6 je       0x43403edb
43403dec mov      ecx, dword ptr [0x4346a620]
43403df2 movss    xmm1, dword ptr [0x43470340]
43403dfa movss    xmm2, dword ptr [0x434723ec]
43403e02 mov      ecx, dword ptr [ecx]
43403e04 xor      ecx, dword ptr [0x434671e4]
43403e0a xor      ecx, 0xd2563274
43403e10 movss    xmm0, dword ptr [ecx + edx]
43403e15 mov      ecx, dword ptr [esp + 0x1c]
43403e19 subss    xmm0, dword ptr [ecx + 0x64]
43403e1e andps    xmm0, xmm1
43403e21 comiss   xmm2, xmm0
43403e24 jae      0x43403e2c
43403e26 or       esi, 0x100
43403e2c mov      eax, dword ptr [0x43467200]
43403e31 movss    xmm0, dword ptr [ecx + 0x60]
43403e36 mov      eax, dword ptr [eax]
43403e38 xor      eax, dword ptr [0x4346a5fc]
43403e3e xor      eax, 0x176a381
43403e43 ucomiss  xmm0, dword ptr [eax + edx]
43403e47 lahf     
43403e48 test     ah, 0x44
43403e4b jnp      0x43403e53
43403e4d or       esi, 0x200
43403e53 mov      eax, dword ptr [0x43467b44]
43403e58 mov      eax, dword ptr [eax]
43403e5a xor      eax, dword ptr [0x4346a774]
43403e60 xor      eax, 0x6777c9ce
43403e65 movss    xmm0, dword ptr [eax + edx]
43403e6a mov      eax, esi
43403e6c subss    xmm0, dword ptr [ecx + 0x44]
43403e71 or       eax, 0x1000
43403e76 mov      ecx, edi
43403e78 andps    xmm0, xmm1
43403e7b comiss   xmm2, xmm0
43403e7e cmovae   eax, esi
43403e81 mov      dword ptr [esp + 0x54], eax
43403e85 mov      eax, dword ptr [0x43468d48]
43403e8a mov      eax, dword ptr [eax]
43403e8c xor      eax, dword ptr [0x43467e94]
43403e92 xor      eax, 0xc6c78c82
43403e97 push     dword ptr [eax + edx]
43403e9a call     0x43342dd7
43403e9f mov      esi, dword ptr [esp + 0x54]
43403ea3 mov      edx, eax
43403ea5 mov      dword ptr [esp + 0x14], esi
43403ea9 test     edx, edx
43403eab je       0x43403edb
43403eac mov      ecx, dword ptr cs:[0x43468da0]
43403ead mov      ecx, dword ptr [0x43468da0]
43403eb3 mov      eax, dword ptr [esp + 0x1c]
43403eb7 mov      dword ptr [esp + 0x14], esi
43403ebb mov      ecx, dword ptr [ecx]
43403ebd xor      ecx, dword ptr [0x4346a6bc]
43403ec3 mov      eax, dword ptr [eax + 0x74]
43403ec6 xor      ecx, 0x695ff325
43403ecc cmp      eax, dword ptr [ecx + edx]
43403ecf je       0x43403edb
43403ed1 or       esi, 0x2000
43403ed7 mov      dword ptr [esp + 0x14], esi
43403edb mov      ecx, dword ptr [esp + 0x20]
43403edf call     0x43331efc
43403ee4 mov      ecx, dword ptr [esp + 0x20]
43403ee8 xor      esi, esi
43403eea cmp      dword ptr [eax + 4], ecx
43403eed cmove    esi, eax
43403ef0 test     esi, esi
43403ef2 je       0x43403fab
43403ef4 mov      bl, 0
43403ef6 add      byte ptr [eax], al
43403ef8 lea      ecx, [edi + 8]
43403efb mov      eax, dword ptr [ecx]
43403efd call     dword ptr [eax + 0x28]
43403f00 test     eax, eax
43403f02 jne      0x43403f10
43403f04 pop      ss
43403f05 jle      0x43403ef4
43403f07 inc      esi
43403f08 adc      edi, dword ptr [0xfcf95bfe]
43403f0e jno      0x43403eac
43403f10 mov      ecx, eax
43403f12 call     0x433b8a2b
43403f17 mov      ecx, dword ptr [esp + 0x20]
43403f1b lea      edi, [esp + 0x60]
43403f1f add      esi, 0xc
43403f22 mov      dword ptr [esp + 0x54], eax
43403f26 lea      edx, [esp + 0x60]
43403f2a movsd    dword ptr es:[edi], dword ptr [esi]
43403f2b movsd    dword ptr es:[edi], dword ptr [esi]
43403f2c movsd    dword ptr es:[edi], dword ptr [esi]
43403f2d call     0x43384c9e
43403f32 movss    xmm0, dword ptr [esp + 0x64]
43403f38 mulss    xmm0, dword ptr [0x4346dba4]
43403f40 mov      ecx, dword ptr [esp + 0x54]
43403f44 cvttss2si eax, xmm0
43403f48 movss    xmm0, dword ptr [esp + 0x60]
43403f4e mulss    xmm0, dword ptr [0x4346dba4]
43403f56 movzx    eax, ax
43403f59 movd     xmm1, eax
43403f5d cvttss2si eax, xmm0
43403f61 cvtdq2ps xmm1, xmm1
43403f64 movzx    eax, ax
43403f67 movd     xmm0, eax
43403f6b mulss    xmm1, dword ptr [0x434721a0]
43403f73 cvtdq2ps xmm0, xmm0
43403f76 mulss    xmm0, dword ptr [0x434721a0]
43403f7e ucomiss  xmm0, dword ptr [ecx + 0x1a8]
43403f85 lahf     
43403f86 test     ah, 0x44
43403f89 jp       0x43403f98
43403f8b ucomiss  xmm1, dword ptr [ecx + 0x1ac]
43403f92 lahf     
43403f93 test     ah, 0x44
43403f96 jnp      0x43403fa7
43403f98 mov      eax, dword ptr [esp + 0x14]
43403f9c mov      edi, dword ptr [esp + 0x18]
43403fa0 or       eax, 0x800
43403fa5 jmp      0x43403faf
43403fa7 mov      edi, dword ptr [esp + 0x18]
43403fab mov      eax, dword ptr [esp + 0x14]
43403faf test     eax, 0xfffffdfe
43403fb4 jne      0x434043e8
43403fba mov      esi, dword ptr [esp + 0x10]
43403fbe mov      ecx, dword ptr [esi + 0x1c]
43403fc1 mov      eax, dword ptr [ecx]
43403fc3 call     dword ptr [eax + 0x334]
43403fc9 mov      ecx, eax
43403fcb mov      dword ptr [esp + 0x14], ecx
43403fcf test     edi, edi
43403fd1 jne      0x43403fdf
43403fd3 in       eax, 0x86
43403fd5 add      eax, 0xca0cbf0f
43403fda xchg     byte ptr [ebx], bl
43403fdc cld      
43403fdd pop      esi
43403fde aaa      
43403fdf mov      eax, dword ptr [0x434693d8]
43403fe4 mov      edx, ecx
43403fe6 mov      eax, dword ptr [eax]
43403fe8 xor      eax, dword ptr [0x43468bc4]
43403fee xor      eax, 0x3d10b94c
43403ff3 mov      eax, dword ptr [eax + edi]
43403ff6 mov      dword ptr [esp + 0x30], eax
43403ffa mov      eax, dword ptr [0x43475794]
43403fff sub      edx, dword ptr [eax]
43404001 mov      eax, dword ptr [0x43467b04]
43404006 mov      dword ptr [esp + 0x54], edx
4340400a cmp      dword ptr [eax + 0x18], 1
4340400e je       0x434040de
43404014 call     0x43407de2
43404019 test     al, al
4340401b je       0x434040de
43404021 test     edx, 0xffffffc0
43404027 jne      0x434040de
4340402d movd     xmm0, dword ptr [0x43468290]
43404035 xorps    xmm2, xmm2
43404038 cvtdq2ps xmm0, xmm0
4340403b mov      eax, dword ptr [0x4346a338]
43404040 divss    xmm0, dword ptr [0x434720f8]
43404048 movaps   xmm1, xmm0
4340404b movss    dword ptr [esp + 0x50], xmm0
43404051 movaps   xmm0, xmm2
43404054 maxss    xmm1, xmm0
43404058 movss    xmm0, dword ptr [0x43470514]
43404060 minss    xmm1, xmm0
43404064 divss    xmm1, dword ptr [eax]
43404068 mov      eax, dword ptr [esp + 0x10]
4340406c mov      ecx, dword ptr [eax + 0x1c]
4340406f mov      eax, dword ptr [ecx]
43404071 addss    xmm1, dword ptr [0x43472240]
43404079 cvttss2si esi, xmm1
4340407d call     dword ptr [eax + 0x38]
43404080 mov      eax, dword ptr [0x43467b04]
43404085 mov      ecx, dword ptr [esp + 0x54]
43404089 fdiv     dword ptr [eax + 0x20]
4340408c fadd     dword ptr [0x43472240]
43404092 fstp     dword ptr [esp + 0x38]
43404096 cvttss2si eax, dword ptr [esp + 0x38]
4340409c add      eax, esi
4340409e mov      dword ptr [esp + 0x34], eax
434040a2 mov      eax, dword ptr [esp + 0x10]
434040a6 mov      edx, dword ptr [eax + 0x3c]
434040a9 mov      eax, dword ptr [esp + 0x34]
434040ad add      edx, ecx
434040af add      eax, esi
434040b1 cmp      edx, eax
434040b3 jg       0x434040c3
434040b5 cvttss2si eax, dword ptr [esp + 0x38]
434040bb cmp      edx, eax
434040bd jge      0x43404c7e
434040c3 mov      eax, dword ptr [0x43467b04]
434040c8 mov      eax, dword ptr [eax + 0x28]
434040cb sub      eax, ecx
434040cd add      eax, dword ptr [esp + 0x34]
434040d1 cmp      eax, -1
434040d4 je       0x43404c7e
434040da mov      esi, dword ptr [esp + 0x10]
434040de mov      ecx, dword ptr [esi + 0x1c]
434040e1 mov      eax, dword ptr [ecx]
434040e3 call     dword ptr [eax + 0x38]
434040e6 mov      eax, dword ptr [0x43467b04]
434040eb xorps    xmm2, xmm2
434040ee movd     xmm0, dword ptr [0x43468290]
434040f6 cvtdq2ps xmm0, xmm0
434040f9 and      dword ptr [esp + 0x38], 0
434040fe mov      edi, dword ptr [esp + 0x14]
43404102 fdiv     dword ptr [eax + 0x20]
43404105 mov      eax, dword ptr [0x4346a338]
4340410a divss    xmm0, dword ptr [0x434720f8]
43404112 fadd     dword ptr [0x43472240]
43404118 movaps   xmm1, xmm0
4340411b fstp     dword ptr [esp + 0x54]
4340411f cvttss2si ecx, dword ptr [esp + 0x54]
43404125 movss    dword ptr [esp + 0x54], xmm0
4340412b movaps   xmm0, xmm2
4340412e maxss    xmm1, xmm0
43404132 inc      ecx
43404133 movss    xmm0, dword ptr [0x43470514]
4340413b minss    xmm1, xmm0
4340413f divss    xmm1, dword ptr [eax]
43404143 addss    xmm1, dword ptr [0x43472240]
4340414b cvttss2si eax, xmm1
4340414f add      eax, ecx
43404151 mov      dword ptr [esp + 0x24], eax
43404155 mov      eax, dword ptr [0x43475794]
4340415a mov      esi, dword ptr [eax]
4340415c inc      esi
4340415d cmp      esi, edi
4340415f jg       0x43404193
43404161 mov      ecx, esi
43404163 call     0x43331efc
43404168 xor      ecx, ecx
4340416a cmp      dword ptr [eax + 4], esi
4340416d cmove    ecx, eax
43404170 test     ecx, ecx
43404172 je       0x43404193
43404174 cmp      dword ptr [ecx + 8], 0x7f7fffff
4340417b jne      0x43404181
4340417d dec      dword ptr [esp + 0x24]
43404181 mov      ecx, dword ptr [esp + 0x38]
43404185 inc      ecx
43404186 inc      esi
43404187 mov      dword ptr [esp + 0x38], ecx
4340418b cmp      ecx, 0x96
43404191 jb       0x4340415d
43404193 mov      eax, dword ptr [esp + 0x24]
43404197 mov      edi, dword ptr [esp + 0x18]
4340419b mov      esi, dword ptr [esp + 0x10]
4340419f cmp      eax, dword ptr [esp + 0x30]
434041a3 jne      0x43404c7e
434041a9 mov      eax, dword ptr [0x434757dc]
434041ae mov      edx, dword ptr [eax]
434041b0 mov      eax, dword ptr [0x43475b2c]
434041b5 add      edx, dword ptr [eax]
434041b7 mov      dword ptr [esp + 0x50], edx
434041bb cmp      dword ptr [esp + 0x14], edx
434041bf jg       0x43404220
434041c1 mov      edi, dword ptr [esp + 0x14]
434041c5 mov      eax, edi
434041c7 mov      ecx, 0x96
434041cc cdq      
434041cd idiv     ecx
434041cf imul     ecx, edx, 0x90
434041d5 xor      edx, edx
434041d7 add      ecx, dword ptr [esi + 0x54]
434041da cmp      dword ptr [ecx], edi
434041dc lea      eax, [ecx + 4]
434041df cmove    edx, eax
434041e2 mov      dword ptr [esp + 0x54], edx
434041e6 test     edx, edx
434041e8 je       0x4340421c
434041ea mov      ecx, edi
434041ec call     0x43331efc
434041f1 xor      ecx, ecx
434041f3 cmp      dword ptr [eax + 4], edi
434041f6 cmove    ecx, eax
434041f9 test     ecx, ecx
434041fb je       0x4340421c
434041fd mov      eax, dword ptr [esp + 0x54]
43404201 mov      edx, dword ptr [esp + 0x30]
43404205 mov      dword ptr [eax], edx
43404207 cmp      dword ptr [ecx + 8], 0x7f7fffff
4340420e je       0x43404215
43404210 inc      edx
43404211 mov      dword ptr [esp + 0x30], edx
43404215 inc      edi
43404216 cmp      edi, dword ptr [esp + 0x50]
4340421a jle      0x434041c5
4340421c mov      edi, dword ptr [esp + 0x18]
43404220 test     edi, edi
43404222 jne      0x4340423c
43404224 push     ecx
43404225 mov      ch, 0xaa
43404227 adc      al, 0xf8
43404229 pop      eax
4340422a push     edx
4340422b loope    0x434041f3
4340422d out      dx, al
4340422e dec      ebp
4340422f dec      edi
43404230 pop      ss
43404231 xchg     byte ptr [eax - 0x3fc8002c], ah
43404237 cmp      dword ptr [eax + 0x3e], -0x3c
4340423c mov      eax, dword ptr [0x4346a390]
43404241 xor      ecx, ecx
43404243 mov      esi, dword ptr [esp + 0x1c]
43404247 movss    xmm1, dword ptr [0x4346f628]
4340424f movss    xmm2, dword ptr [0x43470340]
43404257 mov      eax, dword ptr [eax]
43404259 xor      eax, dword ptr [0x43468324]
4340425f lea      edx, [esi + 4]
43404262 xor      eax, 0x5ae32976
43404267 add      eax, edi
43404269 sub      eax, edx
4340426b movss    xmm0, dword ptr [eax + edx]
43404270 subss    xmm0, dword ptr [edx]
43404274 andps    xmm0, xmm2
43404277 comiss   xmm1, xmm0
4340427a jb       0x43404285
4340427c inc      ecx
4340427d add      edx, 4
43404280 cmp      ecx, 3
43404283 jl       0x4340426b
43404285 test     edi, edi
43404287 jne      0x43404295
43404289 rcr      dword ptr [ebp - 0xd1df8cf], 1
4340428f mov      eax, 0x48038d75
43404294 mov      cl, 0xa1
43404295 mov      eax, dword ptr [0x434682b8]
43404296 mov      eax, 0x33434682
4340429a xor      ecx, ecx
4340429b leave    
4340429c mov      edx, dword ptr [esp + 0x40]
434042a0 mov      eax, dword ptr [eax]
434042a2 xor      eax, dword ptr [0x43467d90]
434042a8 xor      eax, 0x1bae1168
434042ad add      eax, edi
434042af sub      eax, edx
434042b1 movss    xmm0, dword ptr [eax + edx]
434042b6 subss    xmm0, dword ptr [edx]
434042ba andps    xmm0, xmm2
434042bd comiss   xmm1, xmm0
434042c0 jb       0x434042cb
434042c2 inc      ecx
434042c3 add      edx, 4
434042c6 cmp      ecx, 3
434042c9 jl       0x434042b1
434042cb test     edi, edi
434042cd jne      0x434042db
434042cf loope    0x4340434c
434042d1 mov      edi, 0xb535d69
434042d6 fist     word ptr [esi + 0x2a]
434042d9 stc      
434042da sbb      dword ptr [ecx + 0x43467f74], esp
434042db mov      eax, dword ptr [0x43467f74]
434042e0 xor      ecx, ecx
434042e2 mov      edx, dword ptr [esp + 0x44]
434042e6 mov      eax, dword ptr [eax]
434042e8 xor      eax, dword ptr [0x43467a64]
434042ee xor      eax, 0x48442721
434042f3 add      eax, edi
434042f5 sub      eax, edx
434042f7 movss    xmm0, dword ptr [eax + edx]
434042fc subss    xmm0, dword ptr [edx]
43404300 andps    xmm0, xmm2
43404303 comiss   xmm1, xmm0
43404306 jb       0x43404311
43404308 inc      ecx
43404309 add      edx, 4
4340430c cmp      ecx, 3
4340430f jl       0x434042f7
43404311 test     edi, edi
43404313 jne      0x43404351
43404315 salc     
43404316 sahf     
43404317 xchg     bl, cl
43404319 enter    0x74f3, 0x3a
4340431d fimul    dword ptr [0x8785e0d]
43404323 out      0x80, eax
43404325 sbb      dword ptr [ecx], edx
43404327 bound    ecx, qword ptr [ebp + 0x3011ed6a]
4340432d or       al, 0xb4
4340432f push     eax
43404330 add      cl, dl
43404332 xlatb    
43404333 sbb      eax, 0x2b4ed9d7
43404338 stosb    byte ptr es:[edi], al
43404339 in       eax, 0xd0
4340433b pop      ss
4340433c pop      edi
4340433d adc      al, 0xe
4340433f and      edi, 0xffffff83
43404342 mov      ah, 0x20
43404344 mov      ebx, 0x7c63f95a
43404349 ret      0xb600
43404351 mov      eax, dword ptr [0x43467a74]
43404356 mov      eax, dword ptr [eax]
43404358 xor      eax, dword ptr [0x434678c0]
4340435e xor      eax, 0xcd812654
43404363 mov      ecx, dword ptr [eax + edi]
43404366 cmp      dword ptr [esi + 0x58], ecx
43404369 jne      0x434043a9
4340436b cmp      ecx, -1
4340436e je       0x434043a9
43404370 mov      eax, dword ptr [0x4346a890]
43404375 push     ecx
43404376 mov      eax, dword ptr [eax]
43404378 mov      edx, dword ptr [eax + 0x10]
4340437b mov      eax, esp
4340437d mov      dword ptr [eax], ecx
4340437f mov      ecx, dword ptr [0x4346a890]
43404385 call     edx
43404387 test     eax, eax
43404389 je       0x434043a9
4340438b mov      ecx, dword ptr [0x43468d48]
43404391 mov      ecx, dword ptr [ecx]
43404393 xor      ecx, dword ptr [0x43467e94]
43404399 xor      ecx, 0xc6c78c82
4340439f push     dword ptr [ecx + eax]
434043a2 mov      ecx, edi
434043a4 call     0x43342dd7
434043a9 mov      esi, dword ptr [esp + 0x20]
434043ad mov      ecx, esi
434043af call     0x43331efc
434043b4 xor      ecx, ecx
434043b6 cmp      dword ptr [eax + 4], esi
434043b9 cmove    ecx, eax
434043bc test     ecx, ecx
434043be je       0x43404c7e
434043c4 lea      ecx, [edi + 8]
434043c7 mov      eax, dword ptr [ecx]
434043c9 call     dword ptr [eax + 0x28]
434043cc test     eax, eax
434043ce jne      0x434043dc
434043d0 xchg     byte ptr [edx + 0x2fc9dfed], bl
434043d6 xor      eax, 0xbc0ac3d8
434043db mov      ecx, eax
434043dc mov      ecx, eax
434043de call     0x433b8a2b
434043e3 jmp      0x43404c7e
434043e8 mov      ecx, dword ptr [0x4346a514]
434043ee mov      eax, dword ptr [ecx]
434043f0 call     dword ptr [eax + 0x334]
434043f6 dec      eax
434043f7 mov      esi, dword ptr [esp + 0x10]
434043fb mov      dword ptr [esp + 0x24], eax
434043ff mov      ecx, 0x96
43404404 cdq      
43404405 idiv     ecx
43404407 mov      edi, dword ptr [esp + 0x24]
4340440b imul     ecx, edx, 0x90
43404411 xor      edx, edx
43404413 add      ecx, dword ptr [esi + 0x54]
43404416 cmp      dword ptr [ecx], edi
43404418 lea      eax, [ecx + 4]
4340441b mov      edi, dword ptr [esp + 0x18]
4340441f cmove    edx, eax
43404422 mov      dword ptr [esp + 0x44], edx
43404426 test     edx, edx
43404428 je       0x434048e3
4340442e test     edi, edi
43404430 jne      0x4340443e
43404432 in       al, 0x8f
43404434 mov      al, byte ptr [0x5797dfdd]
4340443e mov      eax, dword ptr [0x434693d8]
43404443 xor      edx, edx
43404445 mov      esi, dword ptr [esp + 0x44]
43404449 mov      ecx, dword ptr [eax]
4340444b xor      ecx, dword ptr [0x43468bc4]
43404451 mov      eax, dword ptr [esi]
43404453 xor      ecx, 0x3d10b94c
43404459 cmp      eax, dword ptr [ecx + edi]
4340445c lea      ecx, [esi + 4]
4340445f setne    dl
43404462 mov      dword ptr [esp + 0x14], edx
43404466 test     edi, edi
43404468 jne      0x43404476
4340446a and      byte ptr [ebp + 0x5d], bl
43404476 mov      eax, dword ptr [0x4346a390]
4340447b and      dword ptr [esp + 0x30], 0
43404480 movss    xmm1, dword ptr [0x4346f628]
43404488 movss    xmm3, dword ptr [0x43470340]
43404490 mov      eax, dword ptr [eax]
43404492 xor      eax, dword ptr [0x43468324]
43404498 xor      eax, 0x5ae32976
4340449d add      eax, edi
4340449f sub      eax, ecx
434044a1 movss    xmm0, dword ptr [eax + ecx]
434044a6 subss    xmm0, dword ptr [ecx]
434044aa andps    xmm0, xmm3
434044ad comiss   xmm1, xmm0
434044b0 jb       0x434044c2
434044b2 inc      dword ptr [esp + 0x30]
434044b6 add      ecx, 4
434044b9 cmp      dword ptr [esp + 0x30], 3
434044be jl       0x434044a1
434044c0 jmp      0x434044c9
434044c2 or       edx, 2
434044c5 mov      dword ptr [esp + 0x14], edx
434044c9 lea      ecx, [esi + 0x10]
434044cc test     edi, edi
434044ce jne      0x434044dc
434044d0 mov      cl, 0xa8
434044d2 pop      esi
434044d3 push     cs
434044d4 dec      esi
434044d5 adc      byte ptr [ecx + 0x13], ah
434044d8 cmp      bl, byte ptr [ecx - 0x475e39b1]
434044dc mov      eax, dword ptr [0x434682b8]
434044de add      byte ptr [esi + 0x43], 0x83
434044e1 and      dword ptr [esp + 0x30], 0
434044e2 and      al, 0x30
434044e5 add      byte ptr [ebx - 0x6ffacd00], cl
434044e6 mov      eax, dword ptr [eax]
434044e8 xor      eax, dword ptr [0x43467d90]
434044eb jge      0x43404533
434044ed inc      ebx
434044ee xor      eax, 0x1bae1168
434044f3 add      eax, edi
434044f5 sub      eax, ecx
434044f7 movss    xmm0, dword ptr [eax + ecx]
434044fc subss    xmm0, dword ptr [ecx]
43404500 andps    xmm0, xmm3
43404503 comiss   xmm1, xmm0
43404506 jb       0x43404518
43404508 inc      dword ptr [esp + 0x30]
4340450c add      ecx, 4
4340450f cmp      dword ptr [esp + 0x30], 3
43404514 jl       0x434044f7
43404516 jmp      0x4340451f
43404518 or       edx, 4
43404519 retf     0x8904
4340451b mov      dword ptr [esp + 0x14], edx
4340451f lea      ecx, [esi + 0x1c]
43404522 test     edi, edi
43404524 jne      0x43404532
43404526 cdq      
43404527 jecxz    0x434045a0
43404529 out      dx, eax
4340452a ljmp     0x90cd:0x703df044
43404531 ret      
43404532 mov      eax, dword ptr [0x43467f74]
43404533 je       0x434045b4
43404535 inc      esi
43404536 inc      ebx
43404537 and      dword ptr [esp + 0x30], 0
4340453c mov      eax, dword ptr [eax]
4340453e xor      eax, dword ptr [0x43467a64]
43404544 xor      eax, 0x48442721
43404549 add      eax, edi
4340454b sub      eax, ecx
4340454d movss    xmm0, dword ptr [eax + ecx]
43404552 subss    xmm0, dword ptr [ecx]
43404556 andps    xmm0, xmm3
43404559 comiss   xmm1, xmm0
4340455c jb       0x4340456e
4340455e inc      dword ptr [esp + 0x30]
43404562 add      ecx, 4
43404565 cmp      dword ptr [esp + 0x30], 3
4340456a jl       0x4340454d
4340456c jmp      0x43404575
4340456e or       edx, 8
43404571 mov      dword ptr [esp + 0x14], edx
43404575 movss    xmm1, dword ptr [esi + 0x28]
4340457a test     edi, edi
4340457c jne      0x4340458a
4340457e in       eax, dx
4340457f xchg     esi, eax
43404580 mov      ah, 4
43404582 push     es
43404583 mov      gs, word ptr [edx]
43404585 call     dword ptr [ebx]
43404587 jg       0x43404519
43404589 stosb    byte ptr es:[edi], al
4340458a mov      eax, dword ptr [0x43468a34]
4340458f mov      eax, dword ptr [eax]
43404591 xor      eax, dword ptr [0x43468c00]
43404597 xor      eax, 0xc246315e
4340459c movss    xmm0, dword ptr [eax + edi + 8]
434045a0 cmp      byte ptr [eax], cl
434045a2 subss    xmm0, xmm1
434045a6 movss    xmm1, dword ptr [0x4346dd4c]
434045ae andps    xmm0, xmm3
434045b1 comiss   xmm1, xmm0
434045b4 jae      0x434045bd
434045b6 or       edx, 0x10
434045b9 mov      dword ptr [esp + 0x14], edx
434045bd test     edi, edi
434045bf jne      0x434045cd
434045c1 jecxz    0x43404619
434045c3 jmp      0x3e2bfa27
434045cd mov      eax, dword ptr [0x434670cc]
434045d2 mov      eax, dword ptr [eax]
434045d4 xor      eax, dword ptr [0x43468bcc]
434045da xor      eax, 0xa9ee6062
434045df movss    xmm1, dword ptr [eax + edi]
434045e4 movss    xmm2, dword ptr [eax + edi + 4]
434045ea subss    xmm2, dword ptr [esi + 0x30]
434045ef subss    xmm1, dword ptr [esi + 0x2c]
434045f4 movss    xmm0, dword ptr [eax + edi + 8]
434045fa subss    xmm0, dword ptr [esi + 0x34]
434045ff mulss    xmm2, xmm2
43404603 mulss    xmm1, xmm1
43404607 mulss    xmm0, xmm0
4340460b addss    xmm2, xmm1
4340460f addss    xmm2, xmm0
43404613 comiss   xmm2, dword ptr [0x4346ff6c]
43404619 inc      ebx
4340461a jb       0x43404623
4340461c or       edx, 0x20
4340461f mov      dword ptr [esp + 0x14], edx
43404623 test     edi, edi
43404625 jne      0x43404633
43404627 mov      ecx, 0x42a3f999
4340462c push     ecx
4340462d and      eax, 0xd4d537b5
43404632 popal    
43404633 mov      eax, dword ptr [0x4346a6dc]
43404638 mov      ecx, dword ptr [eax]
4340463a xor      ecx, dword ptr [0x43468bd8]
43404640 mov      eax, dword ptr [esi + 0x3c]
43404643 xor      ecx, 0x8cfc633a
43404649 cmp      eax, dword ptr [ecx + edi]
4340464c je       0x43404655
4340464e or       edx, 0x40
43404651 mov      dword ptr [esp + 0x14], edx
43404655 movss    xmm1, dword ptr [esi + 0x4c]
4340465a test     edi, edi
4340465c jne      0x4340466a
4340465e xor      eax, 0x8706194c
43404663 ja       0x434045ea
43404665 xor      al, 0xdd
43404667 add      ebp, dword ptr [ebx]
43404669 xchg     byte ptr [ecx + 0x43468354], ah
4340466a mov      eax, dword ptr [0x43468354]
4340466f mov      eax, dword ptr [eax]
43404671 xor      eax, dword ptr [0x4346852c]
43404677 xor      eax, 0x66146802
4340467c movss    xmm0, dword ptr [eax + edi]
43404681 subss    xmm0, xmm1
43404685 movss    xmm1, dword ptr [0x434723ec]
4340468d andps    xmm0, xmm3
43404690 comiss   xmm1, xmm0
43404693 jae      0x4340469f
43404695 or       edx, 0x400
4340469b mov      dword ptr [esp + 0x14], edx
4340469f test     edi, edi
434046a1 jne      0x434046af
434046a3 popfd    
434046a4 mov      esi, 0x9522931a
434046a9 mov      byte ptr [ebx], bl
434046ab push     0xe
434046ad sbb      dword ptr [edx], eax
434046af mov      eax, dword ptr [0x43467a74]
434046b4 mov      eax, dword ptr [eax]
434046b6 xor      eax, dword ptr [0x434678c0]
434046bc xor      eax, 0xcd812654
434046c1 mov      ecx, dword ptr [eax + edi]
434046c4 cmp      dword ptr [esi + 0x58], ecx
434046c7 je       0x434046d8
434046c9 or       edx, 0x80
434046cf mov      dword ptr [esp + 0x14], edx
434046d3 jmp      0x434047f5
434046d8 cmp      ecx, -1
434046db je       0x434047f5
434046e1 mov      eax, dword ptr [0x4346a890]
434046e6 push     ecx
434046e7 mov      eax, dword ptr [eax]
434046e9 mov      edx, dword ptr [eax + 0x10]
434046ec mov      eax, esp
434046ee mov      dword ptr [eax], ecx
434046f0 mov      ecx, dword ptr [0x4346a890]
434046f6 call     edx
434046f8 mov      edx, eax
434046fa test     edx, edx
434046fc je       0x434047f5
43404702 mov      ecx, dword ptr [0x4346a620]
43404708 movss    xmm1, dword ptr [0x43470340]
43404710 movss    xmm2, dword ptr [0x434723ec]
43404718 mov      ecx, dword ptr [ecx]
4340471a xor      ecx, dword ptr [0x434671e4]
43404720 xor      ecx, 0xd2563274
43404726 movss    xmm0, dword ptr [ecx + edx]
4340472b subss    xmm0, dword ptr [esi + 0x64]
43404730 mov      ecx, dword ptr [esp + 0x14]
43404734 andps    xmm0, xmm1
43404737 comiss   xmm2, xmm0
4340473a jae      0x43404742
4340473c or       ecx, 0x100
43404742 mov      eax, dword ptr [0x43467200]
43404747 movss    xmm0, dword ptr [esi + 0x60]
4340474c mov      eax, dword ptr [eax]
4340474e xor      eax, dword ptr [0x4346a5fc]
43404754 xor      eax, 0x176a381
43404759 ucomiss  xmm0, dword ptr [eax + edx]
4340475d lahf     
4340475e test     ah, 0x44
43404761 jnp      0x43404769
43404763 or       ecx, 0x200
43404769 mov      eax, dword ptr [0x43467b44]
4340476e mov      eax, dword ptr [eax]
43404770 xor      eax, dword ptr [0x4346a774]
43404776 xor      eax, 0x6777c9ce
4340477b movss    xmm0, dword ptr [eax + edx]
43404780 mov      eax, ecx
43404782 subss    xmm0, dword ptr [esi + 0x44]
43404787 or       eax, 0x1000
4340478c andps    xmm0, xmm1
4340478f comiss   xmm2, xmm0
43404792 cmovae   eax, ecx
43404795 mov      ecx, edi
43404797 mov      dword ptr [esp + 0x54], eax
4340479b mov      eax, dword ptr [0x43468d48]
434047a0 mov      eax, dword ptr [eax]
434047a2 xor      eax, dword ptr [0x43467e94]
434047a8 xor      eax, 0xc6c78c82
434047ad push     dword ptr [eax + edx]
434047b0 call     0x43342dd7
434047b5 mov      edx, dword ptr [esp + 0x54]
434047b9 mov      dword ptr [esp + 0x50], eax
434047bd mov      dword ptr [esp + 0x14], edx
434047c1 test     eax, eax
434047c3 je       0x434047f5
434047c5 mov      ecx, dword ptr [0x43468da0]
434047cb mov      eax, dword ptr [esi + 0x74]
434047ce mov      esi, dword ptr [esp + 0x50]
434047d2 mov      dword ptr [esp + 0x14], edx
434047d6 mov      ecx, dword ptr [ecx]
434047d8 xor      ecx, dword ptr [0x4346a6bc]
434047de xor      ecx, 0x695ff325
434047e4 cmp      eax, dword ptr [ecx + esi]
434047e7 je       0x434047f5
434047e9 mov      esi, edx
434047eb or       esi, 0x2000
434047f1 mov      dword ptr [esp + 0x14], esi
434047f5 mov      ecx, dword ptr [esp + 0x24]
434047f9 call     0x43331efc
434047fe mov      ecx, dword ptr [esp + 0x24]
43404802 xor      esi, esi
43404804 cmp      dword ptr [eax + 4], ecx
43404807 cmove    esi, eax
4340480a test     esi, esi
4340480c je       0x434048c5
43404812 lea      ecx, [edi + 8]
43404815 mov      eax, dword ptr [ecx]
43404817 call     dword ptr [eax + 0x28]
4340481a test     eax, eax
4340481c jne      0x4340482a
4340481e sbb      bl, bh
43404820 out      dx, eax
43404821 or       byte ptr [ecx - 0x5a], ah
4340482a mov      ecx, eax
4340482c call     0x433b8a2b
43404831 mov      ecx, dword ptr [esp + 0x24]
43404835 lea      edi, [esp + 0x60]
43404839 add      esi, 0xc
4340483c mov      dword ptr [esp + 0x54], eax
43404840 lea      edx, [esp + 0x60]
43404844 movsd    dword ptr es:[edi], dword ptr [esi]
43404845 movsd    dword ptr es:[edi], dword ptr [esi]
43404846 movsd    dword ptr es:[edi], dword ptr [esi]
43404847 call     0x43384c9e
4340484c movss    xmm0, dword ptr [esp + 0x64]
43404852 mulss    xmm0, dword ptr [0x4346dba4]
4340485a mov      ecx, dword ptr [esp + 0x54]
4340485e cvttss2si eax, xmm0
43404862 movss    xmm0, dword ptr [esp + 0x60]
43404868 mulss    xmm0, dword ptr [0x4346dba4]
43404870 movzx    eax, ax
43404873 movd     xmm1, eax
43404877 cvttss2si eax, xmm0
4340487b cvtdq2ps xmm1, xmm1
4340487e movzx    eax, ax
43404881 movd     xmm0, eax
43404885 mulss    xmm1, dword ptr [0x434721a0]
4340488d cvtdq2ps xmm0, xmm0
43404890 mulss    xmm0, dword ptr [0x434721a0]
43404898 ucomiss  xmm0, dword ptr [ecx + 0x1a8]
4340489f lahf     
434048a0 test     ah, 0x44
434048a3 jp       0x434048b2
434048a5 ucomiss  xmm1, dword ptr [ecx + 0x1ac]
434048ac lahf     
434048ad test     ah, 0x44
434048b0 jnp      0x434048c1
434048b2 mov      eax, dword ptr [esp + 0x14]
434048b6 mov      edi, dword ptr [esp + 0x18]
434048ba or       eax, 0x800
434048bf jmp      0x434048c9
434048c1 mov      edi, dword ptr [esp + 0x18]
434048c5 mov      eax, dword ptr [esp + 0x14]
434048c9 test     eax, 0xfffffdfe
434048ce jne      0x434048df
434048d0 mov      edx, dword ptr [esp + 0x44]
434048d4 push     0x8c
434048d9 push     edx
434048da jmp      0x43404c45
434048df mov      esi, dword ptr [esp + 0x10]
434048e3 test     edi, edi
434048e5 jne      0x434048f3
434048e7 dec      edx
434048e8 retf     0x7e
434048f3 mov      eax, dword ptr [0x434693d8]
434048f8 mov      ecx, dword ptr [eax]
434048fa xor      ecx, dword ptr [0x43468bc4]
43404900 mov      eax, dword ptr [esp + 0x1c]
43404904 xor      ecx, 0x3d10b94c
4340490a mov      eax, dword ptr [eax]
4340490c cmp      eax, dword ptr [ecx + edi]
4340490f jge      0x43404c7e
43404915 mov      ecx, dword ptr [0x4346a514]
4340491b mov      eax, dword ptr [ecx]
4340491d call     dword ptr [eax + 0x334]
43404923 inc      eax
43404924 mov      ecx, 0x96
43404929 mov      dword ptr [esp + 0x24], eax
4340492c and      al, 0x99
4340492d cdq      
4340492e idiv     ecx
43404930 imul     ecx, edx, 0x90
43404936 mov      edx, dword ptr [esp + 0x24]
4340493a add      ecx, dword ptr [esi + 0x54]
4340493d xor      esi, esi
4340493f cmp      dword ptr [ecx], edx
43404941 lea      eax, [ecx + 4]
43404944 cmove    esi, eax
43404947 mov      dword ptr [esp + 0x34], esi
4340494b test     esi, esi
4340494d je       0x43404c7e
43404953 test     edi, edi
43404955 jne      0x43404963
43404957 cmpsd    dword ptr [esi], dword ptr es:[edi]
43404958 xor      al, 0x44
4340495a inc      edx
4340495b adc      eax, 0x98fd6929
43404960 inc      edi
43404961 loopne   0x434048f6
43404963 mov      eax, dword ptr [0x434693d8]
43404968 xor      edx, edx
4340496a mov      ecx, dword ptr [eax]
4340496c xor      ecx, dword ptr [0x43468bc4]
43404972 mov      eax, dword ptr [esi]
43404974 xor      ecx, 0x3d10b94c
4340497a cmp      eax, dword ptr [ecx + edi]
4340497d lea      ecx, [esi + 4]
43404980 setne    dl
43404983 mov      dword ptr [esp + 0x14], edx
43404987 test     edi, edi
43404989 jne      0x43404997
4340498b jne      0x4340492c
4340498d add      esp, dword ptr [ecx - 0x6c]
43404990 mov      ebp, 0xcd0a4e7f
43404995 push     esp
43404996 outsd    dx, dword ptr [esi]
43404997 mov      eax, dword ptr [0x4346a390]
4340499c and      dword ptr [esp + 0x30], 0
434049a1 movss    xmm1, dword ptr [0x4346f628]
434049a9 movss    xmm3, dword ptr [0x43470340]
434049b1 mov      eax, dword ptr [eax]
434049b3 xor      eax, dword ptr [0x43468324]
434049b9 xor      eax, 0x5ae32976
434049be add      eax, edi
434049c0 sub      eax, ecx
434049c2 movss    xmm0, dword ptr [eax + ecx]
434049c7 subss    xmm0, dword ptr [ecx]
434049cb andps    xmm0, xmm3
434049ce comiss   xmm1, xmm0
434049d1 jb       0x434049e3
434049d3 inc      dword ptr [esp + 0x30]
434049d7 add      ecx, 4
434049da cmp      dword ptr [esp + 0x30], 3
434049df jl       0x434049c2
434049e1 jmp      0x434049ea
434049e3 or       edx, 2
434049e6 mov      dword ptr [esp + 0x14], edx
434049ea lea      ecx, [esi + 0x10]
434049ed test     edi, edi
434049ef jne      0x434049fd
434049f1 fucompp  
434049f3 shr      byte ptr [esp + esi*8 - 0x6eb3d907], cl
434049fa adc      eax, 0xb8a1d50e
434049fd mov      eax, dword ptr [0x434682b8]
434049ff add      byte ptr [esi + 0x43], 0x83
43404a02 and      dword ptr [esp + 0x30], 0
43404a03 and      al, 0x30
43404a06 add      byte ptr [ebx - 0x6ffacd00], cl
43404a07 mov      eax, dword ptr [eax]
43404a09 xor      eax, dword ptr [0x43467d90]
43404a0c jge      0x43404a54
43404a0e inc      ebx
43404a0f xor      eax, 0x1bae1168
43404a14 add      eax, edi
43404a16 sub      eax, ecx
43404a18 movss    xmm0, dword ptr [eax + ecx]
43404a1d subss    xmm0, dword ptr [ecx]
43404a21 andps    xmm0, xmm3
43404a24 comiss   xmm1, xmm0
43404a27 jb       0x43404a39
43404a29 inc      dword ptr [esp + 0x30]
43404a2d add      ecx, 4
43404a30 cmp      dword ptr [esp + 0x30], 3
43404a35 jl       0x43404a18
43404a37 jmp      0x43404a40
43404a39 or       edx, 4
43404a3c mov      dword ptr [esp + 0x14], edx
43404a40 lea      ecx, [esi + 0x1c]
43404a43 test     edi, edi
43404a45 jne      0x43404a53
43404a47 adc      bh, dh
43404a49 cmp      al, 0x27
43404a4b cmp      al, 0xa7
43404a4d das      
43404a4e mov      dword ptr [ebp - 0x5e14feb2], esp
43404a53 mov      eax, dword ptr [0x43467f74]
43404a54 je       0x43404ad5
43404a56 inc      esi
43404a57 inc      ebx
43404a58 and      dword ptr [esp + 0x30], 0
43404a5d mov      eax, dword ptr [eax]
43404a5f xor      eax, dword ptr [0x43467a64]
43404a65 xor      eax, 0x48442721
43404a6a add      eax, edi
43404a6c sub      eax, ecx
43404a6e movss    xmm0, dword ptr [eax + ecx]
43404a73 subss    xmm0, dword ptr [ecx]
43404a77 andps    xmm0, xmm3
43404a7a comiss   xmm1, xmm0
43404a7d jb       0x43404a8f
43404a7f inc      dword ptr [esp + 0x30]
43404a83 add      ecx, 4
43404a86 cmp      dword ptr [esp + 0x30], 3
43404a8b jl       0x43404a6e
43404a8d jmp      0x43404a96
43404a8f or       edx, 8
43404a92 mov      dword ptr [esp + 0x14], edx
43404a96 movss    xmm1, dword ptr [esi + 0x28]
43404a9b test     edi, edi
43404a9d jne      0x43404aab
43404a9f add      dword ptr [ecx + eax*2 + 1], edx
43404aa3 mov      cl, 0xe3
43404aa5 dec      esi
43404aa6 aad      0xe3
43404aa8 xchg     ebx, eax
43404aa9 stosb    byte ptr es:[edi], al
43404aaa pushal   
43404aab mov      eax, dword ptr [0x43468a34]
43404ab0 mov      eax, dword ptr [eax]
43404ab2 xor      eax, dword ptr [0x43468c00]
43404ab8 xor      eax, 0xc246315e
43404abd movss    xmm0, dword ptr [eax + edi + 8]
43404ac3 subss    xmm0, xmm1
43404ac7 movss    xmm1, dword ptr [0x4346dd4c]
43404acf andps    xmm0, xmm3
43404ad2 comiss   xmm1, xmm0
43404ad5 jae      0x43404ade
43404ad7 or       edx, 0x10
43404ada mov      dword ptr [esp + 0x14], edx
43404ade test     edi, edi
43404ae0 jne      0x43404aee
43404ae2 add      edx, ecx
43404ae4 aas      
43404ae5 adc      al, 0x11
43404ae7 clc      
43404ae8 ret      
43404aee mov      eax, dword ptr [0x434670cc]
43404af3 mov      eax, dword ptr [eax]
43404af5 xor      eax, dword ptr [0x43468bcc]
43404afb xor      eax, 0xa9ee6062
43404b00 movss    xmm1, dword ptr [eax + edi]
43404b05 movss    xmm2, dword ptr [eax + edi + 4]
43404b0b subss    xmm2, dword ptr [esi + 0x30]
43404b10 subss    xmm1, dword ptr [esi + 0x2c]
43404b15 movss    xmm0, dword ptr [eax + edi + 8]
43404b1b subss    xmm0, dword ptr [esi + 0x34]
43404b20 mulss    xmm2, xmm2
43404b24 mulss    xmm1, xmm1
43404b28 mulss    xmm0, xmm0
43404b2c addss    xmm2, xmm1
43404b30 addss    xmm2, xmm0
43404b34 comiss   xmm2, dword ptr [0x4346ff6c]
43404b3b jb       0x43404b44
43404b3d or       edx, 0x20
43404b40 mov      dword ptr [esp + 0x14], edx
43404b44 test     edi, edi
43404b46 jne      0x43404b54
43404b48 push     ss
43404b49 pop      ebp
43404b4a stc      
43404b4b and      dl, byte ptr [ebp - 0x125aa8d0]
43404b51 movsd    dword ptr es:[edi], dword ptr [esi]
43404b52 loope    0x43404b3b
43404b54 mov      eax, dword ptr [0x4346a6dc]
43404b59 mov      ecx, dword ptr [eax]
43404b5b xor      ecx, dword ptr [0x43468bd8]
43404b61 mov      eax, dword ptr [esi + 0x3c]
43404b64 xor      ecx, 0x8cfc633a
43404b6a cmp      eax, dword ptr [ecx + edi]
43404b6d je       0x43404b76
43404b6f or       edx, 0x40
43404b72 mov      dword ptr [esp + 0x14], edx
43404b76 movss    xmm1, dword ptr [esi + 0x4c]
43404b7b test     edi, edi
43404b7d jne      0x43404b8b
43404b7f mov      eax, 0xf0ae1371
43404b8b mov      eax, dword ptr [0x43468354]
43404b90 mov      eax, dword ptr [eax]
43404b92 xor      eax, dword ptr [0x4346852c]
43404b98 xor      eax, 0x66146802
43404b9d movss    xmm0, dword ptr [eax + edi]
43404ba2 subss    xmm0, xmm1
43404ba6 movss    xmm1, dword ptr [0x434723ec]
43404bae andps    xmm0, xmm3
43404bb1 comiss   xmm1, xmm0
43404bb4 jae      0x43404bc0
43404bb6 or       edx, 0x400
43404bbc mov      dword ptr [esp + 0x14], edx
43404bc0 test     edi, edi
43404bc2 jne      0x43404bd0
43404bc4 push     -0x36
43404bc6 les      esi, ptr [esi + 0x449e553c]
43404bcc mov      ch, 0xf8
43404bce iretd    
43404bcf leave    
43404bd0 mov      eax, dword ptr [0x43467a74]
43404bd5 mov      eax, dword ptr [eax]
43404bd7 xor      eax, dword ptr [0x434678c0]
43404bdd xor      eax, 0xcd812654
43404be2 mov      ecx, dword ptr [eax + edi]
43404be5 cmp      dword ptr [esi + 0x58], ecx
43404be8 je       0x43404d8b
43404bee or       edx, 0x80
43404bf4 mov      dword ptr [esp + 0x14], edx
43404bf8 mov      esi, dword ptr [esp + 0x14]
43404bfc mov      ecx, dword ptr [esp + 0x24]
43404c00 call     0x43331efc
43404c05 mov      edx, dword ptr [esp + 0x24]
43404c09 xor      ecx, ecx
43404c0b cmp      dword ptr [eax + 4], edx
43404c0e cmove    ecx, eax
43404c11 test     ecx, ecx
43404c13 je       0x43404c34
43404c15 lea      ecx, [edi + 8]
43404c18 mov      eax, dword ptr [ecx]
43404c1a call     dword ptr [eax + 0x28]
43404c1d test     eax, eax
43404c1f jne      0x43404c2d
43404c21 add      al, 0x60
43404c23 push     es
43404c24 mov      bh, 0xcc
43404c26 adc      eax, 0x459c7813
43404c2b cmpsd    dword ptr [esi], dword ptr es:[edi]
43404c2c pop      ss
43404c2d mov      ecx, eax
43404c2f call     0x433b8a2b
43404c34 test     esi, 0xfffff5fe
43404c3a jne      0x43404c7e
43404c3c push     0x8c
43404c41 push     dword ptr [esp + 0x38]
43404c45 mov      esi, dword ptr [esp + 0x24]
43404c49 push     esi
43404c4a call     0x774fd4a0
43404c4f add      esp, 0xc
43404c52 test     edi, edi
43404c54 jne      0x43404c62
43404c56 dec      ebp
43404c57 adc      esp, dword ptr [0x2563e1f0]
43404c5d pop      esp
43404c5f sub      dword ptr [edx - 0x44], edx
43404c62 mov      eax, dword ptr [0x434693d8]
43404c67 mov      eax, dword ptr [eax]
43404c69 xor      eax, dword ptr [0x43468bc4]
43404c6f xor      eax, 0x3d10b94c
43404c74 mov      eax, dword ptr [eax + edi]
43404c77 mov      dword ptr [esi], eax
43404c79 call     0x433d11f7
43404c7e mov      eax, dword ptr [esp + 0x10]
43404c82 mov      esi, 0x96
43404c87 movss    xmm1, dword ptr [0x4346f628]
43404c8f movss    xmm3, dword ptr [0x43470340]
43404c97 movss    xmm4, dword ptr [0x434723ec]
43404c9f mov      eax, dword ptr [eax + 0x24]
43404ca2 movss    xmm2, dword ptr [0x4346dd4c]
43404caa movss    xmm5, dword ptr [0x4346ff6c]
43404cb2 or       dword ptr [eax + 0xc], 0xffffffff
43404cb6 mov      eax, dword ptr [esp + 0x10]
43404cba mov      eax, dword ptr [eax + 0x24]
43404cbd and      dword ptr [eax + 0x1c], 0
43404cc1 mov      eax, dword ptr [esp + 0x10]
43404cc5 mov      eax, dword ptr [eax + 0x24]
43404cc8 mov      dword ptr [eax + 0x24], 1
43404ccf mov      eax, dword ptr [esp + 0x20]
43404cd3 mov      dword ptr [esp + 0x38], eax
43404cd7 cdq      
43404cd8 idiv     esi
43404cda mov      eax, dword ptr [esp + 0x10]
43404cde imul     ecx, edx, 0x90
43404ce4 mov      esi, dword ptr [eax + 0x54]
43404ce7 mov      eax, dword ptr [esp + 0x20]
43404ceb add      esi, ecx
43404ced mov      dword ptr [esp + 0x40], ecx
43404cf1 mov      dword ptr [esp + 0x1c], esi
43404cf5 cmp      dword ptr [esi], eax
43404cf7 jne      0x434056f7
43404cfd test     edi, edi
43404cff jne      0x43404d0d
43404d01 arpl     word ptr [ecx], bp
43404d03 mov      esp, 0xa25b6205
43404d08 and      ebp, ebx
43404d0a xchg     esi, eax
43404d0b bound    esp, qword ptr gs:[ecx + 0x434693d8]
43404d0d mov      eax, dword ptr [0x434693d8]
43404d12 xor      edx, edx
43404d14 mov      ecx, dword ptr [eax]
43404d16 xor      ecx, dword ptr [0x43468bc4]
43404d1c mov      eax, dword ptr [esi + 4]
43404d1f xor      ecx, 0x3d10b94c
43404d25 cmp      eax, dword ptr [ecx + edi]
43404d28 lea      ecx, [esi + 8]
43404d2b mov      dword ptr [esp + 0x44], ecx
43404d2f setne    dl
43404d32 mov      dword ptr [esp + 0x14], edx
43404d36 test     edi, edi
43404d38 jne      0x43404d46
43404d3a dec      edx
43404d3b in       eax, dx
43404d3c sar      byte ptr [0xfb109efa], 0x46
43404d43 sub      dword ptr [ecx - 0x5c6f5e9f], 0x64834346
43404d46 mov      eax, dword ptr [0x4346a390]
43404d4b and      dword ptr [esp + 0x34], 0
43404d4d and      al, 0x34
43404d4f add      byte ptr [ebx + 0x24053300], cl
43404d50 mov      eax, dword ptr [eax]
43404d52 xor      eax, dword ptr [0x43468324]
43404d55 add      dword ptr [esi + 0x43], 0x35
43404d58 xor      eax, 0x5ae32976
43404d59 jbe      0x43404d84
43404d5b jecxz    0x43404db7
43404d5d add      eax, edi
43404d5f sub      eax, dword ptr [esp + 0x44]
43404d63 movss    xmm0, dword ptr [eax + ecx]
43404d68 subss    xmm0, dword ptr [ecx]
43404d6c andps    xmm0, xmm3
43404d6f comiss   xmm1, xmm0
43404d72 jb       0x43404eb5
43404d78 inc      dword ptr [esp + 0x34]
43404d7c add      ecx, 4
43404d7f cmp      dword ptr [esp + 0x34], 3
43404d84 jl       0x43404d63
43404d86 jmp      0x43404ebc
43404d8b cmp      ecx, -1
43404d8e je       0x43404bf8
43404d94 mov      eax, dword ptr [0x4346a890]
43404d99 push     ecx
43404d9a mov      eax, dword ptr [eax]
43404d9c mov      edx, dword ptr [eax + 0x10]
43404d9f mov      eax, esp
43404da1 mov      dword ptr [eax], ecx
43404da3 mov      ecx, dword ptr [0x4346a890]
43404da9 call     edx
43404dab mov      edx, eax
43404dad test     edx, edx
43404daf je       0x43404bf8
43404db5 mov      ecx, dword ptr [0x4346a620]
43404db7 and      byte ptr [esi + 0xff34346], ah
43404dbb movss    xmm1, dword ptr [0x43470340]
43404dbd adc      byte ptr [0x43470340], cl
43404dc3 movss    xmm2, dword ptr [0x434723ec]
43404dcb mov      ecx, dword ptr [ecx]
43404dcd xor      ecx, dword ptr [0x434671e4]
43404dd3 xor      ecx, 0xd2563274
43404dd9 movss    xmm0, dword ptr [ecx + edx]
43404dde subss    xmm0, dword ptr [esi + 0x64]
43404de3 mov      esi, dword ptr [esp + 0x14]
43404de7 andps    xmm0, xmm1
43404dea comiss   xmm2, xmm0
43404ded jae      0x43404df5
43404def or       esi, 0x100
43404df5 mov      eax, dword ptr [0x43467200]
43404dfa mov      ecx, dword ptr [esp + 0x34]
43404dfe mov      eax, dword ptr [eax]
43404e00 xor      eax, dword ptr [0x4346a5fc]
43404e06 movss    xmm0, dword ptr [ecx + 0x60]
43404e0b xor      eax, 0x176a381
43404e10 ucomiss  xmm0, dword ptr [eax + edx]
43404e14 lahf     
43404e15 test     ah, 0x44
43404e18 jnp      0x43404e20
43404e1a or       esi, 0x200
43404e20 mov      eax, dword ptr [0x43467b44]
43404e25 mov      eax, dword ptr [eax]
43404e27 xor      eax, dword ptr [0x4346a774]
43404e2d xor      eax, 0x6777c9ce
43404e32 movss    xmm0, dword ptr [eax + edx]
43404e37 mov      eax, esi
43404e39 subss    xmm0, dword ptr [ecx + 0x44]
43404e3e or       eax, 0x1000
43404e43 mov      ecx, edi
43404e45 andps    xmm0, xmm1
43404e48 comiss   xmm2, xmm0
43404e4b cmovae   eax, esi
43404e4e mov      dword ptr [esp + 0x54], eax
43404e52 mov      eax, dword ptr [0x43468d48]
43404e57 mov      eax, dword ptr [eax]
43404e59 xor      eax, dword ptr [0x43467e94]
43404e5f xor      eax, 0xc6c78c82
43404e64 push     dword ptr [eax + edx]
43404e67 call     0x43342dd7
43404e6c mov      edx, dword ptr [esp + 0x54]
43404e70 mov      esi, edx
43404e72 mov      dword ptr [esp + 0x50], eax
43404e76 test     eax, eax
43404e78 je       0x43404bfc
43404e7e mov      ecx, dword ptr [0x43468da0]
43404e84 mov      eax, dword ptr [esp + 0x34]
43404e88 mov      edi, dword ptr [esp + 0x50]
43404e8c mov      ecx, dword ptr [ecx]
43404e8e xor      ecx, dword ptr [0x4346a6bc]
43404e94 mov      eax, dword ptr [eax + 0x74]
43404e97 xor      ecx, 0x695ff325
43404e9d cmp      eax, dword ptr [ecx + edi]
43404ea0 mov      edi, dword ptr [esp + 0x18]
43404ea4 je       0x43404bfc
43404eaa or       esi, 0x2000
43404eb0 jmp      0x43404bfc
43404eb5 or       edx, 2
43404eb8 mov      dword ptr [esp + 0x14], edx
43404ebc lea      ecx, [esi + 0x14]
43404ebf mov      dword ptr [esp + 0x30], ecx
43404ec3 test     edi, edi
43404ec5 jne      0x43404ed3
43404ec7 cmp      eax, ebx
43404ec9 and      cl, byte ptr [ebx - 0x259860df]
43404ecf xchg     edx, ebx
43404ed1 lea      esi, [edx + 0x4682b8a1]
43404ed3 mov      eax, dword ptr [0x434682b8]
43404ed7 inc      ebx
43404ed8 and      dword ptr [esp + 0x34], 0
43404edd mov      eax, dword ptr [eax]
43404edf xor      eax, dword ptr [0x43467d90]
43404ee5 xor      eax, 0x1bae1168
43404eea add      eax, edi
43404eec sub      eax, dword ptr [esp + 0x30]
43404ef0 movss    xmm0, dword ptr [eax + ecx]
43404ef5 subss    xmm0, dword ptr [ecx]
43404ef9 andps    xmm0, xmm3
43404efc comiss   xmm1, xmm0
43404eff jb       0x43404f11
43404f01 inc      dword ptr [esp + 0x34]
43404f05 add      ecx, 4
43404f08 cmp      dword ptr [esp + 0x34], 3
43404f0d jl       0x43404ef0
43404f0f jmp      0x43404f18
43404f11 or       edx, 4
43404f14 mov      dword ptr [esp + 0x14], edx
43404f18 lea      ecx, [esi + 0x20]
43404f1b mov      dword ptr [esp + 0x24], ecx
43404f1f test     edi, edi
43404f21 jne      0x43404f2f
43404f23 mov      ebp, 0xdaab61dd
43404f28 xor      al, 0x12
43404f2a leave    
43404f2b cmpsd    dword ptr [esi], dword ptr es:[edi]
43404f2c sahf     
43404f2d in       eax, 0xee
43404f2f mov      eax, dword ptr [0x43467f74]
43404f34 and      dword ptr [esp + 0x34], 0
43404f39 mov      eax, dword ptr [eax]
43404f3b xor      eax, dword ptr [0x43467a64]
43404f41 xor      eax, 0x48442721
43404f46 add      eax, edi
43404f48 sub      eax, dword ptr [esp + 0x24]
43404f4c movss    xmm0, dword ptr [eax + ecx]
43404f51 subss    xmm0, dword ptr [ecx]
43404f55 andps    xmm0, xmm3
43404f58 comiss   xmm1, xmm0
43404f5b jb       0x43404f6d
43404f5d inc      dword ptr [esp + 0x34]
43404f61 add      ecx, 4
43404f64 cmp      dword ptr [esp + 0x34], 3
43404f69 jl       0x43404f4c
43404f6b jmp      0x43404f74
43404f6d or       edx, 8
43404f70 mov      dword ptr [esp + 0x14], edx
43404f74 movss    xmm1, dword ptr [esi + 0x2c]
43404f79 test     edi, edi
43404f7b jne      0x43404f89
43404f7d movsd    dword ptr es:[edi], dword ptr [esi]
43404f7e pop      ecx
43404f7f ja       0x43404f92
43404f81 sbb      dl, ah
43404f83 add      al, 0xf4
43404f85 out      0x4b, al
43404f87 mov      word ptr [ebx + 0x468a34a1], es
43404f89 mov      eax, dword ptr [0x43468a34]
43404f8d inc      ebx
43404f8e mov      eax, dword ptr [eax]
43404f90 xor      eax, dword ptr [0x43468c00]
43404f92 add      byte ptr [esi + eax*2 + 0x315e3543], cl
43404f96 xor      eax, 0xc246315e
43404f99 inc      esi
43404f9a ret      0xff3
43404f9b movss    xmm0, dword ptr [eax + edi + 8]
43404fa1 subss    xmm0, xmm1
43404fa5 andps    xmm0, xmm3
43404fa8 comiss   xmm2, xmm0
43404fab jae      0x43404fb4
43404fad or       edx, 0x10
43404fb0 mov      dword ptr [esp + 0x14], edx
43404fb4 test     edi, edi
43404fb6 jne      0x43404fc4
43404fb8 xor      al, 0x9a
43404fba sbb      al, 0x3e
43404fbc mov      ebp, eax
43404fbe add      al, byte ptr [ebx - 0x1c548e90]
43404fc4 mov      eax, dword ptr [0x434670cc]
43404fc9 mov      eax, dword ptr [eax]
43404fcb xor      eax, dword ptr [0x43468bcc]
43404fd1 xor      eax, 0xa9ee6062
43404fd6 movss    xmm1, dword ptr [eax + edi]
43404fdb movss    xmm2, dword ptr [eax + edi + 4]
43404fe1 subss    xmm2, dword ptr [esi + 0x34]
43404fe6 subss    xmm1, dword ptr [esi + 0x30]
43404feb movss    xmm0, dword ptr [eax + edi + 8]
43404ff1 subss    xmm0, dword ptr [esi + 0x38]
43404ff6 mulss    xmm2, xmm2
43404ffa mulss    xmm1, xmm1
43404ffe mulss    xmm0, xmm0
43405002 addss    xmm2, xmm1
43405006 addss    xmm2, xmm0
4340500a comiss   xmm2, xmm5
4340500d jb       0x43405016
4340500f or       edx, 0x20
43405012 mov      dword ptr [esp + 0x14], edx
43405016 test     edi, edi
43405018 jne      0x43405026
4340501a push     ds
4340501c rol      dword ptr [esi], 1
4340501e add      eax, 0xc386f929
43405023 mov      dh, 0x1e
43405025 and      esp, dword ptr [ecx + 0x4346a6dc]
43405026 mov      eax, dword ptr [0x4346a6dc]
4340502b mov      ecx, dword ptr [eax]
4340502d xor      ecx, dword ptr [0x43468bd8]
43405033 mov      eax, dword ptr [esi + 0x40]
43405036 xor      ecx, 0x8cfc633a
4340503c cmp      eax, dword ptr [ecx + edi]
4340503f je       0x43405048
43405041 or       edx, 0x40
43405044 mov      dword ptr [esp + 0x14], edx
43405048 movss    xmm1, dword ptr [esi + 0x50]
4340504d test     edi, edi
4340504f jne      0x4340505d
43405051 enter    0x502c, 0x3c
43405055 and      al, 0xea
43405057 loopne   0x434050a2
43405059 call     0xe4794913
4340505d mov      eax, dword ptr [0x43468354]
4340505e push     esp
4340505f add      dword ptr [esi + 0x43], -0x75
43405062 mov      eax, dword ptr [eax]
43405063 add      byte ptr [ebx], dh
43405064 xor      eax, dword ptr [0x4346852c]
43405065 add      eax, 0x4346852c
4340506a xor      eax, 0x66146802
4340506f movss    xmm0, dword ptr [eax + edi]
43405074 subss    xmm0, xmm1
43405078 andps    xmm0, xmm3
4340507b comiss   xmm4, xmm0
4340507e jae      0x4340508a
43405080 or       edx, 0x400
43405086 mov      dword ptr [esp + 0x14], edx
4340508a test     edi, edi
4340508c jne      0x4340509a
4340508e sal      cl, 1
43405090 push     0xcef7c103
43405095 or       dl, byte ptr [edi + ecx*2]
43405098 xor      ecx, ecx
4340509a mov      eax, dword ptr [0x43467a74]
4340509f mov      eax, dword ptr [eax]
434050a1 xor      eax, dword ptr [0x434678c0]
434050a7 xor      eax, 0xcd812654
434050ac mov      ecx, dword ptr [eax + edi]
434050af cmp      dword ptr [esi + 0x5c], ecx
434050b2 je       0x434050c3
434050b4 or       edx, 0x80
434050ba mov      dword ptr [esp + 0x14], edx
434050be jmp      0x434051e3
434050c3 cmp      ecx, -1
434050c6 je       0x434051e3
434050cc mov      eax, dword ptr [0x4346a890]
434050d1 push     ecx
434050d2 mov      eax, dword ptr [eax]
434050d4 mov      edx, dword ptr [eax + 0x10]
434050d7 mov      eax, esp
434050d9 mov      dword ptr [eax], ecx
434050db mov      ecx, dword ptr [0x4346a890]
434050e1 call     edx
434050e3 mov      edx, eax
434050e5 test     edx, edx
434050e7 je       0x434051e3
434050ed mov      ecx, dword ptr [0x4346a620]
434050f3 movss    xmm1, dword ptr [0x43470340]
434050fb movss    xmm2, dword ptr [0x434723ec]
43405103 mov      ecx, dword ptr [ecx]
43405105 xor      ecx, dword ptr [0x434671e4]
4340510b xor      ecx, 0xd2563274
43405111 movss    xmm0, dword ptr [ecx + edx]
43405116 subss    xmm0, dword ptr [esi + 0x68]
4340511b mov      ecx, dword ptr [esp + 0x14]
4340511f andps    xmm0, xmm1
43405122 comiss   xmm2, xmm0
43405125 jae      0x4340512d
43405127 or       ecx, 0x100
4340512d mov      eax, dword ptr [0x43467200]
43405132 movss    xmm0, dword ptr [esi + 0x64]
43405137 mov      eax, dword ptr [eax]
43405139 xor      eax, dword ptr [0x4346a5fc]
4340513f xor      eax, 0x176a381
43405144 ucomiss  xmm0, dword ptr [eax + edx]
43405148 lahf     
43405149 test     ah, 0x44
4340514c jnp      0x43405154
4340514e or       ecx, 0x200
43405154 mov      eax, dword ptr [0x43467b44]
43405159 mov      eax, dword ptr [eax]
4340515b xor      eax, dword ptr [0x4346a774]
43405161 xor      eax, 0x6777c9ce
43405166 movss    xmm0, dword ptr [eax + edx]
4340516b mov      eax, ecx
4340516d subss    xmm0, dword ptr [esi + 0x48]
43405172 or       eax, 0x1000
43405177 andps    xmm0, xmm1
4340517a comiss   xmm2, xmm0
4340517d cmovae   eax, ecx
43405180 mov      ecx, edi
43405182 mov      dword ptr [esp + 0x54], eax
43405186 mov      eax, dword ptr [0x43468d48]
4340518b mov      eax, dword ptr [eax]
4340518d xor      eax, dword ptr [0x43467e94]
43405193 xor      eax, 0xc6c78c82
43405198 push     dword ptr [eax + edx]
4340519b call     0x43342dd7
434051a0 mov      edx, dword ptr [esp + 0x54]
434051a4 mov      dword ptr [esp + 0x50], eax
434051a8 mov      dword ptr [esp + 0x14], edx
434051ac test     eax, eax
434051ae je       0x434051e3
434051b0 mov      ecx, dword ptr [0x43468da0]
434051b6 mov      edi, dword ptr [esp + 0x50]
434051ba mov      eax, dword ptr [esi + 0x78]
434051bd mov      dword ptr [esp + 0x14], edx
434051c1 mov      ecx, dword ptr [ecx]
434051c3 xor      ecx, dword ptr [0x4346a6bc]
434051c9 xor      ecx, 0x695ff325
434051cf cmp      eax, dword ptr [ecx + edi]
434051d2 mov      edi, dword ptr [esp + 0x18]
434051d6 je       0x434051e3
434051d8 mov      eax, edx
434051da or       eax, 0x2000
434051df mov      dword ptr [esp + 0x14], eax
434051e3 mov      ecx, dword ptr [esp + 0x20]
434051e7 call     0x433b9184
434051ec mov      dword ptr [esp + 0x54], eax
434051f0 test     eax, eax
434051f2 je       0x4340528c
434051f8 lea      ecx, [edi + 8]
434051fb mov      edx, dword ptr [ecx]
434051fd call     dword ptr [edx + 0x28]
43405200 test     eax, eax
43405202 jne      0x43405210
43405204 mov      dword ptr [edx + 0x78bdde9d], ebx
4340520a aas      
4340520b push     esi
4340520c stc      
4340520d xor      ecx, dword ptr fs:[ebx + 0x3814e8c8]
43405210 mov      ecx, eax
43405212 call     0x433b8a2b
43405215 sti      
43405216 dec      dword ptr [ebx - 0x72abdb8c]
43405217 mov      esi, dword ptr [esp + 0x54]
4340521b lea      edi, [esp + 0x60]
4340521c jl       0x43405242
4340521e pushal   
4340521f mov      ecx, dword ptr [esp + 0x20]
43405223 lea      edx, [esp + 0x60]
43405227 add      esi, 0xc
4340522a mov      dword ptr [esp + 0x50], eax
4340522e movsd    dword ptr es:[edi], dword ptr [esi]
4340522f movsd    dword ptr es:[edi], dword ptr [esi]
43405230 movsd    dword ptr es:[edi], dword ptr [esi]
43405231 call     0x43384c9e
43405236 movss    xmm0, dword ptr [esp + 0x64]
4340523c call     0x4337f9d3
43405241 movaps   xmm1, xmm0
43405242 sub      al, cl
43405244 movss    xmm0, dword ptr [esp + 0x60]
4340524a call     0x4337f9d3
4340524f mov      ecx, dword ptr [esp + 0x50]
43405253 ucomiss  xmm0, dword ptr [ecx + 0x1a8]
4340525a lahf     
4340525b test     ah, 0x44
4340525e jp       0x4340526d
43405260 ucomiss  xmm1, dword ptr [ecx + 0x1ac]
43405267 lahf     
43405268 test     ah, 0x44
4340526b jnp      0x43405284
4340526d mov      eax, dword ptr [esp + 0x14]
43405271 mov      edi, dword ptr [esp + 0x18]
43405275 or       eax, 0x800
4340527a mov      esi, dword ptr [esp + 0x1c]
4340527e mov      dword ptr [esp + 0x14], eax
43405282 jmp      0x43405290
43405284 mov      edi, dword ptr [esp + 0x18]
43405288 mov      esi, dword ptr [esp + 0x1c]
4340528c mov      eax, dword ptr [esp + 0x14]
43405290 test     al, 4
43405292 je       0x43405352
43405298 mov      eax, dword ptr [esp + 0x10]
4340529c mov      ecx, dword ptr [eax + 0x1c]
4340529f mov      eax, dword ptr [ecx]
434052a1 call     dword ptr [eax + 0x334]
434052a7 mov      dword ptr [0x43467114], eax
434052ac test     edi, edi
434052ae jne      0x434052bc
434052b0 xor      byte ptr [edi], bh
434052b2 pop      ds
434052b3 mov      bh, 0x3f
434052b5 out      dx, al
434052b6 imul     ecx, dword ptr [esi - 0x6474bdf2], -0x5f
434052bc mov      eax, dword ptr [0x434688d0]
434052bd ror      byte ptr [eax + 0x8b4346], 1
434052c1 mov      eax, dword ptr [eax]
434052c3 xor      eax, dword ptr [0x43468c24]
434052c9 xor      eax, 0xe2fbe695
434052ce test     byte ptr [eax + edi], 1
434052d2 je       0x4340534e
434052d4 test     edi, edi
434052d6 jne      0x434052e4
434052d8 leave    
434052d9 cmc      
434052da push     -0x6d
434052dc scasb    al, byte ptr es:[edi]
434052dd cmp      byte ptr [esi - 0x78], al
434052e0 cmp      al, 0x64
434052e2 add      byte ptr [ecx - 0x5f], bl
434052e4 mov      eax, dword ptr [0x43467a74]
434052e5 je       0x43405361
434052e7 inc      esi
434052e8 inc      ebx
434052e9 mov      eax, dword ptr [eax]
434052eb xor      eax, dword ptr [0x434678c0]
434052f1 xor      eax, 0xcd812654
434052f6 mov      ecx, dword ptr [eax + edi]
434052f9 cmp      ecx, -1
434052fc je       0x4340534e
434052fe mov      eax, dword ptr [0x4346a890]
43405303 push     ecx
43405304 mov      eax, dword ptr [eax]
43405306 mov      edx, dword ptr [eax + 0x10]
43405309 mov      eax, esp
4340530b mov      dword ptr [eax], ecx
4340530d mov      ecx, dword ptr [0x4346a890]
43405313 call     edx
43405315 test     eax, eax
43405317 je       0x4340534e
43405319 mov      ecx, dword ptr [0x4346908c]
4340531f mov      ecx, dword ptr [ecx]
43405321 xor      ecx, dword ptr [0x43468ba0]
43405327 xor      ecx, 0x5c9f0fbb
4340532d mov      cx, word ptr [ecx + eax]
43405331 call     0x433d24bb
43405336 test     al, al
43405338 je       0x4340534e
4340533a mov      eax, dword ptr [0x434759c0]
4340533f and      eax, 0xfffffbff
43405344 or       eax, 0x200
43405349 mov      dword ptr [0x434759c0], eax
4340534e mov      eax, dword ptr [esp + 0x14]
43405352 test     al, 1
43405354 je       0x4340539a
43405356 cmp      eax, 1
43405359 jne      0x434056f7
4340535f mov      eax, dword ptr [0x4346a334]
43405361 mov      dword ptr [0xff34346], eax
43405364 movss    xmm0, dword ptr [0x4346f868]
43405366 adc      byte ptr [0x4346f868], al
4340536c movss    xmm1, dword ptr [eax]
43405370 mov      eax, dword ptr [esp + 0x10]
43405374 subss    xmm1, dword ptr [eax + 0x58]
43405379 andps    xmm1, xmmword ptr [0x43470340]
43405380 comiss   xmm0, xmm1
43405383 jae      0x43405392
43405385 test     byte ptr [esi + 0x8c], 8
4340538c je       0x434056f3
43405392 mov      edx, dword ptr [esp + 0x14]
43405396 not      edx
43405398 jmp      0x434053a3
4340539a mov      edx, eax
4340539c not      edx
4340539e test     dl, 2
434053a1 je       0x434053dc
434053a3 mov      ecx, dword ptr [esp + 0x18]
434053a7 lea      esi, [esi + 8]
434053aa lea      edi, [esp + 0x60]
434053ae movsd    dword ptr es:[edi], dword ptr [esi]
434053af movsd    dword ptr es:[edi], dword ptr [esi]
434053b0 movsd    dword ptr es:[edi], dword ptr [esi]
434053b1 test     ecx, ecx
434053b3 jne      0x434053c1
434053b5 mov      ch, 0x36
434053b7 xchg     ecx, eax
434053b8 xor      dword ptr [ebx], ecx
434053ba mov      dl, 0xe1
434053bc sbb      edx, dword ptr [esi]
434053be test     ah, -0x32
434053c1 mov      eax, dword ptr [0x4346a390]
434053c6 lea      esi, [esp + 0x60]
434053ca mov      edi, dword ptr [eax]
434053cc xor      edi, dword ptr [0x43468324]
434053d2 xor      edi, 0x5ae32976
434053d8 add      edi, ecx
434053da jmp      0x43405409
434053dc test     edi, edi
434053de jne      0x434053ec
434053e0 jp       0x43405440
434053e2 jp       0x434053ca
434053e4 xchg     byte ptr [ebp - 0x1943590a], ch
434053ea cmp      ah, byte ptr [ebp + 0x46a390a1]
434053ec mov      eax, dword ptr [0x4346a390]
434053f0 inc      ebx
434053f1 mov      ecx, dword ptr [esp + 0x18]
434053f5 mov      esi, dword ptr [eax]
434053f7 xor      esi, dword ptr [0x43468324]
434053fd xor      esi, 0x5ae32976
43405403 add      esi, edi
43405405 mov      edi, dword ptr [esp + 0x44]
43405409 movsd    dword ptr es:[edi], dword ptr [esi]
4340540a movsd    dword ptr es:[edi], dword ptr [esi]
4340540b movsd    dword ptr es:[edi], dword ptr [esi]
4340540c test     dl, 4
4340540f je       0x43405447
43405411 mov      esi, dword ptr [esp + 0x30]
43405415 lea      edi, [esp + 0x60]
43405419 movsd    dword ptr es:[edi], dword ptr [esi]
4340541a movsd    dword ptr es:[edi], dword ptr [esi]
4340541b movsd    dword ptr es:[edi], dword ptr [esi]
4340541c test     ecx, ecx
4340541e jne      0x4340542c
43405420 fcom     st(5)
43405422 pop      eax
43405423 sbb      dword ptr [edx], esi
4340542c mov      eax, dword ptr [0x434682b8]
43405431 lea      esi, [esp + 0x60]
43405435 mov      edi, dword ptr [eax]
43405437 xor      edi, dword ptr [0x43467d90]
4340543d xor      edi, 0x1bae1168
43405440 adc      dword ptr [esi - 0x1406fce5], ebp
43405443 add      edi, ecx
43405445 jmp      0x43405470
43405446 sub      dword ptr [ebp - 0x28f38a37], eax
43405447 test     ecx, ecx
43405449 jne      0x43405457
4340544b xlatb    
4340544c test     dh, al
4340544e xchg     esi, eax
4340544f xchg     ebx, eax
43405450 jg       0x434054cb
43405452 adc      ah, 0xb9
43405455 cmp      al, 0xa1
43405457 mov      eax, dword ptr [0x434682b8]
43405458 mov      eax, 0x8b434682
4340545c mov      edi, dword ptr [esp + 0x30]
4340545d jl       0x43405483
4340545f xor      byte ptr [ebx - 0x6fcaccd0], cl
43405460 mov      esi, dword ptr [eax]
43405462 xor      esi, dword ptr [0x43467d90]
43405465 jge      0x434054ad
43405467 inc      ebx
43405468 xor      esi, 0x1bae1168
4340546e add      esi, ecx
43405470 movsd    dword ptr es:[edi], dword ptr [esi]
43405471 movsd    dword ptr es:[edi], dword ptr [esi]
43405472 movsd    dword ptr es:[edi], dword ptr [esi]
43405473 test     dl, 8
43405476 je       0x434054ae
43405478 mov      esi, dword ptr [esp + 0x24]
4340547c lea      edi, [esp + 0x60]
43405480 movsd    dword ptr es:[edi], dword ptr [esi]
43405481 movsd    dword ptr es:[edi], dword ptr [esi]
43405482 movsd    dword ptr es:[edi], dword ptr [esi]
43405483 test     ecx, ecx
43405485 jne      0x43405493
43405487 dec      esi
43405488 dec      eax
43405489 dec      eax
4340548a and      al, byte ptr [edx]
4340548c lcall    0x85b8, 0x72e6991f
43405493 mov      eax, dword ptr [0x43467f74]
43405498 lea      esi, [esp + 0x60]
4340549c mov      edi, dword ptr [eax]
4340549e xor      edi, dword ptr [0x43467a64]
434054a4 xor      edi, 0x48442721
434054aa add      edi, ecx
434054ac jmp      0x434054d7
434054ad sub      dword ptr [ebp - 0xaf38a37], eax
434054ae test     ecx, ecx
434054b0 jne      0x434054be
434054b2 cmc      
434054b3 sbb      byte ptr [eax - 0x76], 0xa
434054b7 and      ecx, dword ptr [esi]
434054b9 rcr      byte ptr [edi], cl
434054bb cmp      eax, 0x74a1b2bf
434054be mov      eax, dword ptr [0x43467f74]
434054c0 jg       0x43405508
434054c2 inc      ebx
434054c3 mov      edi, dword ptr [esp + 0x24]
434054c7 mov      esi, dword ptr [eax]
434054c9 xor      esi, dword ptr [0x43467a64]
434054cb jp       0x43405514
434054ce inc      ebx
434054cf xor      esi, 0x48442721
434054d5 add      esi, ecx
434054d7 movsd    dword ptr es:[edi], dword ptr [esi]
434054d8 movsd    dword ptr es:[edi], dword ptr [esi]
434054d9 movsd    dword ptr es:[edi], dword ptr [esi]
434054da mov      edi, dword ptr [esp + 0x18]
434054de test     dl, 0x10
434054e1 je       0x43405516
434054e3 mov      edx, dword ptr [esp + 0x1c]
434054e7 movss    xmm0, dword ptr [edx + 0x2c]
434054ec test     edi, edi
434054ee jne      0x434054fc
434054f0 push     cs
434054f1 mov      bh, 0xec
434054f3 or       cl, dl
434054f5 salc     
434054f6 xchg     edx, eax
434054f7 loope    0x43405555
434054f9 mov      ebx, 0x34a1fd07
434054fc mov      eax, dword ptr [0x43468a34]
434054fe mov      al, byte ptr [esi + 0x43]
43405501 mov      eax, dword ptr [eax]
43405503 xor      eax, dword ptr [0x43468c00]
43405508 inc      ebx
43405509 xor      eax, 0xc246315e
4340550e movss    dword ptr [eax + edi + 8], xmm0
43405514 jmp      0x43405543
43405516 test     edi, edi
43405518 jne      0x43405526
4340551a add      byte ptr [ebp + 0x52], ch
4340551d mov      al, byte ptr [0xa8f0ed2f]
4340551e das      
4340551f in       eax, dx
43405522 xchg     esp, eax
43405523 aaa      
43405524 js       0x4340551e
43405526 mov      eax, dword ptr [0x43468a34]
4340552b mov      edx, dword ptr [esp + 0x1c]
4340552f mov      eax, dword ptr [eax]
43405531 xor      eax, dword ptr [0x43468c00]
43405537 xor      eax, 0xc246315e
4340553c mov      eax, dword ptr [eax + edi + 8]
43405540 mov      dword ptr [edx + 0x2c], eax
43405543 mov      ecx, dword ptr [esp + 0x14]
43405547 test     cl, 0x20
4340554a je       0x4340557d
4340554c test     edi, edi
4340554e jne      0x4340555c
43405550 cmp      edx, dword ptr [esi + 0x1b]
43405553 mov      eax, 0x836d7278
43405558 pop      eax
43405559 sti      
4340555a xor      dl, byte ptr [edx - 0x5f]
4340555c mov      eax, dword ptr [0x434670cc]
4340555d int3     
43405561 mov      esi, dword ptr [eax]
43405563 xor      esi, dword ptr [0x43468bcc]
43405569 xor      esi, 0xa9ee6062
4340556f add      esi, edi
43405571 lea      edi, [edx + 0x30]
43405574 movsd    dword ptr es:[edi], dword ptr [esi]
43405575 movsd    dword ptr es:[edi], dword ptr [esi]
43405576 movsd    dword ptr es:[edi], dword ptr [esi]
43405577 mov      edi, dword ptr [esp + 0x18]
4340557b jmp      0x434055b5
4340557d mov      eax, dword ptr [edx + 0x58]
43405580 mov      esi, dword ptr [edx + 0x54]
43405583 mov      dword ptr [esp + 0x54], eax
43405587 test     edi, edi
43405589 jne      0x43405597
4340558b jp       0x434055c7
4340558d int3     
43405597 mov      eax, dword ptr [0x43467dd4]
4340559c mov      eax, dword ptr [eax]
4340559e xor      eax, dword ptr [0x4346a52c]
434055a4 xor      eax, 0xfb7e3404
434055a9 mov      dword ptr [eax + edi + 4], esi
434055ad mov      esi, dword ptr [esp + 0x54]
434055b1 mov      dword ptr [eax + edi + 8], esi
434055b5 test     ecx, 0x400
434055bb je       0x434055e5
434055bd test     edi, edi
434055bf jne      0x434055cd
434055c1 pop      eax
434055c2 mov      bl, 0x93
434055c4 scasb    al, byte ptr es:[edi]
434055c5 les      esi, ptr [eax + 0x539a25bc]
434055c7 mov      esp, 0xce539a25
434055cb into     
434055cc jp       0x4340556f
434055cd mov      eax, dword ptr [0x43468354]
434055ce push     esp
434055cf add      dword ptr [esi + 0x43], -0x75
434055d2 mov      eax, dword ptr [eax]
434055d3 add      byte ptr [ebx], dh
434055d4 xor      eax, dword ptr [0x4346852c]
434055d5 add      eax, 0x4346852c
434055da xor      eax, 0x66146802
434055df mov      eax, dword ptr [eax + edi]
434055e2 mov      dword ptr [edx + 0x50], eax
434055e5 test     edi, edi
434055e7 jne      0x434055f5
434055e9 sbb      ecx, ebx
434055ec add      cl, byte ptr [edi + 0x1e95fc26]
434055f2 mov      ebx, dword ptr [0x8b30a100]
434055f5 mov      eax, dword ptr [0x43468b30]
434055f8 inc      esi
434055f9 inc      ebx
434055fa xorps    xmm1, xmm1
434055fd movss    xmm2, dword ptr [0x434704a0]
43405605 movss    xmm0, dword ptr [edx + 0x3c]
4340560a push     0xe
4340560c mov      esi, dword ptr [eax]
4340560e xor      esi, dword ptr [0x434693ac]
43405614 pop      ecx
43405615 xor      esi, 0x2f33c681
4340561b call     0x433fd134
43405620 movss    xmm1, dword ptr [esi + edi]
43405625 ucomiss  xmm1, xmm0
43405628 lahf     
43405629 test     ah, 0x44
4340562c jp       0x43405660
4340562e mov      ecx, dword ptr [esp + 0x1c]
43405632 movss    xmm0, dword ptr [ecx + 0x3c]
43405637 test     edi, edi
43405639 jne      0x43405647
4340563b jnp      0x43405639
4340563d cmp      esi, dword ptr [esi + 0x6557393d]
43405643 pop      di
43405645 pop      eax
43405646 sub      dword ptr [ecx + 0x43468b30], esp
43405647 mov      eax, dword ptr [0x43468b30]
4340564c mov      eax, dword ptr [eax]
4340564e xor      eax, dword ptr [0x434693ac]
43405654 xor      eax, 0x2f33c681
43405659 movss    dword ptr [eax + edi], xmm0
4340565e jmp      0x4340568c
43405660 test     edi, edi
43405662 jne      0x43405670
43405664 mul      dword ptr [esi - 0x28]
43405667 mov      edi, dword ptr [eax - 5]
4340566a xchg     ecx, eax
4340566b push     cs
4340566c push     ebp
4340566d xor      eax, 0x30a11d8c
43405670 mov      eax, dword ptr [0x43468b30]
43405672 mov      eax, dword ptr [esi + 0x43]
43405675 mov      ecx, dword ptr [esp + 0x1c]
43405679 mov      eax, dword ptr [eax]
4340567b xor      eax, dword ptr [0x434693ac]
43405681 xor      eax, 0x2f33c681
43405686 mov      eax, dword ptr [eax + edi]
43405689 mov      dword ptr [ecx + 0x3c], eax
4340568c test     byte ptr [esp + 0x14], 0x34
43405691 mov      esi, dword ptr [esp + 0x10]
43405695 je       0x434056fb
43405697 mov      eax, dword ptr [0x43475b2c]
4340569c xor      ecx, ecx
4340569e mov      edx, dword ptr [esp + 0x38]
434056a2 mov      edi, dword ptr [eax]
434056a4 cmp      edx, edi
434056a6 jg       0x434056d5
434056a8 mov      eax, edx
434056aa cdq      
434056ab idiv     dword ptr [esp + 0x58]
434056af imul     eax, edx, 0x90
434056b5 mov      edx, dword ptr [esp + 0x38]
434056b9 add      eax, dword ptr [esi + 0x54]
434056bc cmp      dword ptr [eax], edx
434056be jne      0x434056d5
434056c0 or       dword ptr [eax + 0x8c], 2
434056c7 inc      ecx
434056c8 inc      edx
434056c9 mov      dword ptr [esp + 0x38], edx
434056cd cmp      ecx, 0x96
434056d3 jb       0x434056a4
434056d5 mov      eax, dword ptr [esi + 0x24]
434056d8 mov      edi, dword ptr [esp + 0x18]
434056dc or       dword ptr [eax + 0xc], 0xffffffff
434056e0 mov      eax, dword ptr [esi + 0x24]
434056e3 and      dword ptr [eax + 0x1c], 0
434056e7 mov      eax, dword ptr [esi + 0x24]
434056ea mov      dword ptr [eax + 0x24], 1
434056f1 jmp      0x434056fb
434056f3 mov      esi, eax
434056f5 jmp      0x434056fb
434056f7 mov      esi, dword ptr [esp + 0x10]
434056fb mov      eax, dword ptr [esp + 0x28]
434056ff test     eax, eax
43405701 jle      0x43405954
43405707 cmp      eax, 1
4340570a jle      0x434059af
43405710 push     3
43405712 pop      eax
43405713 cmp      dword ptr [0x43479798], eax
43405719 je       0x434059af
4340571f mov      eax, dword ptr [0x43475794]
43405724 mov      ecx, dword ptr [esi + 0x48]
43405727 cmp      ecx, dword ptr [eax]
43405729 jle      0x434059af
4340572f mov      ecx, dword ptr [esi + 0x1c]
43405732 mov      eax, dword ptr [ecx]
43405734 call     dword ptr [eax + 0x334]
4340573a cmp      dword ptr [esi + 0x48], eax
4340573d jge      0x434059af
43405743 test     edi, edi
43405745 jne      0x43405753
43405747 push     ebx
43405748 out      0xca, eax
4340574a push     0x28b750a5
4340574f sub      ebx, dword ptr [eax + 0x78a12bd8]
43405753 mov      eax, dword ptr [0x43468e78]
43405755 mov      es, word ptr [esi + 0x43]
43405758 mov      eax, dword ptr [eax]
4340575a xor      eax, dword ptr [0x434684e4]
43405760 xor      eax, 0x9d920e35
43405765 cmp      byte ptr [eax + edi], 0
43405769 jne      0x434059af
4340576f mov      ecx, dword ptr [esi + 0x1c]
43405772 mov      eax, dword ptr [ecx]
43405774 call     dword ptr [eax + 0x334]
4340577a mov      ecx, eax
4340577c call     0x4334116b
43405781 mov      ecx, eax
43405783 test     ecx, ecx
43405785 je       0x434059af
4340578b cmp      dword ptr [ecx + 8], 0x7f7fffff
43405792 je       0x434059af
43405798 movss    xmm0, dword ptr [ecx + 0xc]
4340579d call     0x4337f9d3
434057a2 movaps   xmm3, xmm0
434057a5 movss    xmm0, dword ptr [ecx + 0x10]
434057aa movss    dword ptr [esp + 0x58], xmm3
434057b0 call     0x4337f9d3
434057b5 mov      ecx, dword ptr [esi + 0x48]
434057b8 movaps   xmm1, xmm0
434057bb movss    dword ptr [esp + 0x54], xmm1
434057c1 call     0x4334116b
434057c6 mov      ecx, eax
434057c8 test     ecx, ecx
434057ca je       0x434059af
434057d0 cmp      dword ptr [ecx + 8], 0x7f7fffff
434057d7 je       0x434059af
434057dd movss    xmm0, dword ptr [ecx + 0xc]
434057e2 call     0x4337f9d3
434057e7 movaps   xmm2, xmm0
434057ea movss    xmm0, dword ptr [ecx + 0x10]
434057ef movss    dword ptr [esp + 0x50], xmm2
434057f5 call     0x4337f9d3
434057fa ucomiss  xmm2, xmm3
434057fd movss    dword ptr [esp + 0x4c], xmm0
43405803 lahf     
43405804 test     ah, 0x44
43405807 jp       0x43405816
43405809 ucomiss  xmm0, xmm1
4340580c lahf     
4340580d test     ah, 0x44
43405810 jnp      0x434059af
43405816 mov      ecx, dword ptr [esi + 0x1c]
43405819 mov      eax, dword ptr [ecx]
4340581b call     dword ptr [eax + 0x30]
4340581e test     eax, eax
43405820 jne      0x4340582e
43405822 push     esi
43405823 xor      eax, 0x218c9fed
43405828 retf     
4340582e mov      ecx, eax
43405830 call     0x433b8a2b
43405835 movss    xmm1, dword ptr [esp + 0x58]
4340583b mov      ecx, eax
4340583d movss    xmm0, dword ptr [ecx + 0x1a8]
43405845 ucomiss  xmm1, xmm0
43405848 lahf     
43405849 test     ah, 0x44
4340584c jp       0x434058c7
4340584e movss    xmm1, dword ptr [esp + 0x54]
43405854 ucomiss  xmm1, dword ptr [ecx + 0x1ac]
4340585b lahf     
4340585c test     ah, 0x44
4340585f jp       0x434058c7
43405861 mov      ecx, dword ptr [0x43479798]
43405867 xor      esi, esi
43405869 mov      eax, dword ptr [0x43479794]
4340586e mov      byte ptr [0x43468d7c], 0
43405875 test     ecx, ecx
43405877 je       0x434058a0
43405879 add      eax, esi
4340587b xor      edx, edx
4340587d div      dword ptr [esp + 0x48]
43405881 cmp      byte ptr [edx + 0x4347979c], 0
43405888 jne      0x43405896
4340588a mov      eax, dword ptr [0x43479794]
4340588f inc      esi
43405890 cmp      esi, ecx
43405892 jne      0x43405879
43405894 jmp      0x434058a0
43405896 xor      ecx, ecx
43405898 xor      eax, eax
4340589a mov      dword ptr [0x43479798], ecx
434058a0 push     3
434058a2 pop      esi
434058a3 cmp      ecx, esi
434058a5 je       0x434058ae
434058a7 inc      ecx
434058a8 mov      dword ptr [0x43479798], ecx
434058ae add      eax, 2
434058b1 xor      edx, edx
434058b3 div      esi
434058b5 mov      dword ptr [0x43479794], edx
434058bb mov      byte ptr [edx + 0x4347979c], 0
434058c2 jmp      0x434059af
434058c7 movss    xmm1, dword ptr [esp + 0x50]
434058cd ucomiss  xmm1, xmm0
434058d0 lahf     
434058d1 test     ah, 0x44
434058d4 jp       0x434059af
434058da movss    xmm0, dword ptr [esp + 0x4c]
434058e0 ucomiss  xmm0, dword ptr [ecx + 0x1ac]
434058e7 lahf     
434058e8 test     ah, 0x44
434058eb jp       0x434059af
434058f1 mov      ecx, dword ptr [0x43479798]
434058f7 xor      esi, esi
434058f9 mov      eax, dword ptr [0x43479794]
434058fe mov      byte ptr [0x43468d7c], 1
43405905 test     ecx, ecx
43405907 je       0x43405930
43405909 add      eax, esi
4340590b xor      edx, edx
4340590d div      dword ptr [esp + 0x48]
43405911 cmp      byte ptr [edx + 0x4347979c], 0
43405918 je       0x43405926
4340591a mov      eax, dword ptr [0x43479794]
4340591f inc      esi
43405920 cmp      esi, ecx
43405922 jne      0x43405909
43405924 jmp      0x43405930
43405926 xor      ecx, ecx
43405928 xor      eax, eax
4340592a mov      dword ptr [0x43479798], ecx
4340592e inc      edi
4340592f inc      ebx
43405930 push     3
43405932 pop      esi
43405933 cmp      ecx, esi
43405935 je       0x4340593e
43405937 inc      ecx
43405938 mov      dword ptr [0x43479798], ecx
4340593e add      eax, 2
43405941 xor      edx, edx
43405943 div      esi
43405945 mov      dword ptr [0x43479794], edx
4340594b mov      byte ptr [edx + 0x4347979c], 1
43405952 jmp      0x434059af
43405954 mov      eax, dword ptr [esi + 0x20]
43405957 cmp      byte ptr [eax], 0
4340595a je       0x434059af
4340595c mov      eax, dword ptr [esp + 0x2c]
43405960 cmp      eax, dword ptr [esp + 0x3c]
43405964 jne      0x43405997
43405966 test     edi, edi
43405968 jne      0x43405976
4340596a mov      edi, 0xc5940f44
4340596f iretd    
43405970 pop      ecx
43405971 push     eax
43405972 jp       0x4340592e
43405974 movsd    dword ptr es:[edi], dword ptr [esi]
43405975 or       esp, dword ptr [ecx + 0x434682b8]
43405976 mov      eax, dword ptr [0x434682b8]
4340597b movss    xmm0, dword ptr [esi + 0x2c]
43405980 mov      eax, dword ptr [eax]
43405982 xor      eax, dword ptr [0x43467d90]
43405988 xor      eax, 0x1bae1168
4340598d ucomiss  xmm0, dword ptr [eax + edi]
43405991 lahf     
43405992 test     ah, 0x44
43405995 jnp      0x434059af
43405997 mov      eax, dword ptr [esi + 0x24]
4340599a or       dword ptr [eax + 0xc], 0xffffffff
4340599e mov      eax, dword ptr [esi + 0x24]
434059a1 and      dword ptr [eax + 0x1c], 0
434059a5 mov      eax, dword ptr [esi + 0x24]
434059a8 mov      dword ptr [eax + 0x24], 1
434059af cmp      byte ptr [esp + 0xf], 0
434059b4 je       0x43405a12
434059b6 mov      eax, dword ptr [esp + 0x10]
434059ba push     dword ptr [esp + 0x20]
434059be mov      ecx, dword ptr [eax + 0x54]
434059c1 call     0x433f0944
434059c6 mov      ecx, eax
434059c8 test     ecx, ecx
434059ca je       0x43405a12
434059cc test     edi, edi
434059ce jne      0x434059dc
434059d0 cmp      dh, byte ptr [0x48063d7c]
434059d6 xor      dword ptr [ebp + ecx*8 - 0x5e08bbe4], 0x1c
434059dc mov      eax, dword ptr [0x4346791c]
434059de jns      0x43405a26
434059e0 inc      ebx
434059e1 mov      edx, dword ptr [esp + 0x10]
434059e5 mov      eax, dword ptr [eax]
434059e7 xor      eax, dword ptr [0x43467bd4]
434059ed xor      eax, 0x7f5ed2d0
434059f2 mov      eax, dword ptr [eax + edi]
434059f5 mov      dword ptr [ecx + 0x40], eax
434059f8 mov      eax, dword ptr [edx + 0x24]
434059fb or       dword ptr [eax + 0xc], 0xffffffff
434059ff mov      eax, dword ptr [edx + 0x24]
43405a02 and      dword ptr [eax + 0x1c], 0
43405a06 mov      eax, dword ptr [edx + 0x24]
43405a09 mov      dword ptr [eax + 0x24], 1
43405a10 jmp      0x43405a16
43405a12 mov      edx, dword ptr [esp + 0x10]
43405a16 cmp      dword ptr [esp + 0x28], 0
43405a1b jg       0x43405a2b
43405a1d mov      eax, dword ptr [esp + 0x2c]
43405a21 cmp      eax, dword ptr [esp + 0x3c]
43405a25 je       0x43405c5d
43405a26 test     byte ptr [edx], dh
43405a28 add      al, byte ptr [eax]
43405a2a add      byte ptr [ebx + 0x74035472], cl
43405a2b mov      esi, dword ptr [edx + 0x54]
43405a2e add      esi, dword ptr [esp + 0x40]
43405a30 and      al, 0x40
43405a32 mov      ecx, dword ptr [esi + 0x8c]
43405a38 shr      ecx, 4
43405a3b and      ecx, 7
43405a3e test     edi, edi
43405a40 jne      0x43405a4e
43405a42 mov      dword ptr [esi - 0x32e60634], esi
43405a48 sub      dword ptr [ecx + esi], ecx
43405a4b xchg     ebx, eax
43405a4c jge      0x43405a12
43405a4e mov      eax, dword ptr [0x4346a41c]
43405a53 mov      eax, dword ptr [eax]
43405a55 xor      eax, dword ptr [0x43469260]
43405a5b xor      eax, 0xb5a66556
43405a60 mov      dword ptr [eax + edi], ecx
43405a63 test     edi, edi
43405a65 jne      0x43405a73
43405a67 inc      ebx
43405a68 lea      edi, [ebx + eax*2 - 0x55]
43405a6c xchg     edx, eax
43405a6d stc      
43405a6e sbb      byte ptr [edx - 0x5eddb7b0], al
43405a73 mov      eax, dword ptr [0x43468354]
43405a74 push     esp
43405a75 add      dword ptr [esi + 0x43], -0xd
43405a78 movss    xmm0, dword ptr [edx + 0x38]
43405a79 movups   xmm0, xmmword ptr [edx + 0x38]
43405a7d mov      eax, dword ptr [eax]
43405a7f xor      eax, dword ptr [0x4346852c]
43405a85 xor      eax, 0x66146802
43405a8a movss    xmm2, dword ptr [eax + edi]
43405a8f ucomiss  xmm0, xmm2
43405a92 lahf     
43405a93 test     ah, 0x44
43405a96 jp       0x43405aa5
43405a98 cmp      dword ptr [0x43467114], -1
43405a9f je       0x43405b9c
43405aa5 mov      ecx, dword ptr [0x4346794c]
43405aab or       dword ptr [0x43467114], 0xffffffff
43405ab2 xor      ecx, 0xc429e1bf
43405ab8 jmp      0x43405abc
43405aba mov      ecx, eax
43405abc mov      eax, dword ptr [ecx + 0x1c]
43405abf cmp      ecx, eax
43405ac1 jne      0x43405aba
43405ac3 movss    xmm0, dword ptr [ecx + 0x2c]
43405ac8 movss    dword ptr [esp + 0x58], xmm0
43405ace xor      dword ptr [esp + 0x58], ecx
43405ad2 movss    xmm0, dword ptr [esp + 0x58]
43405ad8 ucomiss  xmm0, dword ptr [0x4346ee6c]
43405adf lahf     
43405ae0 test     ah, 0x44
43405ae3 jnp      0x43405b9c
43405ae9 push     dword ptr [esp + 0x20]
43405aed mov      ecx, dword ptr [edx + 0x54]
43405af0 call     0x433f0944
43405af5 mov      dword ptr [esp + 0x58], eax
43405af9 test     eax, eax
43405afb je       0x43405b9c
43405b01 test     edi, edi
43405b03 jne      0x43405b11
43405b05 inc      ecx
43405b06 xchg     ecx, eax
43405b07 push     edx
43405b08 add      eax, 0xa4a935d5
43405b0d xchg     ebp, eax
43405b0e cmp      dh, byte ptr fs:[edi - 0x2fa1f00d]
43405b11 divss    xmm2, xmm0
43405b15 movss    xmm1, dword ptr [eax + 0x10]
43405b1a movss    xmm0, dword ptr [0x4347275c]
43405b22 subss    xmm1, xmm2
43405b26 andps    xmm1, xmmword ptr [0x43470340]
43405b2d comiss   xmm0, xmm1
43405b30 jae      0x43405b9c
43405b32 movaps   xmm0, xmm2
43405b35 call     0x433e104f
43405b3a ucomiss  xmm0, dword ptr [esp + 0x5c]
43405b3f lahf     
43405b40 test     ah, 0x44
43405b43 jnp      0x43405b50
43405b45 mov      eax, dword ptr [esp + 0x20]
43405b49 mov      dword ptr [0x43467114], eax
43405b4e jmp      0x43405b9c
43405b50 test     edi, edi
43405b52 jne      0x43405b60
43405b54 dec      ebp
43405b55 push     esi
43405b56 lea      ecx, [edi]
43405b58 cmp      byte ptr [esi], al
43405b5a sal      dword ptr [esi + 0x3a], 1
43405b5d dec      esp
43405b5e or       ah, byte ptr [ecx]
43405b60 mov      eax, dword ptr [0x434682b8]
43405b61 mov      eax, 0x8b434682
43405b65 mov      ecx, dword ptr [esp + 0x10]
43405b66 dec      esp
43405b67 and      al, 0x10
43405b69 mov      eax, dword ptr [eax]
43405b6b xor      eax, dword ptr [0x43467d90]
43405b71 xor      eax, 0x1bae1168
43405b76 movss    dword ptr [eax + edi], xmm2
43405b7b mov      eax, dword ptr [esp + 0x58]
43405b7f movss    dword ptr [eax + 0x10], xmm2
43405b84 mov      eax, dword ptr [ecx + 0x24]
43405b87 or       dword ptr [eax + 0xc], 0xffffffff
43405b8b mov      eax, dword ptr [ecx + 0x24]
43405b8e and      dword ptr [eax + 0x1c], 0
43405b92 mov      eax, dword ptr [ecx + 0x24]
43405b95 mov      dword ptr [eax + 0x24], 1
43405b9c test     edi, edi
43405b9e jne      0x43405bac
43405ba0 xor      byte ptr [edx + 0x2c], ch
43405ba3 stosd    dword ptr es:[edi], eax
43405ba4 out      dx, al
43405ba5 adc      eax, 0xb5c7cf9
43405baa add      bl, byte ptr [ebx + 0x467a74a1]
43405bac mov      eax, dword ptr [0x43467a74]
43405bb0 inc      ebx
43405bb1 mov      eax, dword ptr [eax]
43405bb3 xor      eax, dword ptr [0x434678c0]
43405bb9 xor      eax, 0xcd812654
43405bbe mov      ecx, dword ptr [eax + edi]
43405bc1 cmp      ecx, -1
43405bc4 je       0x43405c0d
43405bc6 mov      eax, dword ptr [0x4346a890]
43405bcb push     ecx
43405bcc mov      eax, dword ptr [eax]
43405bce mov      edx, dword ptr [eax + 0x10]
43405bd1 mov      eax, esp
43405bd3 mov      dword ptr [eax], ecx
43405bd5 mov      ecx, dword ptr [0x4346a890]
43405bdb call     edx
43405bdd mov      dword ptr [esp + 0x5c], eax
43405be1 test     eax, eax
43405be3 je       0x43405c0d
43405be5 mov      edx, dword ptr [eax]
43405be7 mov      ecx, eax
43405be9 call     dword ptr [edx + 8]
43405bec mov      ecx, dword ptr [eax]
43405bee mov      dword ptr [esi + 0x5c], ecx
43405bf1 mov      eax, dword ptr [0x43467b44]
43405bf6 mov      ecx, dword ptr [esp + 0x5c]
43405bfa mov      eax, dword ptr [eax]
43405bfc xor      eax, dword ptr [0x4346a774]
43405c02 xor      eax, 0x6777c9ce
43405c07 mov      eax, dword ptr [eax + ecx]
43405c0a mov      dword ptr [esi + 0x48], eax
43405c0d test     edi, edi
43405c0f jne      0x43405c1d
43405c11 add      byte ptr [ecx + 0x13], dl
43405c14 mov      eax, 0x9d80d029
43405c19 mov      ah, 0xdf
43405c1b mov      al, 0xfe
43405c1d mov      eax, dword ptr [0x43468354]
43405c22 mov      eax, dword ptr [eax]
43405c24 xor      eax, dword ptr [0x4346852c]
43405c2a xor      eax, 0x66146802
43405c2f mov      eax, dword ptr [eax + edi]
43405c32 mov      dword ptr [esi + 0x50], eax
43405c35 test     edi, edi
43405c37 jne      0x43405c45
43405c39 inc      esp
43405c3a sal      dword ptr [ecx - 0x3e], 1
43405c3d ret      
43405c45 mov      eax, dword ptr [0x4346799c]
43405c4a mov      eax, dword ptr [eax]
43405c4c xor      eax, dword ptr [0x4346a2ec]
43405c52 xor      eax, 0xbcb263a5
43405c57 mov      al, byte ptr [eax + edi]
43405c5a mov      byte ptr [esi + 0x4c], al
43405c5d pop      edi
43405c5e pop      esi
43405c5f mov      esp, ebp
43405c61 pop      ebp
43405c62 ret      4
