4347ea53 push     esi
4347ea54 push     edi
4347ea55 mov      edi, ecx
4347ea57 mov      ecx, 0xa8
4347ea5c call     0x43387448
4347ea61 test     eax, eax
4347ea63 je       0x4347ea7c
4347ea65 push     0
4347ea67 push     dword ptr [esp + 0x14]
4347ea6b mov      ecx, eax
4347ea6d push     0x434745b8
4347ea72 push     edi
4347ea73 call     0x43399927
4347ea78 mov      esi, eax
4347ea7a jmp      0x4347ea7e
4347ea7c xor      esi, esi
4347ea7e push     esi
4347ea7f mov      ecx, edi
4347ea81 call     0x4348206a
4347ea86 pop      edi
4347ea87 mov      eax, esi
4347ea89 pop      esi
4347ea8a ret      8
