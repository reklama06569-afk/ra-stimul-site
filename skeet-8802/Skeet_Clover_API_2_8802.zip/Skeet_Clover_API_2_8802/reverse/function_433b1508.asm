433b1508 push     ebp
433b1509 mov      ebp, esp
433b150b and      esp, 0xfffffff8
433b150e sub      esp, 0x10
433b1511 push     esi
433b1512 mov      esi, ecx
433b1514 push     edi
433b1515 push     0x14
433b1517 pop      ecx
433b1518 mov      eax, dword ptr [esi + 0x80]
433b151e sub      eax, dword ptr [esi + 0x7c]
433b1521 cdq      
433b1522 idiv     ecx
433b1524 mov      ecx, dword ptr [ebp + 0x14]
433b1527 mov      dword ptr [esp + 0x14], esi
433b152b cmp      ecx, eax
433b152d jae      0x433b15bc
433b1533 imul     edi, ecx, 0x14
433b1536 add      edi, dword ptr [esi + 0x7c]
433b1539 mov      dword ptr [esp + 0x10], edi
433b153d mov      eax, dword ptr [edi]
433b153f cmp      eax, dword ptr [edi + 4]
433b1542 je       0x433b15bc
433b1544 mov      ecx, dword ptr [ebp + 8]
433b1547 mov      edx, dword ptr [ebp + 0x1c]
433b154a and      edx, 1
433b154d mov      eax, dword ptr [ecx]
433b154f mov      eax, dword ptr [eax + 0x88]
433b1555 call     eax
433b1557 mov      ecx, dword ptr [ebp + 0x10]
433b155a movss    xmm0, dword ptr [0x4346d490]
433b1562 sub      ecx, eax
433b1564 mulss    xmm0, dword ptr [0x4346eeb0]
433b156c mov      eax, ecx
433b156e cdq      
433b156f sub      eax, edx
433b1571 sar      eax, 1
433b1573 mov      dword ptr [esp + 0xc], eax
433b1577 call     0x433cc0d6
433b157c mov      ecx, dword ptr [ebp + 0xc]
433b157f mov      edx, eax
433b1581 mov      esi, dword ptr [edi + 4]
433b1584 sub      esi, dword ptr [edi]
433b1586 mov      eax, dword ptr [ebp + 8]
433b1589 mov      edi, dword ptr [ecx + 4]
433b158c add      edi, dword ptr [esp + 0xc]
433b1590 sar      esi, 1
433b1592 mov      eax, dword ptr [eax]
433b1594 mov      dword ptr [esp + 0xc], eax
433b1598 mov      eax, dword ptr [esp + 0x10]
433b159c push     esi
433b159d push     dword ptr [eax]
433b159f mov      eax, dword ptr [esp + 0x1c]
433b15a3 mov      eax, dword ptr [eax + 0x28]
433b15a6 sub      eax, edx
433b15a8 mov      edx, dword ptr [ebp + 0x1c]
433b15ab push     eax
433b15ac push     dword ptr [ebp + 0x18]
433b15af mov      eax, dword ptr [esp + 0x1c]
433b15b3 push     edi
433b15b4 push     dword ptr [ecx]
433b15b6 mov      ecx, dword ptr [ebp + 8]
433b15b9 call     dword ptr [eax + 0x3c]
433b15bc pop      edi
433b15bd pop      esi
433b15be mov      esp, ebp
433b15c0 pop      ebp
433b15c1 ret      0x18
