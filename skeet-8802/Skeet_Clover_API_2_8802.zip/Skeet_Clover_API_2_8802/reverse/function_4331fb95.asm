4331fb95 push     esi
4331fb96 push     0
4331fb98 mov      esi, ecx
4331fb9a call     0x433821b6
4331fb9f mov      edx, dword ptr [esi + 0x12c]
4331fba5 push     0x14
4331fba7 pop      ecx
4331fba8 mov      eax, dword ptr [edx + 0x94]
4331fbae sub      eax, dword ptr [edx + 0x90]
4331fbb4 cdq      
4331fbb5 idiv     ecx
4331fbb7 test     eax, eax
4331fbb9 jne      0x4331fbd5
4331fbbb mov      ecx, dword ptr [esi + 0xf8]
4331fbc1 mov      eax, dword ptr [ecx + 0x80]
4331fbc7 sub      eax, dword ptr [ecx + 0x7c]
4331fbca jne      0x4331fbd5
4331fbcc mov      ecx, dword ptr [esi + 0x60]
4331fbcf pop      esi
4331fbd0 jmp      0x433d7108
4331fbd5 pop      esi
4331fbd6 ret      
