4334a06e mov      eax, dword ptr [0x43476924]
4334a073 push     ebx
4334a074 push     ebp
4334a075 push     esi
4334a076 mov      esi, dword ptr [eax + 0xc4]
4334a07c or       ebp, 0xffffffff
4334a07f push     edi
4334a080 mov      edi, ecx
4334a082 mov      dword ptr [esi + 0xe4], edi
4334a088 cmp      edi, 3
4334a08b jne      0x4334a134
4334a091 mov      eax, dword ptr [esi + 0xbc]
4334a097 test     eax, eax
4334a099 je       0x4334a09d
4334a09b mov      ebp, dword ptr [eax]
4334a09d mov      ecx, dword ptr [esi + 0x104]
4334a0a3 mov      eax, dword ptr [esi + 0x9c]
4334a0a9 mov      dword ptr [ecx + 0x5c], eax
4334a0ac mov      eax, dword ptr [ecx]
4334a0ae call     dword ptr [eax + 0x14]
4334a0b1 mov      ecx, dword ptr [esi + 0x108]
4334a0b7 mov      eax, dword ptr [esi + 0xa4]
4334a0bd mov      dword ptr [ecx + 0x5c], eax
4334a0c0 mov      eax, dword ptr [ecx]
4334a0c2 call     dword ptr [eax + 0x14]
4334a0c5 mov      ecx, dword ptr [esi + 0xf0]
4334a0cb mov      eax, dword ptr [esi + 0xac]
4334a0d1 mov      dword ptr [ecx + 0x5c], eax
4334a0d4 mov      eax, dword ptr [ecx]
4334a0d6 call     dword ptr [eax + 0x14]
4334a0d9 mov      ecx, dword ptr [esi + 0xf8]
4334a0df mov      eax, dword ptr [esi + 0xbc]
4334a0e5 mov      dword ptr [ecx + 0x5c], eax
4334a0e8 mov      eax, dword ptr [ecx]
4334a0ea call     dword ptr [eax + 0x14]
4334a0ed mov      ecx, dword ptr [esi + 0xf4]
4334a0f3 mov      eax, dword ptr [esi + 0xb4]
4334a0f9 mov      dword ptr [ecx + 0x5c], eax
4334a0fc mov      eax, dword ptr [ecx]
4334a0fe call     dword ptr [eax + 0x14]
4334a101 mov      ecx, dword ptr [esi + 0xfc]
4334a107 mov      eax, dword ptr [esi + 0xcc]
4334a10d mov      dword ptr [ecx + 0x5c], eax
4334a110 mov      eax, dword ptr [ecx]
4334a112 call     dword ptr [eax + 0x14]
4334a115 mov      ecx, dword ptr [esi + 0x100]
4334a11b mov      eax, dword ptr [esi + 0xd4]
4334a121 mov      dword ptr [ecx + 0x5c], eax
4334a124 mov      eax, dword ptr [ecx]
4334a126 call     dword ptr [eax + 0x14]
4334a129 mov      eax, dword ptr [esi + 0xc4]
4334a12f jmp      0x4334a1db
4334a134 cmp      edi, 2
4334a137 jne      0x4334a1e9
4334a13d mov      eax, dword ptr [esi + 0xb8]
4334a143 test     eax, eax
4334a145 je       0x4334a149
4334a147 mov      ebp, dword ptr [eax]
4334a149 mov      ecx, dword ptr [esi + 0x104]
4334a14f mov      eax, dword ptr [esi + 0x98]
4334a155 mov      dword ptr [ecx + 0x5c], eax
4334a158 mov      eax, dword ptr [ecx]
4334a15a call     dword ptr [eax + 0x14]
4334a15d mov      ecx, dword ptr [esi + 0x108]
4334a163 mov      eax, dword ptr [esi + 0xa0]
4334a169 mov      dword ptr [ecx + 0x5c], eax
4334a16c mov      eax, dword ptr [ecx]
4334a16e call     dword ptr [eax + 0x14]
4334a171 mov      ecx, dword ptr [esi + 0xf0]
4334a177 mov      eax, dword ptr [esi + 0xa8]
4334a17d mov      dword ptr [ecx + 0x5c], eax
4334a180 mov      eax, dword ptr [ecx]
4334a182 call     dword ptr [eax + 0x14]
4334a185 mov      ecx, dword ptr [esi + 0xf8]
4334a18b mov      eax, dword ptr [esi + 0xb8]
4334a191 mov      dword ptr [ecx + 0x5c], eax
4334a194 mov      eax, dword ptr [ecx]
4334a196 call     dword ptr [eax + 0x14]
4334a199 mov      ecx, dword ptr [esi + 0xf4]
4334a19f mov      eax, dword ptr [esi + 0xb0]
4334a1a5 mov      dword ptr [ecx + 0x5c], eax
4334a1a8 mov      eax, dword ptr [ecx]
4334a1aa call     dword ptr [eax + 0x14]
4334a1ad mov      ecx, dword ptr [esi + 0xfc]
4334a1b3 mov      eax, dword ptr [esi + 0xc8]
4334a1b9 mov      dword ptr [ecx + 0x5c], eax
4334a1bc mov      eax, dword ptr [ecx]
4334a1be call     dword ptr [eax + 0x14]
4334a1c1 mov      ecx, dword ptr [esi + 0x100]
4334a1c7 mov      eax, dword ptr [esi + 0xd0]
4334a1cd mov      dword ptr [ecx + 0x5c], eax
4334a1d0 mov      eax, dword ptr [ecx]
4334a1d2 call     dword ptr [eax + 0x14]
4334a1d5 mov      eax, dword ptr [esi + 0xc0]
4334a1db mov      ecx, dword ptr [esi + 0x10c]
4334a1e1 mov      dword ptr [ecx + 0x5c], eax
4334a1e4 mov      eax, dword ptr [ecx]
4334a1e6 call     dword ptr [eax + 0x14]
4334a1e9 mov      eax, dword ptr [esi + 0xfc]
4334a1ef xor      ebx, ebx
4334a1f1 mov      eax, dword ptr [eax + 0x5c]
4334a1f4 test     eax, eax
4334a1f6 jne      0x4334a1fc
4334a1f8 mov      al, bl
4334a1fa jmp      0x4334a1fe
4334a1fc mov      al, byte ptr [eax]
4334a1fe mov      byte ptr [esi + 0xe8], al
4334a204 mov      eax, dword ptr [esi + 0xf0]
4334a20a mov      eax, dword ptr [eax + 0x5c]
4334a20d test     eax, eax
4334a20f jne      0x4334a215
4334a211 mov      al, bl
4334a213 jmp      0x4334a217
4334a215 mov      al, byte ptr [eax]
4334a217 mov      byte ptr [esi + 0xe9], al
4334a21d mov      eax, dword ptr [esi + 0x104]
4334a223 mov      eax, dword ptr [eax + 0x5c]
4334a226 test     eax, eax
4334a228 jne      0x4334a22e
4334a22a mov      al, bl
4334a22c jmp      0x4334a230
4334a22e mov      al, byte ptr [eax]
4334a230 push     edi
4334a231 mov      ecx, esi
4334a233 mov      byte ptr [esi + 0xea], al
4334a239 call     0x433ab7c4
4334a23e mov      eax, dword ptr [esi + 0xf4]
4334a244 mov      eax, dword ptr [eax + 0x5c]
4334a247 test     eax, eax
4334a249 je       0x4334a24e
4334a24b movzx    ebx, word ptr [eax]
4334a24e push     ebp
4334a24f push     ebx
4334a250 mov      ecx, esi
4334a252 call     0x43368201
4334a257 pop      edi
4334a258 pop      esi
4334a259 pop      ebp
4334a25a pop      ebx
4334a25b ret      
