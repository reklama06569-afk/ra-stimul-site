4339bc00 movups   xmm7, xmmword ptr [esi + 0x820]
4339bc07 movss    xmm1, dword ptr [0x43470514]
4339bc0f comiss   xmm1, xmm7
4339bc12 movss    dword ptr [esp + 0x2c], xmm3
4339bc18 jbe      0x4339bc52
4339bc1a movss    xmm0, dword ptr [esp + 0x38]
4339bc20 divss    xmm0, dword ptr [esi + 0x830]
4339bc28 mulss    xmm7, xmm7
4339bc2c subss    xmm1, xmm0
4339bc30 movss    xmm0, dword ptr [0x43470514]
4339bc38 subss    xmm0, xmm7
4339bc3c mulss    xmm1, xmm3
4339bc40 subss    xmm1, xmm3
4339bc44 mulss    xmm1, xmm0
4339bc48 addss    xmm3, xmm1
4339bc4c movss    dword ptr [esp + 0x2c], xmm3
4339bc52 movups   xmm0, xmmword ptr [esp + 0x140]
4339bc5a movss    xmm1, dword ptr [0x4347064c]
4339bc62 comiss   xmm0, xmm1
4339bc65 jbe      0x4339bcb9
4339bc67 movss    xmm7, dword ptr [0x43470514]
4339bc6f subss    xmm0, xmm1
4339bc73 xorps    xmm1, xmm1
4339bc76 mulss    xmm0, dword ptr [0x43470000]
4339bc7e movss    xmm1, xmm0
4339bc82 movss    dword ptr [esp + 0x10c], xmm0
4339bc8b movss    xmm0, dword ptr [0x43472240]
4339bc93 maxss    xmm1, xmm0
4339bc97 movaps   xmm0, xmm7
4339bc9a minss    xmm1, xmm0
4339bc9e movss    xmm0, dword ptr [0x434703bc]
4339bca6 subss    xmm0, xmm1
4339bcaa comiss   xmm7, xmm0
4339bcad jbe      0x4339bcb9
4339bcaf mulss    xmm3, xmm0
4339bcb3 movss    dword ptr [esp + 0x2c], xmm3
4339bcb9 comiss   xmm3, xmm5
4339bcbc jbe      0x4339bd1d
4339bcbe movss    xmm1, dword ptr [0x43472980]
4339bcc6 movaps   xmm0, xmm3
4339bcc9 call     0x43367633
4339bcce push     dword ptr [edx + 4]
4339bcd1 movss    dword ptr [esp + 0x78], xmm0
4339bcd7 call     0x63c2ff20
4339bcdc movss    xmm0, dword ptr [esp + 0x78]
4339bce2 movss    dword ptr [esp], xmm0
4339bce7 xorps    xmm0, xmmword ptr [0x434703d0]
4339bcee push     ecx
4339bcef movss    dword ptr [esp], xmm0
4339bcf4 call     0x63c2ff40
4339bcf9 fadd     dword ptr [esp + 0x34]
4339bcfd pop      ecx
4339bcfe pop      ecx
4339bcff movss    xmm2, dword ptr [esp + 0x14]
4339bd05 movss    xmm4, dword ptr [esp + 0x1c]
4339bd0b movups   xmm6, xmmword ptr [esp + 0x180]
4339bd13 fstp     dword ptr [esp + 0x2c]
4339bd17 movss    xmm3, dword ptr [esp + 0x2c]
4339bd1d movss    xmm1, dword ptr [esi + 0x8d8]
4339bd25 movss    xmm0, dword ptr [0x434725e8]
4339bd2d mulss    xmm1, xmm3
4339bd31 comiss   xmm0, xmm1
4339bd34 ja       0x4339bbad
4339bd3a comiss   xmm6, xmm1
4339bd3d jbe      0x4339bd66
4339bd3f divss    xmm1, xmm6
4339bd43 movaps   xmm0, xmm1
4339bd46 mulss    xmm4, xmm1
4339bd4a mulss    xmm2, xmm0
4339bd4e movss    dword ptr [esp + 0x1c], xmm4
4339bd54 movss    dword ptr [esp + 0x68], xmm4
4339bd5a movss    dword ptr [esp + 0x14], xmm2
4339bd60 movss    dword ptr [esp + 0x64], xmm2
4339bd66 push     dword ptr [ebp + 0xc]
4339bd69 lea      eax, [esi + 0x8a4]
4339bd6f mov      ecx, esi
4339bd71 push     edi
4339bd72 mov      dword ptr [esp + 0x7c], eax
4339bd76 call     0x433c6416
4339bd7b test     al, al
4339bd7d je       0x4339bddb
4339bd7f movss    xmm1, dword ptr [esi + 0x8b0]
4339bd87 lea      eax, [esi + 0x8a4]
4339bd8d movss    xmm0, dword ptr [esp + 0x14]
4339bd93 movss    xmm2, dword ptr [esp + 0x1c]
4339bd99 subss    xmm0, xmm1
4339bd9d addss    xmm1, dword ptr [eax]
4339bda1 movss    dword ptr [esp + 0x64], xmm0
4339bda7 movss    xmm0, dword ptr [esi + 0x8b4]
4339bdaf subss    xmm2, xmm0
4339bdb3 movss    dword ptr [eax], xmm1
4339bdb7 addss    xmm0, dword ptr [eax + 4]
4339bdbc movss    dword ptr [esp + 0x68], xmm2
4339bdc2 movss    dword ptr [eax + 4], xmm0
4339bdc7 movss    xmm0, dword ptr [esi + 0x8b8]
4339bdcf addss    xmm0, dword ptr [eax + 8]
4339bdd4 movss    dword ptr [eax + 8], xmm0
4339bdd9 jmp      0x4339bde8
4339bddb mov      edi, dword ptr [esp + 0x74]
4339bddf add      esi, 0x898
4339bde5 movsd    dword ptr es:[edi], dword ptr [esi]
4339bde6 movsd    dword ptr es:[edi], dword ptr [esi]
4339bde7 movsd    dword ptr es:[edi], dword ptr [esi]
4339bde8 lea      esi, [esp + 0x64]
4339bdec lea      edi, [esp + 0x78]
4339bdf0 movsd    dword ptr es:[edi], dword ptr [esi]
4339bdf1 movsd    dword ptr es:[edi], dword ptr [esi]
4339bdf2 movsd    dword ptr es:[edi], dword ptr [esi]
4339bdf3 mov      esi, dword ptr [esp + 0x4c]
4339bdf7 test     byte ptr [esi + 0x83c], 1
4339bdfe je       0x4339be07
4339be00 or       dword ptr [0x434759c0], 8
4339be07 movss    xmm1, dword ptr [esp + 0x78]
4339be0d movss    xmm2, dword ptr [esp + 0x7c]
4339be13 movss    dword ptr [esp + 0x38], xmm1
4339be19 movss    dword ptr [esp + 0x14], xmm2
4339be1f mov      eax, dword ptr [esp + 0x3c]
4339be23 xorps    xmm0, xmm0
4339be26 test     byte ptr [eax + 0x835], 1
4339be2d je       0x4339bee9
4339be33 cmp      dword ptr [eax + 0x87c], 0
4339be3a jne      0x4339bee9
4339be40 ucomiss  xmm1, xmm0
4339be43 lahf     
4339be44 test     ah, 0x44
4339be47 jp       0x4339bf0b
4339be4d ucomiss  xmm2, xmm0
4339be50 lahf     
4339be51 test     ah, 0x44
4339be54 jp       0x4339bee9
4339be5a push     dword ptr [ebp + 0xc]
4339be5d mov      ecx, esi
4339be5f push     dword ptr [esp + 0x24]
4339be63 call     0x433c6416
4339be68 test     al, al
4339be6a je       0x4339bedf
4339be6c movss    xmm1, dword ptr [esi + 0x8b0]
4339be74 movss    xmm0, dword ptr [esp + 0x38]
4339be7a movss    xmm2, dword ptr [esp + 0x14]
4339be80 subss    xmm0, xmm1
4339be84 addss    xmm1, dword ptr [esi + 0x8a4]
4339be8c movss    dword ptr [esp + 0x38], xmm0
4339be92 movss    dword ptr [esp + 0x78], xmm0
4339be98 movss    xmm0, dword ptr [esi + 0x8b4]
4339bea0 subss    xmm2, xmm0
4339bea4 movss    dword ptr [esi + 0x8a4], xmm1
4339beac addss    xmm0, dword ptr [esi + 0x8a8]
4339beb4 movss    dword ptr [esp + 0x7c], xmm2
4339beba movss    dword ptr [esi + 0x8a8], xmm0
4339bec2 movss    xmm0, dword ptr [esi + 0x8b8]
4339beca addss    xmm0, dword ptr [esi + 0x8ac]
4339bed2 movss    dword ptr [esi + 0x8ac], xmm0
4339beda xorps    xmm0, xmm0
4339bedd jmp      0x4339beef
4339bedf mov      ecx, esi
4339bee1 call     0x4340c87e
4339bee6 xorps    xmm0, xmm0
4339bee9 movss    xmm2, dword ptr [esp + 0x14]
4339beef movss    xmm1, dword ptr [esp + 0x38]
4339bef5 ucomiss  xmm1, xmm0
4339bef8 lahf     
4339bef9 test     ah, 0x44
4339befc jp       0x4339bf0b
4339befe ucomiss  xmm2, xmm0
4339bf01 lahf     
4339bf02 test     ah, 0x44
4339bf05 jnp      0x4339bfb9
4339bf0b lea      ecx, [esp + 0x78]
4339bf0f call     0x43328ae6
4339bf14 movss    xmm1, dword ptr [esp + 0x78]
4339bf1a movss    xmm0, dword ptr [esp + 0x7c]
4339bf20 mulss    xmm1, xmm1
4339bf24 mulss    xmm0, xmm0
4339bf28 addss    xmm1, xmm0
4339bf2c movaps   xmm0, xmm1
4339bf2f movss    xmm1, dword ptr [0x4347259c]
4339bf37 sqrtss   xmm0, xmm0
4339bf3b comiss   xmm1, xmm0
4339bf3e jbe      0x4339bfb9
4339bf40 mov      edi, dword ptr [esp + 0x108]
4339bf47 lea      esi, [esp + 0x78]
4339bf4b mov      eax, dword ptr [esp + 0x3c]
4339bf4f mov      edx, dword ptr [ebp + 8]
4339bf52 push     0
4339bf54 push     dword ptr [ebp + 0xc]
4339bf57 movsd    dword ptr es:[edi], dword ptr [esi]
4339bf58 lea      ecx, [eax + 8]
4339bf5b mov      dword ptr [eax + 0x868], 0x3f800000
4339bf65 mov      eax, dword ptr [ecx]
4339bf67 movsd    dword ptr es:[edi], dword ptr [esi]
4339bf68 movsd    dword ptr es:[edi], dword ptr [esi]
4339bf69 mov      esi, dword ptr [esp + 0x28]
4339bf6d movss    xmm0, dword ptr [esi + 0x1b4]
4339bf75 call     dword ptr [eax]
4339bf77 mov      ecx, dword ptr [esp + 0x5c]
4339bf7b call     0x433b8974
4339bf80 movss    xmm0, dword ptr [esi + 0x20]
4339bf85 lea      edi, [esi + 0x118]
4339bf8b ucomiss  xmm0, dword ptr [edi]
4339bf8e lahf     
4339bf8f test     ah, 0x44
4339bf92 jp       0x4339bfb9
4339bf94 movss    xmm0, dword ptr [esi + 0x24]
4339bf99 ucomiss  xmm0, dword ptr [edi + 4]
4339bf9d lahf     
4339bf9e test     ah, 0x44
4339bfa1 jp       0x4339bfb9
4339bfa3 movss    xmm0, dword ptr [esi + 0x28]
4339bfa8 ucomiss  xmm0, dword ptr [edi + 8]
4339bfac lahf     
4339bfad test     ah, 0x44
4339bfb0 jp       0x4339bfb9
4339bfb2 mov      esi, dword ptr [esp + 0x5c]
4339bfb6 movsd    dword ptr es:[edi], dword ptr [esi]
4339bfb7 movsd    dword ptr es:[edi], dword ptr [esi]
4339bfb8 movsd    dword ptr es:[edi], dword ptr [esi]
4339bfb9 mov      edi, dword ptr [esp + 0x3c]
4339bfbd mov      edx, dword ptr [ebp + 0xc]
4339bfc0 test     byte ptr [edi + 0x834], 0x20
4339bfc7 je       0x4339c48d
4339bfcd test     byte ptr [edx + 0x30], 1
4339bfd1 jne      0x4339c48d
4339bfd7 mov      esi, dword ptr [esp + 0x4c]
4339bfdb imul     eax, dword ptr [esi + 0x804], 0x28
4339bfe2 lea      ecx, [esi + 0x6a8]
4339bfe8 add      ecx, eax
4339bfea mov      eax, dword ptr [ecx + 0x14]
4339bfed mov      eax, dword ptr [eax*4 + 0x434721c4]
4339bff4 call     eax
4339bff6 mov      edx, dword ptr [ebp + 0xc]
4339bff9 test     al, al
4339bffb je       0x4339c48d
4339c001 mov      eax, dword ptr [0x43467eb8]
4339c006 movss    xmm0, dword ptr [esi + 0x8bc]
4339c00e comiss   xmm0, dword ptr [eax]
4339c011 jbe      0x4339c017
4339c013 or       dword ptr [edx + 0x30], 1
4339c017 mov      eax, dword ptr [esp + 0x20]
4339c01b test     dword ptr [eax], 0x400
4339c021 jne      0x4339c030
4339c023 cmp      dword ptr [eax + 0xd8], 0x40
4339c02a jne      0x4339c491
4339c030 test     byte ptr [esi + 0x83c], 8
4339c037 jne      0x4339c074
4339c039 mov      ecx, dword ptr [ebp + 8]
4339c03c test     ecx, ecx
4339c03e jne      0x4339c04c
4339c040 xchg     esp, eax
4339c041 dec      edi
4339c042 int3     
4339c04c mov      eax, dword ptr [0x43467434]
4339c051 mov      eax, dword ptr [eax]
4339c053 xor      eax, dword ptr [0x43467fa8]
4339c059 xor      eax, 0x1bc6d160
4339c05e movss    xmm0, dword ptr [eax + ecx]
4339c063 comiss   xmm0, dword ptr [0x434723f8]
4339c06a mov      eax, dword ptr [esp + 0x20]
4339c06e ja       0x4339c494
4339c074 cmp      dword ptr [esi + 0x85c], 0
4339c07b mov      edi, dword ptr [edx + 8]
4339c07e mov      dword ptr [esp + 0x58], edi
4339c082 mov      edi, dword ptr [esp + 0x3c]
4339c086 mov      byte ptr [esp + 0x33], 0
4339c08b je       0x4339c0ac
4339c08d lea      ecx, [esp + 0x33]
4339c091 push     ecx
4339c092 mov      ecx, dword ptr [ebp + 8]
4339c095 push     edx
4339c096 push     ecx
4339c097 push     eax
4339c098 mov      ecx, esi
4339c09a call     0x4332fd2b
4339c09f mov      cl, byte ptr [esp + 0x33]
4339c0a3 mov      dword ptr [esp + 0x58], eax
4339c0a7 jmp      0x4339c408
4339c0ac mov      eax, dword ptr [esi + 0x848]
4339c0b2 lea      edi, [esp + 0x11c]
4339c0b9 shl      eax, 7
4339c0bc push     0x64
4339c0be pop      ecx
4339c0bf cdq      
4339c0c0 idiv     ecx
4339c0c2 mov      esi, dword ptr [esp + 0x5c]
4339c0c6 lea      edx, [esp + 0x11c]
4339c0cd xor      ecx, ecx
4339c0cf inc      ecx
4339c0d0 cmp      eax, ecx
4339c0d2 movsd    dword ptr es:[edi], dword ptr [esi]
4339c0d3 cmovg    ecx, eax
4339c0d6 and      dword ptr [esp + 0x44], 0
4339c0db mov      dword ptr [esp + 0x40], ecx
4339c0df mov      ecx, dword ptr [ebp + 8]
4339c0e2 movsd    dword ptr es:[edi], dword ptr [esi]
4339c0e3 movsd    dword ptr es:[edi], dword ptr [esi]
4339c0e4 call     0x433d1edc
4339c0e9 mov      esi, dword ptr [esp + 0x4c]
4339c0ed lea      ecx, [esp + 0x290]
4339c0f4 mov      edi, dword ptr [esp + 0x20]
4339c0f8 mov      al, byte ptr [esi + 0x83c]
4339c0fe shr      al, 7
4339c101 movzx    eax, al
4339c104 push     eax
4339c105 push     dword ptr [edi + 0xc]
4339c108 call     0x433eb28b
4339c10d lea      eax, [esp + 0xb8]
4339c114 push     eax
4339c115 lea      eax, [esp + 0x114]
4339c11c push     eax
4339c11d lea      edx, [esp + 0xd4]
4339c124 lea      ecx, [esp + 0x124]
4339c12b call     0x43366128
4339c130 xor      eax, eax
4339c132 mov      dword ptr [esp + 0xe4], 0x4346dcec
4339c13d lea      ecx, [esp + 0x290]
4339c144 mov      dword ptr [esp + 0xe8], eax
4339c14b push     ecx
4339c14c lea      ecx, [esp + 0xe8]
4339c153 mov      dword ptr [esp + 0xf0], eax
4339c15a push     ecx
4339c15b lea      ecx, [esp + 0xd4]
4339c162 mov      dword ptr [esp + 0xf8], eax
4339c169 mov      dword ptr [esp + 0xfc], eax
4339c170 lea      edx, [edi + 0xdc]
4339c176 mov      dword ptr [esp + 0x100], eax
4339c17d mov      eax, 0x4600400b
4339c182 push     ecx
4339c183 mov      ecx, dword ptr [ebp + 8]
4339c186 mov      dword ptr [esp + 0x108], eax
4339c18d mov      dword ptr [esp + 0x10c], eax
4339c194 mov      dword ptr [esp + 0x110], 0x3f800000
4339c19f call     0x43364cec
4339c1a4 test     eax, eax
4339c1a6 je       0x4339c402
4339c1ac test     byte ptr [esi + 0x83c], 0x10
4339c1b3 jne      0x4339c1f1
4339c1b5 movss    xmm3, dword ptr [esp + 0x2c8]
4339c1be lea      eax, [edi + 0xdc]
4339c1c4 movss    xmm0, dword ptr [eax]
4339c1c8 movss    xmm1, dword ptr [eax + 4]
4339c1cd movss    xmm2, dword ptr [eax + 8]
4339c1d2 movss    xmm4, dword ptr [esp + 0x2cc]
4339c1db movss    xmm5, dword ptr [esp + 0x2d0]
4339c1e4 call     0x433e7c6b
4339c1e9 test     al, al
4339c1eb jne      0x4339c402
4339c1f1 cmp      dword ptr [esi + 0x848], 0
4339c1f8 jne      0x4339c201
4339c1fa mov      cl, 1
4339c1fc jmp      0x4339c404
4339c201 cmp      dword ptr [edi + 0xd8], 0x40
4339c208 jne      0x4339c234
4339c20a test     byte ptr [edi + 0x7c], 6
4339c20e movss    xmm3, dword ptr [0x4346f99c]
4339c216 movss    dword ptr [esp + 0x48], xmm3
4339c21c je       0x4339c228
4339c21e movss    xmm0, dword ptr [0x4346f044]
4339c226 jmp      0x4339c230
4339c228 movss    xmm0, dword ptr [0x4346fa5c]
4339c230 xor      edx, edx
4339c232 jmp      0x4339c250
4339c234 movss    xmm3, dword ptr [edi + 0xd0]
4339c23c movss    xmm0, dword ptr [edi + 0xc4]
4339c244 mov      edx, dword ptr [edi + 0xb0]
4339c24a movss    dword ptr [esp + 0x48], xmm3
4339c250 xor      ecx, ecx
4339c252 mov      dword ptr [esp + 0x54], edx
4339c256 movss    dword ptr [esp + 0x5c], xmm0
4339c25c mov      dword ptr [esp + 0x28], ecx
4339c260 movzx    eax, byte ptr [ecx + 0x4346fc50]
4339c267 movaps   xmm1, xmm0
4339c26a movss    xmm2, dword ptr [edi + 0x100]
4339c272 movaps   xmm0, xmm3
4339c275 push     1
4339c277 push     ecx
4339c278 mov      ecx, dword ptr [edi + 0xd8]
4339c27e push     eax
4339c27f call     0x433adb4f
4339c284 movss    dword ptr [esp + 0x64], xmm0
4339c28a lea      eax, [esp + 0x290]
4339c291 movss    xmm5, dword ptr [esp + 0x64]
4339c297 lea      edx, [edi + 0xdc]
4339c29d movq     xmm0, qword ptr [esp + 0xcc]
4339c2a6 movaps   xmm4, xmm5
4339c2a9 mulss    xmm4, dword ptr [esp + 0x110]
4339c2b2 movaps   xmm3, xmm5
4339c2b5 mov      ecx, dword ptr [ebp + 8]
4339c2b8 mulss    xmm3, dword ptr [esp + 0x114]
4339c2c1 push     eax
4339c2c2 mulss    xmm5, dword ptr [esp + 0x11c]
4339c2cb lea      eax, [esp + 0xe8]
4339c2d2 push     eax
4339c2d3 movq     qword ptr [esp + 0x98], xmm0
4339c2dc movaps   xmm0, xmm1
4339c2df mulss    xmm0, dword ptr [esp + 0xc0]
4339c2e8 lea      eax, [esp + 0x98]
4339c2ef push     eax
4339c2f0 addss    xmm4, dword ptr [esp + 0x9c]
4339c2f9 addss    xmm3, dword ptr [esp + 0xa0]
4339c302 addss    xmm5, dword ptr [esp + 0xe0]
4339c30b movss    dword ptr [esp + 0x74], xmm1
4339c311 addss    xmm4, xmm0
4339c315 movaps   xmm0, xmm1
4339c318 mulss    xmm0, dword ptr [esp + 0xc8]
4339c321 mulss    xmm1, dword ptr [esp + 0xcc]
4339c32a addss    xmm3, xmm0
4339c32e addss    xmm5, xmm1
4339c332 movaps   xmm1, xmm4
4339c335 mulss    xmm1, xmm4
4339c339 movaps   xmm0, xmm3
4339c33c mulss    xmm0, xmm3
4339c340 addss    xmm1, xmm0
4339c344 movaps   xmm0, xmm5
4339c347 mulss    xmm0, xmm5
4339c34b addss    xmm1, xmm0
4339c34f movaps   xmm0, xmm1
4339c352 movss    xmm1, dword ptr [0x43470514]
4339c35a sqrtss   xmm0, xmm0
4339c35e addss    xmm0, dword ptr [0x43472108]
4339c366 divss    xmm1, xmm0
4339c36a mulss    xmm4, xmm1
4339c36e mulss    xmm3, xmm1
4339c372 mulss    xmm5, xmm1
4339c376 movss    dword ptr [esp + 0x9c], xmm4
4339c37f movss    dword ptr [esp + 0xa0], xmm3
4339c388 movss    dword ptr [esp + 0xa4], xmm5
4339c391 call     0x43364cec
4339c396 test     eax, eax
4339c398 je       0x4339c3c2
4339c39a lea      eax, [esp + 0x290]
4339c3a1 mov      ecx, esi
4339c3a3 push     eax
4339c3a4 call     0x4331fbdb
4339c3a9 mov      edx, dword ptr [esp + 0x44]
4339c3ad test     al, al
4339c3af je       0x4339c3c6
4339c3b1 inc      edx
4339c3b2 mov      dword ptr [esp + 0x44], edx
4339c3b6 cmp      edx, dword ptr [esp + 0x40]
4339c3ba jge      0x4339c1fa
4339c3c0 jmp      0x4339c3c6
4339c3c2 mov      edx, dword ptr [esp + 0x44]
4339c3c6 mov      ecx, dword ptr [esp + 0x28]
4339c3ca mov      eax, edx
4339c3cc sub      eax, ecx
4339c3ce sub      eax, -0x80
4339c3d1 cmp      eax, dword ptr [esp + 0x40]
4339c3d5 jl       0x4339c402
4339c3d7 inc      ecx
4339c3d8 mov      dword ptr [esp + 0x28], ecx
4339c3dc cmp      ecx, 0x80
4339c3e2 jge      0x4339c3f9
4339c3e4 movss    xmm0, dword ptr [esp + 0x5c]
4339c3ea movss    xmm3, dword ptr [esp + 0x48]
4339c3f0 mov      edx, dword ptr [esp + 0x54]
4339c3f4 jmp      0x4339c260
4339c3f9 cmp      edx, dword ptr [esp + 0x40]
4339c3fd setge    cl
4339c400 jmp      0x4339c404
4339c402 xor      cl, cl
4339c404 mov      edi, dword ptr [esp + 0x3c]
4339c408 mov      eax, dword ptr [esp + 0x20]
4339c40c test     dword ptr [eax], 0x400
4339c412 je       0x4339c436
4339c414 mov      edx, dword ptr [ebp + 0xc]
4339c417 test     cl, cl
4339c419 jne      0x4339c421
4339c41b test     byte ptr [edx + 0x30], 1
4339c41f je       0x4339c491
4339c421 cmp      dword ptr [esp + 0x58], -1
4339c426 mov      edi, dword ptr [esp + 0x3c]
4339c42a je       0x4339c436
4339c42c mov      esi, dword ptr [esp + 0x58]
4339c430 mov      dword ptr [edx + 8], esi
4339c433 lea      esi, [edi - 8]
4339c436 mov      edx, dword ptr [ebp + 0xc]
4339c439 test     cl, cl
4339c43b je       0x4339c491
4339c43d or       dword ptr [edx + 0x30], 1
4339c441 test     byte ptr [esi + 0x83c], 0x40
4339c448 je       0x4339c465
4339c44a mov      eax, dword ptr [0x43467eb8]
4339c44f movss    xmm0, dword ptr [esi + 0x850]
4339c457 addss    xmm0, dword ptr [eax]
4339c45b movss    dword ptr [esi + 0x8bc], xmm0
4339c463 jmp      0x4339c48d
4339c465 push     ecx
4339c466 push     ecx
4339c467 mov      dword ptr [esp + 4], 0x3dcccccd
4339c46f mov      dword ptr [esp], 0x3d000000
4339c476 call     0x63c2ff40
4339c47b mov      eax, dword ptr [0x43467eb8]
4339c480 mov      edx, dword ptr [ebp + 0xc]
4339c483 pop      ecx
4339c484 pop      ecx
4339c485 fadd     dword ptr [eax]
4339c487 fstp     dword ptr [esi + 0x8bc]
4339c48d mov      eax, dword ptr [esp + 0x20]
4339c491 mov      ecx, dword ptr [ebp + 8]
4339c494 cmp      dword ptr [edi + 0x854], 0
4339c49b je       0x4339c4ee
4339c49d test     dword ptr [eax], 0x100000
4339c4a3 jne      0x4339c4d3
4339c4a5 test     dword ptr [eax], 0x400
4339c4ab je       0x4339c4b3
4339c4ad test     byte ptr [edx + 0x30], 1
4339c4b1 jne      0x4339c4d3
4339c4b3 test     byte ptr [eax], 2
4339c4b6 je       0x4339c4ee
4339c4b8 test     dword ptr [edx + 0x30], 0x800
4339c4bf je       0x4339c4ee
4339c4c1 cmp      dword ptr [eax + 0xd8], 0x40
4339c4c8 je       0x4339c4d3
4339c4ca cmp      byte ptr [eax + 0x124], 0
4339c4d1 jne      0x4339c4ee
4339c4d3 push     0
4339c4d5 push     edx
4339c4d6 push     ecx
4339c4d7 mov      ecx, dword ptr [esp + 0x58]
4339c4db push     eax
4339c4dc call     0x4332fd2b
4339c4e1 mov      ecx, eax
4339c4e3 cmp      ecx, -1
4339c4e6 je       0x4339c4ee
4339c4e8 mov      eax, dword ptr [ebp + 0xc]
4339c4eb mov      dword ptr [eax + 8], ecx
4339c4ee pop      edi
4339c4ef pop      esi
4339c4f0 mov      esp, ebp
4339c4f2 pop      ebp
4339c4f3 ret      8
