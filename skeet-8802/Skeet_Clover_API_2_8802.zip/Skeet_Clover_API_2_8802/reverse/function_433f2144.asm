433f2144 mov      eax, dword ptr [esp + 4]
433f2148 mov      eax, dword ptr [eax + 0x5c]
433f214b test     eax, eax
433f214d jne      0x433f2153
433f214f xor      al, al
433f2151 jmp      0x433f2155
433f2153 mov      al, byte ptr [eax]
433f2155 cmp      byte ptr [ecx + 0xe9], al
433f215b je       0x433f2163
433f215d mov      byte ptr [ecx + 0xe9], al
433f2163 ret      4
