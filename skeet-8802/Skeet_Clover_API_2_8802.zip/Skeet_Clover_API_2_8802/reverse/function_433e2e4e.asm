433e2e4e mov      byte ptr [ecx + 0x16], 0
433e2e52 ret      
