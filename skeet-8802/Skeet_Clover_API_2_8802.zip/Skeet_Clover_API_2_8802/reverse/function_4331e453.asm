4331e453 push     ebp
4331e454 mov      ebp, esp
4331e456 and      esp, 0xfffffff8
4331e459 sub      esp, 0x28
4331e45c push     esi
4331e45d push     edi
4331e45e mov      edi, ecx
4331e460 mov      dword ptr [esp + 0x10], edi
4331e464 call     0x433e41ca
4331e469 push     0x10a0
4331e46e push     dword ptr [ebp + 8]
4331e471 lea      eax, [edi + 0x10]
4331e474 push     eax
4331e475 call     0x774fd4a0
4331e47a mov      esi, dword ptr [edi]
4331e47c lea      ecx, [esp + 0x24]
4331e480 add      esp, 0xc
4331e483 mov      dword ptr [esp + 0xc], esi
4331e487 call     0x433f27c3
4331e48c mov      ecx, dword ptr [edi + 0x2c]
4331e48f test     esi, esi
4331e491 jne      0x4331e49f
4331e493 salc     
4331e494 xchg     esi, eax
4331e495 xor      al, 0x3a
4331e497 cmp      al, 0x41
4331e499 sub      byte ptr [ebx + 0x28ba8891], ah
4331e49f mov      eax, dword ptr [0x434688d0]
4331e4a4 mov      eax, dword ptr [eax]
4331e4a6 xor      eax, dword ptr [0x43468c24]
4331e4ac xor      eax, 0xe2fbe695
4331e4b1 mov      dword ptr [eax + esi], ecx
4331e4b4 movd     xmm0, dword ptr [edi + 0x5c]
4331e4b9 mov      eax, dword ptr [0x4346a338]
4331e4be cvtdq2ps xmm0, xmm0
4331e4c1 mulss    xmm0, dword ptr [eax]
4331e4c5 test     esi, esi
4331e4c7 jne      0x4331e4d5
4331e4c9 sbb      al, 0x92
4331e4cb jg       0x4331e543
4331e4cd xor      dl, byte ptr [esi]
4331e4cf adc      dword ptr [eax], 0xe3b9a3
4331e4d5 mov      eax, dword ptr [0x43469198]
4331e4da mov      ecx, esi
4331e4dc and      dword ptr [esp + 0x20], 0
4331e4e1 and      dword ptr [esp + 0x28], 0
4331e4e6 movss    xmm2, dword ptr [esp + 0x28]
4331e4ec mov      eax, dword ptr [eax]
4331e4ee xor      eax, dword ptr [0x4346a538]
4331e4f4 xor      eax, 0xd5fd2e2c
4331e4f9 movss    dword ptr [eax + esi], xmm0
4331e4fe movss    xmm0, dword ptr [edi + 0x38]
4331e503 movss    dword ptr [esp + 0x24], xmm0
4331e509 movss    xmm0, dword ptr [esp + 0x20]
4331e50f movss    xmm1, dword ptr [esp + 0x24]
4331e515 call     0x433411f2
4331e51a mov      eax, dword ptr [esi]
4331e51c mov      ecx, esi
4331e51e call     dword ptr [eax + 0xc]
4331e521 mov      ecx, eax
4331e523 mov      edx, dword ptr [eax]
4331e525 call     dword ptr [edx + 8]
4331e528 mov      ecx, dword ptr [esp + 0x10]
4331e52c lea      edi, [esp + 0x20]
4331e530 mov      esi, eax
4331e532 movss    xmm1, dword ptr [ecx + 0x28]
4331e537 movsd    dword ptr es:[edi], dword ptr [esi]
4331e538 movss    dword ptr [esp + 0x14], xmm1
4331e53e movsd    dword ptr es:[edi], dword ptr [esi]
4331e53f movsd    dword ptr es:[edi], dword ptr [esi]
4331e540 movss    xmm0, dword ptr [esp + 0x28]
4331e543 inc      esp
4331e544 and      al, 0x28
4331e546 ucomiss  xmm0, xmm1
4331e549 lahf     
4331e54a test     ah, 0x44
4331e54d jnp      0x4331e56e
4331e54f mov      ecx, dword ptr [esp + 0xc]
4331e553 mov      eax, dword ptr [ecx]
4331e555 call     dword ptr [eax + 0xc]
4331e558 mov      ecx, eax
4331e55a mov      edx, dword ptr [eax]
4331e55c call     dword ptr [edx + 8]
4331e55f movss    xmm0, dword ptr [esp + 0x14]
4331e565 mov      ecx, dword ptr [esp + 0x10]
4331e569 movss    dword ptr [eax + 8], xmm0
4331e56e mov      eax, dword ptr [0x4346a8e4]
4331e573 lea      esi, [ecx + 0x1c]
4331e576 lea      edi, [esp + 0x20]
4331e57a movsd    dword ptr es:[edi], dword ptr [esi]
4331e57b movsd    dword ptr es:[edi], dword ptr [esi]
4331e57c movsd    dword ptr es:[edi], dword ptr [esi]
4331e57d mov      edi, dword ptr [eax]
4331e57f lea      esi, [esp + 0x20]
4331e583 xor      edi, dword ptr [0x434688cc]
4331e589 xor      edi, 0x36375c23
4331e58f add      edi, dword ptr [esp + 0xc]
4331e593 movsd    dword ptr es:[edi], dword ptr [esi]
4331e594 movsd    dword ptr es:[edi], dword ptr [esi]
4331e595 movsd    dword ptr es:[edi], dword ptr [esi]
4331e596 lea      esi, [ecx + 0x40]
4331e599 mov      ecx, dword ptr [esp + 0xc]
4331e59d movss    xmm0, dword ptr [esi]
4331e5a1 movss    xmm1, dword ptr [esi + 4]
4331e5a6 movss    xmm2, dword ptr [esi + 8]
4331e5ab call     0x4334c8f6
4331e5b0 mov      eax, dword ptr [0x434670cc]
4331e5b5 lea      edi, [esp + 0x20]
4331e5b9 movsd    dword ptr es:[edi], dword ptr [esi]
4331e5ba movsd    dword ptr es:[edi], dword ptr [esi]
4331e5bb movsd    dword ptr es:[edi], dword ptr [esi]
4331e5bc mov      edi, dword ptr [eax]
4331e5be lea      esi, [esp + 0x20]
4331e5c2 xor      edi, dword ptr [0x43468bcc]
4331e5c8 xor      edi, 0xa9ee6062
4331e5ce add      edi, dword ptr [esp + 0xc]
4331e5d2 movsd    dword ptr es:[edi], dword ptr [esi]
4331e5d3 movsd    dword ptr es:[edi], dword ptr [esi]
4331e5d4 movsd    dword ptr es:[edi], dword ptr [esi]
4331e5d5 mov      edi, dword ptr [esp + 0x10]
4331e5d9 mov      esi, dword ptr [esp + 0xc]
4331e5dd push     esi
4331e5de lea      ecx, [edi + 0x70]
4331e5e1 call     0x4331ed0b
4331e5e6 xor      ecx, ecx
4331e5e8 test     byte ptr [edi + 0x6c], 4
4331e5ec je       0x4331e65c
4331e5ee mov      eax, dword ptr [0x43469064]
4331e5f3 mov      eax, dword ptr [eax]
4331e5f5 xor      eax, dword ptr [0x4346a484]
4331e5fb xor      eax, 0x17978090
4331e600 cmp      dword ptr [eax + esi + 0xc], ecx
4331e604 je       0x4331e65c
4331e606 push     dword ptr [eax + esi]
4331e609 lea      edx, [edi + 0x240]
4331e60f mov      ecx, esi
4331e611 call     0x43407ea3
4331e616 mov      eax, dword ptr [0x43468e7c]
4331e61b mov      ecx, 0xfff00
4331e620 mov      eax, dword ptr [eax]
4331e622 xor      eax, dword ptr [0x434674a8]
4331e628 xor      eax, 0x54783141
4331e62d mov      dword ptr [eax + esi + 8], ecx
4331e631 mov      dword ptr [eax + esi + 0xc], ecx
4331e635 mov      ecx, dword ptr [0x43469060]
4331e63b test     ecx, ecx
4331e63d je       0x4331e6cb
4331e643 mov      eax, dword ptr [0x4346a808]
4331e648 mov      ecx, dword ptr [ecx]
4331e64a mov      eax, dword ptr [eax]
4331e64c xor      eax, dword ptr [0x43468be8]
4331e652 xor      eax, 0x2b554ad0
4331e657 mov      dword ptr [eax + esi], ecx
4331e65a jmp      0x4331e6cb
4331e65c mov      eax, dword ptr [0x43468e7c]
4331e661 mov      eax, dword ptr [eax]
4331e663 xor      eax, dword ptr [0x434674a8]
4331e669 xor      eax, 0x54783141
4331e66e mov      dword ptr [eax + esi + 8], ecx
4331e672 mov      eax, dword ptr [0x4346a808]
4331e677 mov      eax, dword ptr [eax]
4331e679 xor      eax, dword ptr [0x43468be8]
4331e67f xor      eax, 0x2b554ad0
4331e684 mov      dword ptr [eax + esi], ecx
4331e687 mov      eax, dword ptr [0x434675cc]
4331e68c mov      eax, dword ptr [eax]
4331e68e xor      eax, dword ptr [0x43468538]
4331e694 xor      eax, 0xc7e1ecd2
4331e699 mov      dword ptr [eax + esi], 0xff7fffff
4331e6a0 mov      eax, dword ptr [0x434688b4]
4331e6a5 mov      eax, dword ptr [eax]
4331e6a7 xor      eax, dword ptr [0x4346a7d0]
4331e6ad xor      eax, 0x471e13c
4331e6b2 mov      dword ptr [eax + esi], ecx
4331e6b5 mov      eax, dword ptr [0x43467634]
4331e6ba mov      eax, dword ptr [eax]
4331e6bc xor      eax, dword ptr [0x43468f2c]
4331e6c2 xor      eax, 0xbb78dc43
4331e6c7 and      dword ptr [eax + esi], 0xfffffffd
4331e6cb mov      ecx, dword ptr [esp + 0x18]
4331e6cf test     ecx, ecx
4331e6d1 je       0x4331e6d9
4331e6d3 mov      al, byte ptr [esp + 0x1c]
4331e6d7 mov      byte ptr [ecx], al
4331e6d9 pop      edi
4331e6da pop      esi
4331e6db mov      esp, ebp
4331e6dd pop      ebp
4331e6de ret      4
