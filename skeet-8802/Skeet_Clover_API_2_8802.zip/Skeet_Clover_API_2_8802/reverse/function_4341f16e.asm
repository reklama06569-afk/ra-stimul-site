4341f16e mov      eax, dword ptr [0x43475a7c]
4341f173 push     esi
4341f174 test     eax, eax
4341f176 je       0x4341f194
4341f178 mov      esi, dword ptr [eax + 0x4c]
4341f17b cmp      esi, dword ptr [eax + 0x50]
4341f17e je       0x4341f194
4341f180 mov      eax, dword ptr [esi + 0x94]
4341f186 mov      dword ptr [ecx], eax
4341f188 mov      eax, dword ptr [esi + 0xb8]
4341f18e mov      dword ptr [edx], eax
4341f190 mov      al, 1
4341f192 pop      esi
4341f193 ret      
4341f194 xor      al, al
4341f196 pop      esi
4341f197 ret      
