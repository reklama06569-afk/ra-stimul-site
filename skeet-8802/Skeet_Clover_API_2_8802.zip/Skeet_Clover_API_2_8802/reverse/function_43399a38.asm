43399a38 push     ebp
43399a39 mov      ebp, esp
43399a3b and      esp, 0xfffffff0
43399a3e sub      esp, 0x618
43399a44 push     esi
43399a45 push     edi
43399a46 mov      edi, ecx
43399a48 mov      dword ptr [esp + 0x20], edx
43399a4c mov      ecx, dword ptr [ebp + 8]
43399a4f mov      dword ptr [esp + 0x3c], edi
43399a53 test     ecx, ecx
43399a55 jne      0x43399a63
43399a57 sub      dh, ah
43399a59 in       eax, 0x4a
43399a5b into     
43399a5c cmp      al, 0xf0
43399a5e popfd    
43399a5f inc      eax
43399a60 iretd    
43399a61 lodsd    eax, dword ptr [esi]
43399a62 std      
43399a63 mov      eax, dword ptr [0x4346a6dc]
43399a68 mov      esi, 0x8cfc633a
43399a6d mov      eax, dword ptr [eax]
43399a6f xor      eax, dword ptr [0x43468bd8]
43399a75 xor      eax, esi
43399a77 mov      eax, dword ptr [eax + ecx]
43399a7a cmp      eax, dword ptr [edi + 0x808]
43399a80 setg     al
43399a83 mov      byte ptr [edi + 0x804], al
43399a89 test     ecx, ecx
43399a8b jne      0x43399a99
43399a8d sti      
43399a8e ret      
43399a99 mov      eax, dword ptr [0x4346a6dc]
43399a9e mov      eax, dword ptr [eax]
43399aa0 xor      eax, dword ptr [0x43468bd8]
43399aa6 xor      eax, esi
43399aa8 mov      eax, dword ptr [eax + ecx]
43399aab mov      dword ptr [edi + 0x808], eax
43399ab1 mov      eax, dword ptr [edi + 0x7f8]
43399ab7 cmp      byte ptr [eax], 0
43399aba je       0x43399adb
43399abc mov      eax, dword ptr [0x43467f48]
43399ac1 mov      ecx, 0x43467f34
43399ac6 mov      eax, dword ptr [eax*4 + 0x434721c4]
43399acd call     eax
43399acf test     al, al
43399ad1 jne      0x4339c4ee
43399ad7 mov      edx, dword ptr [esp + 0x20]
43399adb lea      eax, [edi + 0x85c]
43399ae1 xorps    xmm4, xmm4
43399ae4 and      dword ptr [eax], 0
43399ae7 and      dword ptr [eax + 4], 0
43399aeb and      dword ptr [eax + 8], 0
43399aef and      dword ptr [edi + 0x868], 0
43399af6 mov      dword ptr [esp + 0x108], eax
43399afd mov      eax, dword ptr [0x43467b04]
43399b02 movss    xmm0, dword ptr [eax + 0x20]
43399b07 mulss    xmm0, dword ptr [0x4346edd0]
43399b0f movss    dword ptr [edi + 0x8d0], xmm0
43399b17 cmp      dword ptr [edx + 0xc], 0
43399b1b je       0x4339c4ee
43399b21 movsx    edx, byte ptr [edx + 0x124]
43399b28 lea      esi, [edi - 8]
43399b2b mov      dword ptr [esp + 0x4c], esi
43399b2f cmp      edx, 9
43399b32 jge      0x43399b3c
43399b34 mov      dword ptr [esi + 0x804], edx
43399b3a jmp      0x43399b3e
43399b3c xor      edx, edx
43399b3e mov      ecx, dword ptr [esi + edx*4 + 0x4bc]
43399b45 mov      dword ptr [esi + 0x85c], ecx
43399b4b mov      eax, dword ptr [esi + edx*4 + 0x4f0]
43399b52 mov      dword ptr [esi + 0x860], eax
43399b58 mov      ah, byte ptr [esi + edx + 0x524]
43399b5f xor      ah, byte ptr [esi + 0x83d]
43399b65 and      ah, 1
43399b68 xor      ah, byte ptr [esi + 0x83d]
43399b6e mov      byte ptr [esi + 0x83d], ah
43399b74 mov      al, byte ptr [esi + edx + 0x24]
43399b78 mov      byte ptr [esp + 0x33], al
43399b7c mov      byte ptr [esi + 0x818], al
43399b82 mov      al, byte ptr [esi + edx + 0x2bc]
43399b89 shl      al, 5
43399b8c xor      al, byte ptr [esi + 0x83c]
43399b92 and      al, 0x20
43399b94 xor      al, byte ptr [esi + 0x83c]
43399b9a mov      byte ptr [esi + 0x83c], al
43399ba0 test     ecx, ecx
43399ba2 jne      0x43399bbf
43399ba4 test     ah, 1
43399ba7 jne      0x43399bbf
43399ba9 cmp      byte ptr [esp + 0x33], cl
43399bad jne      0x43399bbf
43399baf test     al, 0x20
43399bb1 jne      0x43399bbf
43399bb3 mov      ecx, esi
43399bb5 call     0x4340c87e
43399bba jmp      0x4339c4ee
43399bbf mov      eax, dword ptr [ebp + 0xc]
43399bc2 test     byte ptr [eax + 0x30], 1
43399bc6 jne      0x43399bd0
43399bc8 movd     xmm0, dword ptr [esi + edx*4 + 0x74]
43399bce jmp      0x43399bd9
43399bd0 movd     xmm0, dword ptr [esi + edx*4 + 0xa8]
43399bd9 cvtdq2ps xmm0, xmm0
43399bdc divss    xmm0, dword ptr [0x4347064c]
43399be4 movss    dword ptr [esi + 0x81c], xmm0
43399bec movd     xmm0, dword ptr [esi + edx*4 + 0xdc]
43399bf5 movss    xmm5, dword ptr [0x4346f908]
43399bfd movss    xmm6, dword ptr [0x43470000]
43399c05 cvtdq2ps xmm0, xmm0
43399c08 mulss    xmm0, xmm5
43399c0c movss    dword ptr [esi + 0x820], xmm0
43399c14 mov      eax, dword ptr [esi + edx*4 + 0x200]
43399c1b cmp      eax, 0x3e9
43399c20 jne      0x43399c34
43399c22 cmp      byte ptr [esi + 0x828], 0
43399c29 je       0x43399c4e
43399c2b mov      byte ptr [esi + 0x828], 0
43399c32 jmp      0x43399c4e
43399c34 movd     xmm0, eax
43399c38 cvtdq2ps xmm0, xmm0
43399c3b mov      byte ptr [esi + 0x828], 1
43399c42 mulss    xmm0, xmm6
43399c46 movss    dword ptr [esi + 0x824], xmm0
43399c4e movd     xmm0, dword ptr [esi + edx*4 + 0x110]
43399c57 cvtdq2ps xmm0, xmm0
43399c5a mulss    xmm0, xmm6
43399c5e movss    dword ptr [esi + 0x82c], xmm0
43399c66 movd     xmm1, dword ptr [esi + edx*4 + 0x40]
43399c6c movss    xmm0, dword ptr [0x434720e0]
43399c74 cvtdq2ps xmm1, xmm1
43399c77 mulss    xmm1, dword ptr [0x43472980]
43399c7f call     0x43367633
43399c84 movss    dword ptr [esi + 0x830], xmm0
43399c8c movd     xmm0, dword ptr [esi + edx*4 + 0x198]
43399c95 cvtdq2ps xmm0, xmm0
43399c98 mulss    xmm0, xmm5
43399c9c movss    dword ptr [esi + 0x834], xmm0
43399ca4 movd     xmm0, dword ptr [esi + edx*4 + 0x1cc]
43399cad cvtdq2ps xmm0, xmm0
43399cb0 mulss    xmm0, xmm5
43399cb4 movss    dword ptr [esi + 0x838], xmm0
43399cbc mov      cl, byte ptr [esi + edx + 0x17c]
43399cc3 xor      cl, byte ptr [esi + 0x83c]
43399cc9 and      cl, 1
43399ccc xor      cl, byte ptr [esi + 0x83c]
43399cd2 mov      byte ptr [esi + 0x83c], cl
43399cd8 mov      al, byte ptr [esi + edx + 0x144]
43399cdf add      al, al
43399ce1 xor      al, cl
43399ce3 and      al, 2
43399ce5 xor      cl, al
43399ce7 mov      byte ptr [esi + 0x83c], cl
43399ced mov      al, byte ptr [esi + edx + 0x160]
43399cf4 shl      al, 2
43399cf7 xor      al, cl
43399cf9 and      al, 4
43399cfb xor      cl, al
43399cfd mov      byte ptr [esi + 0x83c], cl
43399d03 mov      al, byte ptr [esi + edx + 0x3fc]
43399d0a shl      al, 4
43399d0d xor      al, cl
43399d0f and      al, 0x10
43399d11 xor      cl, al
43399d13 xor      eax, eax
43399d15 mov      byte ptr [esi + 0x83c], cl
43399d1b mov      ch, byte ptr [esi + edx + 0x418]
43399d22 and      dword ptr [esi + 0x840], 0
43399d29 shl      ch, 3
43399d2c xor      ch, cl
43399d2e and      ch, 8
43399d31 xor      ch, cl
43399d33 mov      byte ptr [esi + 0x83c], ch
43399d39 cmp      byte ptr [esi + edx + 0x234], al
43399d40 je       0x43399d4b
43399d42 push     2
43399d44 pop      eax
43399d45 mov      dword ptr [esi + 0x840], eax
43399d4b cmp      byte ptr [esi + edx + 0x250], 0
43399d53 je       0x43399d5e
43399d55 or       eax, 4
43399d58 mov      dword ptr [esi + 0x840], eax
43399d5e cmp      byte ptr [esi + edx + 0x26c], 0
43399d66 je       0x43399d71
43399d68 or       eax, 8
43399d6b mov      dword ptr [esi + 0x840], eax
43399d71 lea      eax, [edx + 0x22]
43399d74 imul     eax, eax, 0x28
43399d77 mov      eax, dword ptr [eax + esi]
43399d7a and      eax, 0xfffffffc
43399d7d cmp      eax, 4
43399d80 jne      0x43399d8e
43399d82 movd     xmm4, dword ptr [esi + edx*4 + 0x288]
43399d8b cvtdq2ps xmm4, xmm4
43399d8e movss    dword ptr [esi + 0x844], xmm4
43399d96 mov      eax, dword ptr [esi + edx*4 + 0x2d8]
43399d9d mov      dword ptr [esi + 0x848], eax
43399da3 movd     xmm0, dword ptr [esi + edx*4 + 0x488]
43399dac cvtdq2ps xmm0, xmm0
43399daf mulss    xmm0, xmm6
43399db3 movss    dword ptr [esi + 0x84c], xmm0
43399dbb mov      cl, byte ptr [esi + edx + 0x340]
43399dc2 shl      cl, 6
43399dc5 xor      cl, ch
43399dc7 and      cl, 0x40
43399dca xor      cl, ch
43399dcc mov      byte ptr [esi + 0x83c], cl
43399dd2 and      cl, 0x7f
43399dd5 movd     xmm0, dword ptr [esi + edx*4 + 0x35c]
43399dde cvtdq2ps xmm0, xmm0
43399de1 mulss    xmm0, xmm6
43399de5 movss    dword ptr [esi + 0x850], xmm0
43399ded mov      eax, dword ptr [esi + edx*4 + 0x30c]
43399df4 mov      dword ptr [esi + 0x854], eax
43399dfa mov      al, byte ptr [esi + edx + 0x3e0]
43399e01 and      dword ptr [esi + 0x858], 0
43399e08 shl      al, 7
43399e0b or       al, cl
43399e0d mov      byte ptr [esi + 0x83c], al
43399e13 xor      eax, eax
43399e15 cmp      byte ptr [esi + edx + 0x434], al
43399e1c je       0x43399e27
43399e1e push     2
43399e20 pop      eax
43399e21 mov      dword ptr [esi + 0x858], eax
43399e27 cmp      byte ptr [esi + edx + 0x450], 0
43399e2f je       0x43399e3a
43399e31 or       eax, 4
43399e34 mov      dword ptr [esi + 0x858], eax
43399e3a cmp      byte ptr [esi + edx + 0x46c], 0
43399e42 je       0x43399e4d
43399e44 or       eax, 8
43399e47 mov      dword ptr [esi + 0x858], eax
43399e4d push     dword ptr [ebp + 0xc]
43399e50 movss    xmm3, dword ptr [edi + 0x83c]
43399e58 mov      ecx, esi
43399e5a push     dword ptr [esp + 0x24]
43399e5e call     0x433ee27b
43399e63 mov      edi, dword ptr [ebp + 8]
43399e66 test     edi, edi
43399e68 jne      0x43399e76
43399e6a jmp      0x43399ea0
43399e76 mov      eax, dword ptr [0x43468b50]
43399e7b mov      eax, dword ptr [eax]
43399e7d xor      eax, dword ptr [0x43467b48]
43399e83 xor      eax, 0x38ca5228
43399e88 mov      eax, dword ptr [eax + edi]
43399e8b shr      eax, 3
43399e8e test     al, 1
43399e90 jne      0x43399efa
43399e92 test     edi, edi
43399e94 jne      0x43399ea2
43399e96 jae      0x43399e66
43399e98 add      eax, dword ptr [esi - 0x42cfb211]
43399e9e rcr      byte ptr [eax + 0x7ca176af], 1
43399ea0 scasd    eax, dword ptr es:[edi]
43399ea1 jbe      0x43399e44
43399ea2 mov      eax, dword ptr [0x4346757c]
43399ea3 jl       0x43399f1a
43399ea4 jne      0x43399eec
43399ea5 inc      esi
43399ea6 inc      ebx
43399ea7 mov      edx, dword ptr [eax]
43399ea9 xor      edx, dword ptr [0x4346707c]
43399eaf xor      edx, 0x43fa575
43399eb5 test     edi, edi
43399eb7 jne      0x43399ec5
43399eb9 lock xchg dword ptr [esi + 0x6b6eda], ecx
43399ec0 mov      ch, 0x37
43399ec2 xchg     ebp, eax
43399ec3 push     edx
43399ec4 xchg     ebp, eax
43399ec5 mov      eax, dword ptr [0x4346934c]
43399eca mov      ecx, dword ptr [eax]
43399ecc xor      ecx, dword ptr [0x434671f8]
43399ed2 mov      al, byte ptr [edx + edi]
43399ed5 xor      ecx, 0x334b460c
43399edb cmp      al, byte ptr [ecx + edi]
43399ede jne      0x43399efa
43399ee0 mov      eax, dword ptr [ebp + 0xc]
43399ee3 mov      ecx, dword ptr [esp + 0x3c]
43399ee7 mov      eax, dword ptr [eax + 4]
43399eea sub      eax, dword ptr [ecx + 0x800]
43399eec add      byte ptr [eax], cl
43399eee add      byte ptr [eax], al
43399ef0 cdq      
43399ef1 xor      eax, edx
43399ef3 sub      eax, edx
43399ef5 cmp      eax, 1
43399ef8 jle      0x43399f05
43399efa mov      eax, dword ptr [esi]
43399efc mov      ecx, esi
43399efe call     dword ptr [eax + 0x1c]
43399f01 mov      ecx, dword ptr [esp + 0x3c]
43399f05 mov      eax, dword ptr [esp + 0x20]
43399f09 lea      edi, [esp + 0x84]
43399f10 add      eax, 0x20
43399f13 cmp      byte ptr [ecx + 0x904], 0
43399f1a mov      esi, eax
43399f1c mov      dword ptr [esp + 0x74], eax
43399f20 movsd    dword ptr es:[edi], dword ptr [esi]
43399f21 movsd    dword ptr es:[edi], dword ptr [esi]
43399f22 movsd    dword ptr es:[edi], dword ptr [esi]
43399f23 je       0x43399f35
43399f25 lea      esi, [ecx + 0x8f8]
43399f2b lea      edi, [esp + 0x84]
43399f32 movsd    dword ptr es:[edi], dword ptr [esi]
43399f33 movsd    dword ptr es:[edi], dword ptr [esi]
43399f34 movsd    dword ptr es:[edi], dword ptr [esi]
43399f35 mov      edx, dword ptr [ebp + 0xc]
43399f38 movss    xmm5, dword ptr [0x43470340]
43399f40 movss    xmm6, dword ptr [0x434725e4]
43399f48 movss    xmm4, dword ptr [0x43471f88]
43399f50 lea      eax, [edx + 0xc]
43399f53 movss    xmm3, dword ptr [eax]
43399f57 subss    xmm3, dword ptr [ecx + 0x86c]
43399f5f mov      dword ptr [esp + 0x5c], eax
43399f63 subss    xmm3, dword ptr [esp + 0x84]
43399f6c ucomiss  xmm3, xmm3
43399f6f movss    dword ptr [esp + 0x34], xmm3
43399f75 lahf     
43399f76 test     ah, 0x44
43399f79 jnp      0x43399fb4
43399f7b xorps    xmm3, xmm3
43399f7e movss    dword ptr [esp + 0x34], xmm3
43399f84 xorps    xmm2, xmm2
43399f87 movss    xmm1, dword ptr [edx + 0x10]
43399f8c subss    xmm1, dword ptr [ecx + 0x870]
43399f94 subss    xmm1, dword ptr [esp + 0x88]
43399f9d ucomiss  xmm1, xmm1
43399fa0 movss    dword ptr [esp + 0x28], xmm1
43399fa6 lahf     
43399fa7 test     ah, 0x44
43399faa jnp      0x4339a014
43399fac xorps    xmm1, xmm1
43399faf jmp      0x4339a058
43399fb4 movaps   xmm0, xmm3
43399fb7 andps    xmm0, xmm5
43399fba comiss   xmm0, xmm6
43399fbd jbe      0x43399f84
43399fbf movaps   xmm0, xmm3
43399fc2 divss    xmm0, xmm4
43399fc6 andps    xmm0, xmm5
43399fc9 call     0x4341ad12
43399fce movss    xmm3, dword ptr [esp + 0x34]
43399fd4 xorps    xmm2, xmm2
43399fd7 comiss   xmm2, xmm3
43399fda mov      ecx, dword ptr [esp + 0x3c]
43399fde mov      edx, dword ptr [ebp + 0xc]
43399fe1 movss    xmm4, dword ptr [0x43471f88]
43399fe9 movss    xmm5, dword ptr [0x43470340]
43399ff1 movss    xmm6, dword ptr [0x434725e4]
43399ff9 mulss    xmm0, xmm4
43399ffd jbe      0x4339a00e
43399fff addss    xmm3, xmm0
4339a003 movss    dword ptr [esp + 0x34], xmm3
4339a009 jmp      0x43399f87
4339a00e subss    xmm3, xmm0
4339a012 jmp      0x4339a003
4339a014 movaps   xmm0, xmm1
4339a017 andps    xmm0, xmm5
4339a01a comiss   xmm0, xmm6
4339a01d jbe      0x4339a058
4339a01f movaps   xmm0, xmm1
4339a022 divss    xmm0, xmm4
4339a026 andps    xmm0, xmm5
4339a029 call     0x4341ad12
4339a02e movss    xmm1, dword ptr [esp + 0x28]
4339a034 xorps    xmm2, xmm2
4339a037 comiss   xmm2, xmm1
4339a03a mov      ecx, dword ptr [esp + 0x3c]
4339a03e mulss    xmm0, dword ptr [0x43471f88]
4339a046 movss    xmm3, dword ptr [esp + 0x34]
4339a04c jbe      0x4339a054
4339a04e addss    xmm1, xmm0
4339a052 jmp      0x4339a058
4339a054 subss    xmm1, xmm0
4339a058 movss    xmm4, dword ptr [ecx + 0x8d0]
4339a060 lea      edx, [ecx + 0x8b8]
4339a066 movaps   xmm5, xmm4
4339a069 mulss    xmm5, xmm3
4339a06d movaps   xmm3, xmm4
4339a070 mulss    xmm3, xmm1
4339a074 mulss    xmm4, xmm2
4339a078 movss    dword ptr [esp + 0x54], xmm5
4339a07e movss    dword ptr [esp + 0xcc], xmm5
4339a087 movss    dword ptr [esp + 0x48], xmm3
4339a08d movss    dword ptr [esp + 0xd0], xmm3
4339a096 movss    dword ptr [esp + 0xd4], xmm4
4339a09f movss    dword ptr [ecx + 0x8c4], xmm5
4339a0a7 movss    dword ptr [ecx + 0x8c8], xmm3
4339a0af movss    dword ptr [ecx + 0x8cc], xmm4
4339a0b7 and      dword ptr [ecx + 0x86c], 0
4339a0be and      dword ptr [ecx + 0x870], 0
4339a0c5 and      dword ptr [ecx + 0x874], 0
4339a0cc movss    xmm0, dword ptr [edx + 4]
4339a0d1 movss    xmm1, dword ptr [edx]
4339a0d5 mulss    xmm0, xmm0
4339a0d9 mov      dword ptr [esp + 0x40], edx
4339a0dd mulss    xmm1, xmm1
4339a0e1 ucomiss  xmm5, dword ptr [edx]
4339a0e4 addss    xmm1, xmm0
4339a0e8 movss    xmm0, dword ptr [ecx + 0x8d0]
4339a0f0 mulss    xmm0, dword ptr [0x4346f130]
4339a0f8 lahf     
4339a0f9 movss    dword ptr [esp + 0x28], xmm0
4339a0ff movaps   xmm6, xmm1
4339a102 sqrtss   xmm6, xmm6
4339a106 movss    dword ptr [esp + 0x150], xmm6
4339a10f movups   xmmword ptr [esp + 0x140], xmm6
4339a117 test     ah, 0x44
4339a11a jp       0x4339a137
4339a11c ucomiss  xmm3, dword ptr [edx + 4]
4339a120 lahf     
4339a121 test     ah, 0x44
4339a124 jp       0x4339a137
4339a126 ucomiss  xmm4, dword ptr [edx + 8]
4339a12a lahf     
4339a12b test     ah, 0x44
4339a12e jp       0x4339a137
4339a130 mov      esi, edx
4339a132 jmp      0x4339a1cb
4339a137 mov      ecx, dword ptr [esp + 0x40]
4339a13b lea      edx, [esp + 0x190]
4339a142 call     0x4334df4d
4339a147 lea      edx, [esp + 0x1f8]
4339a14e lea      ecx, [esp + 0xcc]
4339a155 call     0x4334df4d
4339a15a lea      eax, [esp + 0x208]
4339a161 push     eax
4339a162 lea      edx, [esp + 0x1fc]
4339a169 lea      ecx, [esp + 0x194]
4339a170 call     0x4334a802
4339a175 movss    xmm0, dword ptr [esp + 0x28]
4339a17b lea      eax, [esp + 0x218]
4339a182 push     eax
4339a183 lea      edx, [esp + 0x20c]
4339a18a lea      ecx, [esp + 0x194]
4339a191 call     0x4334199d
4339a196 lea      edx, [esp + 0x11c]
4339a19d lea      ecx, [esp + 0x218]
4339a1a4 call     0x433945fb
4339a1a9 movss    xmm3, dword ptr [esp + 0x48]
4339a1af lea      esi, [esp + 0x11c]
4339a1b6 movss    xmm5, dword ptr [esp + 0x54]
4339a1bc xorps    xmm2, xmm2
4339a1bf movups   xmm6, xmmword ptr [esp + 0x140]
4339a1c7 mov      edx, dword ptr [esp + 0x40]
4339a1cb lea      edi, [esp + 0xb8]
4339a1d2 movss    xmm7, dword ptr [0x434725e8]
4339a1da movsd    dword ptr es:[edi], dword ptr [esi]
4339a1db movsd    dword ptr es:[edi], dword ptr [esi]
4339a1dc movsd    dword ptr es:[edi], dword ptr [esi]
4339a1dd mov      edi, edx
4339a1df lea      esi, [esp + 0xb8]
4339a1e6 movsd    dword ptr es:[edi], dword ptr [esi]
4339a1e7 movsd    dword ptr es:[edi], dword ptr [esi]
4339a1e8 movsd    dword ptr es:[edi], dword ptr [esi]
4339a1e9 movss    xmm1, dword ptr [edx]
4339a1ed movss    xmm0, dword ptr [edx + 4]
4339a1f2 mulss    xmm1, xmm1
4339a1f6 mulss    xmm0, xmm0
4339a1fa addss    xmm1, xmm0
4339a1fe movaps   xmm0, xmm5
4339a201 movaps   xmm4, xmm1
4339a204 movss    xmm1, dword ptr [0x43470340]
4339a20c sqrtss   xmm4, xmm4
4339a210 andps    xmm0, xmm1
4339a213 comiss   xmm0, xmm7
4339a216 movss    dword ptr [esp + 0x170], xmm4
4339a21f jae      0x4339a230
4339a221 movaps   xmm0, xmm3
4339a224 andps    xmm0, xmm1
4339a227 comiss   xmm0, xmm7
4339a22a jae      0x4339a230
4339a22c xor      cl, cl
4339a22e jmp      0x4339a232
4339a230 mov      cl, 2
4339a232 mov      edi, dword ptr [esp + 0x3c]
4339a236 mov      al, byte ptr [edi + 0x835]
4339a23c and      al, 0xfd
4339a23e or       al, cl
4339a240 ucomiss  xmm4, xmm2
4339a243 lahf     
4339a244 test     ah, 0x44
4339a247 jnp      0x4339a252
4339a249 comiss   xmm4, xmm6
4339a24c jb       0x4339a252
4339a24e mov      cl, 4
4339a250 jmp      0x4339a254
4339a252 xor      cl, cl
4339a254 mulss    xmm3, xmm3
4339a258 and      al, 0xfb
4339a25a or       al, cl
4339a25c mulss    xmm5, xmm5
4339a260 mov      byte ptr [edi + 0x835], al
4339a266 addss    xmm3, xmm5
4339a26a movaps   xmm0, xmm3
4339a26d sqrtss   xmm0, xmm0
4339a271 comiss   xmm0, xmm7
4339a274 movss    dword ptr [esp + 0x16c], xmm0
4339a27d jb       0x4339a28c
4339a27f mov      eax, dword ptr [0x4346a334]
4339a284 mov      eax, dword ptr [eax]
4339a286 mov      dword ptr [edi + 0x8d4], eax
4339a28c mov      eax, dword ptr [ebp + 0xc]
4339a28f push     dword ptr [esp + 0x20]
4339a293 mov      esi, dword ptr [esp + 0x50]
4339a297 mov      ecx, esi
4339a299 mov      eax, dword ptr [eax + 4]
4339a29c mov      dword ptr [edi + 0x800], eax
4339a2a2 lea      eax, [esp + 0x178]
4339a2a9 push     eax
4339a2aa call     0x433d5acc
4339a2af movss    xmm0, dword ptr [esp + 0x178]
4339a2b8 mulss    xmm0, dword ptr [0x43470528]
4339a2c0 movss    dword ptr [esp + 0x28], xmm0
4339a2c6 call     0x7750c6d0
4339a2cb movss    dword ptr [esp + 0x54], xmm0
4339a2d1 movss    xmm0, dword ptr [esp + 0x28]
4339a2d7 call     0x7750a770
4339a2dc movss    dword ptr [esp + 0x48], xmm0
4339a2e2 movss    xmm0, dword ptr [esp + 0x174]
4339a2eb mulss    xmm0, dword ptr [0x43470528]
4339a2f3 movss    dword ptr [esp + 0x28], xmm0
4339a2f9 call     0x7750c6d0
4339a2fe movss    dword ptr [esp + 0x40], xmm0
4339a304 movss    xmm0, dword ptr [esp + 0x28]
4339a30a call     0x7750a770
4339a30f movss    xmm4, dword ptr [esp + 0x40]
4339a315 movaps   xmm3, xmm0
4339a318 xorps    xmm4, xmmword ptr [0x434703d0]
4339a31f movaps   xmm2, xmm3
4339a322 mulss    xmm2, dword ptr [esp + 0x48]
4339a328 xor      edx, edx
4339a32a inc      edx
4339a32b mov      eax, dword ptr [0x43469300]
4339a330 mulss    xmm3, dword ptr [esp + 0x54]
4339a336 mov      dword ptr [esp + 0x44], edx
4339a33a movaps   xmm1, xmm2
4339a33d mulss    xmm1, xmm2
4339a341 mov      eax, dword ptr [eax]
4339a343 movaps   xmm0, xmm3
4339a346 mov      dword ptr [esp + 0x18], eax
4339a34a mulss    xmm0, xmm3
4339a34e addss    xmm1, xmm0
4339a352 movaps   xmm0, xmm4
4339a355 mulss    xmm0, xmm4
4339a359 addss    xmm1, xmm0
4339a35d xorps    xmm0, xmm0
4339a360 movss    xmm0, xmm1
4339a364 movss    xmm1, dword ptr [0x43470514]
4339a36c sqrtss   xmm0, xmm0
4339a370 movss    dword ptr [esp + 0x160], xmm0
4339a379 addss    xmm0, dword ptr [0x43472108]
4339a381 divss    xmm1, xmm0
4339a385 movaps   xmm0, xmm1
4339a388 mulss    xmm0, xmm2
4339a38c movss    dword ptr [esp + 0x60], xmm0
4339a392 movaps   xmm0, xmm1
4339a395 mulss    xmm0, xmm3
4339a399 mulss    xmm1, xmm4
4339a39d movss    dword ptr [esp + 0x70], xmm0
4339a3a3 movss    dword ptr [esp + 0x50], xmm1
4339a3a9 cmp      eax, edx
4339a3ab jl       0x4339a973
4339a3b1 mov      ecx, dword ptr [0x4346a890]
4339a3b7 push     edx
4339a3b8 mov      eax, dword ptr [ecx]
4339a3ba mov      eax, dword ptr [eax + 0xc]
4339a3bd call     eax
4339a3bf mov      ecx, dword ptr [esp + 0x44]
4339a3c3 mov      edi, eax
4339a3c5 and      ecx, 0x3f
4339a3c8 add      ecx, 0x3a
4339a3cb imul     eax, ecx, 0x28
4339a3ce mov      ecx, edi
4339a3d0 add      eax, esi
4339a3d2 mov      dword ptr [esp + 0x58], eax
4339a3d6 add      eax, 0x24
4339a3d9 mov      dword ptr [esp + 0x38], eax
4339a3dd call     0x43358962
4339a3e2 test     al, al
4339a3e4 jne      0x4339a40a
4339a3e6 mov      eax, dword ptr [esp + 0x58]
4339a3ea and      dword ptr [eax], 0
4339a3ed lea      ecx, [eax + 0x14]
4339a3f0 and      dword ptr [eax + 4], 0
4339a3f4 and      dword ptr [eax + 8], 0
4339a3f8 and      dword ptr [eax + 0xc], 0
4339a3fc and      dword ptr [eax + 0x10], 0
4339a400 call     0x43419df8
4339a405 jmp      0x4339a94f
4339a40a mov      eax, dword ptr [0x4346a338]
4339a40f mov      ecx, dword ptr [esp + 0x38]
4339a413 mov      eax, dword ptr [eax]
4339a415 mov      dword ptr [ecx], eax
4339a417 mov      ecx, dword ptr [esp + 0x44]
4339a41b call     0x433b8a2b
4339a420 push     dword ptr [esp + 0x38]
4339a424 lea      ecx, [esp + 0x294]
4339a42b push     ecx
4339a42c push     eax
4339a42d push     edi
4339a42e push     dword ptr [esp + 0x30]
4339a432 mov      ecx, esi
4339a434 call     0x4336ec3b
4339a439 test     al, al
4339a43b je       0x4339a3e6
4339a43d xor      eax, eax
4339a43f cmp      byte ptr [esi + 0x818], al
4339a445 je       0x4339a44d
4339a447 mov      eax, dword ptr [esi + 0x840]
4339a44d test     byte ptr [esi + 0x83c], 0x20
4339a454 je       0x4339a45c
4339a456 or       eax, dword ptr [esi + 0x858]
4339a45c test     eax, eax
4339a45e je       0x4339a912
4339a464 not      eax
4339a466 mov      ecx, edi
4339a468 mov      dword ptr [esp + 0x9c], eax
4339a46f call     0x433fd30d
4339a474 test     eax, eax
4339a476 je       0x4339a912
4339a47c test     edi, edi
4339a47e jne      0x4339a48c
4339a480 sar      al, cl
4339a482 push     0x5b11c4e8
4339a487 cwde     
4339a488 xor      cl, dh
4339a48a jmp      0x4339a4e1
4339a48c mov      ecx, dword ptr [eax]
4339a48e mov      eax, dword ptr [0x43468240]
4339a493 mov      eax, dword ptr [eax]
4339a495 xor      eax, dword ptr [0x4346a84c]
4339a49b xor      eax, 0xc2b6fb10
4339a4a0 imul     edx, dword ptr [eax + edi], 0xc
4339a4a4 add      edx, dword ptr [ecx + 0xb0]
4339a4aa add      edx, ecx
4339a4ac mov      dword ptr [esp + 0x14], edx
4339a4b0 je       0x4339a912
4339a4b6 xor      eax, eax
4339a4b8 cmp      dword ptr [edx + 4], eax
4339a4bb je       0x4339a912
4339a4c1 cmp      dword ptr [edx + 4], 6
4339a4c5 jle      0x4339a912
4339a4cb movss    xmm0, dword ptr [0x4346f858]
4339a4d3 mov      edi, dword ptr [esp + 0x58]
4339a4d7 mov      dword ptr [esp + 0x1c], eax
4339a4db mov      dword ptr [esp + 0x34], eax
4339a4df lea      eax, [esp + 0x2a8]
4339a4e1 and      al, 0xa8
4339a4e3 add      al, byte ptr [eax]
4339a4e5 add      bl, dh
4339a4e6 movss    dword ptr [esp + 0x28], xmm0
4339a4e7 movups   xmmword ptr [esp + 0x28], xmm0
4339a4ec mov      ecx, eax
4339a4ee mov      dword ptr [esp + 0x24], eax
4339a4f2 mov      eax, dword ptr [esp + 0x34]
4339a4f6 add      eax, edx
4339a4f8 add      eax, dword ptr [edx + 8]
4339a4fb cmp      dword ptr [eax], 0
4339a4fe jl       0x4339a8e8
4339a504 movss    xmm0, dword ptr [eax + 0x30]
4339a509 comiss   xmm0, dword ptr [0x4346ee6c]
4339a510 jbe      0x4339a8e8
4339a516 mov      ecx, dword ptr [eax + 4]
4339a519 mov      dword ptr [esp + 0x2c], 1
4339a521 shl      dword ptr [esp + 0x2c], cl
4339a525 mov      ecx, dword ptr [esp + 0x9c]
4339a52c test     dword ptr [esp + 0x2c], ecx
4339a530 jne      0x4339a8e4
4339a536 test     byte ptr [esi + 0x83c], 2
4339a53d movss    xmm3, dword ptr [eax + 0x14]
4339a542 movss    xmm1, dword ptr [eax + 0x18]
4339a547 addss    xmm3, dword ptr [eax + 8]
4339a54c addss    xmm1, dword ptr [eax + 0xc]
4339a551 movss    xmm2, dword ptr [eax + 0x1c]
4339a556 movss    xmm0, dword ptr [0x43472240]
4339a55e addss    xmm2, dword ptr [eax + 0x10]
4339a563 mov      eax, dword ptr [esp + 0x24]
4339a567 mulss    xmm1, xmm0
4339a56b mulss    xmm3, xmm0
4339a56f movss    xmm4, dword ptr [eax - 0x14]
4339a574 movss    xmm5, dword ptr [eax - 4]
4339a579 mulss    xmm2, xmm0
4339a57d movss    xmm0, dword ptr [eax - 0x18]
4339a582 mulss    xmm0, xmm3
4339a586 mulss    xmm4, xmm1
4339a58a movss    xmm6, dword ptr [eax + 0xc]
4339a58f mulss    xmm5, xmm1
4339a593 addss    xmm4, xmm0
4339a597 mulss    xmm6, xmm1
4339a59b movss    xmm0, dword ptr [eax - 0x10]
4339a5a0 mulss    xmm0, xmm2
4339a5a4 addss    xmm4, xmm0
4339a5a8 movss    xmm0, dword ptr [eax - 8]
4339a5ad mulss    xmm0, xmm3
4339a5b1 addss    xmm5, xmm0
4339a5b5 movss    xmm0, dword ptr [eax]
4339a5b9 addss    xmm4, dword ptr [eax - 0xc]
4339a5be mulss    xmm0, xmm2
4339a5c2 addss    xmm5, xmm0
4339a5c6 movss    dword ptr [esp + 0x54], xmm4
4339a5cc movss    xmm0, dword ptr [eax + 8]
4339a5d1 mulss    xmm0, xmm3
4339a5d5 movss    dword ptr [esp + 0x84], xmm4
4339a5de addss    xmm5, dword ptr [eax + 4]
4339a5e3 addss    xmm6, xmm0
4339a5e7 movss    xmm0, dword ptr [eax + 0x10]
4339a5ec mulss    xmm0, xmm2
4339a5f0 movss    dword ptr [esp + 0x48], xmm5
4339a5f6 addss    xmm6, xmm0
4339a5fa movss    dword ptr [esp + 0x88], xmm5
4339a603 addss    xmm6, dword ptr [eax + 0x14]
4339a608 movss    dword ptr [esp + 0x40], xmm6
4339a60e movss    dword ptr [esp + 0x8c], xmm6
4339a617 jne      0x4339a66f
4339a619 mov      eax, dword ptr [esp + 0x20]
4339a61d movss    xmm3, dword ptr [esp + 0x84]
4339a626 movss    xmm4, dword ptr [esp + 0x88]
4339a62f movss    xmm5, dword ptr [esp + 0x8c]
4339a638 movss    xmm0, dword ptr [eax + 0xdc]
4339a640 movss    xmm1, dword ptr [eax + 0xe0]
4339a648 movss    xmm2, dword ptr [eax + 0xe4]
4339a650 call     0x433e7c6b
4339a655 test     al, al
4339a657 jne      0x4339a8e0
4339a65d movss    xmm4, dword ptr [esp + 0x54]
4339a663 movss    xmm5, dword ptr [esp + 0x48]
4339a669 movss    xmm6, dword ptr [esp + 0x40]
4339a66f or       dword ptr [esp + 0x26c], 0xffffffff
4339a677 xor      eax, eax
4339a679 or       dword ptr [esp + 0x278], 0xffffffff
4339a681 mov      ecx, 0x600400b
4339a686 mov      dword ptr [esp + 0xfc], ecx
4339a68d movaps   xmm3, xmm5
4339a690 mov      dword ptr [esp + 0x100], ecx
4339a697 mov      ecx, dword ptr [0x43468304]
4339a69d mov      dword ptr [esp + 0xe8], eax
4339a6a4 mov      dword ptr [esp + 0xec], eax
4339a6ab mov      dword ptr [esp + 0xf0], eax
4339a6b2 mov      dword ptr [esp + 0xf4], eax
4339a6b9 mov      dword ptr [esp + 0xf8], eax
4339a6c0 mov      word ptr [esp + 0x25e], ax
4339a6c8 mov      dword ptr [esp + 0x274], eax
4339a6cf mov      dword ptr [esp + 0x104], 0x3f800000
4339a6da mov      dword ptr [esp + 0xe4], 0x43470404
4339a6e5 mov      dword ptr [esp + 0x254], 0x3f800000
4339a6f0 mov      eax, dword ptr [ecx]
4339a6f2 and      dword ptr [esp + 0x1e0], 0
4339a6fa mov      byte ptr [esp + 0x1e4], 1
4339a702 mov      byte ptr [esp + 0x1e5], 1
4339a70a mov      edx, dword ptr [eax + 0x14]
4339a70d mov      eax, dword ptr [esp + 0x20]
4339a711 movss    xmm0, dword ptr [eax + 0xdc]
4339a719 movss    xmm1, dword ptr [eax + 0xe0]
4339a721 subss    xmm4, xmm0
4339a725 movss    xmm2, dword ptr [eax + 0xe4]
4339a72d subss    xmm3, xmm1
4339a731 movss    dword ptr [esp + 0x1a4], xmm1
4339a73a movaps   xmm1, xmm6
4339a73d subss    xmm1, xmm2
4339a741 movss    dword ptr [esp + 0x1a0], xmm0
4339a74a xorps    xmm0, xmm0
4339a74d movss    dword ptr [esp + 0x1a8], xmm2
4339a756 movss    dword ptr [esp + 0x1b0], xmm4
4339a75f movss    dword ptr [esp + 0x1b4], xmm3
4339a768 mulss    xmm3, xmm3
4339a76c mulss    xmm4, xmm4
4339a770 movss    dword ptr [esp + 0x1b8], xmm1
4339a779 mulss    xmm1, xmm1
4339a77d addss    xmm3, xmm4
4339a781 movaps   xmmword ptr [esp + 0x1c0], xmm0
4339a789 movaps   xmmword ptr [esp + 0x1d0], xmm0
4339a791 addss    xmm3, xmm1
4339a795 ucomiss  xmm3, dword ptr [0x4346ee6c]
4339a79c lahf     
4339a79d test     ah, 0x44
4339a7a0 jp       0x4339a7aa
4339a7a2 mov      byte ptr [esp + 0x1e5], 0
4339a7aa lea      eax, [esp + 0x228]
4339a7b1 push     eax
4339a7b2 lea      eax, [esp + 0xe8]
4339a7b9 push     eax
4339a7ba push     0x2004001
4339a7bf lea      eax, [esp + 0x1ac]
4339a7c6 push     eax
4339a7c7 call     edx
4339a7c9 movss    xmm5, dword ptr [0x43470514]
4339a7d1 comiss   xmm5, dword ptr [esp + 0x254]
4339a7d9 mov      eax, dword ptr [esp + 0x1c]
4339a7dd ja       0x4339a908
4339a7e3 cmp      byte ptr [esp + 0x25e], 0
4339a7eb jne      0x4339a908
4339a7f1 cmp      byte ptr [esp + 0x25f], 0
4339a7f9 jne      0x4339a908
4339a7ff mov      ecx, dword ptr [esp + 0x2c]
4339a803 or       eax, ecx
4339a805 cmp      byte ptr [esi + 0x818], 0
4339a80c mov      dword ptr [esp + 0x1c], eax
4339a810 je       0x4339a908
4339a816 test     dword ptr [esi + 0x840], ecx
4339a81c je       0x4339a908
4339a822 mov      eax, dword ptr [esp + 0x20]
4339a826 movss    xmm6, dword ptr [esp + 0x54]
4339a82c movss    xmm7, dword ptr [esp + 0x48]
4339a832 movaps   xmm4, xmm6
4339a835 movss    xmm3, dword ptr [esp + 0x40]
4339a83b movaps   xmm2, xmm7
4339a83e subss    xmm4, dword ptr [eax + 0xdc]
4339a846 subss    xmm2, dword ptr [eax + 0xe0]
4339a84e subss    xmm3, dword ptr [eax + 0xe4]
4339a856 movaps   xmm1, xmm4
4339a859 mulss    xmm1, xmm4
4339a85d movaps   xmm0, xmm2
4339a860 mulss    xmm0, xmm2
4339a864 addss    xmm1, xmm0
4339a868 movaps   xmm0, xmm3
4339a86b mulss    xmm0, xmm3
4339a86f addss    xmm1, xmm0
4339a873 movaps   xmm0, xmm1
4339a876 movaps   xmm1, xmm5
4339a879 sqrtss   xmm0, xmm0
4339a87d movss    dword ptr [esp + 0x10c], xmm0
4339a886 addss    xmm0, dword ptr [0x43472108]
4339a88e divss    xmm1, xmm0
4339a892 movaps   xmm5, xmm1
4339a895 movaps   xmm0, xmm1
4339a898 mulss    xmm5, xmm2
4339a89c mulss    xmm0, xmm4
4339a8a0 mulss    xmm5, dword ptr [esp + 0x70]
4339a8a6 mulss    xmm0, dword ptr [esp + 0x60]
4339a8ac mulss    xmm1, xmm3
4339a8b0 addss    xmm5, xmm0
4339a8b4 mulss    xmm1, dword ptr [esp + 0x50]
4339a8ba addss    xmm5, xmm1
4339a8be comiss   xmm5, dword ptr [esp + 0x28]
4339a8c3 jbe      0x4339a8e0
4339a8c5 movss    dword ptr [edi + 8], xmm6
4339a8ca movss    dword ptr [edi + 0xc], xmm7
4339a8cf movss    xmm0, dword ptr [esp + 0x40]
4339a8d5 movss    dword ptr [edi + 0x10], xmm0
4339a8da movss    dword ptr [esp + 0x28], xmm5
4339a8e0 mov      edx, dword ptr [esp + 0x14]
4339a8e4 mov      ecx, dword ptr [esp + 0x24]
4339a8e8 mov      eax, dword ptr [esp + 0x1c]
4339a8ec add      dword ptr [esp + 0x34], 0x44
4339a8f1 add      ecx, 0x30
4339a8f4 cmp      dword ptr [esp + 0x34], 0x198
4339a8fc mov      dword ptr [esp + 0x24], ecx
4339a900 jle      0x4339a4f2
4339a906 jmp      0x4339a914
4339a908 mov      edx, dword ptr [esp + 0x14]
4339a90c mov      ecx, dword ptr [esp + 0x24]
4339a910 jmp      0x4339a8ec
4339a912 xor      eax, eax
4339a914 mov      ecx, dword ptr [esp + 0x58]
4339a918 mov      dword ptr [ecx + 4], eax
4339a91b test     eax, eax
4339a91d je       0x4339a932
4339a91f mov      eax, dword ptr [0x4346a338]
4339a924 movss    xmm0, dword ptr [ecx]
4339a928 addss    xmm0, dword ptr [eax]
4339a92c movss    dword ptr [ecx], xmm0
4339a930 jmp      0x4339a95c
4339a932 and      dword ptr [ecx], 0
4339a935 and      dword ptr [ecx + 4], 0
4339a939 and      dword ptr [ecx + 8], 0
4339a93d and      dword ptr [ecx + 0xc], 0
4339a941 and      dword ptr [ecx + 0x10], 0
4339a945 cmp      byte ptr [ecx + 0x20], 0
4339a949 je       0x4339a94f
4339a94b mov      byte ptr [ecx + 0x20], 0
4339a94f mov      eax, dword ptr [0x4346a338]
4339a954 mov      ecx, dword ptr [esp + 0x38]
4339a958 mov      eax, dword ptr [eax]
4339a95a mov      dword ptr [ecx], eax
4339a95c mov      edx, dword ptr [esp + 0x44]
4339a960 inc      edx
4339a961 mov      dword ptr [esp + 0x44], edx
4339a965 cmp      edx, dword ptr [esp + 0x18]
4339a969 jle      0x4339a3b1
4339a96f mov      edi, dword ptr [esp + 0x3c]
4339a973 mov      ecx, dword ptr [esp + 0x20]
4339a977 test     byte ptr [ecx], 0x10
4339a97a jne      0x4339c4ee
4339a980 test     byte ptr [edi + 0x835], 1
4339a987 jne      0x4339a996
4339a989 cmp      byte ptr [edi + 0x810], 0
4339a990 je       0x4339acf5
4339a996 mov      esi, dword ptr [ebp + 8]
4339a999 test     esi, esi
4339a99b jne      0x4339a9a9
4339a99d std      
4339a99e dec      esp
4339a99f fimul    word ptr [esi - 0x5c62bf8d]
4339a9a9 mov      eax, dword ptr [0x434682b8]
4339a9ae xorps    xmm1, xmm1
4339a9b1 mov      edx, dword ptr [eax]
4339a9b3 xor      edx, dword ptr [0x43467d90]
4339a9b9 xor      edx, 0x1bae1168
4339a9bf movss    xmm0, dword ptr [edx + esi]
4339a9c4 ucomiss  xmm0, xmm1
4339a9c7 lahf     
4339a9c8 test     ah, 0x44
4339a9cb jp       0x4339a9d4
4339a9cd and      dword ptr [edi + 0x884], 0
4339a9d4 movss    xmm0, dword ptr [edx + esi + 4]
4339a9da ucomiss  xmm0, xmm1
4339a9dd lahf     
4339a9de test     ah, 0x44
4339a9e1 jp       0x4339a9ea
4339a9e3 and      dword ptr [edi + 0x888], 0
4339a9ea lea      esi, [ecx + 0x8c]
4339a9f0 lea      edi, [esp + 0xb8]
4339a9f7 movsd    dword ptr es:[edi], dword ptr [esi]
4339a9f8 lea      ecx, [esp + 0xb8]
4339a9ff movsd    dword ptr es:[edi], dword ptr [esi]
4339aa00 movsd    dword ptr es:[edi], dword ptr [esi]
4339aa01 mov      edi, dword ptr [esp + 0x3c]
4339aa05 lea      esi, [edi + 0x884]
4339aa0b mov      edx, esi
4339aa0d mov      dword ptr [esp + 0x18], esi
4339aa11 call     0x4336b421
4339aa16 mov      eax, dword ptr [ebp + 0xc]
4339aa19 test     byte ptr [eax + 0x30], 1
4339aa1d je       0x4339ac8d
4339aa23 cmp      byte ptr [edi + 0x804], 0
4339aa2a je       0x4339ac8d
4339aa30 mov      edx, dword ptr [ebp + 8]
4339aa33 test     edx, edx
4339aa35 jne      0x4339aa43
4339aa37 fcomp    dword ptr [eax - 0x2d]
4339aa3a mov      ah, 0x2e
4339aa3c mov      byte ptr [0xf18afb1], al
4339aa41 mul      dword ptr [ecx]
4339aa43 mov      eax, dword ptr [0x4346a80c]
4339aa48 mov      eax, dword ptr [eax]
4339aa4a xor      eax, dword ptr [0x43469208]
4339aa50 xor      eax, 0xde530a8b
4339aa55 movss    xmm1, dword ptr [eax + edx]
4339aa5a mov      eax, dword ptr [esp + 0x20]
4339aa5e mov      ecx, dword ptr [eax + 0xc]
4339aa61 test     ecx, ecx
4339aa63 jne      0x4339aa71
4339aa65 inc      edi
4339aa66 pushaw   
4339aa68 in       eax, 0x85
4339aa6a out      dx, eax
4339aa6b or       al, 0xa3
4339aa6d in       al, 0xdd
4339aa6f xchg     edi, eax
4339aa70 loop     0x4339aa13
4339aa71 mov      eax, dword ptr [0x43467a50]
4339aa72 push     eax
4339aa73 jp       0x4339aabb
4339aa75 inc      ebx
4339aa76 mov      eax, dword ptr [eax]
4339aa78 xor      eax, dword ptr [0x4346a458]
4339aa7e xor      eax, 0xf71ce331
4339aa83 movss    xmm0, dword ptr [eax + ecx]
4339aa88 call     0x4332fc35
4339aa8d movaps   xmm1, xmm0
4339aa90 movss    dword ptr [esp + 0x50], xmm1
4339aa96 test     edx, edx
4339aa98 jne      0x4339aaa6
4339aa9a add      eax, 0x3a7b8ccb
4339aa9f ljmp     0xf39e:0x87d5e2d6
4339aaa6 mov      eax, dword ptr [0x43467f74]
4339aaab lea      edi, [esp + 0x110]
4339aab2 mov      esi, dword ptr [eax]
4339aab4 xor      esi, dword ptr [0x43467a64]
4339aaba xor      esi, 0x48442721
4339aabb mul      byte ptr [ecx]
4339aabd daa      
4339aabe inc      esp
4339aabf dec      eax
4339aac0 mov      eax, dword ptr [0x43467eb8]
4339aac5 add      esi, edx
4339aac7 movss    xmm0, dword ptr [eax]
4339aacb movsd    dword ptr es:[edi], dword ptr [esi]
4339aacc movss    dword ptr [esp + 0x28], xmm0
4339aad2 movsd    dword ptr es:[edi], dword ptr [esi]
4339aad3 movsd    dword ptr es:[edi], dword ptr [esi]
4339aad4 mov      esi, dword ptr [esp + 0x18]
4339aad8 lea      edi, [esp + 0x90]
4339aadf movsd    dword ptr es:[edi], dword ptr [esi]
4339aae0 movsd    dword ptr es:[edi], dword ptr [esi]
4339aae1 movsd    dword ptr es:[edi], dword ptr [esi]
4339aae2 xor      esi, esi
4339aae4 inc      esi
4339aae5 comiss   xmm0, xmm1
4339aae8 mov      dword ptr [esp + 0x48], esi
4339aaec jae      0x4339ab22
4339aaee lea      edx, [esp + 0x90]
4339aaf5 lea      ecx, [esp + 0x110]
4339aafc call     0x4336b421
4339ab01 mov      eax, dword ptr [0x4346a338]
4339ab06 inc      esi
4339ab07 movss    xmm0, dword ptr [esp + 0x28]
4339ab0d addss    xmm0, dword ptr [eax]
4339ab11 comiss   xmm0, dword ptr [esp + 0x50]
4339ab16 movss    dword ptr [esp + 0x28], xmm0
4339ab1c jb       0x4339aaee
4339ab1e mov      dword ptr [esp + 0x48], esi
4339ab22 mov      eax, dword ptr [0x4346794c]
4339ab27 xor      eax, 0xc429e1bf
4339ab2c jmp      0x4339ab30
4339ab2e mov      eax, ecx
4339ab30 mov      ecx, dword ptr [eax + 0x1c]
4339ab33 cmp      eax, ecx
4339ab35 jne      0x4339ab2e
4339ab37 movss    xmm0, dword ptr [eax + 0x2c]
4339ab3c mov      edi, dword ptr [esp + 0x3c]
4339ab40 movss    dword ptr [esp + 0x18], xmm0
4339ab46 xor      eax, dword ptr [esp + 0x18]
4339ab4a movss    xmm0, dword ptr [esp + 0x98]
4339ab53 movss    xmm2, dword ptr [edi + 0x82c]
4339ab5b lea      esi, [edi + 0x8a8]
4339ab61 movss    xmm1, dword ptr [edi + 0x830]
4339ab69 mov      ecx, esi
4339ab6b subss    xmm0, dword ptr [edi + 0x8a4]
4339ab73 mov      dword ptr [esp + 0x28], eax
4339ab77 mulss    xmm2, dword ptr [esp + 0x28]
4339ab7d mulss    xmm1, dword ptr [esp + 0x28]
4339ab83 mulss    xmm2, dword ptr [esp + 0x90]
4339ab8c mulss    xmm1, dword ptr [esp + 0x94]
4339ab95 movss    dword ptr [esp + 0x90], xmm2
4339ab9e subss    xmm2, dword ptr [edi + 0x89c]
4339aba6 movss    dword ptr [esp + 0x94], xmm1
4339abaf subss    xmm1, dword ptr [edi + 0x8a0]
4339abb7 movss    dword ptr [esi], xmm2
4339abbb movss    dword ptr [esi + 4], xmm1
4339abc0 movss    dword ptr [esi + 8], xmm0
4339abc5 call     0x433e9160
4339abca mov      eax, dword ptr [esp + 0x48]
4339abce cmp      eax, 1
4339abd1 jle      0x4339ac0d
4339abd3 movss    xmm1, dword ptr [0x43470514]
4339abdb movd     xmm0, eax
4339abdf cvtdq2ps xmm0, xmm0
4339abe2 divss    xmm1, xmm0
4339abe6 movss    xmm0, dword ptr [esi]
4339abea mulss    xmm0, xmm1
4339abee movss    dword ptr [esi], xmm0
4339abf2 movaps   xmm0, xmm1
4339abf5 mulss    xmm0, dword ptr [esi + 4]
4339abfa movss    dword ptr [esi + 4], xmm0
4339abff movss    xmm0, dword ptr [esi + 8]
4339ac04 mulss    xmm0, xmm1
4339ac08 movss    dword ptr [esi + 8], xmm0
4339ac0d push     ecx
4339ac0e push     ecx
4339ac0f mov      dword ptr [esp + 4], 0x3e99999a
4339ac17 mov      dword ptr [esp], 0x3e4ccccd
4339ac1e call     0x63c2ff40
4339ac23 movss    xmm1, dword ptr [esi]
4339ac27 movss    xmm0, dword ptr [esi + 4]
4339ac2c mulss    xmm1, xmm1
4339ac30 pop      ecx
4339ac31 mulss    xmm0, xmm0
4339ac35 pop      ecx
4339ac36 fmul     dword ptr [edi + 0x8d0]
4339ac3c addss    xmm1, xmm0
4339ac40 fstp     dword ptr [esp + 0x18]
4339ac44 movaps   xmm0, xmm1
4339ac47 movss    xmm1, dword ptr [esp + 0x18]
4339ac4d sqrtss   xmm0, xmm0
4339ac51 comiss   xmm0, xmm1
4339ac54 movss    dword ptr [esp + 0x48], xmm0
4339ac5a jbe      0x4339ac87
4339ac5c divss    xmm1, xmm0
4339ac60 movss    xmm0, dword ptr [esi]
4339ac64 mulss    xmm0, xmm1
4339ac68 movss    dword ptr [esi], xmm0
4339ac6c movaps   xmm0, xmm1
4339ac6f mulss    xmm0, dword ptr [esi + 4]
4339ac74 movss    dword ptr [esi + 4], xmm0
4339ac79 movss    xmm0, dword ptr [esi + 8]
4339ac7e mulss    xmm0, xmm1
4339ac82 movss    dword ptr [esi + 8], xmm0
4339ac87 lea      esi, [edi + 0x884]
4339ac8d mov      eax, dword ptr [0x4346794c]
4339ac92 xor      eax, 0xc429e1bf
4339ac97 jmp      0x4339ac9b
4339ac99 mov      eax, ecx
4339ac9b mov      ecx, dword ptr [eax + 0x1c]
4339ac9e cmp      eax, ecx
4339aca0 jne      0x4339ac99
4339aca2 movss    xmm0, dword ptr [eax + 0x2c]
4339aca7 movss    dword ptr [esp + 0x18], xmm0
4339acad xor      eax, dword ptr [esp + 0x18]
4339acb1 movss    xmm0, dword ptr [edi + 0x82c]
4339acb9 mov      ecx, dword ptr [esp + 0x20]
4339acbd mov      dword ptr [esp + 0x28], eax
4339acc1 mulss    xmm0, dword ptr [esp + 0x28]
4339acc7 mulss    xmm0, dword ptr [esi]
4339accb mov      esi, dword ptr [esp + 0x4c]
4339accf movss    dword ptr [edi + 0x890], xmm0
4339acd7 movss    xmm0, dword ptr [edi + 0x830]
4339acdf mulss    xmm0, dword ptr [esp + 0x28]
4339ace5 mulss    xmm0, dword ptr [edi + 0x888]
4339aced movss    dword ptr [edi + 0x894], xmm0
4339acf5 mov      ecx, dword ptr [ecx + 0xc]
4339acf8 mov      dword ptr [esp + 0x18], ecx
4339acfc test     ecx, ecx
4339acfe je       0x4339c4ee
4339ad04 mov      eax, dword ptr [0x4346908c]
4339ad09 mov      eax, dword ptr [eax]
4339ad0b xor      eax, dword ptr [0x43468ba0]
4339ad11 xor      eax, 0x5c9f0fbb
4339ad16 mov      cx, word ptr [eax + ecx]
4339ad1a call     0x433d24bb
4339ad1f test     al, al
4339ad21 je       0x4339c4ee
4339ad27 mov      eax, dword ptr [0x4346a60c]
4339ad2c mov      ecx, dword ptr [esp + 0x18]
4339ad30 mov      eax, dword ptr [eax]
4339ad32 xor      eax, dword ptr [0x434678a8]
4339ad38 xor      eax, 0xca5ec698
4339ad3d cmp      dword ptr [eax + ecx], 0
4339ad41 jle      0x4339c4ee
4339ad47 mov      eax, dword ptr [0x43467430]
4339ad4c mov      eax, dword ptr [eax]
4339ad4e xor      eax, dword ptr [0x4346a718]
4339ad54 xor      eax, 0xb8969256
4339ad59 cmp      byte ptr [eax + ecx], 0
4339ad5d jne      0x4339c4ee
4339ad63 test     byte ptr [edi + 0x835], 1
4339ad6a jne      0x4339ad7c
4339ad6c cmp      byte ptr [edi + 0x810], 0
4339ad73 jne      0x4339ad7c
4339ad75 mov      ecx, esi
4339ad77 call     0x4340c87e
4339ad7c xor      eax, eax
4339ad7e lea      edi, [esp + 0x78]
4339ad82 stosd    dword ptr es:[edi], eax
4339ad83 stosd    dword ptr es:[edi], eax
4339ad84 stosd    dword ptr es:[edi], eax
4339ad85 mov      edi, dword ptr [esp + 0x3c]
4339ad89 cmp      byte ptr [edi + 0x810], 0
4339ad90 je       0x4339be07
4339ad96 imul     eax, dword ptr [edi + 0x7fc], 0x28
4339ad9d lea      ecx, [edi + 0x538]
4339ada3 add      ecx, eax
4339ada5 mov      eax, dword ptr [ecx + 0x14]
4339ada8 mov      eax, dword ptr [eax*4 + 0x434721c4]
4339adaf call     eax
4339adb1 test     al, al
4339adb3 je       0x4339be07
4339adb9 mov      eax, dword ptr [0x4346a334]
4339adbe movss    xmm0, dword ptr [edi + 0x878]
4339adc6 comiss   xmm0, dword ptr [eax]
4339adc9 ja       0x4339be07
4339adcf cmp      byte ptr [esi + 0x828], 0
4339add6 mov      edi, dword ptr [esp + 0x20]
4339adda je       0x4339ae29
4339addc mov      edx, dword ptr [edi + 0xc]
4339addf mov      dword ptr [esp + 0x18], 0x289d6d91
4339ade7 mov      eax, dword ptr [esp + 0x18]
4339adeb mov      ecx, dword ptr [edx]
4339aded sub      ecx, eax
4339adef mov      ecx, dword ptr [ecx + 0x289d7449]
4339adf5 mov      dword ptr [esp + 0x28], ecx
4339adf9 call     0x433e533f
4339adfe test     al, al
4339ae00 je       0x4339ae0b
4339ae02 mov      eax, dword ptr [ebp + 0xc]
4339ae05 test     byte ptr [eax + 0x30], 1
4339ae09 jne      0x4339ae29
4339ae0b mov      eax, dword ptr [0x4346a334]
4339ae10 movss    xmm0, dword ptr [eax]
4339ae14 subss    xmm0, dword ptr [esi + 0x8dc]
4339ae1c comiss   xmm0, dword ptr [esi + 0x824]
4339ae23 ja       0x4339b86e
4339ae29 push     edi
4339ae2a lea      eax, [esp + 0xdc]
4339ae31 mov      ecx, esi
4339ae33 push     eax
4339ae34 call     0x433d5acc
4339ae39 movss    xmm0, dword ptr [esp + 0xdc]
4339ae42 mulss    xmm0, dword ptr [0x43470528]
4339ae4a movss    dword ptr [esp + 0x18], xmm0
4339ae50 call     0x7750c6d0
4339ae55 movss    dword ptr [esp + 0x60], xmm0
4339ae5b movss    xmm0, dword ptr [esp + 0x18]
4339ae61 call     0x7750a770
4339ae66 movss    dword ptr [esp + 0x50], xmm0
4339ae6c movss    xmm0, dword ptr [esp + 0xd8]
4339ae75 mulss    xmm0, dword ptr [0x43470528]
4339ae7d movss    dword ptr [esp + 0x18], xmm0
4339ae83 call     0x7750c6d0
4339ae88 movss    dword ptr [esp + 0x70], xmm0
4339ae8e movss    xmm0, dword ptr [esp + 0x18]
4339ae94 call     0x7750a770
4339ae99 movss    xmm2, dword ptr [esp + 0x50]
4339ae9f xor      edi, edi
4339aea1 movss    xmm1, dword ptr [esp + 0x60]
4339aea7 xor      ecx, ecx
4339aea9 mulss    xmm2, xmm0
4339aead inc      ecx
4339aeae mov      eax, dword ptr [0x43469300]
4339aeb3 mulss    xmm1, xmm0
4339aeb7 and      dword ptr [esp + 0x138], edi
4339aebe movss    xmm0, dword ptr [esp + 0x70]
4339aec4 xorps    xmm0, xmmword ptr [0x434703d0]
4339aecb mulss    xmm2, xmm2
4339aecf mov      eax, dword ptr [eax]
4339aed1 mulss    xmm1, xmm1
4339aed5 mov      dword ptr [esp + 0x34], edi
4339aed9 mulss    xmm0, xmm0
4339aedd mov      dword ptr [esp + 0x9c], eax
4339aee4 mov      dword ptr [esp + 0x14], ecx
4339aee8 addss    xmm2, xmm1
4339aeec movss    xmm1, dword ptr [esi + 0x830]
4339aef4 movss    dword ptr [esp + 0x38], xmm1
4339aefa addss    xmm2, xmm0
4339aefe movaps   xmm0, xmm2
4339af01 xorps    xmm2, xmm2
4339af04 sqrtss   xmm0, xmm0
4339af08 movss    dword ptr [esp + 0x24], xmm2
4339af0e movss    dword ptr [esp + 0x54], xmm0
4339af14 xorps    xmm0, xmm0
4339af17 movss    dword ptr [esp + 0x130], xmm2
4339af20 movss    dword ptr [esp + 0x1c], xmm0
4339af26 movss    dword ptr [esp + 0x134], xmm0
4339af2f movups   xmmword ptr [esp + 0x140], xmm0
4339af37 cmp      eax, ecx
4339af39 jl       0x4339b319
4339af3f mov      edx, ecx
4339af41 mov      ecx, dword ptr [0x4346a890]
4339af47 push     edx
4339af48 mov      eax, dword ptr [ecx]
4339af4a mov      eax, dword ptr [eax + 0xc]
4339af4d call     eax
4339af4f mov      ecx, dword ptr [esp + 0x14]
4339af53 mov      edx, eax
4339af55 movss    xmm0, dword ptr [esi + 0x82c]
4339af5d and      ecx, 0x3f
4339af60 add      ecx, 0x3a
4339af63 imul     ecx, ecx, 0x28
4339af66 add      ecx, esi
4339af68 comiss   xmm0, dword ptr [ecx]
4339af6b ja       0x4339b303
4339af71 mov      eax, dword ptr [ecx + 4]
4339af74 test     dword ptr [esi + 0x840], eax
4339af7a je       0x4339b303
4339af80 lea      esi, [ecx + 8]
4339af83 lea      edi, [esp + 0xa0]
4339af8a movsd    dword ptr es:[edi], dword ptr [esi]
4339af8b lea      eax, [esp + 0xa0]
4339af92 push     eax
4339af93 push     edx
4339af94 movsd    dword ptr es:[edi], dword ptr [esi]
4339af95 movsd    dword ptr es:[edi], dword ptr [esi]
4339af96 mov      esi, dword ptr [esp + 0x54]
4339af9a mov      ecx, esi
4339af9c movss    xmm0, dword ptr [esp + 0xa8]
4339afa5 addss    xmm0, dword ptr [esi + 0x8e0]
4339afad movss    dword ptr [esp + 0xa8], xmm0
4339afb6 movss    xmm0, dword ptr [esi + 0x8e4]
4339afbe addss    xmm0, dword ptr [esp + 0xac]
4339afc7 movss    dword ptr [esp + 0xac], xmm0
4339afd0 movss    xmm0, dword ptr [esi + 0x8e8]
4339afd8 addss    xmm0, dword ptr [esp + 0xb0]
4339afe1 movss    dword ptr [esp + 0xb0], xmm0
4339afea call     0x4340b419
4339afef mov      edi, dword ptr [esp + 0x20]
4339aff3 movss    xmm2, dword ptr [esp + 0xa0]
4339affc movss    xmm3, dword ptr [esp + 0xa4]
4339b005 movss    xmm4, dword ptr [esp + 0xa8]
4339b00e subss    xmm2, dword ptr [edi + 0xdc]
4339b016 subss    xmm3, dword ptr [edi + 0xe0]
4339b01e subss    xmm4, dword ptr [edi + 0xe4]
4339b026 movss    xmm6, dword ptr [0x43470514]
4339b02e movaps   xmm1, xmm2
4339b031 mulss    xmm1, xmm2
4339b035 movaps   xmm0, xmm3
4339b038 mulss    xmm0, xmm3
4339b03c addss    xmm1, xmm0
4339b040 movaps   xmm0, xmm4
4339b043 mulss    xmm0, xmm4
4339b047 addss    xmm1, xmm0
4339b04b movaps   xmm7, xmm1
4339b04e sqrtss   xmm7, xmm7
4339b052 movaps   xmm0, xmm7
4339b055 movss    dword ptr [esp + 0x58], xmm7
4339b05b addss    xmm0, dword ptr [0x43472108]
4339b063 movups   xmmword ptr [esp + 0x180], xmm7
4339b06b divss    xmm6, xmm0
4339b06f xorps    xmm0, xmm0
4339b072 ucomiss  xmm7, xmm0
4339b075 movaps   xmm1, xmm6
4339b078 movaps   xmm5, xmm6
4339b07b mulss    xmm1, xmm2
4339b07f mulss    xmm5, xmm3
4339b083 mulss    xmm6, xmm4
4339b087 lahf     
4339b088 movss    dword ptr [esp + 0x18], xmm1
4339b08e movss    dword ptr [esp + 0x50], xmm5
4339b094 movss    dword ptr [esp + 0x60], xmm6
4339b09a test     ah, 0x44
4339b09d jnp      0x4339b2ff
4339b0a3 movss    xmm2, dword ptr [0x434720f8]
4339b0ab divss    xmm2, xmm7
4339b0af ucomiss  xmm5, xmm0
4339b0b2 mulss    xmm2, dword ptr [esi + 0x830]
4339b0ba lahf     
4339b0bb movss    dword ptr [esp + 0x70], xmm2
4339b0c1 test     ah, 0x44
4339b0c4 jp       0x4339b0ee
4339b0c6 ucomiss  xmm1, xmm0
4339b0c9 lahf     
4339b0ca test     ah, 0x44
4339b0cd jp       0x4339b0ee
4339b0cf comiss   xmm6, xmm0
4339b0d2 jbe      0x4339b0de
4339b0d4 movss    xmm1, dword ptr [0x43470960]
4339b0dc jmp      0x4339b0e6
4339b0de movss    xmm1, dword ptr [0x4346fdc0]
4339b0e6 movss    dword ptr [esp + 0x44], xmm0
4339b0ec jmp      0x4339b15f
4339b0ee cvtps2pd xmm1, xmm1
4339b0f1 cvtps2pd xmm0, xmm5
4339b0f4 call     0x77509ee0
4339b0f9 movss    xmm1, dword ptr [esp + 0x18]
4339b0ff cvtsd2ss xmm0, xmm0
4339b103 mulss    xmm1, xmm1
4339b107 mulss    xmm0, dword ptr [0x4346dd48]
4339b10f movss    dword ptr [esp + 0x44], xmm0
4339b115 movss    xmm0, dword ptr [esp + 0x50]
4339b11b mulss    xmm0, xmm0
4339b11f addss    xmm1, xmm0
4339b123 movaps   xmm0, xmm1
4339b126 xorps    xmm1, xmm1
4339b129 sqrtss   xmm0, xmm0
4339b12d movss    dword ptr [esp + 0x164], xmm0
4339b136 cvtss2sd xmm1, xmm0
4339b13a movss    xmm0, dword ptr [esp + 0x60]
4339b140 xorps    xmm0, xmmword ptr [0x434703d0]
4339b147 cvtss2sd xmm0, xmm0
4339b14b call     0x77509ee0
4339b150 xorps    xmm1, xmm1
4339b153 cvtsd2ss xmm1, xmm0
4339b157 mulss    xmm1, dword ptr [0x4346dd48]
4339b15f movss    dword ptr [esp + 0x40], xmm1
4339b165 subss    xmm1, dword ptr [esp + 0xd8]
4339b16e ucomiss  xmm1, xmm1
4339b171 movss    dword ptr [esp + 0x2c], xmm1
4339b177 lahf     
4339b178 test     ah, 0x44
4339b17b jnp      0x4339b182
4339b17d xorps    xmm1, xmm1
4339b180 jmp      0x4339b1cf
4339b182 movss    xmm2, dword ptr [0x43470340]
4339b18a movaps   xmm0, xmm1
4339b18d andps    xmm0, xmm2
4339b190 comiss   xmm0, dword ptr [0x434725e4]
4339b197 jbe      0x4339b1d5
4339b199 movaps   xmm0, xmm1
4339b19c divss    xmm0, dword ptr [0x43471f88]
4339b1a4 andps    xmm0, xmm2
4339b1a7 call     0x4341ad12
4339b1ac movss    xmm1, dword ptr [esp + 0x2c]
4339b1b2 movaps   xmm2, xmm0
4339b1b5 mulss    xmm2, dword ptr [0x43471f88]
4339b1bd xorps    xmm0, xmm0
4339b1c0 comiss   xmm0, xmm1
4339b1c3 jbe      0x4339b1cb
4339b1c5 addss    xmm1, xmm2
4339b1c9 jmp      0x4339b1cf
4339b1cb subss    xmm1, xmm2
4339b1cf movss    dword ptr [esp + 0x2c], xmm1
4339b1d5 movss    xmm5, dword ptr [esp + 0x44]
4339b1db movaps   xmm2, xmm5
4339b1de subss    xmm2, dword ptr [esp + 0xdc]
4339b1e7 ucomiss  xmm2, xmm2
4339b1ea movss    dword ptr [esp + 0x18], xmm2
4339b1f0 lahf     
4339b1f1 test     ah, 0x44
4339b1f4 jnp      0x4339b1fb
4339b1f6 xorps    xmm2, xmm2
4339b1f9 jmp      0x4339b254
4339b1fb movss    xmm3, dword ptr [0x43470340]
4339b203 movaps   xmm0, xmm2
4339b206 andps    xmm0, xmm3
4339b209 comiss   xmm0, dword ptr [0x434725e4]
4339b210 jbe      0x4339b254
4339b212 movaps   xmm0, xmm2
4339b215 divss    xmm0, dword ptr [0x43471f88]
4339b21d andps    xmm0, xmm3
4339b220 call     0x4341ad12
4339b225 movss    xmm2, dword ptr [esp + 0x18]
4339b22b movaps   xmm1, xmm0
4339b22e mulss    xmm1, dword ptr [0x43471f88]
4339b236 xorps    xmm0, xmm0
4339b239 comiss   xmm0, xmm2
4339b23c movss    xmm5, dword ptr [esp + 0x44]
4339b242 jbe      0x4339b24a
4339b244 addss    xmm2, xmm1
4339b248 jmp      0x4339b24e
4339b24a subss    xmm2, xmm1
4339b24e movss    xmm1, dword ptr [esp + 0x2c]
4339b254 movss    xmm4, dword ptr [0x43470340]
4339b25c movaps   xmm0, xmm1
4339b25f movss    xmm3, dword ptr [esp + 0x70]
4339b265 andps    xmm0, xmm4
4339b268 comiss   xmm3, xmm0
4339b26b jb       0x4339b2ff
4339b271 mov      edx, dword ptr [esp + 0x14]
4339b275 movaps   xmm0, xmm2
4339b278 andps    xmm0, xmm4
4339b27b comiss   xmm3, xmm0
4339b27e jb       0x4339b2f9
4339b280 mulss    xmm1, xmm1
4339b284 xorps    xmm0, xmm0
4339b287 mulss    xmm2, xmm2
4339b28b addss    xmm1, xmm2
4339b28f movss    xmm0, xmm1
4339b293 movss    xmm1, dword ptr [esp + 0x38]
4339b299 sqrtss   xmm0, xmm0
4339b29d comiss   xmm1, xmm0
4339b2a0 movss    dword ptr [esp + 0x168], xmm0
4339b2a9 jbe      0x4339b2f9
4339b2ab movss    xmm2, dword ptr [esp + 0x40]
4339b2b1 mov      edi, edx
4339b2b3 and      dword ptr [esp + 0x138], 0
4339b2bb movss    dword ptr [esp + 0x38], xmm0
4339b2c1 movaps   xmm0, xmm5
4339b2c4 movss    dword ptr [esp + 0x1c], xmm0
4339b2ca movss    dword ptr [esp + 0x134], xmm0
4339b2d3 movss    xmm0, dword ptr [esp + 0x180]
4339b2dc mov      dword ptr [esp + 0x34], edi
4339b2e0 movss    dword ptr [esp + 0x24], xmm2
4339b2e6 movss    dword ptr [esp + 0x130], xmm2
4339b2ef movups   xmmword ptr [esp + 0x140], xmm0
4339b2f7 jmp      0x4339b307
4339b2f9 mov      edi, dword ptr [esp + 0x34]
4339b2fd jmp      0x4339b307
4339b2ff mov      edi, dword ptr [esp + 0x34]
4339b303 mov      edx, dword ptr [esp + 0x14]
4339b307 inc      edx
4339b308 mov      dword ptr [esp + 0x14], edx
4339b30c cmp      edx, dword ptr [esp + 0x9c]
4339b313 jle      0x4339af41
4339b319 mov      edx, dword ptr [esi + 0x884]
4339b31f test     edx, edx
4339b321 je       0x4339b6b7
4339b327 mov      ecx, dword ptr [0x4346a890]
4339b32d push     edx
4339b32e mov      eax, dword ptr [ecx]
4339b330 mov      eax, dword ptr [eax + 0xc]
4339b333 call     eax
4339b335 mov      ecx, dword ptr [esi + 0x884]
4339b33b mov      edx, eax
4339b33d and      ecx, 0x3f
4339b340 mov      dword ptr [esp + 0x50], edx
4339b344 add      ecx, 0x3a
4339b347 imul     eax, ecx, 0x28
4339b34a mov      ecx, edx
4339b34c add      eax, esi
4339b34e mov      dword ptr [esp + 0x18], eax
4339b352 call     0x43358962
4339b357 test     al, al
4339b359 je       0x4339b8ac
4339b35f mov      ecx, dword ptr [esp + 0x18]
4339b363 movss    xmm0, dword ptr [esi + 0x82c]
4339b36b comiss   xmm0, dword ptr [ecx]
4339b36e ja       0x4339b8ac
4339b374 mov      eax, dword ptr [ecx + 4]
4339b377 test     dword ptr [esi + 0x840], eax
4339b37d je       0x4339b8ac
4339b383 test     edi, edi
4339b385 je       0x4339b395
4339b387 mov      edx, dword ptr [esi + 0x884]
4339b38d cmp      edi, edx
4339b38f je       0x4339b6b7
4339b395 lea      esi, [ecx + 8]
4339b398 lea      edi, [esp + 0xac]
4339b39f movsd    dword ptr es:[edi], dword ptr [esi]
4339b3a0 lea      eax, [esp + 0xac]
4339b3a7 push     eax
4339b3a8 push     dword ptr [esp + 0x54]
4339b3ac movsd    dword ptr es:[edi], dword ptr [esi]
4339b3ad movsd    dword ptr es:[edi], dword ptr [esi]
4339b3ae mov      esi, dword ptr [esp + 0x54]
4339b3b2 mov      ecx, esi
4339b3b4 movss    xmm0, dword ptr [esi + 0x8e0]
4339b3bc addss    xmm0, dword ptr [esp + 0xb4]
4339b3c5 movss    dword ptr [esp + 0xb4], xmm0
4339b3ce movss    xmm0, dword ptr [esi + 0x8e4]
4339b3d6 addss    xmm0, dword ptr [esp + 0xb8]
4339b3df movss    dword ptr [esp + 0xb8], xmm0
4339b3e8 movss    xmm0, dword ptr [esi + 0x8e8]
4339b3f0 addss    xmm0, dword ptr [esp + 0xbc]
4339b3f9 movss    dword ptr [esp + 0xbc], xmm0
4339b402 call     0x4340b419
4339b407 mov      eax, dword ptr [esp + 0x20]
4339b40b movss    xmm2, dword ptr [esp + 0xac]
4339b414 movss    xmm3, dword ptr [esp + 0xb0]
4339b41d movss    xmm4, dword ptr [esp + 0xb4]
4339b426 subss    xmm2, dword ptr [eax + 0xdc]
4339b42e subss    xmm3, dword ptr [eax + 0xe0]
4339b436 subss    xmm4, dword ptr [eax + 0xe4]
4339b43e movaps   xmm1, xmm2
4339b441 mulss    xmm1, xmm2
4339b445 movaps   xmm0, xmm3
4339b448 mulss    xmm0, xmm3
4339b44c addss    xmm1, xmm0
4339b450 movaps   xmm0, xmm4
4339b453 mulss    xmm0, xmm4
4339b457 addss    xmm1, xmm0
4339b45b movaps   xmm0, xmm1
4339b45e movss    xmm1, dword ptr [0x43470514]
4339b466 sqrtss   xmm0, xmm0
4339b46a movups   xmmword ptr [esp + 0x140], xmm0
4339b472 movss    dword ptr [esp + 0x154], xmm0
4339b47b addss    xmm0, dword ptr [0x43472108]
4339b483 divss    xmm1, xmm0
4339b487 xorps    xmm0, xmm0
4339b48a mulss    xmm3, xmm1
4339b48e mulss    xmm2, xmm1
4339b492 ucomiss  xmm3, xmm0
4339b495 mulss    xmm4, xmm1
4339b499 lahf     
4339b49a movss    dword ptr [esp + 0x18], xmm2
4339b4a0 movss    dword ptr [esp + 0x50], xmm3
4339b4a6 movss    dword ptr [esp + 0x60], xmm4
4339b4ac test     ah, 0x44
4339b4af jp       0x4339b4d9
4339b4b1 ucomiss  xmm2, xmm0
4339b4b4 lahf     
4339b4b5 test     ah, 0x44
4339b4b8 jp       0x4339b4d9
4339b4ba comiss   xmm4, xmm0
4339b4bd jbe      0x4339b4c9
4339b4bf movss    xmm1, dword ptr [0x43470960]
4339b4c7 jmp      0x4339b4d1
4339b4c9 movss    xmm1, dword ptr [0x4346fdc0]
4339b4d1 movss    dword ptr [esp + 0x1c], xmm0
4339b4d7 jmp      0x4339b54a
4339b4d9 cvtps2pd xmm1, xmm2
4339b4dc cvtps2pd xmm0, xmm3
4339b4df call     0x77509ee0
4339b4e4 movss    xmm1, dword ptr [esp + 0x18]
4339b4ea cvtsd2ss xmm0, xmm0
4339b4ee mulss    xmm1, xmm1
4339b4f2 mulss    xmm0, dword ptr [0x4346dd48]
4339b4fa movss    dword ptr [esp + 0x1c], xmm0
4339b500 movss    xmm0, dword ptr [esp + 0x50]
4339b506 mulss    xmm0, xmm0
4339b50a addss    xmm1, xmm0
4339b50e movaps   xmm0, xmm1
4339b511 xorps    xmm1, xmm1
4339b514 sqrtss   xmm0, xmm0
4339b518 movss    dword ptr [esp + 0x158], xmm0
4339b521 cvtss2sd xmm1, xmm0
4339b525 movss    xmm0, dword ptr [esp + 0x60]
4339b52b xorps    xmm0, xmmword ptr [0x434703d0]
4339b532 cvtss2sd xmm0, xmm0
4339b536 call     0x77509ee0
4339b53b xorps    xmm1, xmm1
4339b53e cvtsd2ss xmm1, xmm0
4339b542 mulss    xmm1, dword ptr [0x4346dd48]
4339b54a movaps   xmm2, xmm1
4339b54d movss    dword ptr [esp + 0x24], xmm1
4339b553 subss    xmm2, dword ptr [esp + 0xd8]
4339b55c ucomiss  xmm2, xmm2
4339b55f movss    dword ptr [esp + 0x2c], xmm2
4339b565 lahf     
4339b566 test     ah, 0x44
4339b569 jnp      0x4339b570
4339b56b xorps    xmm2, xmm2
4339b56e jmp      0x4339b5bd
4339b570 movss    xmm1, dword ptr [0x43470340]
4339b578 movaps   xmm0, xmm2
4339b57b andps    xmm0, xmm1
4339b57e comiss   xmm0, dword ptr [0x434725e4]
4339b585 jbe      0x4339b5c3
4339b587 movaps   xmm0, xmm2
4339b58a divss    xmm0, dword ptr [0x43471f88]
4339b592 andps    xmm0, xmm1
4339b595 call     0x4341ad12
4339b59a movss    xmm2, dword ptr [esp + 0x2c]
4339b5a0 movaps   xmm1, xmm0
4339b5a3 mulss    xmm1, dword ptr [0x43471f88]
4339b5ab xorps    xmm0, xmm0
4339b5ae comiss   xmm0, xmm2
4339b5b1 jbe      0x4339b5b9
4339b5b3 addss    xmm2, xmm1
4339b5b7 jmp      0x4339b5bd
4339b5b9 subss    xmm2, xmm1
4339b5bd movss    dword ptr [esp + 0x2c], xmm2
4339b5c3 movss    xmm1, dword ptr [esp + 0x1c]
4339b5c9 movaps   xmm3, xmm1
4339b5cc subss    xmm3, dword ptr [esp + 0xdc]
4339b5d5 ucomiss  xmm3, xmm3
4339b5d8 movss    dword ptr [esp + 0x18], xmm3
4339b5de lahf     
4339b5df test     ah, 0x44
4339b5e2 jnp      0x4339b5e9
4339b5e4 xorps    xmm3, xmm3
4339b5e7 jmp      0x4339b642
4339b5e9 movss    xmm4, dword ptr [0x43470340]
4339b5f1 movaps   xmm0, xmm3
4339b5f4 andps    xmm0, xmm4
4339b5f7 comiss   xmm0, dword ptr [0x434725e4]
4339b5fe jbe      0x4339b642
4339b600 movaps   xmm0, xmm3
4339b603 divss    xmm0, dword ptr [0x43471f88]
4339b60b andps    xmm0, xmm4
4339b60e call     0x4341ad12
4339b613 movss    xmm3, dword ptr [esp + 0x18]
4339b619 movaps   xmm1, xmm0
4339b61c mulss    xmm1, dword ptr [0x43471f88]
4339b624 xorps    xmm0, xmm0
4339b627 comiss   xmm0, xmm3
4339b62a movss    xmm2, dword ptr [esp + 0x2c]
4339b630 jbe      0x4339b638
4339b632 addss    xmm3, xmm1
4339b636 jmp      0x4339b63c
4339b638 subss    xmm3, xmm1
4339b63c movss    xmm1, dword ptr [esp + 0x1c]
4339b642 mulss    xmm3, xmm3
4339b646 mulss    xmm2, xmm2
4339b64a addss    xmm2, xmm3
4339b64e xorps    xmm3, xmm3
4339b651 movss    xmm3, xmm2
4339b655 sqrtss   xmm3, xmm3
4339b659 comiss   xmm3, dword ptr [esi + 0x830]
4339b660 movss    dword ptr [esp + 0x15c], xmm3
4339b669 jae      0x4339b86e
4339b66f movaps   xmm0, xmm3
4339b672 subss    xmm0, dword ptr [esp + 0x38]
4339b678 comiss   xmm0, dword ptr [0x4347259c]
4339b67f ja       0x4339b86e
4339b685 mov      edi, dword ptr [esi + 0x884]
4339b68b mov      edx, edi
4339b68d movss    xmm2, dword ptr [esp + 0x24]
4339b693 and      dword ptr [esp + 0x138], 0
4339b69b mov      dword ptr [esp + 0x34], edi
4339b69f movss    dword ptr [esp + 0x38], xmm3
4339b6a5 movss    dword ptr [esp + 0x130], xmm2
4339b6ae movss    dword ptr [esp + 0x134], xmm1
4339b6b7 cmp      edi, 1
4339b6ba jl       0x4339b86e
4339b6c0 mov      eax, dword ptr [esp + 0x34]
4339b6c4 lea      esi, [esp + 0x130]
4339b6cb lea      edi, [esp + 0x284]
4339b6d2 movsd    dword ptr es:[edi], dword ptr [esi]
4339b6d3 movsd    dword ptr es:[edi], dword ptr [esi]
4339b6d4 movsd    dword ptr es:[edi], dword ptr [esi]
4339b6d5 mov      esi, dword ptr [esp + 0x4c]
4339b6d9 cmp      edx, eax
4339b6db je       0x4339b78d
4339b6e1 mov      dword ptr [esi + 0x884], eax
4339b6e7 cmp      eax, dword ptr [esi + 0x888]
4339b6ed je       0x4339b74d
4339b6ef push     ecx
4339b6f0 push     ecx
4339b6f1 mov      dword ptr [esp + 4], 0x40000000
4339b6f9 mov      dword ptr [esp], 0xc0000000
4339b700 call     0x63c2ff40
4339b705 fstp     dword ptr [esi + 0x8e0]
4339b70b mov      dword ptr [esp + 4], 0x40000000
4339b713 mov      dword ptr [esp], 0xc0000000
4339b71a call     0x63c2ff40
4339b71f fstp     dword ptr [esi + 0x8e4]
4339b725 mov      dword ptr [esp + 4], 0x3f800000
4339b72d mov      dword ptr [esp], 0xbf800000
4339b734 call     0x63c2ff40
4339b739 mov      eax, dword ptr [esi + 0x884]
4339b73f pop      ecx
4339b740 fstp     dword ptr [esi + 0x8e8]
4339b746 pop      ecx
4339b747 mov      dword ptr [esi + 0x888], eax
4339b74d mov      eax, dword ptr [0x4346a338]
4339b752 movss    xmm0, dword ptr [0x43470514]
4339b75a divss    xmm0, dword ptr [eax]
4339b75e mov      eax, dword ptr [esi + 0x808]
4339b764 cdq      
4339b765 cvttss2si ecx, xmm0
4339b769 idiv     ecx
4339b76b push     eax
4339b76c call     0x63c2ff20
4339b771 mov      dword ptr [esp], 0x3fc00000
4339b778 push     ecx
4339b779 mov      dword ptr [esp], 0xbfc00000
4339b780 call     0x63c2ff40
4339b785 pop      ecx
4339b786 fstp     dword ptr [esi + 0x8ec]
4339b78c pop      ecx
4339b78d test     byte ptr [esi + 0x83c], 4
4339b794 jne      0x4339b7cd
4339b796 mov      ecx, dword ptr [ebp + 8]
4339b799 test     ecx, ecx
4339b79b jne      0x4339b7a9
4339b79d sal      dword ptr [ebx + ebx*2], cl
4339b79f pop      ebx
4339b7a0 mov      edx, 0x576186d9
4339b7a5 jmp      0x4339b79f
4339b7a9 mov      eax, dword ptr [0x43467434]
4339b7ae mov      eax, dword ptr [eax]
4339b7b0 xor      eax, dword ptr [0x43467fa8]
4339b7b6 xor      eax, 0x1bc6d160
4339b7bb movss    xmm0, dword ptr [eax + ecx]
4339b7c0 comiss   xmm0, dword ptr [0x434723f8]
4339b7c7 ja       0x4339b86e
4339b7cd mov      ecx, dword ptr [esi + 0x804]
4339b7d3 lea      eax, [ecx + 0x22]
4339b7d6 imul     eax, eax, 0x28
4339b7d9 mov      eax, dword ptr [eax + esi]
4339b7dc and      eax, 0xfffffffc
4339b7df cmp      eax, 4
4339b7e2 jne      0x4339b7f5
4339b7e4 imul     eax, ecx, 0x28
4339b7e7 cmp      dword ptr [eax + esi + 0x554], 0
4339b7ef jne      0x4339b8bf
4339b7f5 mov      edi, dword ptr [esp + 0x20]
4339b7f9 mov      edx, dword ptr [edi + 0xc]
4339b7fc mov      dword ptr [esp + 0x18], 0x289d6d91
4339b804 mov      eax, dword ptr [esp + 0x18]
4339b808 mov      ecx, dword ptr [edx]
4339b80a sub      ecx, eax
4339b80c mov      ecx, dword ptr [ecx + 0x289d7449]
4339b812 mov      dword ptr [esp + 0x64], ecx
4339b816 call     0x433e533f
4339b81b test     al, al
4339b81d mov      eax, dword ptr [ebp + 0xc]
4339b820 jne      0x4339b8c2
4339b826 test     byte ptr [eax + 0x30], 1
4339b82a je       0x4339b8c2
4339b830 mov      edx, dword ptr [edi + 0xc]
4339b833 mov      dword ptr [esp + 0x18], 0xe3852753
4339b83b mov      eax, dword ptr [esp + 0x18]
4339b83f add      eax, 0x1c7af3bd
4339b844 mov      ecx, dword ptr [edx]
4339b846 ror      eax, 2
4339b849 push     0
4339b84b mov      ecx, dword ptr [eax + ecx]
4339b84e call     0x433e533f
4339b853 mov      eax, dword ptr [0x4346a334]
4339b858 fstp     dword ptr [esp + 0x18]
4339b85c movss    xmm0, dword ptr [eax]
4339b860 addss    xmm0, dword ptr [esp + 0x18]
4339b866 movss    dword ptr [esi + 0x880], xmm0
4339b86e and      dword ptr [esp + 0x80], 0
4339b876 xorps    xmm0, xmm0
4339b879 xorps    xmm1, xmm1
4339b87c movss    dword ptr [esp + 0x14], xmm0
4339b882 mov      ecx, esi
4339b884 movss    dword ptr [esp + 0x38], xmm1
4339b88a movss    dword ptr [esp + 0x78], xmm1
4339b890 movss    dword ptr [esp + 0x7c], xmm0
4339b896 call     0x433b2251
4339b89b movss    xmm1, dword ptr [esp + 0x38]
4339b8a1 movss    xmm2, dword ptr [esp + 0x14]
4339b8a7 jmp      0x4339be1f
4339b8ac mov      eax, dword ptr [0x4346a334]
4339b8b1 movss    xmm0, dword ptr [eax]
4339b8b5 addss    xmm0, dword ptr [0x43470228]
4339b8bd jmp      0x4339b866
4339b8bf mov      eax, dword ptr [ebp + 0xc]
4339b8c2 mov      esi, dword ptr [esp + 0x74]
4339b8c6 lea      edi, [esp + 0x84]
4339b8cd push     eax
4339b8ce movsd    dword ptr es:[edi], dword ptr [esi]
4339b8cf movsd    dword ptr es:[edi], dword ptr [esi]
4339b8d0 movsd    dword ptr es:[edi], dword ptr [esi]
4339b8d1 mov      edi, dword ptr [esp + 0x24]
4339b8d5 mov      esi, dword ptr [esp + 0x50]
4339b8d9 mov      ecx, esi
4339b8db push     edi
4339b8dc call     0x433c6416
4339b8e1 test     al, al
4339b8e3 je       0x4339b8f7
4339b8e5 movss    xmm0, dword ptr [esi + 0x8a4]
4339b8ed movss    xmm1, dword ptr [esi + 0x8a8]
4339b8f5 jmp      0x4339b907
4339b8f7 movss    xmm0, dword ptr [esi + 0x898]
4339b8ff movss    xmm1, dword ptr [esi + 0x89c]
4339b907 addss    xmm0, dword ptr [esp + 0x84]
4339b910 movss    xmm6, dword ptr [esp + 0x24]
4339b916 addss    xmm1, dword ptr [esp + 0x88]
4339b91f subss    xmm6, xmm0
4339b923 movss    dword ptr [esp + 0x28], xmm1
4339b929 ucomiss  xmm6, xmm6
4339b92c movss    dword ptr [esp + 0x24], xmm6
4339b932 lahf     
4339b933 test     ah, 0x44
4339b936 jnp      0x4339b96d
4339b938 xorps    xmm6, xmm6
4339b93b movss    dword ptr [esp + 0x24], xmm6
4339b941 xorps    xmm5, xmm5
4339b944 movss    xmm4, dword ptr [esp + 0x1c]
4339b94a subss    xmm4, dword ptr [esp + 0x28]
4339b950 movss    dword ptr [esp + 0x64], xmm6
4339b956 ucomiss  xmm4, xmm4
4339b959 movss    dword ptr [esp + 0x1c], xmm4
4339b95f lahf     
4339b960 test     ah, 0x44
4339b963 jnp      0x4339b9bf
4339b965 xorps    xmm4, xmm4
4339b968 jmp      0x4339ba0f
4339b96d movss    xmm1, dword ptr [0x43470340]
4339b975 movaps   xmm0, xmm6
4339b978 andps    xmm0, xmm1
4339b97b comiss   xmm0, dword ptr [0x434725e4]
4339b982 jbe      0x4339b941
4339b984 movaps   xmm0, xmm6
4339b987 divss    xmm0, dword ptr [0x43471f88]
4339b98f andps    xmm0, xmm1
4339b992 call     0x4341ad12
4339b997 movss    xmm6, dword ptr [esp + 0x24]
4339b99d xorps    xmm5, xmm5
4339b9a0 comiss   xmm5, xmm6
4339b9a3 mulss    xmm0, dword ptr [0x43471f88]
4339b9ab jbe      0x4339b9b9
4339b9ad addss    xmm6, xmm0
4339b9b1 movss    dword ptr [esp + 0x24], xmm6
4339b9b7 jmp      0x4339b944
4339b9b9 subss    xmm6, xmm0
4339b9bd jmp      0x4339b9b1
4339b9bf movss    xmm1, dword ptr [0x43470340]
4339b9c7 movaps   xmm0, xmm4
4339b9ca andps    xmm0, xmm1
4339b9cd comiss   xmm0, dword ptr [0x434725e4]
4339b9d4 jbe      0x4339ba15
4339b9d6 movaps   xmm0, xmm4
4339b9d9 divss    xmm0, dword ptr [0x43471f88]
4339b9e1 andps    xmm0, xmm1
4339b9e4 call     0x4341ad12
4339b9e9 movss    xmm4, dword ptr [esp + 0x1c]
4339b9ef xorps    xmm5, xmm5
4339b9f2 comiss   xmm5, xmm4
4339b9f5 mulss    xmm0, dword ptr [0x43471f88]
4339b9fd movss    xmm6, dword ptr [esp + 0x24]
4339ba03 jbe      0x4339ba0b
4339ba05 addss    xmm4, xmm0
4339ba09 jmp      0x4339ba0f
4339ba0b subss    xmm4, xmm0
4339ba0f movss    dword ptr [esp + 0x1c], xmm4
4339ba15 mov      edx, dword ptr [ebp + 0xc]
4339ba18 and      dword ptr [esp + 0x6c], 0
4339ba1d movss    dword ptr [esp + 0x68], xmm4
4339ba23 test     byte ptr [edx + 0x30], 1
4339ba27 jne      0x4339bb12
4339ba2d movss    xmm1, dword ptr [esi + 0x8c0]
4339ba35 movss    xmm0, dword ptr [esi + 0x8c4]
4339ba3d mulss    xmm1, xmm1
4339ba41 mulss    xmm0, xmm0
4339ba45 addss    xmm1, xmm0
4339ba49 movaps   xmm7, xmm1
4339ba4c sqrtss   xmm7, xmm7
4339ba50 comiss   xmm7, dword ptr [0x4346f908]
4339ba57 jb       0x4339bb12
4339ba5d movaps   xmm3, xmm4
4339ba60 movaps   xmm1, xmm6
4339ba63 xorps    xmm3, xmmword ptr [0x434703d0]
4339ba6a mulss    xmm1, xmm6
4339ba6e movaps   xmm0, xmm3
4339ba71 mulss    xmm0, xmm3
4339ba75 addss    xmm1, xmm0
4339ba79 xorps    xmm0, xmm0
4339ba7c movss    xmm0, xmm1
4339ba80 movss    xmm1, dword ptr [0x43470514]
4339ba88 sqrtss   xmm0, xmm0
4339ba8c addss    xmm0, dword ptr [0x43472108]
4339ba94 divss    xmm1, xmm0
4339ba98 movss    xmm0, dword ptr [0x4346dc28]
4339baa0 movaps   xmm2, xmm1
4339baa3 mulss    xmm1, xmm3
4339baa7 mulss    xmm2, xmm6
4339baab mulss    xmm1, dword ptr [esi + 0x8c4]
4339bab3 mulss    xmm2, dword ptr [esi + 0x8c0]
4339babb subss    xmm2, xmm1
4339babf divss    xmm2, xmm7
4339bac3 comiss   xmm0, xmm2
4339bac6 jbe      0x4339bb12
4339bac8 mov      al, byte ptr [esi + 0x83d]
4339bace test     al, 2
4339bad0 je       0x4339baf0
4339bad2 test     al, 4
4339bad4 je       0x4339b86e
4339bada mov      eax, dword ptr [0x4346a334]
4339badf movss    xmm0, dword ptr [eax]
4339bae3 addss    xmm0, dword ptr [0x43472980]
4339baeb jmp      0x4339b866
4339baf0 xorps    xmm0, xmm0
4339baf3 movss    xmm1, dword ptr [esp + 0x38]
4339baf9 movss    xmm0, xmm7
4339bafd sqrtss   xmm0, xmm0
4339bb01 mulss    xmm0, dword ptr [0x434724a8]
4339bb09 comiss   xmm1, xmm0
4339bb0c ja       0x4339b86e
4339bb12 movaps   xmm2, xmm4
4339bb15 mulss    xmm2, dword ptr [0x4346f37c]
4339bb1d mulss    xmm2, dword ptr [esi + 0x8ec]
4339bb25 addss    xmm2, xmm6
4339bb29 ucomiss  xmm2, xmm2
4339bb2c movss    dword ptr [esp + 0x14], xmm2
4339bb32 lahf     
4339bb33 test     ah, 0x44
4339bb36 jnp      0x4339bb3d
4339bb38 xorps    xmm2, xmm2
4339bb3b jmp      0x4339bb90
4339bb3d movss    xmm1, dword ptr [0x43470340]
4339bb45 movaps   xmm0, xmm2
4339bb48 andps    xmm0, xmm1
4339bb4b comiss   xmm0, dword ptr [0x434725e4]
4339bb52 jbe      0x4339bb96
4339bb54 movaps   xmm0, xmm2
4339bb57 divss    xmm0, dword ptr [0x43471f88]
4339bb5f andps    xmm0, xmm1
4339bb62 call     0x4341ad12
4339bb67 movss    xmm2, dword ptr [esp + 0x14]
4339bb6d xorps    xmm5, xmm5
4339bb70 comiss   xmm5, xmm2
4339bb73 mov      edx, dword ptr [ebp + 0xc]
4339bb76 mulss    xmm0, dword ptr [0x43471f88]
4339bb7e movss    xmm4, dword ptr [esp + 0x1c]
4339bb84 jbe      0x4339bb8c
4339bb86 addss    xmm2, xmm0
4339bb8a jmp      0x4339bb90
4339bb8c subss    xmm2, xmm0
4339bb90 movss    dword ptr [esp + 0x14], xmm2
4339bb96 movss    xmm3, dword ptr [esi + 0x81c]
4339bb9e ucomiss  xmm3, xmm5
4339bba1 movss    dword ptr [esp + 0x64], xmm2
4339bba7 lahf     
4339bba8 test     ah, 0x44
4339bbab jp       0x4339bbcd
4339bbad xorps    xmm0, xmm0
4339bbb0 movss    dword ptr [esp + 0x14], xmm0
4339bbb6 movss    dword ptr [esp + 0x64], xmm0
4339bbbc movss    dword ptr [esp + 0x1c], xmm0
4339bbc2 movss    dword ptr [esp + 0x68], xmm0
4339bbc8 jmp      0x4339bd66
4339bbcd movaps   xmm0, xmm4
4339bbd0 movaps   xmm1, xmm2
4339bbd3 mulss    xmm0, xmm4
4339bbd7 xorps    xmm6, xmm6
4339bbda mulss    xmm1, xmm2
4339bbde addss    xmm1, xmm0
4339bbe2 movss    xmm0, dword ptr [0x434725e8]
4339bbea movss    xmm6, xmm1
4339bbee sqrtss   xmm6, xmm6
4339bbf2 comiss   xmm0, xmm6
4339bbf5 movups   xmmword ptr [esp + 0x180], xmm6
4339bbfd ja       0x4339bbad
4339bbff movss    xmm7, dword ptr [esi + 0x820]
4339bc07 movss    xmm1, dword ptr [0x43470514]
4339bc0f comiss   xmm1, xmm7
4339bc12 movss    dword ptr [esp + 0x2c], xmm3
4339bc18 jbe      0x4339bc52
4339bc1a movss    xmm0, dword ptr [esp + 0x38]
4339bc20 divss    xmm0, dword ptr [esi + 0x830]
4339bc28 mulss    xmm7, xmm7
4339bc2c subss    xmm1, xmm0
4339bc30 movss    xmm0, dword ptr [0x43470514]
4339bc38 subss    xmm0, xmm7
4339bc3c mulss    xmm1, xmm3
4339bc40 subss    xmm1, xmm3
4339bc44 mulss    xmm1, xmm0
4339bc48 addss    xmm3, xmm1
4339bc4c movss    dword ptr [esp + 0x2c], xmm3
4339bc52 movups   xmm0, xmmword ptr [esp + 0x140]
4339bc5a movss    xmm1, dword ptr [0x4347064c]
4339bc62 comiss   xmm0, xmm1
4339bc65 jbe      0x4339bcb9
4339bc67 movss    xmm7, dword ptr [0x43470514]
4339bc6f subss    xmm0, xmm1
4339bc73 xorps    xmm1, xmm1
4339bc76 mulss    xmm0, dword ptr [0x43470000]
4339bc7e movss    xmm1, xmm0
4339bc82 movss    dword ptr [esp + 0x10c], xmm0
4339bc8b movss    xmm0, dword ptr [0x43472240]
4339bc93 maxss    xmm1, xmm0
4339bc97 movaps   xmm0, xmm7
4339bc9a minss    xmm1, xmm0
4339bc9e movss    xmm0, dword ptr [0x434703bc]
4339bca6 subss    xmm0, xmm1
4339bcaa comiss   xmm7, xmm0
4339bcad jbe      0x4339bcb9
4339bcaf mulss    xmm3, xmm0
4339bcb3 movss    dword ptr [esp + 0x2c], xmm3
4339bcb9 comiss   xmm3, xmm5
4339bcbc jbe      0x4339bd1d
4339bcbe movss    xmm1, dword ptr [0x43472980]
4339bcc6 movaps   xmm0, xmm3
4339bcc9 call     0x43367633
4339bcce push     dword ptr [edx + 4]
4339bcd1 movss    dword ptr [esp + 0x78], xmm0
4339bcd7 call     0x63c2ff20
4339bcdc movss    xmm0, dword ptr [esp + 0x78]
4339bce2 movss    dword ptr [esp], xmm0
4339bce7 xorps    xmm0, xmmword ptr [0x434703d0]
4339bcee push     ecx
4339bcef movss    dword ptr [esp], xmm0
4339bcf4 call     0x63c2ff40
4339bcf9 fadd     dword ptr [esp + 0x34]
4339bcfd pop      ecx
4339bcfe pop      ecx
4339bcff movss    xmm2, dword ptr [esp + 0x14]
4339bd05 movss    xmm4, dword ptr [esp + 0x1c]
4339bd0b movups   xmm6, xmmword ptr [esp + 0x180]
4339bd13 fstp     dword ptr [esp + 0x2c]
4339bd17 movss    xmm3, dword ptr [esp + 0x2c]
4339bd1d movss    xmm1, dword ptr [esi + 0x8d8]
4339bd25 movss    xmm0, dword ptr [0x434725e8]
4339bd2d mulss    xmm1, xmm3
4339bd31 comiss   xmm0, xmm1
4339bd34 ja       0x4339bbad
4339bd3a comiss   xmm6, xmm1
4339bd3d jbe      0x4339bd66
4339bd3f divss    xmm1, xmm6
4339bd43 movaps   xmm0, xmm1
4339bd46 mulss    xmm4, xmm1
4339bd4a mulss    xmm2, xmm0
4339bd4e movss    dword ptr [esp + 0x1c], xmm4
4339bd54 movss    dword ptr [esp + 0x68], xmm4
4339bd5a movss    dword ptr [esp + 0x14], xmm2
4339bd60 movss    dword ptr [esp + 0x64], xmm2
4339bd66 push     dword ptr [ebp + 0xc]
4339bd69 lea      eax, [esi + 0x8a4]
4339bd6f mov      ecx, esi
4339bd71 push     edi
4339bd72 mov      dword ptr [esp + 0x7c], eax
4339bd76 call     0x433c6416
4339bd7b test     al, al
4339bd7d je       0x4339bddb
4339bd7f movss    xmm1, dword ptr [esi + 0x8b0]
4339bd87 lea      eax, [esi + 0x8a4]
4339bd8d movss    xmm0, dword ptr [esp + 0x14]
4339bd93 movss    xmm2, dword ptr [esp + 0x1c]
4339bd99 subss    xmm0, xmm1
4339bd9d addss    xmm1, dword ptr [eax]
4339bda1 movss    dword ptr [esp + 0x64], xmm0
4339bda7 movss    xmm0, dword ptr [esi + 0x8b4]
4339bdaf subss    xmm2, xmm0
4339bdb3 movss    dword ptr [eax], xmm1
4339bdb7 addss    xmm0, dword ptr [eax + 4]
4339bdbc movss    dword ptr [esp + 0x68], xmm2
4339bdc2 movss    dword ptr [eax + 4], xmm0
4339bdc7 movss    xmm0, dword ptr [esi + 0x8b8]
4339bdcf addss    xmm0, dword ptr [eax + 8]
4339bdd4 movss    dword ptr [eax + 8], xmm0
4339bdd9 jmp      0x4339bde8
4339bddb mov      edi, dword ptr [esp + 0x74]
4339bddf add      esi, 0x898
4339bde5 movsd    dword ptr es:[edi], dword ptr [esi]
4339bde6 movsd    dword ptr es:[edi], dword ptr [esi]
4339bde7 movsd    dword ptr es:[edi], dword ptr [esi]
4339bde8 lea      esi, [esp + 0x64]
4339bdec lea      edi, [esp + 0x78]
4339bdf0 movsd    dword ptr es:[edi], dword ptr [esi]
4339bdf1 movsd    dword ptr es:[edi], dword ptr [esi]
4339bdf2 movsd    dword ptr es:[edi], dword ptr [esi]
4339bdf3 mov      esi, dword ptr [esp + 0x4c]
4339bdf7 test     byte ptr [esi + 0x83c], 1
4339bdfe je       0x4339be07
4339be00 or       dword ptr [0x434759c0], 8
4339be07 movss    xmm1, dword ptr [esp + 0x78]
4339be0d movss    xmm2, dword ptr [esp + 0x7c]
4339be13 movss    dword ptr [esp + 0x38], xmm1
4339be19 movss    dword ptr [esp + 0x14], xmm2
4339be1f mov      eax, dword ptr [esp + 0x3c]
4339be23 xorps    xmm0, xmm0
4339be26 test     byte ptr [eax + 0x835], 1
4339be2d je       0x4339bee9
4339be33 cmp      dword ptr [eax + 0x87c], 0
4339be3a jne      0x4339bee9
4339be40 ucomiss  xmm1, xmm0
4339be43 lahf     
4339be44 test     ah, 0x44
4339be47 jp       0x4339bf0b
4339be4d ucomiss  xmm2, xmm0
4339be50 lahf     
4339be51 test     ah, 0x44
4339be54 jp       0x4339bee9
4339be5a push     dword ptr [ebp + 0xc]
4339be5d mov      ecx, esi
4339be5f push     dword ptr [esp + 0x24]
4339be63 call     0x433c6416
4339be68 test     al, al
4339be6a je       0x4339bedf
4339be6c movss    xmm1, dword ptr [esi + 0x8b0]
4339be74 movss    xmm0, dword ptr [esp + 0x38]
4339be7a movss    xmm2, dword ptr [esp + 0x14]
4339be80 subss    xmm0, xmm1
4339be84 addss    xmm1, dword ptr [esi + 0x8a4]
4339be8c movss    dword ptr [esp + 0x38], xmm0
4339be92 movss    dword ptr [esp + 0x78], xmm0
4339be98 movss    xmm0, dword ptr [esi + 0x8b4]
4339bea0 subss    xmm2, xmm0
4339bea4 movss    dword ptr [esi + 0x8a4], xmm1
4339beac addss    xmm0, dword ptr [esi + 0x8a8]
4339beb4 movss    dword ptr [esp + 0x7c], xmm2
4339beba movss    dword ptr [esi + 0x8a8], xmm0
4339bec2 movss    xmm0, dword ptr [esi + 0x8b8]
4339beca addss    xmm0, dword ptr [esi + 0x8ac]
4339bed2 movss    dword ptr [esi + 0x8ac], xmm0
4339beda xorps    xmm0, xmm0
4339bedd jmp      0x4339beef
4339bedf mov      ecx, esi
4339bee1 call     0x4340c87e
4339bee6 xorps    xmm0, xmm0
4339bee9 movss    xmm2, dword ptr [esp + 0x14]
4339beef movss    xmm1, dword ptr [esp + 0x38]
4339bef5 ucomiss  xmm1, xmm0
4339bef8 lahf     
4339bef9 test     ah, 0x44
4339befc jp       0x4339bf0b
4339befe ucomiss  xmm2, xmm0
4339bf01 lahf     
4339bf02 test     ah, 0x44
4339bf05 jnp      0x4339bfb9
4339bf0b lea      ecx, [esp + 0x78]
4339bf0f call     0x43328ae6
4339bf14 movss    xmm1, dword ptr [esp + 0x78]
4339bf1a movss    xmm0, dword ptr [esp + 0x7c]
4339bf20 mulss    xmm1, xmm1
4339bf24 mulss    xmm0, xmm0
4339bf28 addss    xmm1, xmm0
4339bf2c movaps   xmm0, xmm1
4339bf2f movss    xmm1, dword ptr [0x4347259c]
4339bf37 sqrtss   xmm0, xmm0
4339bf3b comiss   xmm1, xmm0
4339bf3e jbe      0x4339bfb9
4339bf40 mov      edi, dword ptr [esp + 0x108]
4339bf47 lea      esi, [esp + 0x78]
4339bf4b mov      eax, dword ptr [esp + 0x3c]
4339bf4f mov      edx, dword ptr [ebp + 8]
4339bf52 push     0
4339bf54 push     dword ptr [ebp + 0xc]
4339bf57 movsd    dword ptr es:[edi], dword ptr [esi]
4339bf58 lea      ecx, [eax + 8]
4339bf5b mov      dword ptr [eax + 0x868], 0x3f800000
4339bf65 mov      eax, dword ptr [ecx]
4339bf67 movsd    dword ptr es:[edi], dword ptr [esi]
4339bf68 movsd    dword ptr es:[edi], dword ptr [esi]
4339bf69 mov      esi, dword ptr [esp + 0x28]
4339bf6d movss    xmm0, dword ptr [esi + 0x1b4]
4339bf75 call     dword ptr [eax]
4339bf77 mov      ecx, dword ptr [esp + 0x5c]
4339bf7b call     0x433b8974
4339bf80 movss    xmm0, dword ptr [esi + 0x20]
4339bf85 lea      edi, [esi + 0x118]
4339bf8b ucomiss  xmm0, dword ptr [edi]
4339bf8e lahf     
4339bf8f test     ah, 0x44
4339bf92 jp       0x4339bfb9
4339bf94 movss    xmm0, dword ptr [esi + 0x24]
4339bf99 ucomiss  xmm0, dword ptr [edi + 4]
4339bf9d lahf     
4339bf9e test     ah, 0x44
4339bfa1 jp       0x4339bfb9
4339bfa3 movss    xmm0, dword ptr [esi + 0x28]
4339bfa8 ucomiss  xmm0, dword ptr [edi + 8]
4339bfac lahf     
4339bfad test     ah, 0x44
4339bfb0 jp       0x4339bfb9
4339bfb2 mov      esi, dword ptr [esp + 0x5c]
4339bfb6 movsd    dword ptr es:[edi], dword ptr [esi]
4339bfb7 movsd    dword ptr es:[edi], dword ptr [esi]
4339bfb8 movsd    dword ptr es:[edi], dword ptr [esi]
4339bfb9 mov      edi, dword ptr [esp + 0x3c]
4339bfbd mov      edx, dword ptr [ebp + 0xc]
4339bfc0 test     byte ptr [edi + 0x834], 0x20
4339bfc7 je       0x4339c48d
4339bfcd test     byte ptr [edx + 0x30], 1
4339bfd1 jne      0x4339c48d
4339bfd7 mov      esi, dword ptr [esp + 0x4c]
4339bfdb imul     eax, dword ptr [esi + 0x804], 0x28
4339bfe2 lea      ecx, [esi + 0x6a8]
4339bfe8 add      ecx, eax
4339bfea mov      eax, dword ptr [ecx + 0x14]
4339bfed mov      eax, dword ptr [eax*4 + 0x434721c4]
4339bff4 call     eax
4339bff6 mov      edx, dword ptr [ebp + 0xc]
4339bff9 test     al, al
4339bffb je       0x4339c48d
4339c001 mov      eax, dword ptr [0x43467eb8]
4339c006 movss    xmm0, dword ptr [esi + 0x8bc]
4339c00e comiss   xmm0, dword ptr [eax]
4339c011 jbe      0x4339c017
4339c013 or       dword ptr [edx + 0x30], 1
4339c017 mov      eax, dword ptr [esp + 0x20]
4339c01b test     dword ptr [eax], 0x400
4339c021 jne      0x4339c030
4339c023 cmp      dword ptr [eax + 0xd8], 0x40
4339c02a jne      0x4339c491
4339c030 test     byte ptr [esi + 0x83c], 8
4339c037 jne      0x4339c074
4339c039 mov      ecx, dword ptr [ebp + 8]
4339c03c test     ecx, ecx
4339c03e jne      0x4339c04c
4339c040 xchg     esp, eax
4339c041 dec      edi
4339c042 int3     
4339c04c mov      eax, dword ptr [0x43467434]
4339c051 mov      eax, dword ptr [eax]
4339c053 xor      eax, dword ptr [0x43467fa8]
4339c059 xor      eax, 0x1bc6d160
4339c05e movss    xmm0, dword ptr [eax + ecx]
4339c063 comiss   xmm0, dword ptr [0x434723f8]
4339c06a mov      eax, dword ptr [esp + 0x20]
4339c06e ja       0x4339c494
4339c074 cmp      dword ptr [esi + 0x85c], 0
4339c07b mov      edi, dword ptr [edx + 8]
4339c07e mov      dword ptr [esp + 0x58], edi
4339c082 mov      edi, dword ptr [esp + 0x3c]
4339c086 mov      byte ptr [esp + 0x33], 0
4339c08b je       0x4339c0ac
4339c08d lea      ecx, [esp + 0x33]
4339c091 push     ecx
4339c092 mov      ecx, dword ptr [ebp + 8]
4339c095 push     edx
4339c096 push     ecx
4339c097 push     eax
4339c098 mov      ecx, esi
4339c09a call     0x4332fd2b
4339c09f mov      cl, byte ptr [esp + 0x33]
4339c0a3 mov      dword ptr [esp + 0x58], eax
4339c0a7 jmp      0x4339c408
4339c0ac mov      eax, dword ptr [esi + 0x848]
4339c0b2 lea      edi, [esp + 0x11c]
4339c0b9 shl      eax, 7
4339c0bc push     0x64
4339c0be pop      ecx
4339c0bf cdq      
4339c0c0 idiv     ecx
4339c0c2 mov      esi, dword ptr [esp + 0x5c]
4339c0c6 lea      edx, [esp + 0x11c]
4339c0cd xor      ecx, ecx
4339c0cf inc      ecx
4339c0d0 cmp      eax, ecx
4339c0d2 movsd    dword ptr es:[edi], dword ptr [esi]
4339c0d3 cmovg    ecx, eax
4339c0d6 and      dword ptr [esp + 0x44], 0
4339c0db mov      dword ptr [esp + 0x40], ecx
4339c0df mov      ecx, dword ptr [ebp + 8]
4339c0e2 movsd    dword ptr es:[edi], dword ptr [esi]
4339c0e3 movsd    dword ptr es:[edi], dword ptr [esi]
4339c0e4 call     0x433d1edc
4339c0e9 mov      esi, dword ptr [esp + 0x4c]
4339c0ed lea      ecx, [esp + 0x290]
4339c0f4 mov      edi, dword ptr [esp + 0x20]
4339c0f8 mov      al, byte ptr [esi + 0x83c]
4339c0fe shr      al, 7
4339c101 movzx    eax, al
4339c104 push     eax
4339c105 push     dword ptr [edi + 0xc]
4339c108 call     0x433eb28b
4339c10d lea      eax, [esp + 0xb8]
4339c114 push     eax
4339c115 lea      eax, [esp + 0x114]
4339c11c push     eax
4339c11d lea      edx, [esp + 0xd4]
4339c124 lea      ecx, [esp + 0x124]
4339c12b call     0x43366128
4339c130 xor      eax, eax
4339c132 mov      dword ptr [esp + 0xe4], 0x4346dcec
4339c13d lea      ecx, [esp + 0x290]
4339c144 mov      dword ptr [esp + 0xe8], eax
4339c14b push     ecx
4339c14c lea      ecx, [esp + 0xe8]
4339c153 mov      dword ptr [esp + 0xf0], eax
4339c15a push     ecx
4339c15b lea      ecx, [esp + 0xd4]
4339c162 mov      dword ptr [esp + 0xf8], eax
4339c169 mov      dword ptr [esp + 0xfc], eax
4339c170 lea      edx, [edi + 0xdc]
4339c176 mov      dword ptr [esp + 0x100], eax
4339c17d mov      eax, 0x4600400b
4339c182 push     ecx
4339c183 mov      ecx, dword ptr [ebp + 8]
4339c186 mov      dword ptr [esp + 0x108], eax
4339c18d mov      dword ptr [esp + 0x10c], eax
4339c194 mov      dword ptr [esp + 0x110], 0x3f800000
4339c19f call     0x43364cec
4339c1a4 test     eax, eax
4339c1a6 je       0x4339c402
4339c1ac test     byte ptr [esi + 0x83c], 0x10
4339c1b3 jne      0x4339c1f1
4339c1b5 movss    xmm3, dword ptr [esp + 0x2c8]
4339c1be lea      eax, [edi + 0xdc]
4339c1c4 movss    xmm0, dword ptr [eax]
4339c1c8 movss    xmm1, dword ptr [eax + 4]
4339c1cd movss    xmm2, dword ptr [eax + 8]
4339c1d2 movss    xmm4, dword ptr [esp + 0x2cc]
4339c1db movss    xmm5, dword ptr [esp + 0x2d0]
4339c1e4 call     0x433e7c6b
4339c1e9 test     al, al
4339c1eb jne      0x4339c402
4339c1f1 cmp      dword ptr [esi + 0x848], 0
4339c1f8 jne      0x4339c201
4339c1fa mov      cl, 1
4339c1fc jmp      0x4339c404
4339c201 cmp      dword ptr [edi + 0xd8], 0x40
4339c208 jne      0x4339c234
4339c20a test     byte ptr [edi + 0x7c], 6
4339c20e movss    xmm3, dword ptr [0x4346f99c]
4339c216 movss    dword ptr [esp + 0x48], xmm3
4339c21c je       0x4339c228
4339c21e movss    xmm0, dword ptr [0x4346f044]
4339c226 jmp      0x4339c230
4339c228 movss    xmm0, dword ptr [0x4346fa5c]
4339c230 xor      edx, edx
4339c232 jmp      0x4339c250
4339c234 movss    xmm3, dword ptr [edi + 0xd0]
4339c23c movss    xmm0, dword ptr [edi + 0xc4]
4339c244 mov      edx, dword ptr [edi + 0xb0]
4339c24a movss    dword ptr [esp + 0x48], xmm3
4339c250 xor      ecx, ecx
4339c252 mov      dword ptr [esp + 0x54], edx
4339c256 movss    dword ptr [esp + 0x5c], xmm0
4339c25c mov      dword ptr [esp + 0x28], ecx
4339c260 movzx    eax, byte ptr [ecx + 0x4346fc50]
4339c267 movaps   xmm1, xmm0
4339c26a movss    xmm2, dword ptr [edi + 0x100]
4339c272 movaps   xmm0, xmm3
4339c275 push     1
4339c277 push     ecx
4339c278 mov      ecx, dword ptr [edi + 0xd8]
4339c27e push     eax
4339c27f call     0x433adb4f
4339c284 movss    dword ptr [esp + 0x64], xmm0
4339c28a lea      eax, [esp + 0x290]
4339c291 movss    xmm5, dword ptr [esp + 0x64]
4339c297 lea      edx, [edi + 0xdc]
4339c29d movq     xmm0, qword ptr [esp + 0xcc]
4339c2a6 movaps   xmm4, xmm5
4339c2a9 mulss    xmm4, dword ptr [esp + 0x110]
4339c2b2 movaps   xmm3, xmm5
4339c2b5 mov      ecx, dword ptr [ebp + 8]
4339c2b8 mulss    xmm3, dword ptr [esp + 0x114]
4339c2c1 push     eax
4339c2c2 mulss    xmm5, dword ptr [esp + 0x11c]
4339c2cb lea      eax, [esp + 0xe8]
4339c2d2 push     eax
4339c2d3 movq     qword ptr [esp + 0x98], xmm0
4339c2dc movaps   xmm0, xmm1
4339c2df mulss    xmm0, dword ptr [esp + 0xc0]
4339c2e8 lea      eax, [esp + 0x98]
4339c2ef push     eax
4339c2f0 addss    xmm4, dword ptr [esp + 0x9c]
4339c2f9 addss    xmm3, dword ptr [esp + 0xa0]
4339c302 addss    xmm5, dword ptr [esp + 0xe0]
4339c30b movss    dword ptr [esp + 0x74], xmm1
4339c311 addss    xmm4, xmm0
4339c315 movaps   xmm0, xmm1
4339c318 mulss    xmm0, dword ptr [esp + 0xc8]
4339c321 mulss    xmm1, dword ptr [esp + 0xcc]
4339c32a addss    xmm3, xmm0
4339c32e addss    xmm5, xmm1
4339c332 movaps   xmm1, xmm4
4339c335 mulss    xmm1, xmm4
4339c339 movaps   xmm0, xmm3
4339c33c mulss    xmm0, xmm3
4339c340 addss    xmm1, xmm0
4339c344 movaps   xmm0, xmm5
4339c347 mulss    xmm0, xmm5
4339c34b addss    xmm1, xmm0
4339c34f movaps   xmm0, xmm1
4339c352 movss    xmm1, dword ptr [0x43470514]
4339c35a sqrtss   xmm0, xmm0
4339c35e addss    xmm0, dword ptr [0x43472108]
4339c366 divss    xmm1, xmm0
4339c36a mulss    xmm4, xmm1
4339c36e mulss    xmm3, xmm1
4339c372 mulss    xmm5, xmm1
4339c376 movss    dword ptr [esp + 0x9c], xmm4
4339c37f movss    dword ptr [esp + 0xa0], xmm3
4339c388 movss    dword ptr [esp + 0xa4], xmm5
4339c391 call     0x43364cec
4339c396 test     eax, eax
4339c398 je       0x4339c3c2
4339c39a lea      eax, [esp + 0x290]
4339c3a1 mov      ecx, esi
4339c3a3 push     eax
4339c3a4 call     0x4331fbdb
4339c3a9 mov      edx, dword ptr [esp + 0x44]
4339c3ad test     al, al
4339c3af je       0x4339c3c6
4339c3b1 inc      edx
4339c3b2 mov      dword ptr [esp + 0x44], edx
4339c3b6 cmp      edx, dword ptr [esp + 0x40]
4339c3ba jge      0x4339c1fa
4339c3c0 jmp      0x4339c3c6
4339c3c2 mov      edx, dword ptr [esp + 0x44]
4339c3c6 mov      ecx, dword ptr [esp + 0x28]
4339c3ca mov      eax, edx
4339c3cc sub      eax, ecx
4339c3ce sub      eax, -0x80
4339c3d1 cmp      eax, dword ptr [esp + 0x40]
4339c3d5 jl       0x4339c402
4339c3d7 inc      ecx
4339c3d8 mov      dword ptr [esp + 0x28], ecx
4339c3dc cmp      ecx, 0x80
4339c3e2 jge      0x4339c3f9
4339c3e4 movss    xmm0, dword ptr [esp + 0x5c]
4339c3ea movss    xmm3, dword ptr [esp + 0x48]
4339c3f0 mov      edx, dword ptr [esp + 0x54]
4339c3f4 jmp      0x4339c260
4339c3f9 cmp      edx, dword ptr [esp + 0x40]
4339c3fd setge    cl
4339c400 jmp      0x4339c404
4339c402 xor      cl, cl
4339c404 mov      edi, dword ptr [esp + 0x3c]
4339c408 mov      eax, dword ptr [esp + 0x20]
4339c40c test     dword ptr [eax], 0x400
4339c412 je       0x4339c436
4339c414 mov      edx, dword ptr [ebp + 0xc]
4339c417 test     cl, cl
4339c419 jne      0x4339c421
4339c41b test     byte ptr [edx + 0x30], 1
4339c41f je       0x4339c491
4339c421 cmp      dword ptr [esp + 0x58], -1
4339c426 mov      edi, dword ptr [esp + 0x3c]
4339c42a je       0x4339c436
4339c42c mov      esi, dword ptr [esp + 0x58]
4339c430 mov      dword ptr [edx + 8], esi
4339c433 lea      esi, [edi - 8]
4339c436 mov      edx, dword ptr [ebp + 0xc]
4339c439 test     cl, cl
4339c43b je       0x4339c491
4339c43d or       dword ptr [edx + 0x30], 1
4339c441 test     byte ptr [esi + 0x83c], 0x40
4339c448 je       0x4339c465
4339c44a mov      eax, dword ptr [0x43467eb8]
4339c44f movss    xmm0, dword ptr [esi + 0x850]
4339c457 addss    xmm0, dword ptr [eax]
4339c45b movss    dword ptr [esi + 0x8bc], xmm0
4339c463 jmp      0x4339c48d
4339c465 push     ecx
4339c466 push     ecx
4339c467 mov      dword ptr [esp + 4], 0x3dcccccd
4339c46f mov      dword ptr [esp], 0x3d000000
4339c476 call     0x63c2ff40
4339c47b mov      eax, dword ptr [0x43467eb8]
4339c480 mov      edx, dword ptr [ebp + 0xc]
4339c483 pop      ecx
4339c484 pop      ecx
4339c485 fadd     dword ptr [eax]
4339c487 fstp     dword ptr [esi + 0x8bc]
4339c48d mov      eax, dword ptr [esp + 0x20]
4339c491 mov      ecx, dword ptr [ebp + 8]
4339c494 cmp      dword ptr [edi + 0x854], 0
4339c49b je       0x4339c4ee
4339c49d test     dword ptr [eax], 0x100000
4339c4a3 jne      0x4339c4d3
4339c4a5 test     dword ptr [eax], 0x400
4339c4ab je       0x4339c4b3
4339c4ad test     byte ptr [edx + 0x30], 1
4339c4b1 jne      0x4339c4d3
4339c4b3 test     byte ptr [eax], 2
4339c4b6 je       0x4339c4ee
4339c4b8 test     dword ptr [edx + 0x30], 0x800
4339c4bf je       0x4339c4ee
4339c4c1 cmp      dword ptr [eax + 0xd8], 0x40
4339c4c8 je       0x4339c4d3
4339c4ca cmp      byte ptr [eax + 0x124], 0
4339c4d1 jne      0x4339c4ee
4339c4d3 push     0
4339c4d5 push     edx
4339c4d6 push     ecx
4339c4d7 mov      ecx, dword ptr [esp + 0x58]
4339c4db push     eax
4339c4dc call     0x4332fd2b
4339c4e1 mov      ecx, eax
4339c4e3 cmp      ecx, -1
4339c4e6 je       0x4339c4ee
4339c4e8 mov      eax, dword ptr [ebp + 0xc]
4339c4eb mov      dword ptr [eax + 8], ecx
4339c4ee pop      edi
4339c4ef pop      esi
4339c4f0 mov      esp, ebp
4339c4f2 pop      ebp
4339c4f3 ret      8
