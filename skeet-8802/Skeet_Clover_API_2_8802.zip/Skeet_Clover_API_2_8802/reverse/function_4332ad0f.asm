4332ad0f cmp      byte ptr [ecx + 0x14], 0
4332ad13 je       0x4332ad35
4332ad15 mov      eax, dword ptr [esp + 4]
4332ad19 cmp      dword ptr [eax + 4], 0x201
4332ad20 jne      0x4332ad35
4332ad22 mov      eax, dword ptr [ecx]
4332ad24 push     dword ptr [esp + 8]
4332ad28 mov      eax, dword ptr [eax + 4]
4332ad2b call     eax
4332ad2d test     al, al
4332ad2f je       0x4332ad35
4332ad31 mov      al, 1
4332ad33 jmp      0x4332ad37
4332ad35 xor      al, al
4332ad37 ret      8
