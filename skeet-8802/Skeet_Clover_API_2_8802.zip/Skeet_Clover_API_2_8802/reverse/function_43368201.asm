43368201 push     ebp
43368202 mov      ebp, esp
43368204 and      esp, 0xfffffff8
43368207 sub      esp, 0x134
4336820d push     ebx
4336820e mov      ebx, ecx
43368210 push     esi
43368211 push     edi
43368212 mov      dword ptr [esp + 0x3c], ebx
43368216 mov      ecx, dword ptr [ebx + 0xf8]
4336821c test     ecx, ecx
4336821e je       0x43368429
43368224 mov      edi, dword ptr [ebp + 0xc]
43368227 xor      eax, eax
43368229 mov      dword ptr [esp + 0x10], eax
4336822d cmp      edi, -1
43368230 jne      0x4336823f
43368232 mov      edi, dword ptr [ecx + 0x5c]
43368235 test     edi, edi
43368237 jne      0x4336823d
43368239 mov      edi, eax
4336823b jmp      0x4336823f
4336823d mov      edi, dword ptr [edi]
4336823f mov      ecx, dword ptr [0x43476424]
43368245 test     ecx, ecx
43368247 jne      0x43368264
43368249 mov      eax, dword ptr [0x43468b9c]
4336824e test     eax, eax
43368250 je       0x4336825c
43368252 call     eax
43368254 mov      ecx, eax
43368256 mov      dword ptr [0x43476424], ecx
4336825c test     ecx, ecx
4336825e je       0x43368429
43368264 mov      eax, dword ptr [ecx]
43368266 call     dword ptr [eax]
43368268 mov      dword ptr [esp + 0x30], eax
4336826c test     eax, eax
4336826e je       0x43368429
43368274 xor      eax, eax
43368276 lea      ecx, [ebx + 0x138]
4336827c mov      esi, eax
4336827e mov      dword ptr [esp + 0x20], eax
43368282 mov      dword ptr [esp + 0x28], eax
43368286 mov      byte ptr [esp + 0x18], al
4336828a lea      eax, [ebp + 8]
4336828d push     eax
4336828e lea      eax, [esp + 0x38]
43368292 mov      dword ptr [esp + 0x28], esi
43368296 push     eax
43368297 call     0x4338a4c7
4336829c mov      ecx, dword ptr [ebx + 0x140]
433682a2 mov      eax, dword ptr [ebx + 0x13c]
433682a8 mov      edx, dword ptr [esp + 0x34]
433682ac cmp      edx, dword ptr [eax + ecx*4]
433682af je       0x433683b9
433682b5 mov      ecx, dword ptr [edx + 8]
433682b8 mov      eax, dword ptr [edx + 4]
433682bb mov      dword ptr [esp + 0x34], ecx
433682bf mov      dword ptr [esp + 0x1c], eax
433682c3 cmp      eax, ecx
433682c5 je       0x433683b9
433682cb mov      eax, dword ptr [esp + 0x18]
433682cf xor      ebx, ebx
433682d1 mov      ecx, dword ptr [esp + 0x1c]
433682d5 mov      esi, dword ptr [0x43467040]
433682db test     esi, esi
433682dd movzx    edx, word ptr [ecx]
433682e0 mov      dword ptr [esp + 0x10], esi
433682e4 mov      esi, dword ptr [esp + 0x24]
433682e8 mov      dword ptr [esp + 0x14], edx
433682ec je       0x43368386
433682f2 mov      ecx, dword ptr [esp + 0x30]
433682f6 push     edx
433682f7 call     dword ptr [esp + 0x14]
433682fb test     eax, eax
433682fd je       0x4336837a
433682ff push     dword ptr [eax + 0x24]
43368302 call     0x43397087
43368307 mov      dword ptr [esp + 0x10], eax
4336830b test     eax, eax
4336830d je       0x4336837a
4336830f push     0x100
43368314 lea      eax, [esp + 0x44]
43368318 push     ebx
43368319 push     eax
4336831a call     0x774fdc80
4336831f add      esp, 0xc
43368322 lea      eax, [esp + 0x40]
43368326 push     ebx
43368327 push     ebx
43368328 push     0x100
4336832d push     eax
4336832e push     dword ptr [esp + 0x20]
43368332 call     0x75bf85d0
43368337 nop      
43368338 push     eax
43368339 push     dword ptr [esp + 0x24]
4336833d push     ebx
4336833e push     0xfde9
43368343 call     0x75bfb8e0
43368348 cmp      esi, dword ptr [esp + 0x28]
4336834c jae      0x43368367
4336834e push     dword ptr [esp + 0x14]
43368352 lea      eax, [esp + 0x44]
43368356 mov      ecx, esi
43368358 push     eax
43368359 call     0x4335c57f
4336835e add      esi, 0x14
43368361 mov      dword ptr [esp + 0x24], esi
43368365 jmp      0x4336837a
43368367 lea      eax, [esp + 0x14]
4336836b push     eax
4336836c lea      eax, [esp + 0x44]
43368370 push     eax
43368371 lea      ecx, [esp + 0x28]
43368375 call     0x433b30d5
4336837a mov      edx, dword ptr [esp + 0x14]
4336837e mov      ecx, dword ptr [esp + 0x1c]
43368382 mov      eax, dword ptr [esp + 0x18]
43368386 cmp      edx, edi
43368388 movzx    eax, al
4336838b mov      dword ptr [esp + 0x10], 1
43368393 cmove    eax, dword ptr [esp + 0x10]
43368398 add      ecx, 2
4336839b mov      dword ptr [esp + 0x18], eax
4336839f mov      dword ptr [esp + 0x1c], ecx
433683a3 cmp      ecx, dword ptr [esp + 0x34]
433683a7 jne      0x433682d5
433683ad mov      eax, dword ptr [esp + 0x20]
433683b1 mov      ebx, dword ptr [esp + 0x3c]
433683b5 mov      dword ptr [esp + 0x10], eax
433683b9 lea      ecx, [esp + 0x20]
433683bd call     0x433b69e8
433683c2 mov      esi, dword ptr [ebx + 0xd8]
433683c8 add      esi, 0xac
433683ce push     esi
433683cf call     0x77c34040
433683d4 mov      ecx, dword ptr [ebx + 0xf8]
433683da sub      esp, 0x10
433683dd mov      edx, dword ptr [esp + 0x20]
433683e1 mov      eax, esp
433683e3 mov      dword ptr [eax], edx
433683e5 mov      edx, dword ptr [esp + 0x34]
433683e9 mov      dword ptr [eax + 4], edx
433683ec mov      edx, dword ptr [esp + 0x38]
433683f0 mov      dword ptr [eax + 8], edx
433683f3 call     0x433ee01c
433683f8 test     esi, esi
433683fa je       0x43368402
433683fc push     esi
433683fd call     0x77c33dc0
43368402 cmp      byte ptr [esp + 0x18], 0
43368407 jne      0x4336841d
43368409 mov      eax, dword ptr [ebx + 0xf8]
4336840f mov      ecx, dword ptr [eax + 0x7c]
43368412 cmp      ecx, dword ptr [eax + 0x80]
43368418 je       0x4336841d
4336841a mov      edi, dword ptr [ecx + 0x10]
4336841d mov      ecx, dword ptr [ebx + 0xf8]
43368423 push     edi
43368424 call     0x43398ecf
43368429 pop      edi
4336842a pop      esi
4336842b pop      ebx
4336842c mov      esp, ebp
4336842e pop      ebp
4336842f ret      8
