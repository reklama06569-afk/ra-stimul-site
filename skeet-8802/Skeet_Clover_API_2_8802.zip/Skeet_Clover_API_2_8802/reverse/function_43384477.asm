43384477 push     ebp
43384478 mov      ebp, esp
4338447a and      esp, 0xfffffff8
4338447d sub      esp, 0x90
43384483 push     ebx
43384484 push     ebp
43384485 mov      ebx, ecx
43384487 xor      ebp, ebp
43384489 push     esi
4338448a push     edi
4338448b mov      eax, dword ptr [ebx + 0x60]
4338448e push     dword ptr [eax + 0x18]
43384491 push     dword ptr [eax + 0x14]
43384494 lea      eax, [esp + 0x30]
43384498 push     ebp
43384499 push     ebp
4338449a push     eax
4338449b call     0x76ef1e30
433844a0 nop      
433844a1 mov      esi, dword ptr [ebx + 0x60]
433844a4 lea      edi, [esp + 0x18]
433844a8 mov      ecx, dword ptr [ebx + 0x94]
433844ae add      esi, 0x24
433844b1 mov      eax, dword ptr [ebx + 0x28]
433844b4 add      eax, ecx
433844b6 push     0x60
433844b8 movsd    dword ptr es:[edi], dword ptr [esi]
433844b9 push     ebp
433844ba movsd    dword ptr es:[edi], dword ptr [esi]
433844bb movsd    dword ptr es:[edi], dword ptr [esi]
433844bc movsd    dword ptr es:[edi], dword ptr [esi]
433844bd add      eax, dword ptr [esp + 0x20]
433844c1 add      dword ptr [esp + 0x30], eax
433844c5 mov      eax, dword ptr [esp + 0x24]
433844c9 add      eax, ecx
433844cb add      dword ptr [esp + 0x34], eax
433844cf mov      eax, dword ptr [esp + 0x28]
433844d3 add      eax, ecx
433844d5 sub      dword ptr [esp + 0x38], eax
433844d9 mov      eax, dword ptr [esp + 0x2c]
433844dd add      eax, ecx
433844df sub      dword ptr [esp + 0x3c], eax
433844e3 lea      eax, [esp + 0x48]
433844e7 push     eax
433844e8 call     0x774fdc80
433844ed mov      eax, dword ptr [ebx + 0x74]
433844f0 add      esp, 0xc
433844f3 mov      ebx, dword ptr [ebx + 0x70]
433844f6 mov      dword ptr [esp + 0x3c], eax
433844fa mov      dword ptr [esp + 0x38], ebx
433844fe cmp      ebx, eax
43384500 je       0x43384719
43384506 movss    xmm4, dword ptr [0x4346ff74]
4338450e mov      edx, dword ptr [ebx]
43384510 lea      esi, [esp + 0x28]
43384514 lea      edi, [esp + 0x18]
43384518 movsd    dword ptr es:[edi], dword ptr [esi]
43384519 mov      al, byte ptr [edx + 0x73]
4338451c mov      ebp, dword ptr [edx + 0x6c]
4338451f movsd    dword ptr es:[edi], dword ptr [esi]
43384520 mov      dword ptr [esp + 0x14], ebp
43384524 mov      byte ptr [esp + 0x13], al
43384528 movsd    dword ptr es:[edi], dword ptr [esi]
43384529 movsd    dword ptr es:[edi], dword ptr [esi]
4338452a movsx    esi, byte ptr [edx + 0x70]
4338452e mov      edi, dword ptr [esp + esi*4 + 0x40]
43384532 add      edi, dword ptr [esp + 0x2c]
43384536 cmp      al, 0xff
43384538 je       0x433845d6
4338453e mov      eax, dword ptr [esp + 0x20]
43384542 sub      eax, dword ptr [esp + 0x18]
43384546 movd     xmm2, eax
4338454a movsx    eax, byte ptr [edx + 0x71]
4338454e cvtdq2ps xmm2, xmm2
43384551 movd     xmm0, eax
43384555 cvtdq2ps xmm0, xmm0
43384558 mov      eax, dword ptr [esp + 0x24]
4338455c sub      eax, edi
4338455e divss    xmm0, xmm4
43384562 movd     xmm3, eax
43384566 movsx    eax, byte ptr [esp + 0x13]
4338456b mulss    xmm0, xmm2
4338456f cvtdq2ps xmm3, xmm3
43384572 cvttss2si ecx, xmm0
43384576 movd     xmm0, eax
4338457a cvtdq2ps xmm0, xmm0
4338457d mov      dword ptr [edx + 0x28], ecx
43384580 mov      dword ptr [edx + 0x30], ecx
43384583 divss    xmm2, xmm4
43384587 divss    xmm0, xmm4
4338458b mulss    xmm0, xmm3
4338458f divss    xmm3, xmm4
43384593 cvttss2si eax, xmm0
43384597 movd     xmm0, dword ptr [esp + 0x18]
4338459d mov      dword ptr [edx + 0x2c], eax
433845a0 mov      dword ptr [edx + 0x34], eax
433845a3 mov      edx, dword ptr [ebx]
433845a5 cvtdq2ps xmm0, xmm0
433845a8 movsx    eax, byte ptr [edx + 0x70]
433845ac movd     xmm1, eax
433845b0 movsx    eax, byte ptr [edx + 0x72]
433845b4 cvtdq2ps xmm1, xmm1
433845b7 mulss    xmm1, xmm2
433845bb addss    xmm1, xmm0
433845bf cvttss2si ecx, xmm1
433845c3 movd     xmm1, eax
433845c7 add      ecx, dword ptr [edx + 0x54]
433845ca cvtdq2ps xmm1, xmm1
433845cd mulss    xmm1, xmm3
433845d1 jmp      0x43384668
433845d6 mov      eax, dword ptr [edx + 0x64]
433845d9 lea      ecx, [eax + ebp*2]
433845dc jmp      0x433845e5
433845de mov      dword ptr [esp + esi*4 + 0x40], ecx
433845e2 inc      esi
433845e3 mov      edx, dword ptr [ebx]
433845e5 movsx    eax, byte ptr [edx + 0x71]
433845e9 cmp      esi, eax
433845eb jb       0x433845de
433845ed mov      eax, dword ptr [esp + 0x20]
433845f1 sub      eax, dword ptr [esp + 0x18]
433845f5 movd     xmm2, eax
433845f9 movsx    eax, byte ptr [edx + 0x71]
433845fd cvtdq2ps xmm2, xmm2
43384600 mov      dword ptr [edx + 0x2c], ecx
43384603 mov      dword ptr [edx + 0x34], ecx
43384606 movd     xmm0, eax
4338460a cvtdq2ps xmm0, xmm0
4338460d divss    xmm0, xmm4
43384611 mulss    xmm0, xmm2
43384615 divss    xmm2, xmm4
43384619 cvttss2si eax, xmm0
4338461d movd     xmm0, dword ptr [esp + 0x18]
43384623 mov      dword ptr [edx + 0x28], eax
43384626 mov      dword ptr [edx + 0x30], eax
43384629 mov      edx, dword ptr [ebx]
4338462b cvtdq2ps xmm0, xmm0
4338462e movsx    eax, byte ptr [edx + 0x70]
43384632 movd     xmm1, eax
43384636 mov      eax, dword ptr [esp + 0x24]
4338463a cvtdq2ps xmm1, xmm1
4338463d mulss    xmm1, xmm2
43384641 addss    xmm1, xmm0
43384645 cvttss2si ecx, xmm1
43384649 add      ecx, dword ptr [edx + 0x54]
4338464c sub      eax, edi
4338464e movd     xmm1, eax
43384652 movsx    eax, byte ptr [edx + 0x72]
43384656 cvtdq2ps xmm1, xmm1
43384659 movd     xmm0, eax
4338465d divss    xmm1, xmm4
43384661 cvtdq2ps xmm0, xmm0
43384664 mulss    xmm1, xmm0
43384668 movd     xmm0, edi
4338466c cvtdq2ps xmm0, xmm0
4338466f mov      edi, dword ptr [esp + 0x14]
43384673 addss    xmm1, xmm0
43384677 cvttss2si eax, xmm1
4338467b mov      dword ptr [edx + 0x24], eax
4338467e mov      dword ptr [edx + 0x20], ecx
43384681 mov      ebp, dword ptr [ebx]
43384683 mov      ecx, dword ptr [esp + 0x14]
43384687 mov      esi, dword ptr [ebp + 0x20]
4338468a mov      ebx, dword ptr [ebp + 0x24]
4338468d lea      eax, [esi + ecx]
43384690 add      ecx, ebx
43384692 sub      esi, eax
43384694 mov      dword ptr [ebp + 0x24], ecx
43384697 sub      esi, dword ptr [esp + 0x14]
4338469b sub      ebx, ecx
4338469d sub      ebx, dword ptr [esp + 0x14]
433846a1 mov      dword ptr [ebp + 0x20], eax
433846a4 add      dword ptr [ebp + 0x28], esi
433846a7 add      dword ptr [ebp + 0x2c], ebx
433846aa mov      ebx, dword ptr [esp + 0x38]
433846ae mov      dword ptr [esp + 0x18], eax
433846b2 mov      esi, dword ptr [ebx]
433846b4 mov      edx, esi
433846b6 movsx    ecx, byte ptr [esi + 0x71]
433846ba movsx    eax, byte ptr [esi + 0x70]
433846be add      ecx, eax
433846c0 cmp      ecx, 0x18
433846c3 jl       0x433846e0
433846c5 mov      ecx, dword ptr [esp + 0x30]
433846c9 mov      eax, dword ptr [esi + 0x28]
433846cc sub      ecx, edi
433846ce add      eax, dword ptr [esi + 0x20]
433846d1 cmp      eax, ecx
433846d3 je       0x433846e0
433846d5 sub      ecx, dword ptr [esi + 0x20]
433846d8 mov      dword ptr [esi + 0x28], ecx
433846db mov      dword ptr [esi + 0x30], ecx
433846de mov      edx, dword ptr [ebx]
433846e0 movsx    ecx, byte ptr [edx + 0x73]
433846e4 movsx    eax, byte ptr [edx + 0x72]
433846e8 add      ecx, eax
433846ea cmp      ecx, 0x18
433846ed jl       0x43384708
433846ef mov      ecx, dword ptr [esp + 0x34]
433846f3 mov      eax, dword ptr [edx + 0x2c]
433846f6 sub      ecx, edi
433846f8 add      eax, dword ptr [edx + 0x24]
433846fb cmp      eax, ecx
433846fd je       0x43384708
433846ff sub      ecx, dword ptr [edx + 0x24]
43384702 mov      dword ptr [edx + 0x2c], ecx
43384705 mov      dword ptr [edx + 0x34], ecx
43384708 add      ebx, 4
4338470b mov      dword ptr [esp + 0x38], ebx
4338470f cmp      ebx, dword ptr [esp + 0x3c]
43384713 jne      0x4338450e
43384719 pop      edi
4338471a pop      esi
4338471b pop      ebp
4338471c pop      ebx
4338471d mov      esp, ebp
4338471f pop      ebp
43384720 ret      
