433c95ce push     ebp
433c95cf mov      ebp, esp
433c95d1 and      esp, 0xfffffff0
433c95d4 sub      esp, 0x244
433c95da mov      eax, ecx
433c95dc push     ebx
433c95dd push     esi
433c95de mov      dword ptr [esp + 0x20], eax
433c95e2 mov      esi, dword ptr [eax + 4]
433c95e5 push     edi
433c95e6 mov      dword ptr [esp + 0x18], esi
433c95ea movss    xmm0, dword ptr [esi + 0x104]
433c95f2 movss    xmm1, dword ptr [esi + 0x100]
433c95fa ucomiss  xmm0, xmm1
433c95fd lahf     
433c95fe test     ah, 0x44
433c9601 jnp      0x433c96cb
433c9607 ucomiss  xmm1, dword ptr [0x43470514]
433c960e lahf     
433c960f test     ah, 0x44
433c9612 jnp      0x433c96bb
433c9618 add      esi, 0xa8
433c961e push     esi
433c961f mov      dword ptr [esp + 0x24], esi
433c9623 call     0x77c34040
433c9628 mov      edi, dword ptr [esp + 0x18]
433c962c mov      dword ptr [esp + 0x14], 7
433c9634 lea      esi, [edi + 0x10]
433c9637 lea      ebx, [edi + 0x15c]
433c963d movd     xmm0, dword ptr [esi]
433c9641 push     dword ptr [esi + 4]
433c9644 mov      ecx, dword ptr [esi - 0x10]
433c9647 cvtdq2ps xmm0, xmm0
433c964a mulss    xmm0, dword ptr [edi + 0x100]
433c9652 addss    xmm0, dword ptr [0x43472240]
433c965a cvttss2si edx, xmm0
433c965e call     0x4334e194
433c9663 mov      ecx, dword ptr [ebx]
433c9665 mov      dword ptr [esp + 0x1c], eax
433c9669 cmp      eax, ecx
433c966b je       0x433c967d
433c966d test     ecx, ecx
433c966f je       0x433c9679
433c9671 mov      eax, dword ptr [ecx]
433c9673 call     dword ptr [eax]
433c9675 mov      eax, dword ptr [esp + 0x1c]
433c9679 mov      dword ptr [ebx], eax
433c967b mov      ecx, eax
433c967d mov      edx, dword ptr [ebx + 4]
433c9680 test     edx, edx
433c9682 je       0x433c968c
433c9684 mov      eax, dword ptr [edx]
433c9686 push     edx
433c9687 call     dword ptr [eax + 8]
433c968a mov      ecx, dword ptr [ebx]
433c968c and      dword ptr [ebx + 4], 0
433c9690 test     ecx, ecx
433c9692 jne      0x433c969e
433c9694 push     -9
433c9696 push     -1
433c9698 call     0x77c66e30
433c969d nop      
433c969e add      ebx, 0xc
433c96a1 add      esi, 0x18
433c96a4 sub      dword ptr [esp + 0x14], 1
433c96a9 jne      0x433c963d
433c96ab mov      esi, dword ptr [esp + 0x20]
433c96af test     esi, esi
433c96b1 je       0x433c96b9
433c96b3 push     esi
433c96b4 call     0x77c33dc0
433c96b9 mov      esi, edi
433c96bb movss    xmm0, dword ptr [esi + 0x100]
433c96c3 movss    dword ptr [esi + 0x104], xmm0
433c96cb lea      edi, [esi + 0x108]
433c96d1 lea      ebx, [esi + 0x15c]
433c96d7 cmp      edi, ebx
433c96d9 je       0x433c9702
433c96db mov      ecx, dword ptr [edi]
433c96dd test     ecx, ecx
433c96df je       0x433c96f3
433c96e1 mov      eax, dword ptr [ecx]
433c96e3 call     dword ptr [eax + 0x10]
433c96e6 test     al, al
433c96e8 je       0x433c96f3
433c96ea mov      edx, edi
433c96ec mov      ecx, esi
433c96ee call     0x4334a887
433c96f3 add      edi, 0xc
433c96f6 cmp      edi, ebx
433c96f8 jne      0x433c96db
433c96fa movss    xmm0, dword ptr [esi + 0x104]
433c9702 ucomiss  xmm0, dword ptr [0x43470514]
433c9709 lahf     
433c970a test     ah, 0x44
433c970d jnp      0x433c973c
433c970f lea      edi, [esi + 0x15c]
433c9715 lea      ebx, [esi + 0x1b0]
433c971b jmp      0x433c9738
433c971d mov      ecx, dword ptr [edi]
433c971f test     ecx, ecx
433c9721 je       0x433c9735
433c9723 mov      eax, dword ptr [ecx]
433c9725 call     dword ptr [eax + 0x10]
433c9728 test     al, al
433c972a je       0x433c9735
433c972c mov      edx, edi
433c972e mov      ecx, esi
433c9730 call     0x4334a887
433c9735 add      edi, 0xc
433c9738 cmp      edi, ebx
433c973a jne      0x433c971d
433c973c mov      ebx, dword ptr [esi + 0xd4]
433c9742 mov      edi, dword ptr [esi + 0xd0]
433c9748 jmp      0x433c97b6
433c974a cmp      byte ptr [edi + 0x28], 0
433c974e je       0x433c9767
433c9750 mov      byte ptr [edi + 0x28], 0
433c9754 mov      ecx, dword ptr [edi + 0x24]
433c9757 test     ecx, ecx
433c9759 je       0x433c9761
433c975b mov      eax, dword ptr [ecx]
433c975d push     ecx
433c975e call     dword ptr [eax + 8]
433c9761 and      dword ptr [edi + 0x24], 0
433c9765 jmp      0x433c976d
433c9767 cmp      dword ptr [edi + 0x24], 0
433c976b jne      0x433c97b3
433c976d mov      eax, dword ptr [edi + 0x10]
433c9770 cmp      eax, dword ptr [edi + 0x14]
433c9773 je       0x433c97b3
433c9775 mov      ecx, edi
433c9777 call     0x4341cc03
433c977c mov      eax, dword ptr [edi + 0x14]
433c977f lea      ecx, [esp + 0x14]
433c9783 sub      eax, dword ptr [edi + 0x10]
433c9786 mov      edx, dword ptr [edi + 4]
433c9789 and      dword ptr [esp + 0x14], 0
433c978e push     ecx
433c978f mov      ecx, dword ptr [esi + 0xc8]
433c9795 push     eax
433c9796 push     dword ptr [edi + 0x10]
433c9799 push     dword ptr [edi + 8]
433c979c call     0x4336afee
433c97a1 test     eax, eax
433c97a3 js       0x433c97ac
433c97a5 mov      eax, dword ptr [esp + 0x14]
433c97a9 mov      dword ptr [edi + 0x24], eax
433c97ac mov      ecx, edi
433c97ae call     0x4341cc03
433c97b3 add      edi, 0x2c
433c97b6 cmp      edi, ebx
433c97b8 jne      0x433c974a
433c97ba mov      eax, dword ptr fs:[0x18]
433c97c0 lea      edi, [esp + 0x50]
433c97c4 mov      ebx, dword ptr [esi + 0xc8]
433c97ca lea      ecx, [esp + 0x50]
433c97ce push     ecx
433c97cf push     ebx
433c97d0 mov      eax, dword ptr [eax + 0x24]
433c97d3 mov      dword ptr [esi + 0xf8], eax
433c97d9 xor      eax, eax
433c97db stosd    dword ptr es:[edi], eax
433c97dc stosd    dword ptr es:[edi], eax
433c97dd stosd    dword ptr es:[edi], eax
433c97de stosd    dword ptr es:[edi], eax
433c97df xor      eax, eax
433c97e1 lea      edi, [esp + 0x30]
433c97e5 stosd    dword ptr es:[edi], eax
433c97e6 stosd    dword ptr es:[edi], eax
433c97e7 stosd    dword ptr es:[edi], eax
433c97e8 stosd    dword ptr es:[edi], eax
433c97e9 mov      eax, dword ptr [ebx]
433c97eb call     dword ptr [eax + 0x24]
433c97ee test     eax, eax
433c97f0 js       0x433c9820
433c97f2 lea      eax, [esp + 0x28]
433c97f6 push     eax
433c97f7 push     dword ptr [esp + 0x5c]
433c97fb call     0x76eedaf0
433c9800 test     eax, eax
433c9802 je       0x433c9820
433c9804 mov      eax, dword ptr [esp + 0x30]
433c9808 sub      eax, dword ptr [esp + 0x28]
433c980c mov      dword ptr [esi + 0xf4], eax
433c9812 mov      eax, dword ptr [esp + 0x34]
433c9816 sub      eax, dword ptr [esp + 0x2c]
433c981a mov      dword ptr [esi + 0xf0], eax
433c9820 xor      edx, edx
433c9822 cmp      dword ptr [esi + 0xf4], edx
433c9828 je       0x433c9da5
433c982e cmp      dword ptr [esi + 0xf0], edx
433c9834 je       0x433c9da5
433c983a mov      cl, 1
433c983c lea      eax, [esi + 0xe0]
433c9842 xchg     byte ptr [eax], cl
433c9844 push     0x130
433c9849 push     edx
433c984a lea      eax, [esp + 0x128]
433c9851 push     eax
433c9852 call     0x774fdc80
433c9857 mov      eax, dword ptr [ebx]
433c9859 lea      ecx, [esp + 0x12c]
433c9860 add      esp, 0xc
433c9863 push     ecx
433c9864 push     ebx
433c9865 call     dword ptr [eax + 0x1c]
433c9868 test     byte ptr [esp + 0x154], 0x10
433c9870 je       0x433c98a6
433c9872 mov      eax, dword ptr [ebx]
433c9874 push     1
433c9876 push     0x1b
433c9878 push     ebx
433c9879 call     dword ptr [eax + 0xe4]
433c987f mov      eax, dword ptr [ebx]
433c9881 push     1
433c9883 push     0x18
433c9885 push     ebx
433c9886 call     dword ptr [eax + 0xe4]
433c988c mov      eax, dword ptr [ebx]
433c988e push     1
433c9890 push     0xf
433c9892 push     ebx
433c9893 call     dword ptr [eax + 0xe4]
433c9899 mov      eax, dword ptr [ebx]
433c989b push     5
433c989d push     0x19
433c989f push     ebx
433c98a0 call     dword ptr [eax + 0xe4]
433c98a6 mov      eax, dword ptr [ebx]
433c98a8 push     1
433c98aa push     7
433c98ac push     ebx
433c98ad call     dword ptr [eax + 0xe4]
433c98b3 mov      eax, dword ptr [ebx]
433c98b5 push     3
433c98b7 push     8
433c98b9 push     ebx
433c98ba call     dword ptr [eax + 0xe4]
433c98c0 mov      eax, dword ptr [ebx]
433c98c2 push     2
433c98c4 push     9
433c98c6 push     ebx
433c98c7 call     dword ptr [eax + 0xe4]
433c98cd mov      eax, dword ptr [ebx]
433c98cf push     1
433c98d1 push     0xe
433c98d3 push     ebx
433c98d4 call     dword ptr [eax + 0xe4]
433c98da mov      eax, dword ptr [ebx]
433c98dc push     5
433c98de push     0x13
433c98e0 push     ebx
433c98e1 call     dword ptr [eax + 0xe4]
433c98e7 mov      eax, dword ptr [ebx]
433c98e9 push     6
433c98eb push     0x14
433c98ed push     ebx
433c98ee call     dword ptr [eax + 0xe4]
433c98f4 mov      eax, dword ptr [ebx]
433c98f6 push     1
433c98f8 push     0x16
433c98fa push     ebx
433c98fb call     dword ptr [eax + 0xe4]
433c9901 mov      eax, dword ptr [ebx]
433c9903 push     4
433c9905 pop      edi
433c9906 push     edi
433c9907 push     0x17
433c9909 push     ebx
433c990a call     dword ptr [eax + 0xe4]
433c9910 mov      eax, dword ptr [ebx]
433c9912 push     0
433c9914 push     0x1c
433c9916 push     ebx
433c9917 call     dword ptr [eax + 0xe4]
433c991d mov      eax, dword ptr [ebx]
433c991f push     0
433c9921 push     0x1d
433c9923 push     ebx
433c9924 call     dword ptr [eax + 0xe4]
433c992a mov      eax, dword ptr [ebx]
433c992c push     0
433c992e push     0x30
433c9930 push     ebx
433c9931 call     dword ptr [eax + 0xe4]
433c9937 mov      eax, dword ptr [ebx]
433c9939 push     0
433c993b push     0x34
433c993d push     ebx
433c993e call     dword ptr [eax + 0xe4]
433c9944 mov      eax, dword ptr [ebx]
433c9946 push     0
433c9948 push     0x80
433c994d push     ebx
433c994e call     dword ptr [eax + 0xe4]
433c9954 mov      eax, dword ptr [ebx]
433c9956 push     1
433c9958 push     0x88
433c995d push     ebx
433c995e call     dword ptr [eax + 0xe4]
433c9964 mov      eax, dword ptr [ebx]
433c9966 push     0
433c9968 push     0x89
433c996d push     ebx
433c996e call     dword ptr [eax + 0xe4]
433c9974 mov      eax, dword ptr [ebx]
433c9976 push     1
433c9978 push     0x91
433c997d push     ebx
433c997e call     dword ptr [eax + 0xe4]
433c9984 mov      eax, dword ptr [ebx]
433c9986 push     0
433c9988 push     0x97
433c998d push     ebx
433c998e call     dword ptr [eax + 0xe4]
433c9994 mov      eax, dword ptr [ebx]
433c9996 push     1
433c9998 push     0xa1
433c999d push     ebx
433c999e call     dword ptr [eax + 0xe4]
433c99a4 mov      eax, dword ptr [ebx]
433c99a6 push     0xf
433c99a8 push     0xa8
433c99ad push     ebx
433c99ae call     dword ptr [eax + 0xe4]
433c99b4 mov      eax, dword ptr [ebx]
433c99b6 push     1
433c99b8 push     0xab
433c99bd push     ebx
433c99be call     dword ptr [eax + 0xe4]
433c99c4 mov      eax, dword ptr [ebx]
433c99c6 push     1
433c99c8 push     0xb0
433c99cd push     ebx
433c99ce call     dword ptr [eax + 0xe4]
433c99d4 mov      eax, dword ptr [ebx]
433c99d6 push     1
433c99d8 push     0xae
433c99dd push     ebx
433c99de call     dword ptr [eax + 0xe4]
433c99e4 mov      eax, dword ptr [ebx]
433c99e6 push     0
433c99e8 push     0xb8
433c99ed push     ebx
433c99ee call     dword ptr [eax + 0xe4]
433c99f4 mov      eax, dword ptr [ebx]
433c99f6 push     1
433c99f8 push     0xce
433c99fd push     ebx
433c99fe call     dword ptr [eax + 0xe4]
433c9a04 mov      eax, dword ptr [ebx]
433c9a06 push     2
433c9a08 push     0xcf
433c9a0d push     ebx
433c9a0e call     dword ptr [eax + 0xe4]
433c9a14 mov      eax, dword ptr [ebx]
433c9a16 push     6
433c9a18 push     0xd0
433c9a1d push     ebx
433c9a1e call     dword ptr [eax + 0xe4]
433c9a24 mov      eax, dword ptr [ebx]
433c9a26 push     5
433c9a28 push     0xd1
433c9a2d push     ebx
433c9a2e call     dword ptr [eax + 0xe4]
433c9a34 mov      eax, dword ptr [ebx]
433c9a36 push     edi
433c9a37 push     edi
433c9a38 push     0
433c9a3a push     ebx
433c9a3b call     dword ptr [eax + 0x10c]
433c9a41 mov      eax, dword ptr [ebx]
433c9a43 push     2
433c9a45 push     5
433c9a47 push     0
433c9a49 push     ebx
433c9a4a call     dword ptr [eax + 0x10c]
433c9a50 mov      eax, dword ptr [ebx]
433c9a52 push     0
433c9a54 push     6
433c9a56 push     0
433c9a58 push     ebx
433c9a59 call     dword ptr [eax + 0x10c]
433c9a5f mov      eax, dword ptr [ebx]
433c9a61 push     edi
433c9a62 push     1
433c9a64 push     0
433c9a66 push     ebx
433c9a67 call     dword ptr [eax + 0x10c]
433c9a6d mov      eax, dword ptr [ebx]
433c9a6f push     2
433c9a71 push     2
433c9a73 push     0
433c9a75 push     ebx
433c9a76 call     dword ptr [eax + 0x10c]
433c9a7c mov      eax, dword ptr [ebx]
433c9a7e push     0
433c9a80 push     3
433c9a82 push     0
433c9a84 push     ebx
433c9a85 call     dword ptr [eax + 0x10c]
433c9a8b mov      eax, dword ptr [ebx]
433c9a8d push     0
433c9a8f push     0xb
433c9a91 push     0
433c9a93 push     ebx
433c9a94 call     dword ptr [eax + 0x10c]
433c9a9a mov      eax, dword ptr [ebx]
433c9a9c push     0
433c9a9e push     0x18
433c9aa0 push     0
433c9aa2 push     ebx
433c9aa3 call     dword ptr [eax + 0x10c]
433c9aa9 mov      eax, dword ptr [ebx]
433c9aab push     1
433c9aad push     1
433c9aaf push     1
433c9ab1 push     ebx
433c9ab2 call     dword ptr [eax + 0x10c]
433c9ab8 mov      eax, dword ptr [ebx]
433c9aba push     1
433c9abc push     edi
433c9abd push     1
433c9abf push     ebx
433c9ac0 call     dword ptr [eax + 0x10c]
433c9ac6 mov      eax, dword ptr [ebx]
433c9ac8 push     2
433c9aca push     6
433c9acc push     0
433c9ace push     ebx
433c9acf call     dword ptr [eax + 0x114]
433c9ad5 mov      eax, dword ptr [ebx]
433c9ad7 push     2
433c9ad9 push     5
433c9adb push     0
433c9add push     ebx
433c9ade call     dword ptr [eax + 0x114]
433c9ae4 mov      eax, dword ptr [ebx]
433c9ae6 push     0
433c9ae8 push     9
433c9aea push     0
433c9aec push     ebx
433c9aed call     dword ptr [eax + 0x114]
433c9af3 mov      eax, dword ptr [ebx]
433c9af5 push     0
433c9af7 push     8
433c9af9 push     0
433c9afb push     ebx
433c9afc call     dword ptr [eax + 0x114]
433c9b02 push     dword ptr [esp + 0x18c]
433c9b09 mov      eax, dword ptr [ebx]
433c9b0b xor      edi, edi
433c9b0d push     0xa
433c9b0f push     edi
433c9b10 push     ebx
433c9b11 call     dword ptr [eax + 0x114]
433c9b17 mov      eax, dword ptr [ebx]
433c9b19 push     1
433c9b1b push     1
433c9b1d push     edi
433c9b1e push     ebx
433c9b1f call     dword ptr [eax + 0x114]
433c9b25 mov      eax, dword ptr [ebx]
433c9b27 push     1
433c9b29 push     2
433c9b2b push     edi
433c9b2c push     ebx
433c9b2d call     dword ptr [eax + 0x114]
433c9b33 mov      eax, dword ptr [ebx]
433c9b35 push     1
433c9b37 push     1
433c9b39 push     1
433c9b3b push     ebx
433c9b3c call     dword ptr [eax + 0x114]
433c9b42 mov      eax, dword ptr [ebx]
433c9b44 push     1
433c9b46 push     2
433c9b48 push     1
433c9b4a push     ebx
433c9b4b call     dword ptr [eax + 0x114]
433c9b51 mov      eax, dword ptr [ebx]
433c9b53 add      esi, 0xfc
433c9b59 push     esi
433c9b5a push     ebx
433c9b5b call     dword ptr [eax + 0x168]
433c9b61 test     eax, eax
433c9b63 js       0x433c9b78
433c9b65 mov      ecx, 0x142
433c9b6a cmp      dword ptr [esi], ecx
433c9b6c je       0x433c9b78
433c9b6e mov      eax, dword ptr [ebx]
433c9b70 push     ecx
433c9b71 push     ebx
433c9b72 call     dword ptr [eax + 0x164]
433c9b78 movaps   xmm0, xmmword ptr [0x4346f650]
433c9b7f lea      ecx, [esp + 0x60]
433c9b83 movups   xmmword ptr [esp + 0x60], xmm0
433c9b88 push     ecx
433c9b89 movaps   xmm0, xmmword ptr [0x43470970]
433c9b90 movups   xmmword ptr [esp + 0x74], xmm0
433c9b95 push     0x100
433c9b9a movaps   xmm0, xmmword ptr [0x43470460]
433c9ba1 movups   xmmword ptr [esp + 0x88], xmm0
433c9ba9 push     ebx
433c9baa movaps   xmm0, xmmword ptr [0x4346db90]
433c9bb1 movups   xmmword ptr [esp + 0x9c], xmm0
433c9bb9 mov      eax, dword ptr [ebx]
433c9bbb call     dword ptr [eax + 0xb0]
433c9bc1 mov      eax, dword ptr [ebx]
433c9bc3 lea      edx, [esp + 0x60]
433c9bc7 push     edx
433c9bc8 push     2
433c9bca push     ebx
433c9bcb call     dword ptr [eax + 0xb0]
433c9bd1 push     6
433c9bd3 pop      ecx
433c9bd4 xor      eax, eax
433c9bd6 lea      edi, [esp + 0x38]
433c9bda rep stosd dword ptr es:[edi], eax
433c9bdc mov      eax, dword ptr [ebx]
433c9bde lea      ecx, [esp + 0x38]
433c9be2 push     ecx
433c9be3 push     ebx
433c9be4 call     dword ptr [eax + 0xc0]
433c9bea mov      ecx, dword ptr [esp + 0x38]
433c9bee mov      eax, ecx
433c9bf0 shr      eax, 0x1f
433c9bf3 movss    xmm1, dword ptr [0x43472240]
433c9bfb movd     xmm0, ecx
433c9bff cvtdq2pd xmm0, xmm0
433c9c03 addsd    xmm0, qword ptr [eax*8 + 0x43472600]
433c9c0c mov      eax, dword ptr [esp + 0x40]
433c9c10 add      eax, ecx
433c9c12 mov      ecx, dword ptr [esp + 0x3c]
433c9c16 cvtpd2ps xmm5, xmm0
433c9c1a movd     xmm0, eax
433c9c1e cvtdq2pd xmm0, xmm0
433c9c22 shr      eax, 0x1f
433c9c25 addss    xmm5, xmm1
433c9c29 addsd    xmm0, qword ptr [eax*8 + 0x43472600]
433c9c32 mov      eax, dword ptr [esp + 0x44]
433c9c36 add      eax, ecx
433c9c38 movss    dword ptr [esp + 0x20], xmm5
433c9c3e cvtpd2ps xmm4, xmm0
433c9c42 movd     xmm0, eax
433c9c46 cvtdq2pd xmm0, xmm0
433c9c4a shr      eax, 0x1f
433c9c4d addss    xmm4, xmm1
433c9c51 addsd    xmm0, qword ptr [eax*8 + 0x43472600]
433c9c5a movss    dword ptr [esp + 0x1c], xmm4
433c9c60 cvtpd2ps xmm7, xmm0
433c9c64 movd     xmm0, ecx
433c9c68 cvtdq2pd xmm0, xmm0
433c9c6c shr      ecx, 0x1f
433c9c6f addss    xmm7, xmm1
433c9c73 addsd    xmm0, qword ptr [ecx*8 + 0x43472600]
433c9c7c cvtpd2ps xmm6, xmm0
433c9c80 addss    xmm6, xmm1
433c9c84 movss    xmm1, dword ptr [0x43470514]
433c9c8c movaps   xmm2, xmm1
433c9c8f movaps   xmm3, xmm1
433c9c92 movaps   xmm0, xmm6
433c9c95 subss    xmm0, xmm7
433c9c99 divss    xmm1, xmm0
433c9c9d movaps   xmm0, xmm4
433c9ca0 movss    xmm4, dword ptr [0x43470514]
433c9ca8 subss    xmm0, xmm5
433c9cac unpcklps xmm1, xmm3
433c9caf movaps   xmm5, xmm4
433c9cb2 divss    xmm5, xmm0
433c9cb6 xorps    xmm0, xmm0
433c9cb9 unpcklps xmm5, xmm2
433c9cbc unpcklps xmm5, xmm1
433c9cbf movss    xmm0, xmm5
433c9cc3 addss    xmm0, xmm0
433c9cc7 movss    xmm1, dword ptr [esp + 0x20]
433c9ccd lea      esi, [esp + 0xa0]
433c9cd4 addss    xmm1, dword ptr [esp + 0x1c]
433c9cda movss    xmm2, dword ptr [0x43472c58]
433c9ce2 lea      edi, [esp + 0xe0]
433c9ce9 movaps   xmmword ptr [esp + 0xa0], xmm0
433c9cf1 movaps   xmm3, xmm7
433c9cf4 addss    xmm3, xmm6
433c9cf8 movaps   xmm0, xmm5
433c9cfb andps    xmm0, xmmword ptr [0x4346ffc0]
433c9d02 xorps    xmm1, xmmword ptr [0x434703d0]
433c9d09 addps    xmm0, xmm0
433c9d0c unpcklps xmm1, xmm2
433c9d0f push     0x10
433c9d11 xorps    xmm3, xmmword ptr [0x434703d0]
433c9d18 unpcklps xmm3, xmm4
433c9d1b unpcklps xmm1, xmm3
433c9d1e movaps   xmmword ptr [esp + 0xb4], xmm0
433c9d26 movaps   xmm0, xmm5
433c9d29 andps    xmm0, xmmword ptr [0x4346efd0]
433c9d30 mulps    xmm1, xmm5
433c9d33 pop      ecx
433c9d34 movaps   xmmword ptr [esp + 0xc0], xmm0
433c9d3c movaps   xmmword ptr [esp + 0xd0], xmm1
433c9d44 rep movsd dword ptr es:[edi], dword ptr [esi]
433c9d46 mov      eax, dword ptr [ebx]
433c9d48 lea      ecx, [esp + 0xe0]
433c9d4f push     ecx
433c9d50 push     3
433c9d52 push     ebx
433c9d53 call     dword ptr [eax + 0xb0]
433c9d59 mov      ecx, dword ptr [esp + 0x24]
433c9d5d movss    xmm0, dword ptr [0x43472240]
433c9d65 mov      eax, dword ptr [ecx]
433c9d67 call     dword ptr [eax + 0x74]
433c9d6a mov      edi, dword ptr [esp + 0x18]
433c9d6e mov      eax, dword ptr [ebx]
433c9d70 lea      esi, [edi + 0xcc]
433c9d76 push     esi
433c9d77 push     0
433c9d79 push     ebx
433c9d7a call     dword ptr [eax + 0x100]
433c9d80 test     eax, eax
433c9d82 jns      0x433c9d87
433c9d84 and      dword ptr [esi], 0
433c9d87 mov      ecx, dword ptr [edi + 0xc8]
433c9d8d push     0
433c9d8f push     0
433c9d91 push     ecx
433c9d92 mov      edx, dword ptr [ecx]
433c9d94 call     dword ptr [edx + 0x104]
433c9d9a and      dword ptr [edi + 0xc4], 0
433c9da1 mov      al, 1
433c9da3 jmp      0x433c9da7
433c9da5 xor      al, al
433c9da7 pop      edi
433c9da8 pop      esi
433c9da9 pop      ebx
433c9daa mov      esp, ebp
433c9dac pop      ebp
433c9dad ret      
