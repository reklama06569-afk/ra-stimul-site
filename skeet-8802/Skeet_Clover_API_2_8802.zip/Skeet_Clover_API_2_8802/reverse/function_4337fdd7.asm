4337fdd7 mov      eax, dword ptr [ecx + 0xfc]
4337fddd mov      eax, dword ptr [eax + 0x5c]
4337fde0 test     eax, eax
4337fde2 je       0x4337fe08
4337fde4 mov      al, byte ptr [eax]
4337fde6 test     al, al
4337fde8 je       0x4337fe08
4337fdea call     0x4334d9e5
4337fdef mov      eax, dword ptr [0x4346a334]
4337fdf4 movss    xmm0, dword ptr [eax]
4337fdf8 addss    xmm0, dword ptr [0x4346dd4c]
4337fe00 movss    dword ptr [0x4346a8a0], xmm0
4337fe08 ret      4
