4332fd2b push     ebp
4332fd2c mov      ebp, esp
4332fd2e and      esp, 0xfffffff0
4332fd31 sub      esp, 0x45a8
4332fd37 mov      eax, dword ptr [ebp + 8]
4332fd3a movss    xmm0, dword ptr [0x4347064c]
4332fd42 push     esi
4332fd43 mov      dword ptr [esp + 0x1c], ecx
4332fd47 lea      ecx, [eax + 0x174]
4332fd4d push     edi
4332fd4e mov      esi, ecx
4332fd50 mov      dword ptr [esp + 0x18], ecx
4332fd54 lea      edi, [esp + 0x40]
4332fd58 lea      ecx, [esp + 0x40]
4332fd5c movsd    dword ptr es:[edi], dword ptr [esi]
4332fd5d movsd    dword ptr es:[edi], dword ptr [esi]
4332fd5e movsd    dword ptr es:[edi], dword ptr [esi]
4332fd5f lea      esi, [eax + 0xdc]
4332fd65 movss    xmm1, dword ptr [esi]
4332fd69 movss    xmm2, dword ptr [esi + 4]
4332fd6e movss    xmm3, dword ptr [esi + 8]
4332fd73 mov      dword ptr [esp + 0x24], esi
4332fd77 call     0x4332aa97
4332fd7c mov      edi, eax
4332fd7e mov      dword ptr [esp + 0x3c], edi
4332fd82 test     edi, edi
4332fd84 je       0x43330217
4332fd8a mov      eax, dword ptr [ebp + 0x10]
4332fd8d test     byte ptr [eax + 0x30], 1
4332fd91 mov      eax, dword ptr [ebp + 0x14]
4332fd94 jne      0x4332fddf
4332fd96 test     eax, eax
4332fd98 je       0x4332fddf
4332fd9a mov      eax, dword ptr [esp + 0x20]
4332fd9e test     byte ptr [eax + 0x83c], 0x10
4332fda5 jne      0x4332fddf
4332fda7 lea      eax, [esp + 0x88]
4332fdab add      byte ptr [eax], al
4332fdad add      byte ptr [ebx - 0x2b17af31], cl
4332fdae mov      ecx, edi
4332fdb0 push     eax
4332fdb1 call     0x433fb98a
4332fdb3 mov      ebx, 0xff3000c
4332fdb6 movss    xmm0, dword ptr [esi]
4332fdb8 adc      byte ptr [esi], al
4332fdba movss    xmm1, dword ptr [esi + 4]
4332fdbf movss    xmm2, dword ptr [esi + 8]
4332fdc4 movss    xmm3, dword ptr [eax]
4332fdc8 movss    xmm4, dword ptr [eax + 4]
4332fdcd movss    xmm5, dword ptr [eax + 8]
4332fdd2 call     0x433e7c6b
4332fdd7 test     al, al
4332fdd9 jne      0x43330217
4332fddf push     edi
4332fde0 lea      ecx, [esp + 0x2e4]
4332fde7 call     0x4339f326
4332fdec mov      eax, dword ptr [esp + 0x20]
4332fdf0 lea      ecx, [edi + 8]
4332fdf3 or       dword ptr [esp + 0x2c], 0xffffffff
4332fdf8 mov      dword ptr [esp + 0x10], 0xbf800000
4332fe00 movd     xmm0, dword ptr [eax + 0x860]
4332fe08 mov      eax, dword ptr [eax + 0x85c]
4332fe0e cvtdq2ps xmm0, xmm0
4332fe11 mov      dword ptr [esp + 0x30], eax
4332fe15 mov      eax, dword ptr [ecx]
4332fe17 movss    dword ptr [esp + 0x14], xmm0
4332fe1d call     dword ptr [eax + 0x28]
4332fe20 test     eax, eax
4332fe22 jne      0x4332fe30
4332fe24 jnp      0x4332fdab
4332fe26 daa      
4332fe27 push     ebp
4332fe28 fadd     dword ptr [ecx]
4332fe2a fidivr   dword ptr [ecx - 0x1d39cf0c]
4332fe30 mov      ecx, eax
4332fe32 call     0x433b8a2b
4332fe37 movss    xmm3, dword ptr [0x43472240]
4332fe3f mov      ecx, eax
4332fe41 mov      dword ptr [esp + 0x1c], ecx
4332fe45 cmp      dword ptr [ecx + 0x5d8], 0
4332fe4c jne      0x4332fe58
4332fe4e or       dword ptr [esp + 0x10], 0xffffffff
4332fe53 jmp      0x4332ffb6
4332fe58 mov      eax, dword ptr [ebp + 8]
4332fe5b movss    xmm1, dword ptr [0x4346f868]
4332fe63 mov      esi, dword ptr [ecx + 0x5d4]
4332fe69 mov      ecx, esi
4332fe6b and      ecx, 0x1f
4332fe6e movss    xmm0, dword ptr [eax + 0x198]
4332fe76 addss    xmm0, dword ptr [0x43476928]
4332fe7e mov      eax, dword ptr [0x43467eb8]
4332fe83 movss    xmm2, dword ptr [eax]
4332fe87 mov      eax, dword ptr [0x4346a338]
4332fe8c subss    xmm2, xmm0
4332fe90 subss    xmm1, dword ptr [eax]
4332fe94 movaps   xmm0, xmm2
4332fe97 subss    xmm0, xmm1
4332fe9b addss    xmm1, xmm2
4332fe9f divss    xmm0, dword ptr [eax]
4332fea3 divss    xmm1, dword ptr [eax]
4332fea7 mov      eax, dword ptr [esp + 0x1c]
4332feab mov      ecx, dword ptr [eax + ecx*4 + 0x5dc]
4332feb2 mov      ecx, dword ptr [ecx + 0x4c]
4332feb5 mov      eax, ecx
4332feb7 mov      dword ptr [esp + 0x34], ecx
4332febb addss    xmm0, xmm3
4332febf addss    xmm1, xmm3
4332fec3 cvttss2si edi, xmm0
4332fec7 cvttss2si edx, xmm1
4332fecb cmp      edx, ecx
4332fecd mov      ecx, dword ptr [esp + 0x1c]
4332fed1 cmovle   eax, edx
4332fed4 mov      dword ptr [esp + 0xc], eax
4332fed8 mov      ecx, dword ptr [ecx + 0x5d8]
4332fede dec      ecx
4332fedf add      ecx, esi
4332fee1 mov      esi, dword ptr [esp + 0x1c]
4332fee5 and      ecx, 0x1f
4332fee8 mov      ecx, dword ptr [esi + ecx*4 + 0x5dc]
4332feef mov      eax, dword ptr [ecx + 0x4c]
4332fef2 cmp      edi, eax
4332fef4 cmovge   eax, edi
4332fef7 cmp      dword ptr [esp + 0x30], 1
4332fefc mov      ecx, eax
4332fefe mov      dword ptr [esp + 0x38], eax
4332ff02 mov      eax, dword ptr [0x4346a338]
4332ff07 mov      dword ptr [esp + 0x28], ecx
4332ff0b jne      0x4332ff40
4332ff0d movss    xmm0, dword ptr [0x43472980]
4332ff15 divss    xmm0, dword ptr [eax]
4332ff19 mov      edx, dword ptr [esp + 0x34]
4332ff1d mov      dword ptr [esp + 0x28], ecx
4332ff21 addss    xmm0, xmm3
4332ff25 cvttss2si eax, xmm0
4332ff29 sub      edx, eax
4332ff2b mov      eax, ecx
4332ff2d cmp      edx, eax
4332ff2f jle      0x4332ff40
4332ff31 mov      eax, dword ptr [esp + 0xc]
4332ff35 cmp      edx, eax
4332ff37 cmovl    ecx, edx
4332ff3a mov      dword ptr [esp + 0x28], ecx
4332ff3e jmp      0x4332ff44
4332ff40 mov      eax, dword ptr [esp + 0xc]
4332ff44 mov      edi, dword ptr [esp + 0x3c]
4332ff48 lea      edx, [esp + 0x10]
4332ff4c movss    xmm0, dword ptr [esp + 0x14]
4332ff52 push     edx
4332ff53 lea      edx, [esp + 0x30]
4332ff57 push     edx
4332ff58 mov      edx, dword ptr [esp + 0x20]
4332ff5c push     eax
4332ff5d push     ecx
4332ff5e mov      ecx, dword ptr [esp + 0x34]
4332ff62 push     0
4332ff64 push     esi
4332ff65 push     edi
4332ff66 call     0x433983bb
4332ff6b movss    xmm0, dword ptr [esp + 0x14]
4332ff71 lea      eax, [esp + 0x10]
4332ff75 mov      edx, dword ptr [esp + 0x18]
4332ff79 mov      ecx, dword ptr [esp + 0x24]
4332ff7d push     eax
4332ff7e lea      eax, [esp + 0x30]
4332ff82 push     eax
4332ff83 push     dword ptr [esp + 0x14]
4332ff87 push     dword ptr [esp + 0x34]
4332ff8b push     3
4332ff8d push     dword ptr [esp + 0x30]
4332ff91 push     edi
4332ff92 call     0x433983bb
4332ff97 mov      eax, dword ptr [esp + 0x2c]
4332ff9b mov      dword ptr [esp + 0x10], eax
4332ff9f cmp      eax, -1
4332ffa2 je       0x4332ffb6
4332ffa4 push     0
4332ffa6 push     eax
4332ffa7 push     dword ptr [ebp + 8]
4332ffaa lea      ecx, [esp + 0x2ec]
4332ffb1 call     0x43344c0c
4332ffb6 mov      esi, dword ptr [ebp + 0x10]
4332ffb9 lea      edi, [esp + 0x40]
4332ffbd add      esi, 0xc
4332ffc0 cmp      byte ptr [0x43467144], 0
4332ffc7 movsd    dword ptr es:[edi], dword ptr [esi]
4332ffc8 movsd    dword ptr es:[edi], dword ptr [esi]
4332ffc9 movsd    dword ptr es:[edi], dword ptr [esi]
4332ffca jne      0x4332ffd8
4332ffcc mov      ecx, dword ptr [ebp + 0xc]
4332ffcf lea      edx, [esp + 0x40]
4332ffd3 call     0x433d1edc
4332ffd8 lea      eax, [esp + 0x94]
4332ffdf push     eax
4332ffe0 lea      eax, [esp + 0x8c]
4332ffe7 push     eax
4332ffe8 lea      edx, [esp + 0x60]
4332ffec lea      ecx, [esp + 0x48]
4332fff0 call     0x43366128
4332fff5 mov      esi, dword ptr [ebp + 8]
4332fff8 test     dword ptr [esi], 0x4000
4332fffe jne      0x43330023
43330000 lea      eax, [esp + 0x160]
43330007 mov      ecx, esi
43330009 push     eax
4333000a lea      eax, [esp + 0x98]
43330011 push     eax
43330012 lea      eax, [esp + 0x90]
43330019 push     eax
4333001a lea      edx, [esp + 0x64]
4333001e call     0x43398f25
43330023 cmp      dword ptr [ebp + 0x14], 0
43330027 mov      edi, dword ptr [esp + 0x20]
4333002b je       0x43330038
4333002d mov      al, byte ptr [edi + 0x83c]
43330033 shr      al, 7
43330036 jmp      0x4333003a
43330038 xor      al, al
4333003a push     eax
4333003b push     dword ptr [esi + 0xc]
4333003e lea      ecx, [esp + 0xa8]
43330045 call     0x433eb28b
4333004a xor      ecx, ecx
4333004c mov      dword ptr [esp + 0x64], 0x4346dcec
43330054 test     dword ptr [esi], 0x4000
4333005a mov      eax, 0x4600400b
4333005f mov      dword ptr [esp + 0x68], ecx
43330063 mov      dword ptr [esp + 0x6c], ecx
43330067 mov      dword ptr [esp + 0x70], ecx
4333006b mov      dword ptr [esp + 0x74], ecx
4333006f mov      dword ptr [esp + 0x78], ecx
43330073 mov      dword ptr [esp + 0x7c], eax
43330077 mov      dword ptr [esp + 0x80], eax
4333007e mov      dword ptr [esp + 0x84], 0x3f800000
43330089 mov      dword ptr [esp + 0xc], ecx
4333008d jne      0x433301c7
43330093 cmp      dword ptr [ebp + 0x14], ecx
43330096 je       0x433300de
43330098 cmp      dword ptr [edi + 0x848], ecx
4333009e je       0x433301c7
433300a4 mov      esi, dword ptr [esp + 0x24]
433300a8 lea      eax, [esp + 0xa0]
433300af mov      ecx, dword ptr [ebp + 0xc]
433300b2 mov      edx, esi
433300b4 push     eax
433300b5 lea      eax, [esp + 0x68]
433300b9 push     eax
433300ba lea      eax, [esp + 0x60]
433300be push     eax
433300bf call     0x43364cec
433300c4 test     eax, eax
433300c6 jne      0x433300e2
433300c8 or       esi, 0xffffffff
433300cb lea      ecx, [esp + 0x2e0]
433300d2 call     0x4336630d
433300d7 mov      eax, esi
433300d9 jmp      0x4333021a
433300de mov      esi, dword ptr [esp + 0x24]
433300e2 lea      eax, [esp + 0x160]
433300e9 mov      dword ptr [esp + 0x14], 0x20
433300f1 mov      dword ptr [esp + 0x18], eax
433300f5 lea      ecx, [esp + 0xa0]
433300fc mov      edx, esi
433300fe push     ecx
433300ff lea      ecx, [esp + 0x68]
43330103 push     ecx
43330104 mov      ecx, dword ptr [ebp + 0xc]
43330107 push     eax
43330108 call     0x43364cec
4333010d test     eax, eax
4333010f je       0x43330135
43330111 cmp      dword ptr [ebp + 0x14], 0
43330115 je       0x4333012a
43330117 lea      eax, [esp + 0xa0]
4333011e mov      ecx, edi
43330120 push     eax
43330121 call     0x4331fbdb
43330126 test     al, al
43330128 je       0x43330135
4333012a mov      ecx, dword ptr [esp + 0xc]
4333012e inc      ecx
4333012f mov      dword ptr [esp + 0xc], ecx
43330133 jmp      0x43330139
43330135 mov      ecx, dword ptr [esp + 0xc]
43330139 mov      eax, dword ptr [esp + 0x18]
4333013d add      eax, 0xc
43330140 sub      dword ptr [esp + 0x14], 1
43330145 mov      dword ptr [esp + 0x18], eax
43330149 jne      0x433300f5
4333014b test     ecx, ecx
4333014d jle      0x433300c8
43330153 mov      esi, dword ptr [ebp + 8]
43330156 mov      eax, dword ptr [ebp + 0x14]
43330159 test     eax, eax
4333015b je       0x43330193
4333015d and      dword ptr [edi + 0x85c], 0
43330164 test     dword ptr [esi], 0x4000
4333016a jne      0x43330190
4333016c mov      eax, dword ptr [edi + 0x848]
43330172 shl      eax, 5
43330175 push     0x64
43330177 pop      ecx
43330178 cdq      
43330179 idiv     ecx
4333017b xor      ecx, ecx
4333017d inc      ecx
4333017e cmp      eax, ecx
43330180 cmovg    ecx, eax
43330183 cmp      dword ptr [esp + 0xc], ecx
43330187 jl       0x433300c8
4333018d mov      eax, dword ptr [ebp + 0x14]
43330190 mov      byte ptr [eax], 1
43330193 mov      esi, dword ptr [esp + 0x10]
43330197 cmp      esi, -1
4333019a je       0x433300cb
433301a0 mov      eax, dword ptr [ebp + 8]
433301a3 movss    xmm0, dword ptr [eax + 0x198]
433301ab mov      eax, dword ptr [0x4346a338]
433301b0 divss    xmm0, dword ptr [eax]
433301b4 addss    xmm0, dword ptr [0x43472240]
433301bc cvttss2si eax, xmm0
433301c0 add      esi, eax
433301c2 jmp      0x433300cb
433301c7 mov      edx, dword ptr [esp + 0x24]
433301cb lea      eax, [esp + 0xa0]
433301d2 mov      ecx, dword ptr [ebp + 0xc]
433301d5 push     eax
433301d6 lea      eax, [esp + 0x68]
433301da push     eax
433301db lea      eax, [esp + 0x60]
433301df push     eax
433301e0 call     0x43364cec
433301e5 test     eax, eax
433301e7 je       0x433300c8
433301ed cmp      dword ptr [ebp + 0x14], 0
433301f1 je       0x4333020a
433301f3 lea      eax, [esp + 0xa0]
433301fa mov      ecx, edi
433301fc push     eax
433301fd call     0x4331fbdb
43330202 test     al, al
43330204 je       0x433300c8
4333020a mov      dword ptr [esp + 0xc], 1
43330212 jmp      0x43330156
43330217 or       eax, 0xffffffff
4333021a pop      edi
4333021b pop      esi
4333021c mov      esp, ebp
4333021e pop      ebp
4333021f ret      0x10
