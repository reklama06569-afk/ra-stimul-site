433d7606 push     ebp
433d7607 mov      ebp, esp
433d7609 and      esp, 0xfffffff0
433d760c sub      esp, 0xc78
433d7612 push     esi
433d7613 mov      dword ptr [esp + 0x1c], ecx
433d7617 lea      ecx, [esp + 0x580]
433d761e push     edi
433d761f call     0x433ac5bd
433d7624 mov      ecx, dword ptr [esp + 0x20]
433d7628 mov      esi, dword ptr [ebp + 0xc]
433d762b mov      edx, dword ptr [ebp + 8]
433d762e movss    xmm1, dword ptr [0x434703d0]
433d7636 mov      dword ptr [ecx], edx
433d7638 lea      edi, [ecx + 0x114]
433d763e movss    xmm0, dword ptr [ecx + 0x18]
433d7643 lea      esi, [esi + 0x24]
433d7646 movss    dword ptr [ecx + 0x104], xmm0
433d764e mov      eax, dword ptr [esi + 0xc]
433d7651 mov      dword ptr [ecx + 0x110], eax
433d7657 movsd    dword ptr es:[edi], dword ptr [esi]
433d7658 movsd    dword ptr es:[edi], dword ptr [esi]
433d7659 movsd    dword ptr es:[edi], dword ptr [esi]
433d765a mov      al, byte ptr [ecx + 0x108]
433d7660 and      dword ptr [ecx + 0x5c], 0
433d7664 and      al, 0xc1
433d7666 test     byte ptr [ecx + 0x1c], 1
433d766a jne      0x433d7677
433d766c xorps    xmm0, xmm1
433d766f movss    dword ptr [ecx + 0xc4], xmm0
433d7677 and      al, 0xfe
433d7679 mov      byte ptr [ecx + 0x108], al
433d767f mov      dword ptr [esp + 0x1c], 0x524f1bbc
433d7687 mov      eax, dword ptr [esp + 0x1c]
433d768b mov      ecx, dword ptr [edx]
433d768d rol      eax, 0x15
433d7690 neg      eax
433d7692 xor      eax, 0x875b63f
433d7697 rol      eax, 0x1e
433d769a ror      eax, 0x19
433d769d mov      ecx, dword ptr [eax + ecx]
433d76a0 mov      dword ptr [esp + 0x590], ecx
433d76a7 call     0x433e533f
433d76ac mov      eax, dword ptr [0x434685cc]
433d76b1 mov      ecx, dword ptr [ebp + 8]
433d76b4 fstp     dword ptr [esp + 0x1c]
433d76b8 movss    xmm1, dword ptr [esp + 0x1c]
433d76be mov      eax, dword ptr [eax]
433d76c0 xor      eax, dword ptr [0x43468a84]
433d76c6 xor      eax, 0x3eb71843
433d76cb movss    xmm0, dword ptr [eax + ecx]
433d76d0 call     0x43367633
433d76d5 mov      ecx, dword ptr [esp + 0x20]
433d76d9 movaps   xmm3, xmm0
433d76dc movss    xmm0, dword ptr [0x43470830]
433d76e4 movss    dword ptr [ecx + 0x10c], xmm3
433d76ec test     dword ptr [ecx + 0x110], 0x20000
433d76f6 je       0x433d774d
433d76f8 movss    xmm2, dword ptr [ecx + 0x14]
433d76fd movaps   xmm4, xmm3
433d7700 movss    xmm1, dword ptr [ecx + 0x10]
433d7705 mulss    xmm4, xmm0
433d7709 movss    xmm0, dword ptr [ecx + 0x18]
433d770e mulss    xmm2, xmm2
433d7712 mulss    xmm0, xmm0
433d7716 mulss    xmm1, xmm1
433d771a addss    xmm2, xmm0
433d771e movaps   xmm0, xmm4
433d7721 addss    xmm0, dword ptr [0x43472190]
433d7729 addss    xmm2, xmm1
433d772d movaps   xmm1, xmm2
433d7730 sqrtss   xmm1, xmm1
433d7734 comiss   xmm0, xmm1
433d7737 movss    dword ptr [esp + 0x578], xmm1
433d7740 jbe      0x433d774d
433d7742 movss    dword ptr [ecx + 0x10c], xmm4
433d774a movaps   xmm3, xmm4
433d774d mov      edx, dword ptr [ecx + 0x1c]
433d7750 mov      eax, edx
433d7752 test     dl, 1
433d7755 je       0x433d7764
433d7757 mulss    xmm3, dword ptr [ecx + 0x24]
433d775c movss    dword ptr [ecx + 0x10c], xmm3
433d7764 movss    xmm4, dword ptr [ecx + 0x34]
433d7769 xorps    xmm7, xmm7
433d776c comiss   xmm4, xmm7
433d776f movss    xmm1, dword ptr [0x434704a0]
433d7777 movss    xmm5, dword ptr [0x43470514]
433d777f movss    dword ptr [esp + 0x18], xmm7
433d7785 jbe      0x433d77c1
433d7787 movaps   xmm0, xmm4
433d778a mov      edx, eax
433d778c divss    xmm0, xmm1
433d7790 movaps   xmm1, xmm5
433d7793 subss    xmm1, xmm0
433d7797 movaps   xmm0, xmm7
433d779a movaps   xmm2, xmm1
433d779d maxss    xmm2, xmm0
433d77a1 movaps   xmm0, xmm5
433d77a4 minss    xmm2, xmm0
433d77a8 movss    dword ptr [esp + 0x48], xmm2
433d77ae mulss    xmm2, xmm2
433d77b2 mulss    xmm2, xmm3
433d77b6 movaps   xmm3, xmm2
433d77b9 movss    dword ptr [ecx + 0x10c], xmm3
433d77c1 lea      esi, [ecx + 0x114]
433d77c7 movss    xmm5, dword ptr [esi]
433d77cb movss    xmm1, dword ptr [esi + 4]
433d77d0 movaps   xmm2, xmm5
433d77d3 movss    xmm0, dword ptr [esi + 8]
433d77d8 mulss    xmm2, xmm5
433d77dc mulss    xmm1, xmm1
433d77e0 mulss    xmm0, xmm0
433d77e4 addss    xmm2, xmm1
433d77e8 addss    xmm2, xmm0
433d77ec ucomiss  xmm2, xmm7
433d77ef lahf     
433d77f0 test     ah, 0x44
433d77f3 jnp      0x433d7841
433d77f5 movaps   xmm0, xmm3
433d77f8 mulss    xmm0, xmm3
433d77fc comiss   xmm2, xmm0
433d77ff jbe      0x433d7841
433d7801 movaps   xmm0, xmm2
433d7804 sqrtss   xmm0, xmm0
433d7808 divss    xmm3, xmm0
433d780c movss    dword ptr [esp + 0x57c], xmm0
433d7815 mulss    xmm5, xmm3
433d7819 movss    dword ptr [esi], xmm5
433d781d movss    xmm0, dword ptr [esi + 4]
433d7822 mulss    xmm0, xmm3
433d7826 movss    dword ptr [esi + 4], xmm0
433d782b movss    xmm0, dword ptr [esi + 8]
433d7830 mulss    xmm0, xmm3
433d7834 movss    dword ptr [esi + 8], xmm0
433d7839 movss    xmm4, dword ptr [ecx + 0x34]
433d783e mov      edx, dword ptr [ecx + 0x1c]
433d7841 comiss   xmm4, xmm7
433d7844 jbe      0x433d7868
433d7846 movss    xmm0, dword ptr [ecx + 0x100]
433d784e mulss    xmm0, dword ptr [ecx + 0xe0]
433d7856 subss    xmm4, xmm0
433d785a comiss   xmm7, xmm4
433d785d movss    dword ptr [ecx + 0x34], xmm4
433d7862 jbe      0x433d7868
433d7864 and      dword ptr [ecx + 0x34], 0
433d7868 mov      al, byte ptr [ecx + 0xcc]
433d786e movsd    xmm0, qword ptr [0x43472298]
433d7876 movss    xmm5, dword ptr [0x4347259c]
433d787e movss    xmm4, dword ptr [0x434720b0]
433d7886 movss    xmm1, dword ptr [0x43472828]
433d788e mov      byte ptr [esp + 0x17], al
433d7892 movsd    qword ptr [esp + 0x90], xmm0
433d789b cmp      al, 2
433d789d je       0x433d854d
433d78a3 lea      eax, [ecx + 0xc8]
433d78a9 mov      dword ptr [eax], 0x3f800000
433d78af lea      edi, [esp + 0x58]
433d78b3 or       dword ptr [esp + 0x474], 0xffffffff
433d78bb or       dword ptr [esp + 0x480], 0xffffffff
433d78c3 mov      dword ptr [esp + 0x74], eax
433d78c7 xor      eax, eax
433d78c9 mov      word ptr [esp + 0x466], ax
433d78d1 mov      dword ptr [esp + 0x47c], eax
433d78d8 lea      eax, [ecx + 4]
433d78db mov      dword ptr [esp + 0x45c], 0x3f800000
433d78e6 mov      esi, eax
433d78e8 movss    xmm0, dword ptr [ecx + 0x18]
433d78ed comiss   xmm0, xmm7
433d78f0 mov      dword ptr [esp + 0x50], eax
433d78f4 movsd    dword ptr es:[edi], dword ptr [esi]
433d78f5 movsd    dword ptr es:[edi], dword ptr [esi]
433d78f6 seta     dh
433d78f9 movsd    dword ptr es:[edi], dword ptr [esi]
433d78fa movss    xmm3, dword ptr [esp + 0x60]
433d7900 comiss   xmm0, xmm4
433d7903 subss    xmm3, xmm5
433d7907 seta     dl
433d790a movss    dword ptr [esp + 0x3c], xmm3
433d7910 test     dl, dl
433d7912 je       0x433d7930
433d7914 test     byte ptr [ecx + 0x1c], 1
433d7918 je       0x433d8547
433d791e subss    xmm0, xmm0
433d7922 comiss   xmm0, xmm4
433d7925 seta     dl
433d7928 test     dl, dl
433d792a jne      0x433d8547
433d7930 test     dh, dh
433d7932 je       0x433d793f
433d7934 cmp      byte ptr [esp + 0x17], 9
433d7939 je       0x433d8547
433d793f mov      edx, dword ptr [0x43468304]
433d7945 lea      edi, [esp + 0x68]
433d7949 movss    xmm2, dword ptr [esp + 0x58]
433d794f mov      esi, eax
433d7951 mov      eax, dword ptr [ecx]
433d7953 movaps   xmm0, xmm3
433d7956 movss    xmm1, dword ptr [esp + 0x5c]
433d795c movsd    dword ptr es:[edi], dword ptr [esi]
433d795d movsd    dword ptr es:[edi], dword ptr [esi]
433d795e movsd    dword ptr es:[edi], dword ptr [esi]
433d795f and      dword ptr [esp + 0x4d4], 0
433d7967 subss    xmm1, dword ptr [esp + 0x6c]
433d796d subss    xmm2, dword ptr [esp + 0x68]
433d7973 subss    xmm0, dword ptr [esp + 0x70]
433d7979 mov      dword ptr [esp + 0x4cc], eax
433d7980 mov      dword ptr [esp + 0x4c8], 0x4346edc0
433d798b mov      dword ptr [esp + 0x4d0], 8
433d7996 mov      eax, dword ptr [edx]
433d7998 mov      edi, dword ptr [eax + 0x14]
433d799b mov      eax, dword ptr [ecx + 0xd0]
433d79a1 and      dword ptr [esp + 0x6f0], 0
433d79a9 movss    dword ptr [esp + 0x6c4], xmm1
433d79b2 movss    dword ptr [esp + 0x6c0], xmm2
433d79bb mulss    xmm1, xmm1
433d79bf mov      dword ptr [esp + 0x1c], eax
433d79c3 mulss    xmm2, xmm2
433d79c7 mov      byte ptr [esp + 0x6f5], 1
433d79cf movss    dword ptr [esp + 0x6c8], xmm0
433d79d8 mulss    xmm0, xmm0
433d79dc addss    xmm1, xmm2
433d79e0 addss    xmm1, xmm0
433d79e4 ucomiss  xmm1, xmm7
433d79e7 lahf     
433d79e8 test     ah, 0x44
433d79eb jp       0x433d79f5
433d79ed mov      byte ptr [esp + 0x6f5], 0
433d79f5 movss    xmm3, dword ptr [ecx + 0x44]
433d79fa lea      eax, [esp + 0x430]
433d7a01 movss    xmm4, dword ptr [ecx + 0x48]
433d7a06 movaps   xmm2, xmm3
433d7a09 movss    xmm7, dword ptr [ecx + 0x3c]
433d7a0e movaps   xmm1, xmm4
433d7a11 movss    xmm6, dword ptr [ecx + 0x38]
433d7a16 subss    xmm1, xmm7
433d7a1a movss    xmm0, dword ptr [ecx + 0x40]
433d7a1f subss    xmm2, xmm6
433d7a23 movss    xmm5, dword ptr [ecx + 0x4c]
433d7a28 addss    xmm6, xmm3
433d7a2c movss    dword ptr [esp + 0x24], xmm0
433d7a32 addss    xmm7, xmm4
433d7a36 movaps   xmm0, xmm5
433d7a39 mov      ecx, edx
433d7a3b subss    xmm0, dword ptr [esp + 0x24]
433d7a41 mulss    xmm1, dword ptr [0x43472240]
433d7a49 push     eax
433d7a4a mulss    xmm2, dword ptr [0x43472240]
433d7a52 lea      eax, [esp + 0x4cc]
433d7a59 push     eax
433d7a5a mulss    xmm0, dword ptr [0x43472240]
433d7a62 lea      eax, [esp + 0x6b8]
433d7a69 movss    dword ptr [esp + 0x6ec], xmm1
433d7a72 mulss    xmm1, xmm1
433d7a76 movss    dword ptr [esp + 0x6f0], xmm0
433d7a7f mulss    xmm0, xmm0
433d7a83 movss    dword ptr [esp + 0x6e8], xmm2
433d7a8c mulss    xmm2, xmm2
433d7a90 push     dword ptr [esp + 0x24]
433d7a94 addss    xmm1, xmm2
433d7a98 push     eax
433d7a99 addss    xmm1, xmm0
433d7a9d cvtps2pd xmm0, xmm1
433d7aa0 movsd    xmm1, qword ptr [esp + 0xa0]
433d7aa9 comisd   xmm1, xmm0
433d7aad movss    xmm1, dword ptr [esp + 0x34]
433d7ab3 movss    xmm0, dword ptr [0x43472240]
433d7abb addss    xmm1, xmm5
433d7abf mulss    xmm6, xmm0
433d7ac3 seta     byte ptr [esp + 0x704]
433d7acb mulss    xmm7, xmm0
433d7acf mulss    xmm1, xmm0
433d7ad3 movss    xmm0, dword ptr [esp + 0x78]
433d7ad9 addss    xmm0, xmm6
433d7add movss    dword ptr [esp + 0x6c0], xmm0
433d7ae6 movaps   xmm0, xmm7
433d7ae9 addss    xmm0, dword ptr [esp + 0x7c]
433d7aef movss    dword ptr [esp + 0x6c4], xmm0
433d7af8 movss    xmm0, dword ptr [esp + 0x80]
433d7b01 addss    xmm0, xmm1
433d7b05 movss    dword ptr [esp + 0x6c8], xmm0
433d7b0e movss    xmm0, dword ptr [0x4346f858]
433d7b16 mulss    xmm6, xmm0
433d7b1a mulss    xmm7, xmm0
433d7b1e mulss    xmm1, xmm0
433d7b22 movss    dword ptr [esp + 0x6e0], xmm6
433d7b2b movss    dword ptr [esp + 0x6e4], xmm7
433d7b34 movss    dword ptr [esp + 0x6e8], xmm1
433d7b3d call     edi
433d7b3f movss    xmm0, dword ptr [esp + 0x45c]
433d7b48 movss    xmm1, dword ptr [0x43470514]
433d7b50 comiss   xmm1, xmm0
433d7b53 movss    dword ptr [esp + 0x54], xmm0
433d7b59 ja       0x433d7b6f
433d7b5b cmp      byte ptr [esp + 0x466], 0
433d7b63 jne      0x433d7b6f
433d7b65 cmp      byte ptr [esp + 0x467], 0
433d7b6d je       0x433d7b8f
433d7b6f cmp      dword ptr [esp + 0x47c], 0
433d7b77 je       0x433d7b8f
433d7b79 movss    xmm0, dword ptr [esp + 0x450]
433d7b82 comiss   xmm0, dword ptr [0x4346fd8c]
433d7b89 jae      0x433d84b8
433d7b8f mov      ecx, dword ptr [esp + 0x20]
433d7b93 lea      esi, [esp + 0x43c]
433d7b9a lea      edi, [esp + 0x110]
433d7ba1 movsd    dword ptr es:[edi], dword ptr [esi]
433d7ba2 mov      eax, dword ptr [ecx]
433d7ba4 and      dword ptr [esp + 0x2dc], 0
433d7bac movsd    dword ptr es:[edi], dword ptr [esi]
433d7bad mov      dword ptr [esp + 0x2d0], 0x4346edc0
433d7bb8 mov      dword ptr [esp + 0x2d4], eax
433d7bbf mov      dword ptr [esp + 0x2d8], 8
433d7bca movsd    dword ptr es:[edi], dword ptr [esi]
433d7bcb lea      esi, [ecx + 0x38]
433d7bce lea      edi, [esp + 0xb0]
433d7bd5 movsd    dword ptr es:[edi], dword ptr [esi]
433d7bd6 movsd    dword ptr es:[edi], dword ptr [esi]
433d7bd7 movsd    dword ptr es:[edi], dword ptr [esi]
433d7bd8 mov      esi, ecx
433d7bda movss    xmm0, dword ptr [esi + 0x4c]
433d7bdf movss    xmm1, dword ptr [esi + 0x48]
433d7be4 movss    dword ptr [esp + 0x24], xmm0
433d7bea movss    xmm0, dword ptr [esp + 0x18]
433d7bf0 call     0x43367633
433d7bf5 movss    xmm1, dword ptr [esi + 0x44]
433d7bfa movss    dword ptr [esp + 0x1c], xmm0
433d7c00 movss    xmm0, dword ptr [esp + 0x18]
433d7c06 call     0x43367633
433d7c0b and      dword ptr [esp + 0x1d0], 0
433d7c13 movaps   xmm3, xmm0
433d7c16 movss    xmm0, dword ptr [esi + 4]
433d7c1b movss    xmm2, dword ptr [esp + 0x58]
433d7c21 movss    xmm1, dword ptr [esp + 0x5c]
433d7c27 subss    xmm2, xmm0
433d7c2b movss    dword ptr [esp + 0x30], xmm0
433d7c31 movss    dword ptr [esp + 0x68], xmm3
433d7c37 movss    dword ptr [esp + 0x1a0], xmm2
433d7c40 movss    xmm0, dword ptr [esi + 8]
433d7c45 subss    xmm1, xmm0
433d7c49 movss    dword ptr [esp + 0x44], xmm0
433d7c4f movss    xmm0, dword ptr [esp + 0x3c]
433d7c55 mulss    xmm2, xmm2
433d7c59 movss    dword ptr [esp + 0x1a4], xmm1
433d7c62 movss    xmm7, dword ptr [esi + 0xc]
433d7c67 subss    xmm0, xmm7
433d7c6b mulss    xmm1, xmm1
433d7c6f mov      byte ptr [esp + 0x1d5], 1
433d7c77 addss    xmm1, xmm2
433d7c7b movss    dword ptr [esp + 0x1a8], xmm0
433d7c84 mulss    xmm0, xmm0
433d7c88 addss    xmm1, xmm0
433d7c8c ucomiss  xmm1, dword ptr [esp + 0x18]
433d7c91 lahf     
433d7c92 test     ah, 0x44
433d7c95 jp       0x433d7c9f
433d7c97 mov      byte ptr [esp + 0x1d5], 0
433d7c9f movss    xmm6, dword ptr [esp + 0x1c]
433d7ca5 lea      edx, [esp + 0x430]
433d7cac movss    xmm4, dword ptr [esp + 0xb0]
433d7cb5 movaps   xmm2, xmm3
433d7cb8 movss    xmm5, dword ptr [0x43472240]
433d7cc0 subss    xmm2, xmm4
433d7cc4 movss    xmm0, dword ptr [esp + 0x24]
433d7cca movaps   xmm1, xmm6
433d7ccd subss    xmm1, dword ptr [esp + 0xb4]
433d7cd6 movss    xmm3, dword ptr [esp + 0xb8]
433d7cdf addss    xmm4, dword ptr [esp + 0x68]
433d7ce5 subss    xmm0, xmm3
433d7ce9 mulss    xmm2, xmm5
433d7ced mov      ecx, dword ptr [0x43468304]
433d7cf3 mulss    xmm1, xmm5
433d7cf7 push     edx
433d7cf8 addss    xmm6, dword ptr [esp + 0xb8]
433d7d01 mulss    xmm0, xmm5
433d7d05 lea      edx, [esp + 0x2d4]
433d7d0c push     edx
433d7d0d movss    dword ptr [esp + 0x1cc], xmm1
433d7d16 lea      edx, [esp + 0x198]
433d7d1d movss    dword ptr [esp + 0x1c8], xmm2
433d7d26 movss    dword ptr [esp + 0x1d0], xmm0
433d7d2f mulss    xmm1, xmm1
433d7d33 mulss    xmm2, xmm2
433d7d37 mulss    xmm0, xmm0
433d7d3b addss    xmm3, dword ptr [esp + 0x2c]
433d7d41 addss    xmm1, xmm2
433d7d45 mulss    xmm4, xmm5
433d7d49 mulss    xmm6, xmm5
433d7d4d mulss    xmm3, xmm5
433d7d51 addss    xmm1, xmm0
433d7d55 addss    xmm7, xmm3
433d7d59 cvtps2pd xmm0, xmm1
433d7d5c movsd    xmm1, qword ptr [esp + 0x98]
433d7d65 comisd   xmm1, xmm0
433d7d69 movaps   xmm0, xmm4
433d7d6c movss    dword ptr [esp + 0x1a0], xmm7
433d7d75 addss    xmm0, dword ptr [esp + 0x38]
433d7d7b seta     byte ptr [esp + 0x1dc]
433d7d83 movss    dword ptr [esp + 0x198], xmm0
433d7d8c movaps   xmm0, xmm6
433d7d8f addss    xmm0, dword ptr [esp + 0x4c]
433d7d95 movss    dword ptr [esp + 0x19c], xmm0
433d7d9e movss    xmm0, dword ptr [0x4346f858]
433d7da6 mulss    xmm4, xmm0
433d7daa mulss    xmm6, xmm0
433d7dae mulss    xmm3, xmm0
433d7db2 movss    dword ptr [esp + 0x1b8], xmm4
433d7dbb movss    dword ptr [esp + 0x1bc], xmm6
433d7dc4 movss    dword ptr [esp + 0x1c0], xmm3
433d7dcd push     dword ptr [esi + 0xd0]
433d7dd3 mov      eax, dword ptr [ecx]
433d7dd5 push     edx
433d7dd6 call     dword ptr [eax + 0x14]
433d7dd9 cmp      dword ptr [esp + 0x47c], 0
433d7de1 je       0x433d7dfd
433d7de3 movss    xmm0, dword ptr [esp + 0x450]
433d7dec movss    xmm2, dword ptr [0x4346fd8c]
433d7df4 comiss   xmm0, xmm2
433d7df7 jae      0x433d845f
433d7dfd movss    xmm0, dword ptr [esi + 0x40]
433d7e02 movss    xmm1, dword ptr [esi + 0x3c]
433d7e07 movss    dword ptr [esp + 0x24], xmm0
433d7e0d movss    xmm0, dword ptr [esp + 0x18]
433d7e13 call     0x4332fc35
433d7e18 movss    xmm1, dword ptr [esi + 0x38]
433d7e1d movss    dword ptr [esp + 0x1c], xmm0
433d7e23 movss    xmm0, dword ptr [esp + 0x18]
433d7e29 call     0x4332fc35
433d7e2e movss    xmm2, dword ptr [esp + 0x58]
433d7e34 lea      esi, [esi + 0x44]
433d7e37 movss    xmm1, dword ptr [esp + 0x5c]
433d7e3d lea      edi, [esp + 0x68]
433d7e41 movsd    dword ptr es:[edi], dword ptr [esi]
433d7e42 movaps   xmm5, xmm0
433d7e45 movsd    dword ptr es:[edi], dword ptr [esi]
433d7e46 movsd    dword ptr es:[edi], dword ptr [esi]
433d7e47 mov      edi, dword ptr [esp + 0x50]
433d7e4b and      dword ptr [esp + 0x1d0], 0
433d7e53 movss    xmm0, dword ptr [edi]
433d7e57 subss    xmm2, xmm0
433d7e5b movss    dword ptr [esp + 0x30], xmm0
433d7e61 movss    xmm0, dword ptr [esp + 0x3c]
433d7e67 movss    dword ptr [esp + 0x1a0], xmm2
433d7e70 movss    xmm7, dword ptr [edi + 4]
433d7e75 subss    xmm1, xmm7
433d7e79 mulss    xmm2, xmm2
433d7e7d movss    dword ptr [esp + 0x1a4], xmm1
433d7e86 movss    xmm3, dword ptr [edi + 8]
433d7e8b subss    xmm0, xmm3
433d7e8f mulss    xmm1, xmm1
433d7e93 mov      byte ptr [esp + 0x1d5], 1
433d7e9b movss    dword ptr [esp + 0x44], xmm3
433d7ea1 addss    xmm1, xmm2
433d7ea5 movss    dword ptr [esp + 0x1a8], xmm0
433d7eae mulss    xmm0, xmm0
433d7eb2 addss    xmm1, xmm0
433d7eb6 ucomiss  xmm1, dword ptr [esp + 0x18]
433d7ebb lahf     
433d7ebc test     ah, 0x44
433d7ebf jp       0x433d7ec9
433d7ec1 mov      byte ptr [esp + 0x1d5], 0
433d7ec9 movss    xmm1, dword ptr [esp + 0x6c]
433d7ecf lea      edx, [esp + 0x430]
433d7ed6 movss    xmm6, dword ptr [esp + 0x1c]
433d7edc movss    xmm2, dword ptr [esp + 0x68]
433d7ee2 subss    xmm1, xmm6
433d7ee6 movss    xmm4, dword ptr [0x43472240]
433d7eee subss    xmm2, xmm5
433d7ef2 movss    xmm3, dword ptr [esp + 0x70]
433d7ef8 addss    xmm5, dword ptr [esp + 0x68]
433d7efe movaps   xmm0, xmm3
433d7f01 mov      ecx, dword ptr [0x43468304]
433d7f07 subss    xmm0, dword ptr [esp + 0x24]
433d7f0d mulss    xmm2, xmm4
433d7f11 mov      esi, dword ptr [esp + 0x20]
433d7f15 mulss    xmm1, xmm4
433d7f19 push     edx
433d7f1a mulss    xmm0, xmm4
433d7f1e lea      edx, [esp + 0x2d4]
433d7f25 push     edx
433d7f26 addss    xmm3, dword ptr [esp + 0x2c]
433d7f2c movss    dword ptr [esp + 0x1c8], xmm2
433d7f35 lea      edx, [esp + 0x198]
433d7f3c movss    dword ptr [esp + 0x1cc], xmm1
433d7f45 movss    dword ptr [esp + 0x1d0], xmm0
433d7f4e mulss    xmm2, xmm2
433d7f52 mulss    xmm1, xmm1
433d7f56 mulss    xmm0, xmm0
433d7f5a addss    xmm6, dword ptr [esp + 0x74]
433d7f60 addss    xmm2, xmm1
433d7f64 mulss    xmm5, xmm4
433d7f68 movsd    xmm1, qword ptr [esp + 0x98]
433d7f71 mulss    xmm3, xmm4
433d7f75 addss    xmm2, xmm0
433d7f79 mulss    xmm6, xmm4
433d7f7d addss    xmm7, xmm6
433d7f81 cvtps2pd xmm0, xmm2
433d7f84 movss    dword ptr [esp + 0x19c], xmm7
433d7f8d comisd   xmm1, xmm0
433d7f91 movaps   xmm0, xmm5
433d7f94 addss    xmm0, dword ptr [esp + 0x38]
433d7f9a seta     byte ptr [esp + 0x1dc]
433d7fa2 movss    dword ptr [esp + 0x198], xmm0
433d7fab movss    xmm0, dword ptr [esp + 0x4c]
433d7fb1 addss    xmm0, xmm3
433d7fb5 movss    dword ptr [esp + 0x1a0], xmm0
433d7fbe movss    xmm0, dword ptr [0x4346f858]
433d7fc6 mulss    xmm5, xmm0
433d7fca mulss    xmm6, xmm0
433d7fce mulss    xmm3, xmm0
433d7fd2 movss    dword ptr [esp + 0x1b8], xmm5
433d7fdb movss    dword ptr [esp + 0x1bc], xmm6
433d7fe4 movss    dword ptr [esp + 0x1c0], xmm3
433d7fed push     dword ptr [esi + 0xd0]
433d7ff3 mov      eax, dword ptr [ecx]
433d7ff5 push     edx
433d7ff6 call     dword ptr [eax + 0x14]
433d7ff9 cmp      dword ptr [esp + 0x47c], 0
433d8001 je       0x433d801d
433d8003 movss    xmm0, dword ptr [esp + 0x450]
433d800c movss    xmm2, dword ptr [0x4346fd8c]
433d8014 comiss   xmm0, xmm2
433d8017 jae      0x433d845f
433d801d movss    xmm0, dword ptr [esi + 0x40]
433d8022 movss    xmm1, dword ptr [esi + 0x3c]
433d8027 movss    dword ptr [esp + 0x78], xmm0
433d802d movss    xmm0, dword ptr [esp + 0x18]
433d8033 call     0x4332fc35
433d8038 movss    xmm1, dword ptr [esi + 0x4c]
433d803d movss    dword ptr [esp + 0x34], xmm0
433d8043 movss    xmm0, dword ptr [esi + 0x38]
433d8048 movss    dword ptr [esp + 0x24], xmm0
433d804e movss    xmm0, dword ptr [esi + 0x48]
433d8053 movss    dword ptr [esp + 0x30], xmm1
433d8059 movss    xmm1, dword ptr [esi + 0x44]
433d805e movss    dword ptr [esp + 0x1c], xmm0
433d8064 movss    xmm0, dword ptr [esp + 0x18]
433d806a call     0x43367633
433d806f and      dword ptr [esp + 0x1d0], 0
433d8077 movaps   xmm4, xmm0
433d807a movss    xmm7, dword ptr [edi]
433d807e movss    xmm2, dword ptr [esp + 0x58]
433d8084 movss    xmm1, dword ptr [esp + 0x5c]
433d808a subss    xmm2, xmm7
433d808e movss    dword ptr [esp + 0x1a0], xmm2
433d8097 movss    xmm0, dword ptr [edi + 4]
433d809c subss    xmm1, xmm0
433d80a0 movss    dword ptr [esp + 0x44], xmm0
433d80a6 movss    xmm0, dword ptr [esp + 0x3c]
433d80ac mulss    xmm2, xmm2
433d80b0 movss    dword ptr [esp + 0x1a4], xmm1
433d80b9 movss    xmm3, dword ptr [edi + 8]
433d80be subss    xmm0, xmm3
433d80c2 mulss    xmm1, xmm1
433d80c6 mov      byte ptr [esp + 0x1d5], 1
433d80ce movss    dword ptr [esp + 0x50], xmm3
433d80d4 addss    xmm1, xmm2
433d80d8 movss    dword ptr [esp + 0x1a8], xmm0
433d80e1 mulss    xmm0, xmm0
433d80e5 addss    xmm1, xmm0
433d80e9 ucomiss  xmm1, dword ptr [esp + 0x18]
433d80ee lahf     
433d80ef test     ah, 0x44
433d80f2 jp       0x433d80fc
433d80f4 mov      byte ptr [esp + 0x1d5], 0
433d80fc movss    xmm5, dword ptr [esp + 0x1c]
433d8102 lea      edx, [esp + 0x430]
433d8109 movss    xmm3, dword ptr [0x43472240]
433d8111 movaps   xmm1, xmm5
433d8114 subss    xmm1, dword ptr [esp + 0x34]
433d811a movss    xmm6, dword ptr [esp + 0x30]
433d8120 movaps   xmm2, xmm4
433d8123 subss    xmm2, dword ptr [esp + 0x24]
433d8129 addss    xmm5, dword ptr [esp + 0x34]
433d812f movaps   xmm0, xmm6
433d8132 mov      ecx, dword ptr [0x43468304]
433d8138 subss    xmm0, dword ptr [esp + 0x78]
433d813e mulss    xmm1, xmm3
433d8142 push     edx
433d8143 addss    xmm6, dword ptr [esp + 0x7c]
433d8149 mulss    xmm2, xmm3
433d814d lea      edx, [esp + 0x2d4]
433d8154 push     edx
433d8155 mulss    xmm0, xmm3
433d8159 lea      edx, [esp + 0x198]
433d8160 movss    dword ptr [esp + 0x1cc], xmm1
433d8169 movss    dword ptr [esp + 0x1c8], xmm2
433d8172 movss    dword ptr [esp + 0x1d0], xmm0
433d817b mulss    xmm1, xmm1
433d817f mulss    xmm2, xmm2
433d8183 mulss    xmm0, xmm0
433d8187 addss    xmm4, dword ptr [esp + 0x2c]
433d818d addss    xmm1, xmm2
433d8191 mulss    xmm5, xmm3
433d8195 mulss    xmm6, xmm3
433d8199 mulss    xmm4, xmm3
433d819d addss    xmm1, xmm0
433d81a1 addss    xmm7, xmm4
433d81a5 cvtps2pd xmm0, xmm1
433d81a8 movsd    xmm1, qword ptr [esp + 0x98]
433d81b1 comisd   xmm1, xmm0
433d81b5 movaps   xmm0, xmm5
433d81b8 movss    dword ptr [esp + 0x198], xmm7
433d81c1 addss    xmm0, dword ptr [esp + 0x4c]
433d81c7 seta     byte ptr [esp + 0x1dc]
433d81cf movss    dword ptr [esp + 0x19c], xmm0
433d81d8 movaps   xmm0, xmm6
433d81db addss    xmm0, dword ptr [esp + 0x58]
433d81e1 movss    dword ptr [esp + 0x1a0], xmm0
433d81ea movss    xmm0, dword ptr [0x4346f858]
433d81f2 mulss    xmm4, xmm0
433d81f6 mulss    xmm5, xmm0
433d81fa mulss    xmm6, xmm0
433d81fe movss    dword ptr [esp + 0x1b8], xmm4
433d8207 movss    dword ptr [esp + 0x1bc], xmm5
433d8210 movss    dword ptr [esp + 0x1c0], xmm6
433d8219 push     dword ptr [esi + 0xd0]
433d821f mov      eax, dword ptr [ecx]
433d8221 push     edx
433d8222 call     dword ptr [eax + 0x14]
433d8225 cmp      dword ptr [esp + 0x47c], 0
433d822d je       0x433d8249
433d822f movss    xmm0, dword ptr [esp + 0x450]
433d8238 movss    xmm2, dword ptr [0x4346fd8c]
433d8240 comiss   xmm0, xmm2
433d8243 jae      0x433d845f
433d8249 movss    xmm0, dword ptr [esi + 0x40]
433d824e movss    xmm1, dword ptr [esi + 0x38]
433d8253 movss    dword ptr [esp + 0x34], xmm0
433d8259 movss    xmm0, dword ptr [esi + 0x3c]
433d825e movss    dword ptr [esp + 0x1c], xmm0
433d8264 movss    xmm0, dword ptr [esp + 0x18]
433d826a call     0x4332fc35
433d826f movss    xmm1, dword ptr [esi + 0x4c]
433d8274 movss    dword ptr [esp + 0x24], xmm0
433d827a movss    xmm0, dword ptr [esp + 0x18]
433d8280 movss    dword ptr [esp + 0x30], xmm1
433d8286 movss    xmm1, dword ptr [esi + 0x48]
433d828b call     0x43367633
433d8290 movss    xmm4, dword ptr [esi + 0x44]
433d8295 movaps   xmm5, xmm0
433d8298 and      dword ptr [esp + 0x1d0], 0
433d82a0 movss    xmm7, dword ptr [edi]
433d82a4 movss    xmm2, dword ptr [esp + 0x58]
433d82aa movss    xmm1, dword ptr [esp + 0x5c]
433d82b0 subss    xmm2, xmm7
433d82b4 movss    dword ptr [esp + 0x44], xmm5
433d82ba movss    dword ptr [esp + 0x1a0], xmm2
433d82c3 movss    xmm0, dword ptr [edi + 4]
433d82c8 subss    xmm1, xmm0
433d82cc movss    dword ptr [esp + 0x50], xmm0
433d82d2 movss    xmm0, dword ptr [esp + 0x3c]
433d82d8 mulss    xmm2, xmm2
433d82dc movss    dword ptr [esp + 0x1a4], xmm1
433d82e5 movss    xmm3, dword ptr [edi + 8]
433d82ea subss    xmm0, xmm3
433d82ee mulss    xmm1, xmm1
433d82f2 mov      byte ptr [esp + 0x1d5], 1
433d82fa movss    dword ptr [esp + 0x78], xmm3
433d8300 addss    xmm1, xmm2
433d8304 movss    dword ptr [esp + 0x1a8], xmm0
433d830d mulss    xmm0, xmm0
433d8311 addss    xmm1, xmm0
433d8315 ucomiss  xmm1, dword ptr [esp + 0x18]
433d831a lahf     
433d831b test     ah, 0x44
433d831e jp       0x433d8328
433d8320 mov      byte ptr [esp + 0x1d5], 0
433d8328 movss    xmm3, dword ptr [0x43472240]
433d8330 lea      edx, [esp + 0x430]
433d8337 movss    xmm6, dword ptr [esp + 0x30]
433d833d movaps   xmm1, xmm5
433d8340 movss    xmm5, dword ptr [esp + 0x1c]
433d8346 movaps   xmm2, xmm4
433d8349 subss    xmm2, dword ptr [esp + 0x24]
433d834f subss    xmm1, xmm5
433d8353 mov      ecx, dword ptr [0x43468304]
433d8359 addss    xmm5, dword ptr [esp + 0x44]
433d835f movaps   xmm0, xmm6
433d8362 subss    xmm0, dword ptr [esp + 0x34]
433d8368 addss    xmm6, dword ptr [esp + 0x34]
433d836e mulss    xmm1, xmm3
433d8372 push     edx
433d8373 mulss    xmm2, xmm3
433d8377 lea      edx, [esp + 0x2d4]
433d837e push     edx
433d837f mulss    xmm0, xmm3
433d8383 lea      edx, [esp + 0x198]
433d838a movss    dword ptr [esp + 0x1cc], xmm1
433d8393 movss    dword ptr [esp + 0x1c8], xmm2
433d839c movss    dword ptr [esp + 0x1d0], xmm0
433d83a5 mulss    xmm1, xmm1
433d83a9 mulss    xmm0, xmm0
433d83ad mulss    xmm2, xmm2
433d83b1 addss    xmm4, dword ptr [esp + 0x2c]
433d83b7 mulss    xmm5, xmm3
433d83bb addss    xmm1, xmm2
433d83bf mulss    xmm6, xmm3
433d83c3 mulss    xmm4, xmm3
433d83c7 addss    xmm1, xmm0
433d83cb xorps    xmm0, xmm0
433d83ce addss    xmm7, xmm4
433d83d2 cvtss2sd xmm0, xmm1
433d83d6 movsd    xmm1, qword ptr [esp + 0x98]
433d83df comisd   xmm1, xmm0
433d83e3 movss    xmm0, dword ptr [esp + 0x58]
433d83e9 addss    xmm0, xmm5
433d83ed movss    dword ptr [esp + 0x198], xmm7
433d83f6 seta     byte ptr [esp + 0x1dc]
433d83fe movss    dword ptr [esp + 0x19c], xmm0
433d8407 movaps   xmm0, xmm6
433d840a addss    xmm0, dword ptr [esp + 0x80]
433d8413 movss    dword ptr [esp + 0x1a0], xmm0
433d841c movss    xmm0, dword ptr [0x4346f858]
433d8424 mulss    xmm4, xmm0
433d8428 mulss    xmm5, xmm0
433d842c mulss    xmm6, xmm0
433d8430 movss    dword ptr [esp + 0x1b8], xmm4
433d8439 movss    dword ptr [esp + 0x1bc], xmm5
433d8442 movss    dword ptr [esp + 0x1c0], xmm6
433d844b push     dword ptr [esi + 0xd0]
433d8451 mov      eax, dword ptr [ecx]
433d8453 push     edx
433d8454 call     dword ptr [eax + 0x14]
433d8457 movss    xmm2, dword ptr [0x4346fd8c]
433d845f movss    xmm0, dword ptr [esp + 0x54]
433d8465 lea      esi, [esp + 0x110]
433d846c movss    xmm4, dword ptr [0x43470514]
433d8474 lea      edi, [esp + 0x43c]
433d847b comiss   xmm4, xmm0
433d847e movss    dword ptr [esp + 0x45c], xmm0
433d8487 movsd    dword ptr es:[edi], dword ptr [esi]
433d8488 movsd    dword ptr es:[edi], dword ptr [esi]
433d8489 movsd    dword ptr es:[edi], dword ptr [esi]
433d848a ja       0x433d84a0
433d848c cmp      byte ptr [esp + 0x466], 0
433d8494 jne      0x433d84a0
433d8496 cmp      byte ptr [esp + 0x467], 0
433d849e je       0x433d851a
433d84a0 cmp      dword ptr [esp + 0x47c], 0
433d84a8 je       0x433d851a
433d84aa movss    xmm0, dword ptr [esp + 0x450]
433d84b3 comiss   xmm0, xmm2
433d84b6 jb       0x433d851a
433d84b8 mov      ecx, dword ptr [esp + 0x20]
433d84bc xor      eax, eax
433d84be mov      esi, dword ptr [esp + 0x74]
433d84c2 push     eax
433d84c3 push     esi
433d84c4 or       dword ptr [ecx + 0x1c], 1
433d84c8 mov      ecx, dword ptr [0x43469268]
433d84ce push     eax
433d84cf push     eax
433d84d0 movsx    eax, word ptr [esp + 0x480]
433d84d8 mov      edx, dword ptr [ecx]
433d84da push     eax
433d84db call     dword ptr [edx + 0x10]
433d84de movss    xmm0, dword ptr [esi]
433d84e2 mulss    xmm0, dword ptr [0x4347268c]
433d84ea movss    xmm4, dword ptr [0x43470514]
433d84f2 comiss   xmm0, xmm4
433d84f5 movss    dword ptr [esi], xmm0
433d84f9 jbe      0x433d8501
433d84fb mov      dword ptr [esi], 0x3f800000
433d8501 mov      ecx, dword ptr [esp + 0x20]
433d8505 cmp      byte ptr [ecx + 0xcc], 8
433d850c je       0x433d8512
433d850e and      dword ptr [ecx + 0x18], 0
433d8512 movss    xmm7, dword ptr [esp + 0x18]
433d8518 jmp      0x433d8565
433d851a mov      ecx, dword ptr [esp + 0x20]
433d851e movss    xmm7, dword ptr [esp + 0x18]
433d8524 and      dword ptr [ecx + 0x1c], 0xfffffffe
433d8528 movss    xmm0, dword ptr [ecx + 0x18]
433d852d comiss   xmm0, xmm7
433d8530 jbe      0x433d8565
433d8532 cmp      byte ptr [ecx + 0xcc], 8
433d8539 je       0x433d8565
433d853b mov      dword ptr [ecx + 0xc8], 0x3e800000
433d8545 jmp      0x433d8565
433d8547 and      dword ptr [ecx + 0x1c], 0xfffffffe
433d854b jmp      0x433d855d
433d854d movss    xmm0, dword ptr [ecx + 0x18]
433d8552 comiss   xmm0, xmm1
433d8555 jbe      0x433d855d
433d8557 and      edx, 0xfffffffe
433d855a mov      dword ptr [ecx + 0x1c], edx
433d855d movss    xmm4, dword ptr [0x43470514]
433d8565 mov      dh, byte ptr [ecx + 0x1c]
433d8568 mov      dl, dh
433d856a and      dl, 1
433d856d jne      0x433d8583
433d856f movss    xmm0, dword ptr [ecx + 0x18]
433d8574 xorps    xmm0, xmmword ptr [0x434703d0]
433d857b movss    dword ptr [ecx + 0xc4], xmm0
433d8583 movss    xmm5, dword ptr [0x43472598]
433d858b movss    xmm6, dword ptr [ecx + 0x100]
433d8593 movaps   xmm3, xmm5
433d8596 movss    xmm1, dword ptr [ecx + 0x28]
433d859b movaps   xmm2, xmm6
433d859e mulss    xmm2, dword ptr [0x4346faf4]
433d85a6 subss    xmm3, xmm1
433d85aa comiss   xmm3, xmm2
433d85ad jbe      0x433d85b5
433d85af addss    xmm1, xmm2
433d85b3 jmp      0x433d85cd
433d85b5 movaps   xmm0, xmm2
433d85b8 xorps    xmm0, xmmword ptr [0x434703d0]
433d85bf comiss   xmm0, xmm3
433d85c2 jbe      0x433d85ca
433d85c4 subss    xmm1, xmm2
433d85c8 jmp      0x433d85cd
433d85ca movaps   xmm1, xmm5
433d85cd movss    xmm5, dword ptr [0x43472980]
433d85d5 movss    dword ptr [ecx + 0x28], xmm1
433d85da mov      eax, dword ptr [ecx + 0x110]
433d85e0 movss    xmm2, dword ptr [ecx + 0x2c]
433d85e5 shr      eax, 2
433d85e8 and      al, 1
433d85ea jne      0x433d9469
433d85f0 comiss   xmm2, xmm7
433d85f3 jbe      0x433d85fe
433d85f5 mov      byte ptr [ecx + 0xc0], 1
433d85fc jmp      0x433d860b
433d85fe cmp      byte ptr [ecx + 0xc0], 0
433d8605 je       0x433da2fd
433d860b test     dl, dl
433d860d jne      0x433da2fd
433d8613 movss    xmm0, dword ptr [0x434703bc]
433d861b call     0x4332fc35
433d8620 mov      ecx, dword ptr [esp + 0x20]
433d8624 mov      edx, dword ptr [ecx]
433d8626 mov      dword ptr [esp + 0x1c], edx
433d862a test     edx, edx
433d862c jne      0x433d863a
433d862e test     dword ptr [edi], esi
433d8630 xor      al, dl
433d8632 sub      ebx, dword ptr [ebp - 0x3b]
433d8635 aad      0x45
433d8637 sub      ebx, esp
433d8639 push     es
433d863a mov      eax, dword ptr [0x4346a7e0]
433d863f mov      eax, dword ptr [eax]
433d8641 xor      eax, dword ptr [0x43468c34]
433d8647 xor      eax, 0xa15c3105
433d864c cmp      byte ptr [eax + edx], 0
433d8650 je       0x433d865a
433d8652 mulss    xmm0, dword ptr [0x43470228]
433d865a movss    xmm7, dword ptr [esp + 0x18]
433d8660 movss    xmm2, dword ptr [ecx + 0x2c]
433d8665 movaps   xmm3, xmm7
433d8668 movss    xmm1, dword ptr [ecx + 0x100]
433d8670 subss    xmm3, xmm2
433d8674 mulss    xmm1, xmm0
433d8678 comiss   xmm3, xmm1
433d867b jbe      0x433d8683
433d867d addss    xmm1, xmm2
433d8681 jmp      0x433d869e
433d8683 movaps   xmm0, xmm1
433d8686 xorps    xmm0, xmmword ptr [0x434703d0]
433d868d comiss   xmm0, xmm3
433d8690 jbe      0x433d869b
433d8692 subss    xmm2, xmm1
433d8696 movaps   xmm1, xmm2
433d8699 jmp      0x433d869e
433d869b movaps   xmm1, xmm7
433d869e movss    dword ptr [ecx + 0x2c], xmm1
433d86a3 test     byte ptr [ecx + 0x1c], 1
433d86a7 jne      0x433d86c4
433d86a9 cmp      byte ptr [ecx + 0xcc], 9
433d86b0 je       0x433d86c4
433d86b2 movss    xmm0, dword ptr [ecx + 0xc]
433d86b7 subss    xmm0, dword ptr [0x4346fe78]
433d86bf movss    dword ptr [ecx + 0xc], xmm0
433d86c4 mov      edx, dword ptr [ecx + 0x1c]
433d86c7 lea      eax, [ecx + 0xc8]
433d86cd movss    xmm2, dword ptr [0x434720b0]
433d86d5 lea      edi, [esp + 0x58]
433d86d9 and      edx, 0xfffffff9
433d86dc mov      dword ptr [esp + 0x34], eax
433d86e0 mov      dword ptr [ecx + 0x1c], edx
433d86e3 mov      byte ptr [ecx + 0xc0], 0
433d86ea mov      dword ptr [ecx + 0x30], 0x42800000
433d86f1 mov      dword ptr [eax], 0x3f800000
433d86f7 xor      eax, eax
433d86f9 or       dword ptr [esp + 0x36c], 0xffffffff
433d8701 or       dword ptr [esp + 0x378], 0xffffffff
433d8709 mov      word ptr [esp + 0x35e], ax
433d8711 mov      dword ptr [esp + 0x374], eax
433d8718 lea      eax, [ecx + 4]
433d871b mov      dword ptr [esp + 0x354], 0x3f800000
433d8726 mov      esi, eax
433d8728 movss    xmm1, dword ptr [ecx + 0x18]
433d872d comiss   xmm1, xmm7
433d8730 mov      dword ptr [esp + 0x50], eax
433d8734 movsd    dword ptr es:[edi], dword ptr [esi]
433d8735 movsd    dword ptr es:[edi], dword ptr [esi]
433d8736 seta     byte ptr [esp + 0x2b]
433d873b movsd    dword ptr es:[edi], dword ptr [esi]
433d873c movss    xmm0, dword ptr [esp + 0x60]
433d8742 subss    xmm0, dword ptr [0x4347259c]
433d874a comiss   xmm1, xmm2
433d874d movss    dword ptr [esp + 0x2c], xmm0
433d8753 seta     al
433d8756 test     al, al
433d8758 je       0x433d876a
433d875a test     byte ptr [ecx + 0x1c], 1
433d875e je       0x433d876a
433d8760 subss    xmm1, xmm1
433d8764 comiss   xmm1, xmm2
433d8767 seta     al
433d876a mov      ah, byte ptr [ecx + 0xcc]
433d8770 mov      byte ptr [esp + 0x17], 0
433d8775 cmp      ah, 2
433d8778 jne      0x433d8793
433d877a test     byte ptr [ecx + 0x1c], 1
433d877e je       0x433d8793
433d8780 subss    xmm0, dword ptr [ecx + 0xdc]
433d8788 mov      byte ptr [esp + 0x17], 1
433d878d movss    dword ptr [esp + 0x2c], xmm0
433d8793 test     al, al
433d8795 jne      0x433d9453
433d879b cmp      byte ptr [esp + 0x2b], al
433d879f je       0x433d87aa
433d87a1 cmp      ah, 9
433d87a4 je       0x433d9453
433d87aa mov      edx, dword ptr [0x43468304]
433d87b0 lea      esi, [ecx + 4]
433d87b3 mov      eax, dword ptr [esp + 0x1c]
433d87b7 lea      edi, [esp + 0x68]
433d87bb movss    xmm2, dword ptr [esp + 0x58]
433d87c1 movss    xmm1, dword ptr [esp + 0x5c]
433d87c7 movsd    dword ptr es:[edi], dword ptr [esi]
433d87c8 movsd    dword ptr es:[edi], dword ptr [esi]
433d87c9 movsd    dword ptr es:[edi], dword ptr [esi]
433d87ca and      dword ptr [esp + 0x4e4], 0
433d87d2 subss    xmm1, dword ptr [esp + 0x6c]
433d87d8 subss    xmm2, dword ptr [esp + 0x68]
433d87de subss    xmm0, dword ptr [esp + 0x70]
433d87e4 mov      dword ptr [esp + 0x4dc], eax
433d87eb mov      dword ptr [esp + 0x4d8], 0x4346edc0
433d87f6 mov      dword ptr [esp + 0x4e0], 8
433d8801 mov      eax, dword ptr [edx]
433d8803 mov      edi, dword ptr [ecx + 0xd0]
433d8809 mov      esi, dword ptr [eax + 0x14]
433d880c lea      eax, [ecx + 0x38]
433d880f and      dword ptr [esp + 0x740], 0
433d8817 movss    dword ptr [esp + 0x714], xmm1
433d8820 movss    dword ptr [esp + 0x710], xmm2
433d8829 mulss    xmm1, xmm1
433d882d mov      dword ptr [esp + 0x1c], eax
433d8831 mulss    xmm2, xmm2
433d8835 mov      byte ptr [esp + 0x745], 1
433d883d movss    dword ptr [esp + 0x718], xmm0
433d8846 mulss    xmm0, xmm0
433d884a addss    xmm1, xmm2
433d884e addss    xmm1, xmm0
433d8852 ucomiss  xmm1, xmm7
433d8855 lahf     
433d8856 test     ah, 0x44
433d8859 jp       0x433d8863
433d885b mov      byte ptr [esp + 0x745], 0
433d8863 lea      eax, [ecx + 0x44]
433d8866 mov      ecx, dword ptr [esp + 0x1c]
433d886a movss    xmm3, dword ptr [eax]
433d886e movss    xmm4, dword ptr [eax + 4]
433d8873 movaps   xmm2, xmm3
433d8876 movss    xmm5, dword ptr [eax + 8]
433d887b movaps   xmm1, xmm4
433d887e movss    xmm6, dword ptr [ecx]
433d8882 lea      eax, [esp + 0x328]
433d8889 movss    xmm7, dword ptr [ecx + 4]
433d888e subss    xmm2, xmm6
433d8892 movss    xmm0, dword ptr [ecx + 8]
433d8897 subss    xmm1, xmm7
433d889b movss    dword ptr [esp + 0x24], xmm0
433d88a1 addss    xmm6, xmm3
433d88a5 movaps   xmm0, xmm5
433d88a8 addss    xmm7, xmm4
433d88ac subss    xmm0, dword ptr [esp + 0x24]
433d88b2 mulss    xmm2, dword ptr [0x43472240]
433d88ba mov      ecx, edx
433d88bc push     eax
433d88bd mulss    xmm1, dword ptr [0x43472240]
433d88c5 lea      eax, [esp + 0x4dc]
433d88cc push     eax
433d88cd mulss    xmm0, dword ptr [0x43472240]
433d88d5 lea      eax, [esp + 0x708]
433d88dc push     edi
433d88dd movss    dword ptr [esp + 0x740], xmm1
433d88e6 mulss    xmm1, xmm1
433d88ea push     eax
433d88eb movss    dword ptr [esp + 0x740], xmm2
433d88f4 movss    dword ptr [esp + 0x748], xmm0
433d88fd mulss    xmm2, xmm2
433d8901 mulss    xmm0, xmm0
433d8905 addss    xmm1, xmm2
433d8909 addss    xmm1, xmm0
433d890d cvtps2pd xmm0, xmm1
433d8910 movsd    xmm1, qword ptr [esp + 0xa0]
433d8919 comisd   xmm1, xmm0
433d891d movss    xmm0, dword ptr [esp + 0x34]
433d8923 movss    xmm1, dword ptr [0x43472240]
433d892b addss    xmm0, xmm5
433d892f mulss    xmm6, xmm1
433d8933 seta     byte ptr [esp + 0x754]
433d893b mulss    xmm7, xmm1
433d893f mulss    xmm0, xmm1
433d8943 movss    xmm1, dword ptr [esp + 0x78]
433d8949 addss    xmm1, xmm6
433d894d movss    dword ptr [esp + 0x710], xmm1
433d8956 movss    xmm1, dword ptr [esp + 0x7c]
433d895c addss    xmm1, xmm7
433d8960 movss    dword ptr [esp + 0x714], xmm1
433d8969 movss    xmm1, dword ptr [esp + 0x80]
433d8972 addss    xmm1, xmm0
433d8976 movss    dword ptr [esp + 0x718], xmm1
433d897f movss    xmm1, dword ptr [0x4346f858]
433d8987 mulss    xmm6, xmm1
433d898b mulss    xmm7, xmm1
433d898f mulss    xmm0, xmm1
433d8993 movss    dword ptr [esp + 0x730], xmm6
433d899c movss    dword ptr [esp + 0x734], xmm7
433d89a5 movss    dword ptr [esp + 0x738], xmm0
433d89ae call     esi
433d89b0 movss    xmm0, dword ptr [esp + 0x354]
433d89b9 movss    xmm1, dword ptr [0x43470514]
433d89c1 comiss   xmm1, xmm0
433d89c4 movss    dword ptr [esp + 0x80], xmm0
433d89cd ja       0x433d89e3
433d89cf cmp      byte ptr [esp + 0x35e], 0
433d89d7 jne      0x433d89e3
433d89d9 cmp      byte ptr [esp + 0x35f], 0
433d89e1 je       0x433d8a04
433d89e3 mov      edx, dword ptr [esp + 0x374]
433d89ea test     edx, edx
433d89ec je       0x433d8a04
433d89ee movss    xmm0, dword ptr [esp + 0x348]
433d89f7 comiss   xmm0, dword ptr [0x4346fd8c]
433d89fe jae      0x433d9366
433d8a04 mov      ecx, dword ptr [esp + 0x20]
433d8a08 lea      esi, [esp + 0x334]
433d8a0f lea      edi, [esp + 0x110]
433d8a16 movsd    dword ptr es:[edi], dword ptr [esi]
433d8a17 mov      eax, dword ptr [ecx]
433d8a19 and      dword ptr [esp + 0x2ec], 0
433d8a21 movsd    dword ptr es:[edi], dword ptr [esi]
433d8a22 mov      dword ptr [esp + 0x2e0], 0x4346edc0
433d8a2d mov      dword ptr [esp + 0x2e4], eax
433d8a34 mov      dword ptr [esp + 0x2e8], 8
433d8a3f movsd    dword ptr es:[edi], dword ptr [esi]
433d8a40 lea      esi, [ecx + 0x38]
433d8a43 lea      edi, [esp + 0xb0]
433d8a4a movsd    dword ptr es:[edi], dword ptr [esi]
433d8a4b movsd    dword ptr es:[edi], dword ptr [esi]
433d8a4c movsd    dword ptr es:[edi], dword ptr [esi]
433d8a4d mov      esi, ecx
433d8a4f movss    xmm0, dword ptr [esi + 0x4c]
433d8a54 movss    xmm1, dword ptr [esi + 0x48]
433d8a59 movss    dword ptr [esp + 0x1c], xmm0
433d8a5f movss    xmm0, dword ptr [esp + 0x18]
433d8a65 call     0x43367633
433d8a6a movss    xmm1, dword ptr [esi + 0x44]
433d8a6f movss    dword ptr [esp + 0x24], xmm0
433d8a75 movss    xmm0, dword ptr [esp + 0x18]
433d8a7b call     0x43367633
433d8a80 and      dword ptr [esp + 0x180], 0
433d8a88 movaps   xmm3, xmm0
433d8a8b movss    xmm7, dword ptr [esi + 4]
433d8a90 movss    xmm2, dword ptr [esp + 0x58]
433d8a96 movss    xmm1, dword ptr [esp + 0x5c]
433d8a9c subss    xmm2, xmm7
433d8aa0 movss    dword ptr [esp + 0x68], xmm3
433d8aa6 movss    dword ptr [esp + 0x150], xmm2
433d8aaf movss    xmm0, dword ptr [esi + 8]
433d8ab4 subss    xmm1, xmm0
433d8ab8 movss    dword ptr [esp + 0x30], xmm0
433d8abe movss    xmm0, dword ptr [esp + 0x2c]
433d8ac4 mulss    xmm2, xmm2
433d8ac8 movss    dword ptr [esp + 0x154], xmm1
433d8ad1 movss    xmm4, dword ptr [esi + 0xc]
433d8ad6 subss    xmm0, xmm4
433d8ada mulss    xmm1, xmm1
433d8ade mov      byte ptr [esp + 0x185], 1
433d8ae6 movss    dword ptr [esp + 0x44], xmm4
433d8aec addss    xmm1, xmm2
433d8af0 movss    dword ptr [esp + 0x158], xmm0
433d8af9 mulss    xmm0, xmm0
433d8afd addss    xmm1, xmm0
433d8b01 ucomiss  xmm1, dword ptr [esp + 0x18]
433d8b06 lahf     
433d8b07 test     ah, 0x44
433d8b0a jp       0x433d8b14
433d8b0c mov      byte ptr [esp + 0x185], 0
433d8b14 movss    xmm4, dword ptr [esp + 0xb0]
433d8b1d lea      edx, [esp + 0x328]
433d8b24 movss    xmm1, dword ptr [esp + 0x24]
433d8b2a movaps   xmm2, xmm3
433d8b2d movss    xmm3, dword ptr [esp + 0xb4]
433d8b36 subss    xmm2, xmm4
433d8b3a movss    xmm5, dword ptr [0x43472240]
433d8b42 subss    xmm1, xmm3
433d8b46 movss    xmm6, dword ptr [esp + 0x1c]
433d8b4c addss    xmm3, dword ptr [esp + 0x24]
433d8b52 movaps   xmm0, xmm6
433d8b55 mov      ecx, dword ptr [0x43468304]
433d8b5b subss    xmm0, dword ptr [esp + 0xb8]
433d8b64 mulss    xmm1, xmm5
433d8b68 push     edx
433d8b69 addss    xmm6, dword ptr [esp + 0xbc]
433d8b72 mulss    xmm2, xmm5
433d8b76 lea      edx, [esp + 0x2e4]
433d8b7d push     edx
433d8b7e mulss    xmm0, xmm5
433d8b82 lea      edx, [esp + 0x148]
433d8b89 movss    dword ptr [esp + 0x17c], xmm1
433d8b92 movss    dword ptr [esp + 0x178], xmm2
433d8b9b movss    dword ptr [esp + 0x180], xmm0
433d8ba4 mulss    xmm1, xmm1
433d8ba8 mulss    xmm2, xmm2
433d8bac mulss    xmm0, xmm0
433d8bb0 addss    xmm4, dword ptr [esp + 0x70]
433d8bb6 addss    xmm1, xmm2
433d8bba mulss    xmm3, xmm5
433d8bbe mulss    xmm6, xmm5
433d8bc2 mulss    xmm4, xmm5
433d8bc6 addss    xmm1, xmm0
433d8bca addss    xmm7, xmm4
433d8bce cvtps2pd xmm0, xmm1
433d8bd1 movsd    xmm1, qword ptr [esp + 0x98]
433d8bda comisd   xmm1, xmm0
433d8bde movss    xmm0, dword ptr [esp + 0x38]
433d8be4 addss    xmm0, xmm3
433d8be8 movss    dword ptr [esp + 0x148], xmm7
433d8bf1 seta     byte ptr [esp + 0x18c]
433d8bf9 movss    dword ptr [esp + 0x14c], xmm0
433d8c02 movaps   xmm0, xmm6
433d8c05 addss    xmm0, dword ptr [esp + 0x4c]
433d8c0b movss    dword ptr [esp + 0x150], xmm0
433d8c14 movss    xmm0, dword ptr [0x4346f858]
433d8c1c mulss    xmm4, xmm0
433d8c20 mulss    xmm3, xmm0
433d8c24 mulss    xmm6, xmm0
433d8c28 movss    dword ptr [esp + 0x168], xmm4
433d8c31 movss    dword ptr [esp + 0x16c], xmm3
433d8c3a movss    dword ptr [esp + 0x170], xmm6
433d8c43 push     dword ptr [esi + 0xd0]
433d8c49 mov      eax, dword ptr [ecx]
433d8c4b push     edx
433d8c4c call     dword ptr [eax + 0x14]
433d8c4f cmp      dword ptr [esp + 0x374], 0
433d8c57 je       0x433d8c73
433d8c59 movss    xmm0, dword ptr [esp + 0x348]
433d8c62 movss    xmm2, dword ptr [0x4346fd8c]
433d8c6a comiss   xmm0, xmm2
433d8c6d jae      0x433d92fd
433d8c73 movss    xmm0, dword ptr [esi + 0x40]
433d8c78 movss    xmm1, dword ptr [esi + 0x3c]
433d8c7d movss    dword ptr [esp + 0x1c], xmm0
433d8c83 movss    xmm0, dword ptr [esp + 0x18]
433d8c89 call     0x4332fc35
433d8c8e movss    xmm1, dword ptr [esi + 0x38]
433d8c93 movss    dword ptr [esp + 0x24], xmm0
433d8c99 movss    xmm0, dword ptr [esp + 0x18]
433d8c9f call     0x4332fc35
433d8ca4 movss    xmm2, dword ptr [esp + 0x58]
433d8caa lea      esi, [esi + 0x44]
433d8cad movss    xmm1, dword ptr [esp + 0x5c]
433d8cb3 lea      edi, [esp + 0x68]
433d8cb7 movsd    dword ptr es:[edi], dword ptr [esi]
433d8cb8 movaps   xmm6, xmm0
433d8cbb movsd    dword ptr es:[edi], dword ptr [esi]
433d8cbc movsd    dword ptr es:[edi], dword ptr [esi]
433d8cbd mov      edi, dword ptr [esp + 0x50]
433d8cc1 and      dword ptr [esp + 0x180], 0
433d8cc9 movss    xmm0, dword ptr [edi]
433d8ccd subss    xmm2, xmm0
433d8cd1 movss    dword ptr [esp + 0x30], xmm0
433d8cd7 movss    dword ptr [esp + 0x150], xmm2
433d8ce0 movss    xmm0, dword ptr [edi + 4]
433d8ce5 subss    xmm1, xmm0
433d8ce9 movss    dword ptr [esp + 0x44], xmm0
433d8cef movss    xmm0, dword ptr [esp + 0x2c]
433d8cf5 mulss    xmm2, xmm2
433d8cf9 movss    dword ptr [esp + 0x154], xmm1
433d8d02 movss    xmm3, dword ptr [edi + 8]
433d8d07 subss    xmm0, xmm3
433d8d0b mulss    xmm1, xmm1
433d8d0f mov      byte ptr [esp + 0x185], 1
433d8d17 movss    dword ptr [esp + 0x50], xmm3
433d8d1d addss    xmm1, xmm2
433d8d21 movss    dword ptr [esp + 0x158], xmm0
433d8d2a mulss    xmm0, xmm0
433d8d2e addss    xmm1, xmm0
433d8d32 ucomiss  xmm1, dword ptr [esp + 0x18]
433d8d37 lahf     
433d8d38 test     ah, 0x44
433d8d3b jp       0x433d8d45
433d8d3d mov      byte ptr [esp + 0x185], 0
433d8d45 movss    xmm4, dword ptr [esp + 0x6c]
433d8d4b lea      edx, [esp + 0x328]
433d8d52 movss    xmm2, dword ptr [esp + 0x68]
433d8d58 movaps   xmm1, xmm4
433d8d5b subss    xmm1, dword ptr [esp + 0x24]
433d8d61 movss    xmm5, dword ptr [0x43472240]
433d8d69 subss    xmm2, xmm6
433d8d6d movss    xmm3, dword ptr [esp + 0x70]
433d8d73 addss    xmm6, dword ptr [esp + 0x68]
433d8d79 movaps   xmm0, xmm3
433d8d7c mov      ecx, dword ptr [0x43468304]
433d8d82 subss    xmm0, dword ptr [esp + 0x1c]
433d8d88 mulss    xmm1, xmm5
433d8d8c mov      esi, dword ptr [esp + 0x20]
433d8d90 addss    xmm4, dword ptr [esp + 0x24]
433d8d96 mulss    xmm2, xmm5
433d8d9a push     edx
433d8d9b mulss    xmm0, xmm5
433d8d9f lea      edx, [esp + 0x2e4]
433d8da6 push     edx
433d8da7 movss    dword ptr [esp + 0x17c], xmm1
433d8db0 lea      edx, [esp + 0x148]
433d8db7 movss    dword ptr [esp + 0x178], xmm2
433d8dc0 movss    dword ptr [esp + 0x180], xmm0
433d8dc9 mulss    xmm1, xmm1
433d8dcd mulss    xmm0, xmm0
433d8dd1 addss    xmm3, dword ptr [esp + 0x24]
433d8dd7 mulss    xmm2, xmm2
433d8ddb mulss    xmm6, xmm5
433d8ddf addss    xmm1, xmm2
433d8de3 mulss    xmm4, xmm5
433d8de7 mulss    xmm3, xmm5
433d8deb addss    xmm1, xmm0
433d8def cvtps2pd xmm0, xmm1
433d8df2 movsd    xmm1, qword ptr [esp + 0x98]
433d8dfb comisd   xmm1, xmm0
433d8dff movaps   xmm0, xmm6
433d8e02 addss    xmm0, dword ptr [esp + 0x38]
433d8e08 seta     byte ptr [esp + 0x18c]
433d8e10 movss    dword ptr [esp + 0x148], xmm0
433d8e19 movaps   xmm0, xmm4
433d8e1c addss    xmm0, dword ptr [esp + 0x4c]
433d8e22 movss    dword ptr [esp + 0x14c], xmm0
433d8e2b movaps   xmm0, xmm3
433d8e2e addss    xmm0, dword ptr [esp + 0x58]
433d8e34 movss    dword ptr [esp + 0x150], xmm0
433d8e3d movss    xmm0, dword ptr [0x4346f858]
433d8e45 mulss    xmm6, xmm0
433d8e49 mulss    xmm4, xmm0
433d8e4d mulss    xmm3, xmm0
433d8e51 movss    dword ptr [esp + 0x168], xmm6
433d8e5a movss    dword ptr [esp + 0x16c], xmm4
433d8e63 movss    dword ptr [esp + 0x170], xmm3
433d8e6c push     dword ptr [esi + 0xd0]
433d8e72 mov      eax, dword ptr [ecx]
433d8e74 push     edx
433d8e75 call     dword ptr [eax + 0x14]
433d8e78 cmp      dword ptr [esp + 0x374], 0
433d8e80 je       0x433d8e9c
433d8e82 movss    xmm0, dword ptr [esp + 0x348]
433d8e8b movss    xmm2, dword ptr [0x4346fd8c]
433d8e93 comiss   xmm0, xmm2
433d8e96 jae      0x433d92fd
433d8e9c movss    xmm0, dword ptr [esi + 0x40]
433d8ea1 movss    xmm1, dword ptr [esi + 0x3c]
433d8ea6 movss    dword ptr [esp + 0x50], xmm0
433d8eac movss    xmm0, dword ptr [esp + 0x18]
433d8eb2 call     0x4332fc35
433d8eb7 movss    xmm1, dword ptr [esi + 0x38]
433d8ebc movss    dword ptr [esp + 0x24], xmm0
433d8ec2 movss    xmm0, dword ptr [esi + 0x48]
433d8ec7 movss    dword ptr [esp + 0x1c], xmm1
433d8ecd movss    xmm1, dword ptr [esi + 0x4c]
433d8ed2 movss    dword ptr [esp + 0x44], xmm1
433d8ed8 movss    xmm1, dword ptr [esi + 0x44]
433d8edd movss    dword ptr [esp + 0x30], xmm0
433d8ee3 movss    xmm0, dword ptr [esp + 0x18]
433d8ee9 call     0x43367633
433d8eee and      dword ptr [esp + 0x180], 0
433d8ef6 movaps   xmm3, xmm0
433d8ef9 movss    xmm0, dword ptr [edi]
433d8efd movss    xmm2, dword ptr [esp + 0x58]
433d8f03 movss    xmm1, dword ptr [esp + 0x5c]
433d8f09 subss    xmm2, xmm0
433d8f0d movss    dword ptr [esp + 0x74], xmm0
433d8f13 movss    dword ptr [esp + 0x78], xmm3
433d8f19 movss    dword ptr [esp + 0x150], xmm2
433d8f22 movss    xmm0, dword ptr [edi + 4]
433d8f27 subss    xmm1, xmm0
433d8f2b movss    dword ptr [esp + 0x3c], xmm0
433d8f31 movss    xmm0, dword ptr [esp + 0x2c]
433d8f37 mulss    xmm2, xmm2
433d8f3b movss    dword ptr [esp + 0x154], xmm1
433d8f44 movss    xmm4, dword ptr [edi + 8]
433d8f49 subss    xmm0, xmm4
433d8f4d mulss    xmm1, xmm1
433d8f51 mov      byte ptr [esp + 0x185], 1
433d8f59 movss    dword ptr [esp + 0x54], xmm4
433d8f5f addss    xmm1, xmm2
433d8f63 movss    dword ptr [esp + 0x158], xmm0
433d8f6c mulss    xmm0, xmm0
433d8f70 addss    xmm1, xmm0
433d8f74 ucomiss  xmm1, dword ptr [esp + 0x18]
433d8f79 lahf     
433d8f7a test     ah, 0x44
433d8f7d jp       0x433d8f87
433d8f7f mov      byte ptr [esp + 0x185], 0
433d8f87 movss    xmm5, dword ptr [esp + 0x30]
433d8f8d lea      edx, [esp + 0x328]
433d8f94 movss    xmm4, dword ptr [esp + 0x1c]
433d8f9a movaps   xmm1, xmm5
433d8f9d subss    xmm1, dword ptr [esp + 0x24]
433d8fa3 movss    xmm6, dword ptr [esp + 0x44]
433d8fa9 movaps   xmm2, xmm3
433d8fac movss    xmm3, dword ptr [0x43472240]
433d8fb4 subss    xmm2, xmm4
433d8fb8 addss    xmm4, dword ptr [esp + 0x78]
433d8fbe movaps   xmm0, xmm6
433d8fc1 mov      ecx, dword ptr [0x43468304]
433d8fc7 subss    xmm0, dword ptr [esp + 0x50]
433d8fcd mulss    xmm1, xmm3
433d8fd1 push     edx
433d8fd2 addss    xmm5, dword ptr [esp + 0x28]
433d8fd8 mulss    xmm2, xmm3
433d8fdc lea      edx, [esp + 0x2e4]
433d8fe3 push     edx
433d8fe4 mulss    xmm0, xmm3
433d8fe8 lea      edx, [esp + 0x148]
433d8fef movss    dword ptr [esp + 0x17c], xmm1
433d8ff8 movss    dword ptr [esp + 0x178], xmm2
433d9001 movss    dword ptr [esp + 0x180], xmm0
433d900a mulss    xmm1, xmm1
433d900e mulss    xmm0, xmm0
433d9012 addss    xmm6, dword ptr [esp + 0x58]
433d9018 mulss    xmm2, xmm2
433d901c mulss    xmm4, xmm3
433d9020 addss    xmm1, xmm2
433d9024 mulss    xmm5, xmm3
433d9028 mulss    xmm6, xmm3
433d902c addss    xmm1, xmm0
433d9030 cvtps2pd xmm0, xmm1
433d9033 movsd    xmm1, qword ptr [esp + 0x98]
433d903c comisd   xmm1, xmm0
433d9040 movaps   xmm0, xmm4
433d9043 addss    xmm0, dword ptr [esp + 0x7c]
433d9049 seta     byte ptr [esp + 0x18c]
433d9051 movss    dword ptr [esp + 0x148], xmm0
433d905a movaps   xmm0, xmm5
433d905d addss    xmm0, dword ptr [esp + 0x44]
433d9063 movss    dword ptr [esp + 0x14c], xmm0
433d906c movaps   xmm0, xmm6
433d906f addss    xmm0, dword ptr [esp + 0x5c]
433d9075 movss    dword ptr [esp + 0x150], xmm0
433d907e movss    xmm0, dword ptr [0x4346f858]
433d9086 mulss    xmm4, xmm0
433d908a mulss    xmm5, xmm0
433d908e mulss    xmm6, xmm0
433d9092 movss    dword ptr [esp + 0x168], xmm4
433d909b movss    dword ptr [esp + 0x16c], xmm5
433d90a4 movss    dword ptr [esp + 0x170], xmm6
433d90ad push     dword ptr [esi + 0xd0]
433d90b3 mov      eax, dword ptr [ecx]
433d90b5 push     edx
433d90b6 call     dword ptr [eax + 0x14]
433d90b9 cmp      dword ptr [esp + 0x374], 0
433d90c1 je       0x433d90dd
433d90c3 movss    xmm0, dword ptr [esp + 0x348]
433d90cc movss    xmm2, dword ptr [0x4346fd8c]
433d90d4 comiss   xmm0, xmm2
433d90d7 jae      0x433d92fd
433d90dd movss    xmm0, dword ptr [esi + 0x40]
433d90e2 movss    xmm1, dword ptr [esi + 0x38]
433d90e7 movss    dword ptr [esp + 0x44], xmm0
433d90ed movss    xmm0, dword ptr [esi + 0x3c]
433d90f2 movss    dword ptr [esp + 0x1c], xmm0
433d90f8 movss    xmm0, dword ptr [esp + 0x18]
433d90fe call     0x4332fc35
433d9103 movss    xmm1, dword ptr [esi + 0x4c]
433d9108 movss    dword ptr [esp + 0x24], xmm0
433d910e movss    xmm0, dword ptr [esp + 0x18]
433d9114 movss    dword ptr [esp + 0x30], xmm1
433d911a movss    xmm1, dword ptr [esi + 0x48]
433d911f call     0x43367633
433d9124 movss    xmm4, dword ptr [esi + 0x44]
433d9129 movaps   xmm5, xmm0
433d912c and      dword ptr [esp + 0x180], 0
433d9134 movss    xmm0, dword ptr [edi]
433d9138 movss    xmm2, dword ptr [esp + 0x58]
433d913e movss    xmm1, dword ptr [esp + 0x5c]
433d9144 subss    xmm2, xmm0
433d9148 movss    dword ptr [esp + 0x78], xmm0
433d914e movss    dword ptr [esp + 0x50], xmm5
433d9154 movss    dword ptr [esp + 0x150], xmm2
433d915d movss    xmm0, dword ptr [edi + 4]
433d9162 subss    xmm1, xmm0
433d9166 movss    dword ptr [esp + 0x74], xmm0
433d916c movss    xmm0, dword ptr [esp + 0x2c]
433d9172 mulss    xmm2, xmm2
433d9176 movss    dword ptr [esp + 0x154], xmm1
433d917f movss    xmm3, dword ptr [edi + 8]
433d9184 subss    xmm0, xmm3
433d9188 mulss    xmm1, xmm1
433d918c mov      byte ptr [esp + 0x185], 1
433d9194 movss    dword ptr [esp + 0x3c], xmm3
433d919a addss    xmm1, xmm2
433d919e movss    dword ptr [esp + 0x158], xmm0
433d91a7 mulss    xmm0, xmm0
433d91ab addss    xmm1, xmm0
433d91af ucomiss  xmm1, dword ptr [esp + 0x18]
433d91b4 lahf     
433d91b5 test     ah, 0x44
433d91b8 jp       0x433d91c2
433d91ba mov      byte ptr [esp + 0x185], 0
433d91c2 movss    xmm3, dword ptr [0x43472240]
433d91ca lea      edx, [esp + 0x328]
433d91d1 movss    xmm6, dword ptr [esp + 0x30]
433d91d7 movaps   xmm1, xmm5
433d91da movss    xmm5, dword ptr [esp + 0x1c]
433d91e0 movaps   xmm2, xmm4
433d91e3 subss    xmm2, dword ptr [esp + 0x24]
433d91e9 addss    xmm4, dword ptr [esp + 0x24]
433d91ef subss    xmm1, xmm5
433d91f3 mov      ecx, dword ptr [0x43468304]
433d91f9 movaps   xmm0, xmm6
433d91fc subss    xmm0, dword ptr [esp + 0x44]
433d9202 addss    xmm5, dword ptr [esp + 0x50]
433d9208 mulss    xmm2, xmm3
433d920c push     edx
433d920d mulss    xmm1, xmm3
433d9211 lea      edx, [esp + 0x2e4]
433d9218 push     edx
433d9219 mulss    xmm0, xmm3
433d921d lea      edx, [esp + 0x148]
433d9224 movss    dword ptr [esp + 0x17c], xmm1
433d922d movss    dword ptr [esp + 0x178], xmm2
433d9236 movss    dword ptr [esp + 0x180], xmm0
433d923f mulss    xmm0, xmm0
433d9243 mulss    xmm1, xmm1
433d9247 addss    xmm6, dword ptr [esp + 0x4c]
433d924d mulss    xmm2, xmm2
433d9251 mulss    xmm4, xmm3
433d9255 addss    xmm1, xmm2
433d9259 mulss    xmm5, xmm3
433d925d mulss    xmm6, xmm3
433d9261 addss    xmm1, xmm0
433d9265 xorps    xmm0, xmm0
433d9268 cvtss2sd xmm0, xmm1
433d926c movsd    xmm1, qword ptr [esp + 0x98]
433d9275 comisd   xmm1, xmm0
433d9279 movaps   xmm0, xmm4
433d927c addss    xmm0, dword ptr [esp + 0x80]
433d9285 seta     byte ptr [esp + 0x18c]
433d928d movss    dword ptr [esp + 0x148], xmm0
433d9296 movaps   xmm0, xmm5
433d9299 addss    xmm0, dword ptr [esp + 0x7c]
433d929f movss    dword ptr [esp + 0x14c], xmm0
433d92a8 movaps   xmm0, xmm6
433d92ab addss    xmm0, dword ptr [esp + 0x44]
433d92b1 movss    dword ptr [esp + 0x150], xmm0
433d92ba movss    xmm0, dword ptr [0x4346f858]
433d92c2 mulss    xmm4, xmm0
433d92c6 mulss    xmm5, xmm0
433d92ca mulss    xmm6, xmm0
433d92ce movss    dword ptr [esp + 0x168], xmm4
433d92d7 movss    dword ptr [esp + 0x16c], xmm5
433d92e0 movss    dword ptr [esp + 0x170], xmm6
433d92e9 push     dword ptr [esi + 0xd0]
433d92ef mov      eax, dword ptr [ecx]
433d92f1 push     edx
433d92f2 call     dword ptr [eax + 0x14]
433d92f5 movss    xmm2, dword ptr [0x4346fd8c]
433d92fd movss    xmm0, dword ptr [esp + 0x80]
433d9306 lea      esi, [esp + 0x110]
433d930d movss    xmm1, dword ptr [0x43470514]
433d9315 lea      edi, [esp + 0x334]
433d931c comiss   xmm1, xmm0
433d931f movss    dword ptr [esp + 0x354], xmm0
433d9328 movsd    dword ptr es:[edi], dword ptr [esi]
433d9329 movsd    dword ptr es:[edi], dword ptr [esi]
433d932a movsd    dword ptr es:[edi], dword ptr [esi]
433d932b ja       0x433d9345
433d932d cmp      byte ptr [esp + 0x35e], 0
433d9335 jne      0x433d9345
433d9337 cmp      byte ptr [esp + 0x35f], 0
433d933f je       0x433d9426
433d9345 mov      edx, dword ptr [esp + 0x374]
433d934c test     edx, edx
433d934e je       0x433d9426
433d9354 movss    xmm0, dword ptr [esp + 0x348]
433d935d comiss   xmm0, xmm2
433d9360 jb       0x433d9426
433d9366 mov      ecx, dword ptr [esp + 0x20]
433d936a movss    xmm0, dword ptr [0x4346f6bc]
433d9372 comiss   xmm0, dword ptr [ecx + 0x18]
433d9376 jbe      0x433d9386
433d9378 or       byte ptr [ecx + 0x108], 0x10
433d937f mov      edx, dword ptr [esp + 0x374]
433d9386 mov      eax, dword ptr [ecx + 0x1c]
433d9389 test     edx, edx
433d938b je       0x433d93e7
433d938d mov      esi, dword ptr [esp + 0x34]
433d9391 or       eax, 1
433d9394 mov      dword ptr [ecx + 0x1c], eax
433d9397 xor      eax, eax
433d9399 mov      ecx, dword ptr [0x43469268]
433d939f push     eax
433d93a0 push     esi
433d93a1 push     eax
433d93a2 mov      edx, dword ptr [ecx]
433d93a4 push     eax
433d93a5 movsx    eax, word ptr [esp + 0x378]
433d93ad push     eax
433d93ae call     dword ptr [edx + 0x10]
433d93b1 movss    xmm0, dword ptr [esi]
433d93b5 mulss    xmm0, dword ptr [0x4347268c]
433d93bd movss    xmm1, dword ptr [0x43470514]
433d93c5 comiss   xmm0, xmm1
433d93c8 movss    dword ptr [esi], xmm0
433d93cc jbe      0x433d93d4
433d93ce mov      dword ptr [esi], 0x3f800000
433d93d4 mov      ecx, dword ptr [esp + 0x20]
433d93d8 cmp      byte ptr [ecx + 0xcc], 8
433d93df je       0x433d93ed
433d93e1 and      dword ptr [ecx + 0x18], 0
433d93e5 jmp      0x433d93ed
433d93e7 and      eax, 0xfffffffe
433d93ea mov      dword ptr [ecx + 0x1c], eax
433d93ed cmp      byte ptr [esp + 0x17], 0
433d93f2 movss    xmm7, dword ptr [esp + 0x18]
433d93f8 je       0x433d9459
433d93fa cmp      byte ptr [esp + 0x35f], 0
433d9402 jne      0x433d9459
433d9404 movss    xmm0, dword ptr [esp + 0x354]
433d940d comiss   xmm0, xmm7
433d9410 jbe      0x433d9459
433d9412 comiss   xmm1, xmm0
433d9415 jbe      0x433d9459
433d9417 lea      esi, [esp + 0x334]
433d941e lea      edi, [ecx + 4]
433d9421 movsd    dword ptr es:[edi], dword ptr [esi]
433d9422 movsd    dword ptr es:[edi], dword ptr [esi]
433d9423 movsd    dword ptr es:[edi], dword ptr [esi]
433d9424 jmp      0x433d9459
433d9426 mov      ecx, dword ptr [esp + 0x20]
433d942a movss    xmm7, dword ptr [esp + 0x18]
433d9430 and      dword ptr [ecx + 0x1c], 0xfffffffe
433d9434 movss    xmm0, dword ptr [ecx + 0x18]
433d9439 comiss   xmm0, xmm7
433d943c jbe      0x433d9459
433d943e cmp      byte ptr [ecx + 0xcc], 8
433d9445 je       0x433d9459
433d9447 mov      dword ptr [ecx + 0xc8], 0x3e800000
433d9451 jmp      0x433d9459
433d9453 and      edx, 0xfffffffe
433d9456 mov      dword ptr [ecx + 0x1c], edx
433d9459 and      dword ptr [ecx + 0x2c], 0
433d945d movaps   xmm2, xmm7
433d9460 and      dword ptr [ecx + 0x1c], 0xfffffff9
433d9464 jmp      0x433da2fd
433d9469 comiss   xmm4, xmm2
433d946c movaps   xmm0, xmm2
433d946f jbe      0x433d9478
433d9471 mov      byte ptr [ecx + 0xc0], 1
433d9478 cmp      byte ptr [ecx + 0xc0], 0
433d947f movaps   xmm2, xmm0
433d9482 je       0x433da2fd
433d9488 mov      esi, dword ptr [ecx]
433d948a mulss    xmm1, dword ptr [0x43472c90]
433d9492 mov      dword ptr [esp + 0x1c], esi
433d9496 test     esi, esi
433d9498 jne      0x433d94a6
433d949a aam      0x74
433d949c mov      ecx, 0xbd462734
433d94a1 mov      bh, 0xb7
433d94a3 dec      esi
433d94a4 mov      byte ptr [0xa7e0a153], al
433d94a6 mov      eax, dword ptr [0x4346a7e0]
433d94a9 inc      esi
433d94aa inc      ebx
433d94ab mov      eax, dword ptr [eax]
433d94ad xor      eax, dword ptr [0x43468c34]
433d94b3 xor      eax, 0xa15c3105
433d94b8 cmp      byte ptr [eax + esi], 0
433d94bc je       0x433d94c6
433d94be mulss    xmm1, dword ptr [0x43470228]
433d94c6 movaps   xmm2, xmm0
433d94c9 mulss    xmm1, xmm6
433d94cd movaps   xmm3, xmm4
433d94d0 subss    xmm3, xmm2
433d94d4 comiss   xmm3, xmm1
433d94d7 jbe      0x433d94df
433d94d9 addss    xmm2, xmm1
433d94dd jmp      0x433d94f7
433d94df movaps   xmm0, xmm1
433d94e2 xorps    xmm0, xmmword ptr [0x434703d0]
433d94e9 comiss   xmm0, xmm3
433d94ec jbe      0x433d94f4
433d94ee subss    xmm2, xmm1
433d94f2 jmp      0x433d94f7
433d94f4 movaps   xmm2, xmm4
433d94f7 comiss   xmm2, xmm4
433d94fa movss    dword ptr [ecx + 0x2c], xmm2
433d94ff jae      0x433d9547
433d9501 test     dl, dl
433d9503 je       0x433d9547
433d9505 movaps   xmm0, xmm2
433d9508 mulss    xmm0, xmm2
433d950c movaps   xmm1, xmm0
433d950f addss    xmm0, xmm0
433d9513 mulss    xmm1, dword ptr [0x4346faf4]
433d951b mulss    xmm0, xmm2
433d951f subss    xmm1, xmm0
433d9523 movaps   xmm0, xmm4
433d9526 subss    xmm0, xmm1
433d952a mulss    xmm0, dword ptr [0x43470430]
433d9532 addss    xmm0, dword ptr [0x4346fd94]
433d953a movss    dword ptr [ecx + 0x30], xmm0
433d953f movaps   xmm0, xmm2
433d9542 jmp      0x433da2f4
433d9547 test     dh, 1
433d954a jne      0x433d9567
433d954c cmp      byte ptr [ecx + 0xcc], 9
433d9553 je       0x433d9567
433d9555 movss    xmm0, dword ptr [ecx + 0xc]
433d955a addss    xmm0, dword ptr [0x4346fe78]
433d9562 movss    dword ptr [ecx + 0xc], xmm0
433d9567 mov      dword ptr [ecx + 0x30], 0x42380000
433d956e lea      eax, [ecx + 0xc8]
433d9574 mov      byte ptr [ecx + 0xc0], 0
433d957b lea      edi, [esp + 0x58]
433d957f mov      edx, dword ptr [ecx + 0x1c]
433d9582 movss    xmm2, dword ptr [0x434720b0]
433d958a or       edx, 6
433d958d mov      dword ptr [ecx + 0x1c], edx
433d9590 mov      dword ptr [eax], 0x3f800000
433d9596 or       dword ptr [esp + 0x3c4], 0xffffffff
433d959e or       dword ptr [esp + 0x3d0], 0xffffffff
433d95a6 mov      dword ptr [esp + 0x74], eax
433d95aa xor      eax, eax
433d95ac mov      word ptr [esp + 0x3b6], ax
433d95b4 mov      dword ptr [esp + 0x3cc], eax
433d95bb lea      eax, [ecx + 4]
433d95be mov      dword ptr [esp + 0x3ac], 0x3f800000
433d95c9 mov      esi, eax
433d95cb movss    xmm1, dword ptr [ecx + 0x18]
433d95d0 comiss   xmm1, xmm7
433d95d3 mov      dword ptr [esp + 0x44], eax
433d95d7 movsd    dword ptr es:[edi], dword ptr [esi]
433d95d8 movsd    dword ptr es:[edi], dword ptr [esi]
433d95d9 seta     byte ptr [esp + 0x2b]
433d95de movsd    dword ptr es:[edi], dword ptr [esi]
433d95df movss    xmm0, dword ptr [esp + 0x60]
433d95e5 subss    xmm0, dword ptr [0x4347259c]
433d95ed comiss   xmm1, xmm2
433d95f0 movss    dword ptr [esp + 0x2c], xmm0
433d95f6 seta     al
433d95f9 test     al, al
433d95fb je       0x433d960d
433d95fd test     byte ptr [ecx + 0x1c], 1
433d9601 je       0x433d960d
433d9603 subss    xmm1, xmm1
433d9607 comiss   xmm1, xmm2
433d960a seta     al
433d960d mov      ah, byte ptr [ecx + 0xcc]
433d9613 mov      byte ptr [esp + 0x17], 0
433d9618 cmp      ah, 2
433d961b jne      0x433d9636
433d961d test     byte ptr [ecx + 0x1c], 1
433d9621 je       0x433d9636
433d9623 subss    xmm0, dword ptr [ecx + 0xdc]
433d962b mov      byte ptr [esp + 0x17], 1
433d9630 movss    dword ptr [esp + 0x2c], xmm0
433d9636 test     al, al
433d9638 jne      0x433da2d2
433d963e cmp      byte ptr [esp + 0x2b], al
433d9642 je       0x433d964d
433d9644 cmp      ah, 9
433d9647 je       0x433da2d2
433d964d mov      edx, dword ptr [0x43468304]
433d9653 lea      esi, [ecx + 4]
433d9656 mov      eax, dword ptr [esp + 0x1c]
433d965a lea      edi, [esp + 0x68]
433d965e movss    xmm2, dword ptr [esp + 0x58]
433d9664 movss    xmm1, dword ptr [esp + 0x5c]
433d966a movsd    dword ptr es:[edi], dword ptr [esi]
433d966b movsd    dword ptr es:[edi], dword ptr [esi]
433d966c movsd    dword ptr es:[edi], dword ptr [esi]
433d966d and      dword ptr [esp + 0x4f4], 0
433d9675 subss    xmm1, dword ptr [esp + 0x6c]
433d967b subss    xmm2, dword ptr [esp + 0x68]
433d9681 subss    xmm0, dword ptr [esp + 0x70]
433d9687 mov      dword ptr [esp + 0x4ec], eax
433d968e mov      dword ptr [esp + 0x4e8], 0x4346edc0
433d9699 mov      dword ptr [esp + 0x4f0], 8
433d96a4 mov      eax, dword ptr [edx]
433d96a6 mov      edi, dword ptr [eax + 0x14]
433d96a9 mov      eax, dword ptr [ecx + 0xd0]
433d96af and      dword ptr [esp + 0x790], 0
433d96b7 movss    dword ptr [esp + 0x764], xmm1
433d96c0 movss    dword ptr [esp + 0x760], xmm2
433d96c9 mulss    xmm1, xmm1
433d96cd mov      dword ptr [esp + 0x1c], eax
433d96d1 mulss    xmm2, xmm2
433d96d5 mov      byte ptr [esp + 0x795], 1
433d96dd movss    dword ptr [esp + 0x768], xmm0
433d96e6 mulss    xmm0, xmm0
433d96ea addss    xmm1, xmm2
433d96ee addss    xmm1, xmm0
433d96f2 ucomiss  xmm1, xmm7
433d96f5 lahf     
433d96f6 test     ah, 0x44
433d96f9 jp       0x433d9703
433d96fb mov      byte ptr [esp + 0x795], 0
433d9703 movss    xmm3, dword ptr [ecx + 0x44]
433d9708 lea      eax, [esp + 0x380]
433d970f movss    xmm4, dword ptr [ecx + 0x48]
433d9714 movaps   xmm2, xmm3
433d9717 movss    xmm6, dword ptr [ecx + 0x38]
433d971c movaps   xmm1, xmm4
433d971f movss    xmm7, dword ptr [ecx + 0x3c]
433d9724 subss    xmm2, xmm6
433d9728 movss    xmm0, dword ptr [ecx + 0x40]
433d972d subss    xmm1, xmm7
433d9731 movss    xmm5, dword ptr [ecx + 0x4c]
433d9736 addss    xmm6, xmm3
433d973a movss    dword ptr [esp + 0x24], xmm0
433d9740 addss    xmm7, xmm4
433d9744 movaps   xmm0, xmm5
433d9747 mov      ecx, edx
433d9749 subss    xmm0, dword ptr [esp + 0x24]
433d974f mulss    xmm1, dword ptr [0x43472240]
433d9757 push     eax
433d9758 mulss    xmm2, dword ptr [0x43472240]
433d9760 lea      eax, [esp + 0x4ec]
433d9767 push     eax
433d9768 mulss    xmm0, dword ptr [0x43472240]
433d9770 lea      eax, [esp + 0x758]
433d9777 movss    dword ptr [esp + 0x78c], xmm1
433d9780 mulss    xmm1, xmm1
433d9784 movss    dword ptr [esp + 0x790], xmm0
433d978d mulss    xmm0, xmm0
433d9791 movss    dword ptr [esp + 0x788], xmm2
433d979a mulss    xmm2, xmm2
433d979e push     dword ptr [esp + 0x24]
433d97a2 addss    xmm1, xmm2
433d97a6 push     eax
433d97a7 addss    xmm1, xmm0
433d97ab cvtps2pd xmm0, xmm1
433d97ae movsd    xmm1, qword ptr [esp + 0xa0]
433d97b7 comisd   xmm1, xmm0
433d97bb movss    xmm1, dword ptr [esp + 0x34]
433d97c1 movss    xmm0, dword ptr [0x43472240]
433d97c9 addss    xmm1, xmm5
433d97cd mulss    xmm6, xmm0
433d97d1 seta     byte ptr [esp + 0x7a4]
433d97d9 mulss    xmm7, xmm0
433d97dd mulss    xmm1, xmm0
433d97e1 movss    xmm0, dword ptr [esp + 0x78]
433d97e7 addss    xmm0, xmm6
433d97eb movss    dword ptr [esp + 0x760], xmm0
433d97f4 movss    xmm0, dword ptr [esp + 0x7c]
433d97fa addss    xmm0, xmm7
433d97fe movss    dword ptr [esp + 0x764], xmm0
433d9807 movaps   xmm0, xmm1
433d980a addss    xmm0, dword ptr [esp + 0x80]
433d9813 movss    dword ptr [esp + 0x768], xmm0
433d981c movss    xmm0, dword ptr [0x4346f858]
433d9824 mulss    xmm6, xmm0
433d9828 mulss    xmm7, xmm0
433d982c mulss    xmm1, xmm0
433d9830 movss    dword ptr [esp + 0x780], xmm6
433d9839 movss    dword ptr [esp + 0x784], xmm7
433d9842 movss    dword ptr [esp + 0x788], xmm1
433d984b call     edi
433d984d movss    xmm0, dword ptr [esp + 0x3ac]
433d9856 movss    xmm1, dword ptr [0x43470514]
433d985e comiss   xmm1, xmm0
433d9861 movss    dword ptr [esp + 0x3c], xmm0
433d9867 ja       0x433d987d
433d9869 cmp      byte ptr [esp + 0x3b6], 0
433d9871 jne      0x433d987d
433d9873 cmp      byte ptr [esp + 0x3b7], 0
433d987b je       0x433d989e
433d987d mov      edx, dword ptr [esp + 0x3cc]
433d9884 test     edx, edx
433d9886 je       0x433d989e
433d9888 movss    xmm0, dword ptr [esp + 0x3a0]
433d9891 comiss   xmm0, dword ptr [0x4346fd8c]
433d9898 jae      0x433da1d5
433d989e mov      ecx, dword ptr [esp + 0x20]
433d98a2 lea      esi, [esp + 0x38c]
433d98a9 lea      edi, [esp + 0x110]
433d98b0 movsd    dword ptr es:[edi], dword ptr [esi]
433d98b1 mov      eax, dword ptr [ecx]
433d98b3 and      dword ptr [esp + 0x2fc], 0
433d98bb movsd    dword ptr es:[edi], dword ptr [esi]
433d98bc mov      dword ptr [esp + 0x2f0], 0x4346edc0
433d98c7 mov      dword ptr [esp + 0x2f4], eax
433d98ce mov      dword ptr [esp + 0x2f8], 8
433d98d9 movsd    dword ptr es:[edi], dword ptr [esi]
433d98da lea      esi, [ecx + 0x38]
433d98dd lea      edi, [esp + 0x104]
433d98e4 movsd    dword ptr es:[edi], dword ptr [esi]
433d98e5 movsd    dword ptr es:[edi], dword ptr [esi]
433d98e6 movsd    dword ptr es:[edi], dword ptr [esi]
433d98e7 mov      esi, ecx
433d98e9 movss    xmm0, dword ptr [esi + 0x4c]
433d98ee movss    xmm1, dword ptr [esi + 0x48]
433d98f3 movss    dword ptr [esp + 0x34], xmm0
433d98f9 movss    xmm0, dword ptr [esp + 0x18]
433d98ff call     0x43367633
433d9904 movss    xmm1, dword ptr [esi + 0x44]
433d9909 movss    dword ptr [esp + 0x24], xmm0
433d990f movss    xmm0, dword ptr [esp + 0x18]
433d9915 call     0x43367633
433d991a and      dword ptr [esp + 0x270], 0
433d9922 movaps   xmm4, xmm0
433d9925 movss    xmm7, dword ptr [esi + 4]
433d992a movss    xmm2, dword ptr [esp + 0x58]
433d9930 movss    xmm1, dword ptr [esp + 0x5c]
433d9936 subss    xmm2, xmm7
433d993a movss    dword ptr [esp + 0x68], xmm4
433d9940 movss    dword ptr [esp + 0x240], xmm2
433d9949 movss    xmm0, dword ptr [esi + 8]
433d994e subss    xmm1, xmm0
433d9952 movss    dword ptr [esp + 0x1c], xmm0
433d9958 movss    xmm0, dword ptr [esp + 0x2c]
433d995e mulss    xmm2, xmm2
433d9962 movss    dword ptr [esp + 0x244], xmm1
433d996b movss    xmm3, dword ptr [esi + 0xc]
433d9970 subss    xmm0, xmm3
433d9974 mulss    xmm1, xmm1
433d9978 mov      byte ptr [esp + 0x275], 1
433d9980 movss    dword ptr [esp + 0x30], xmm3
433d9986 addss    xmm2, xmm1
433d998a movss    dword ptr [esp + 0x248], xmm0
433d9993 mulss    xmm0, xmm0
433d9997 addss    xmm2, xmm0
433d999b ucomiss  xmm2, dword ptr [esp + 0x18]
433d99a0 lahf     
433d99a1 test     ah, 0x44
433d99a4 jp       0x433d99ae
433d99a6 mov      byte ptr [esp + 0x275], 0
433d99ae movss    xmm5, dword ptr [esp + 0x104]
433d99b7 lea      edx, [esp + 0x380]
433d99be movss    xmm1, dword ptr [esp + 0x24]
433d99c4 movaps   xmm2, xmm4
433d99c7 movss    xmm4, dword ptr [esp + 0x108]
433d99d0 subss    xmm2, xmm5
433d99d4 movss    xmm6, dword ptr [0x43472240]
433d99dc subss    xmm1, xmm4
433d99e0 movss    xmm0, dword ptr [esp + 0x34]
433d99e6 movss    xmm3, dword ptr [esp + 0x10c]
433d99ef addss    xmm4, dword ptr [esp + 0x24]
433d99f5 subss    xmm0, xmm3
433d99f9 mulss    xmm2, xmm6
433d99fd mov      ecx, dword ptr [0x43468304]
433d9a03 mulss    xmm1, xmm6
433d9a07 push     edx
433d9a08 addss    xmm3, dword ptr [esp + 0x38]
433d9a0e mulss    xmm0, xmm6
433d9a12 lea      edx, [esp + 0x2f4]
433d9a19 push     edx
433d9a1a movss    dword ptr [esp + 0x26c], xmm1
433d9a23 lea      edx, [esp + 0x238]
433d9a2a movss    dword ptr [esp + 0x268], xmm2
433d9a33 movss    dword ptr [esp + 0x270], xmm0
433d9a3c mulss    xmm1, xmm1
433d9a40 mulss    xmm2, xmm2
433d9a44 mulss    xmm0, xmm0
433d9a48 addss    xmm5, dword ptr [esp + 0x70]
433d9a4e addss    xmm1, xmm2
433d9a52 mulss    xmm4, xmm6
433d9a56 mulss    xmm3, xmm6
433d9a5a mulss    xmm5, xmm6
433d9a5e addss    xmm1, xmm0
433d9a62 addss    xmm7, xmm5
433d9a66 cvtps2pd xmm0, xmm1
433d9a69 movsd    xmm1, qword ptr [esp + 0x98]
433d9a72 comisd   xmm1, xmm0
433d9a76 movaps   xmm0, xmm4
433d9a79 movss    dword ptr [esp + 0x238], xmm7
433d9a82 addss    xmm0, dword ptr [esp + 0x24]
433d9a88 seta     byte ptr [esp + 0x27c]
433d9a90 movss    dword ptr [esp + 0x23c], xmm0
433d9a99 movss    xmm0, dword ptr [esp + 0x38]
433d9a9f addss    xmm0, xmm3
433d9aa3 movss    dword ptr [esp + 0x240], xmm0
433d9aac movss    xmm0, dword ptr [0x4346f858]
433d9ab4 mulss    xmm5, xmm0
433d9ab8 mulss    xmm4, xmm0
433d9abc mulss    xmm3, xmm0
433d9ac0 movss    dword ptr [esp + 0x258], xmm5
433d9ac9 movss    dword ptr [esp + 0x25c], xmm4
433d9ad2 movss    dword ptr [esp + 0x260], xmm3
433d9adb push     dword ptr [esi + 0xd0]
433d9ae1 mov      eax, dword ptr [ecx]
433d9ae3 push     edx
433d9ae4 call     dword ptr [eax + 0x14]
433d9ae7 cmp      dword ptr [esp + 0x3cc], 0
433d9aef je       0x433d9b0b
433d9af1 movss    xmm0, dword ptr [esp + 0x3a0]
433d9afa movss    xmm2, dword ptr [0x4346fd8c]
433d9b02 comiss   xmm0, xmm2
433d9b05 jae      0x433da16f
433d9b0b movss    xmm0, dword ptr [esi + 0x40]
433d9b10 movss    xmm1, dword ptr [esi + 0x3c]
433d9b15 movss    dword ptr [esp + 0x34], xmm0
433d9b1b movss    xmm0, dword ptr [esp + 0x18]
433d9b21 call     0x4332fc35
433d9b26 movss    xmm1, dword ptr [esi + 0x38]
433d9b2b movss    dword ptr [esp + 0x24], xmm0
433d9b31 movss    xmm0, dword ptr [esp + 0x18]
433d9b37 call     0x4332fc35
433d9b3c movss    xmm2, dword ptr [esp + 0x58]
433d9b42 lea      esi, [esi + 0x44]
433d9b45 movss    xmm1, dword ptr [esp + 0x5c]
433d9b4b lea      edi, [esp + 0x68]
433d9b4f movsd    dword ptr es:[edi], dword ptr [esi]
433d9b50 movaps   xmm6, xmm0
433d9b53 movsd    dword ptr es:[edi], dword ptr [esi]
433d9b54 movsd    dword ptr es:[edi], dword ptr [esi]
433d9b55 mov      edi, dword ptr [esp + 0x44]
433d9b59 and      dword ptr [esp + 0x270], 0
433d9b61 movss    xmm7, dword ptr [edi]
433d9b65 subss    xmm2, xmm7
433d9b69 movss    dword ptr [esp + 0x240], xmm2
433d9b72 movss    xmm0, dword ptr [edi + 4]
433d9b77 subss    xmm1, xmm0
433d9b7b movss    dword ptr [esp + 0x1c], xmm0
433d9b81 movss    xmm0, dword ptr [esp + 0x2c]
433d9b87 mulss    xmm2, xmm2
433d9b8b movss    dword ptr [esp + 0x244], xmm1
433d9b94 movss    xmm3, dword ptr [edi + 8]
433d9b99 subss    xmm0, xmm3
433d9b9d mulss    xmm1, xmm1
433d9ba1 mov      byte ptr [esp + 0x275], 1
433d9ba9 movss    dword ptr [esp + 0x30], xmm3
433d9baf addss    xmm1, xmm2
433d9bb3 movss    dword ptr [esp + 0x248], xmm0
433d9bbc mulss    xmm0, xmm0
433d9bc0 addss    xmm1, xmm0
433d9bc4 ucomiss  xmm1, dword ptr [esp + 0x18]
433d9bc9 lahf     
433d9bca test     ah, 0x44
433d9bcd jp       0x433d9bd7
433d9bcf mov      byte ptr [esp + 0x275], 0
433d9bd7 movss    xmm4, dword ptr [esp + 0x6c]
433d9bdd lea      edx, [esp + 0x380]
433d9be4 movss    xmm2, dword ptr [esp + 0x68]
433d9bea movaps   xmm1, xmm4
433d9bed subss    xmm1, dword ptr [esp + 0x24]
433d9bf3 movss    xmm5, dword ptr [0x43472240]
433d9bfb subss    xmm2, xmm6
433d9bff movss    xmm3, dword ptr [esp + 0x70]
433d9c05 addss    xmm4, dword ptr [esp + 0x24]
433d9c0b movaps   xmm0, xmm3
433d9c0e mov      ecx, dword ptr [0x43468304]
433d9c14 subss    xmm0, dword ptr [esp + 0x34]
433d9c1a mulss    xmm2, xmm5
433d9c1e mov      esi, dword ptr [esp + 0x20]
433d9c22 mulss    xmm1, xmm5
433d9c26 push     edx
433d9c27 mulss    xmm0, xmm5
433d9c2b lea      edx, [esp + 0x2f4]
433d9c32 push     edx
433d9c33 addss    xmm3, dword ptr [esp + 0x3c]
433d9c39 movss    dword ptr [esp + 0x268], xmm2
433d9c42 lea      edx, [esp + 0x238]
433d9c49 movss    dword ptr [esp + 0x26c], xmm1
433d9c52 movss    dword ptr [esp + 0x270], xmm0
433d9c5b mulss    xmm2, xmm2
433d9c5f mulss    xmm1, xmm1
433d9c63 mulss    xmm0, xmm0
433d9c67 addss    xmm6, dword ptr [esp + 0x70]
433d9c6d addss    xmm2, xmm1
433d9c71 mulss    xmm4, xmm5
433d9c75 movsd    xmm1, qword ptr [esp + 0x98]
433d9c7e mulss    xmm3, xmm5
433d9c82 addss    xmm2, xmm0
433d9c86 mulss    xmm6, xmm5
433d9c8a addss    xmm7, xmm6
433d9c8e cvtps2pd xmm0, xmm2
433d9c91 movss    dword ptr [esp + 0x238], xmm7
433d9c9a comisd   xmm1, xmm0
433d9c9e movaps   xmm0, xmm4
433d9ca1 addss    xmm0, dword ptr [esp + 0x24]
433d9ca7 seta     byte ptr [esp + 0x27c]
433d9caf movss    dword ptr [esp + 0x23c], xmm0
433d9cb8 movss    xmm0, dword ptr [esp + 0x38]
433d9cbe addss    xmm0, xmm3
433d9cc2 movss    dword ptr [esp + 0x240], xmm0
433d9ccb movss    xmm0, dword ptr [0x4346f858]
433d9cd3 mulss    xmm6, xmm0
433d9cd7 mulss    xmm4, xmm0
433d9cdb mulss    xmm3, xmm0
433d9cdf movss    dword ptr [esp + 0x258], xmm6
433d9ce8 movss    dword ptr [esp + 0x25c], xmm4
433d9cf1 movss    dword ptr [esp + 0x260], xmm3
433d9cfa push     dword ptr [esi + 0xd0]
433d9d00 mov      eax, dword ptr [ecx]
433d9d02 push     edx
433d9d03 call     dword ptr [eax + 0x14]
433d9d06 cmp      dword ptr [esp + 0x3cc], 0
433d9d0e je       0x433d9d2a
433d9d10 movss    xmm0, dword ptr [esp + 0x3a0]
433d9d19 movss    xmm2, dword ptr [0x4346fd8c]
433d9d21 comiss   xmm0, xmm2
433d9d24 jae      0x433da16f
433d9d2a movss    xmm0, dword ptr [esi + 0x40]
433d9d2f movss    xmm1, dword ptr [esi + 0x3c]
433d9d34 movss    dword ptr [esp + 0x78], xmm0
433d9d3a movss    xmm0, dword ptr [esp + 0x18]
433d9d40 call     0x4332fc35
433d9d45 movss    xmm1, dword ptr [esi + 0x44]
433d9d4a movss    dword ptr [esp + 0x1c], xmm0
433d9d50 movss    xmm0, dword ptr [esi + 0x38]
433d9d55 movss    dword ptr [esp + 0x24], xmm0
433d9d5b movss    xmm0, dword ptr [esi + 0x4c]
433d9d60 movss    dword ptr [esp + 0x30], xmm0
433d9d66 movss    xmm0, dword ptr [esi + 0x48]
433d9d6b movss    dword ptr [esp + 0x34], xmm0
433d9d71 movss    xmm0, dword ptr [esp + 0x18]
433d9d77 call     0x43367633
433d9d7c and      dword ptr [esp + 0x270], 0
433d9d84 movaps   xmm4, xmm0
433d9d87 movss    xmm0, dword ptr [edi]
433d9d8b movss    xmm2, dword ptr [esp + 0x58]
433d9d91 movss    xmm1, dword ptr [esp + 0x5c]
433d9d97 subss    xmm2, xmm0
433d9d9b movss    dword ptr [esp + 0x44], xmm0
433d9da1 movss    dword ptr [esp + 0x240], xmm2
433d9daa movss    xmm0, dword ptr [edi + 4]
433d9daf subss    xmm1, xmm0
433d9db3 movss    dword ptr [esp + 0x50], xmm0
433d9db9 movss    xmm0, dword ptr [esp + 0x2c]
433d9dbf mulss    xmm2, xmm2
433d9dc3 movss    dword ptr [esp + 0x244], xmm1
433d9dcc movss    xmm7, dword ptr [edi + 8]
433d9dd1 subss    xmm0, xmm7
433d9dd5 mulss    xmm1, xmm1
433d9dd9 mov      byte ptr [esp + 0x275], 1
433d9de1 addss    xmm1, xmm2
433d9de5 movss    dword ptr [esp + 0x248], xmm0
433d9dee mulss    xmm0, xmm0
433d9df2 addss    xmm1, xmm0
433d9df6 ucomiss  xmm1, dword ptr [esp + 0x18]
433d9dfb lahf     
433d9dfc test     ah, 0x44
433d9dff jp       0x433d9e09
433d9e01 mov      byte ptr [esp + 0x275], 0
433d9e09 movss    xmm5, dword ptr [esp + 0x1c]
433d9e0f lea      edx, [esp + 0x380]
433d9e16 movss    xmm1, dword ptr [esp + 0x34]
433d9e1c movaps   xmm2, xmm4
433d9e1f subss    xmm2, dword ptr [esp + 0x24]
433d9e25 movss    xmm3, dword ptr [0x43472240]
433d9e2d subss    xmm1, xmm5
433d9e31 movss    xmm6, dword ptr [esp + 0x30]
433d9e37 addss    xmm4, dword ptr [esp + 0x24]
433d9e3d movaps   xmm0, xmm6
433d9e40 mov      ecx, dword ptr [0x43468304]
433d9e46 subss    xmm0, dword ptr [esp + 0x78]
433d9e4c mulss    xmm1, xmm3
433d9e50 push     edx
433d9e51 addss    xmm5, dword ptr [esp + 0x38]
433d9e57 mulss    xmm2, xmm3
433d9e5b lea      edx, [esp + 0x2f4]
433d9e62 push     edx
433d9e63 mulss    xmm0, xmm3
433d9e67 lea      edx, [esp + 0x238]
433d9e6e movss    dword ptr [esp + 0x26c], xmm1
433d9e77 movss    dword ptr [esp + 0x268], xmm2
433d9e80 movss    dword ptr [esp + 0x270], xmm0
433d9e89 mulss    xmm1, xmm1
433d9e8d mulss    xmm2, xmm2
433d9e91 mulss    xmm0, xmm0
433d9e95 addss    xmm6, dword ptr [esp + 0x80]
433d9e9e addss    xmm1, xmm2
433d9ea2 mulss    xmm4, xmm3
433d9ea6 mulss    xmm5, xmm3
433d9eaa mulss    xmm6, xmm3
433d9eae addss    xmm1, xmm0
433d9eb2 addss    xmm7, xmm6
433d9eb6 cvtps2pd xmm0, xmm1
433d9eb9 movsd    xmm1, qword ptr [esp + 0x98]
433d9ec2 comisd   xmm1, xmm0
433d9ec6 movaps   xmm0, xmm4
433d9ec9 movss    dword ptr [esp + 0x240], xmm7
433d9ed2 addss    xmm0, dword ptr [esp + 0x4c]
433d9ed8 seta     byte ptr [esp + 0x27c]
433d9ee0 movss    dword ptr [esp + 0x238], xmm0
433d9ee9 movaps   xmm0, xmm5
433d9eec addss    xmm0, dword ptr [esp + 0x58]
433d9ef2 movss    dword ptr [esp + 0x23c], xmm0
433d9efb movss    xmm0, dword ptr [0x4346f858]
433d9f03 mulss    xmm4, xmm0
433d9f07 mulss    xmm5, xmm0
433d9f0b mulss    xmm6, xmm0
433d9f0f movss    dword ptr [esp + 0x258], xmm4
433d9f18 movss    dword ptr [esp + 0x25c], xmm5
433d9f21 movss    dword ptr [esp + 0x260], xmm6
433d9f2a push     dword ptr [esi + 0xd0]
433d9f30 mov      eax, dword ptr [ecx]
433d9f32 push     edx
433d9f33 call     dword ptr [eax + 0x14]
433d9f36 cmp      dword ptr [esp + 0x3cc], 0
433d9f3e je       0x433d9f5a
433d9f40 movss    xmm0, dword ptr [esp + 0x3a0]
433d9f49 movss    xmm2, dword ptr [0x4346fd8c]
433d9f51 comiss   xmm0, xmm2
433d9f54 jae      0x433da16f
433d9f5a movss    xmm0, dword ptr [esi + 0x40]
433d9f5f movss    xmm1, dword ptr [esi + 0x38]
433d9f64 movss    dword ptr [esp + 0x34], xmm0
433d9f6a movss    xmm0, dword ptr [esi + 0x3c]
433d9f6f movss    dword ptr [esp + 0x24], xmm0
433d9f75 movss    xmm0, dword ptr [esp + 0x18]
433d9f7b call     0x4332fc35
433d9f80 movss    xmm1, dword ptr [esi + 0x48]
433d9f85 movss    dword ptr [esp + 0x1c], xmm0
433d9f8b movss    xmm0, dword ptr [esi + 0x4c]
433d9f90 movss    dword ptr [esp + 0x30], xmm0
433d9f96 movss    xmm0, dword ptr [esp + 0x18]
433d9f9c call     0x43367633
433d9fa1 movss    xmm3, dword ptr [esi + 0x44]
433d9fa6 movaps   xmm5, xmm0
433d9fa9 and      dword ptr [esp + 0x270], 0
433d9fb1 movss    xmm0, dword ptr [edi]
433d9fb5 movss    xmm2, dword ptr [esp + 0x58]
433d9fbb movss    xmm1, dword ptr [esp + 0x5c]
433d9fc1 subss    xmm2, xmm0
433d9fc5 movss    dword ptr [esp + 0x50], xmm0
433d9fcb movss    dword ptr [esp + 0x44], xmm3
433d9fd1 movss    dword ptr [esp + 0x240], xmm2
433d9fda movss    xmm0, dword ptr [edi + 4]
433d9fdf subss    xmm1, xmm0
433d9fe3 movss    dword ptr [esp + 0x78], xmm0
433d9fe9 movss    xmm0, dword ptr [esp + 0x2c]
433d9fef mulss    xmm2, xmm2
433d9ff3 movss    dword ptr [esp + 0x244], xmm1
433d9ffc movss    xmm7, dword ptr [edi + 8]
433da001 subss    xmm0, xmm7
433da005 mulss    xmm1, xmm1
433da009 mov      byte ptr [esp + 0x275], 1
433da011 addss    xmm1, xmm2
433da015 movss    dword ptr [esp + 0x248], xmm0
433da01e mulss    xmm0, xmm0
433da022 addss    xmm1, xmm0
433da026 ucomiss  xmm1, dword ptr [esp + 0x18]
433da02b lahf     
433da02c test     ah, 0x44
433da02f jp       0x433da039
433da031 mov      byte ptr [esp + 0x275], 0
433da039 movss    xmm4, dword ptr [esp + 0x1c]
433da03f lea      edx, [esp + 0x380]
433da046 movss    xmm6, dword ptr [esp + 0x30]
433da04c movaps   xmm1, xmm5
433da04f subss    xmm1, dword ptr [esp + 0x24]
433da055 movaps   xmm2, xmm3
433da058 mov      ecx, dword ptr [0x43468304]
433da05e movss    xmm3, dword ptr [0x43472240]
433da066 subss    xmm2, xmm4
433da06a addss    xmm4, dword ptr [esp + 0x44]
433da070 movaps   xmm0, xmm6
433da073 subss    xmm0, dword ptr [esp + 0x34]
433da079 addss    xmm5, dword ptr [esp + 0x24]
433da07f mulss    xmm1, xmm3
433da083 push     edx
433da084 mulss    xmm2, xmm3
433da088 lea      edx, [esp + 0x2f4]
433da08f push     edx
433da090 mulss    xmm0, xmm3
433da094 lea      edx, [esp + 0x238]
433da09b movss    dword ptr [esp + 0x26c], xmm1
433da0a4 movss    dword ptr [esp + 0x268], xmm2
433da0ad movss    dword ptr [esp + 0x270], xmm0
433da0b6 mulss    xmm1, xmm1
433da0ba mulss    xmm0, xmm0
433da0be mulss    xmm2, xmm2
433da0c2 addss    xmm6, dword ptr [esp + 0x3c]
433da0c8 mulss    xmm4, xmm3
433da0cc addss    xmm1, xmm2
433da0d0 mulss    xmm5, xmm3
433da0d4 mulss    xmm6, xmm3
433da0d8 addss    xmm1, xmm0
433da0dc xorps    xmm0, xmm0
433da0df addss    xmm7, xmm6
433da0e3 cvtss2sd xmm0, xmm1
433da0e7 movsd    xmm1, qword ptr [esp + 0x98]
433da0f0 comisd   xmm1, xmm0
433da0f4 movaps   xmm0, xmm4
433da0f7 movss    dword ptr [esp + 0x240], xmm7
433da100 addss    xmm0, dword ptr [esp + 0x58]
433da106 seta     byte ptr [esp + 0x27c]
433da10e movss    dword ptr [esp + 0x238], xmm0
433da117 movaps   xmm0, xmm5
433da11a addss    xmm0, dword ptr [esp + 0x80]
433da123 movss    dword ptr [esp + 0x23c], xmm0
433da12c movss    xmm0, dword ptr [0x4346f858]
433da134 mulss    xmm4, xmm0
433da138 mulss    xmm5, xmm0
433da13c mulss    xmm6, xmm0
433da140 movss    dword ptr [esp + 0x258], xmm4
433da149 movss    dword ptr [esp + 0x25c], xmm5
433da152 movss    dword ptr [esp + 0x260], xmm6
433da15b push     dword ptr [esi + 0xd0]
433da161 mov      eax, dword ptr [ecx]
433da163 push     edx
433da164 call     dword ptr [eax + 0x14]
433da167 movss    xmm2, dword ptr [0x4346fd8c]
433da16f movss    xmm0, dword ptr [esp + 0x3c]
433da175 lea      esi, [esp + 0x110]
433da17c movss    xmm1, dword ptr [0x43470514]
433da184 lea      edi, [esp + 0x38c]
433da18b comiss   xmm1, xmm0
433da18e movss    dword ptr [esp + 0x3ac], xmm0
433da197 movsd    dword ptr es:[edi], dword ptr [esi]
433da198 movsd    dword ptr es:[edi], dword ptr [esi]
433da199 movsd    dword ptr es:[edi], dword ptr [esi]
433da19a ja       0x433da1b4
433da19c cmp      byte ptr [esp + 0x3b6], 0
433da1a4 jne      0x433da1b4
433da1a6 cmp      byte ptr [esp + 0x3b7], 0
433da1ae je       0x433da29d
433da1b4 mov      edx, dword ptr [esp + 0x3cc]
433da1bb test     edx, edx
433da1bd je       0x433da29d
433da1c3 movss    xmm0, dword ptr [esp + 0x3a0]
433da1cc comiss   xmm0, xmm2
433da1cf jb       0x433da29d
433da1d5 mov      ecx, dword ptr [esp + 0x20]
433da1d9 movss    xmm0, dword ptr [0x4346f6bc]
433da1e1 comiss   xmm0, dword ptr [ecx + 0x18]
433da1e5 jbe      0x433da1f5
433da1e7 or       byte ptr [ecx + 0x108], 0x10
433da1ee mov      edx, dword ptr [esp + 0x3cc]
433da1f5 mov      eax, dword ptr [ecx + 0x1c]
433da1f8 test     edx, edx
433da1fa je       0x433da256
433da1fc mov      esi, dword ptr [esp + 0x74]
433da200 or       eax, 1
433da203 mov      dword ptr [ecx + 0x1c], eax
433da206 xor      eax, eax
433da208 mov      ecx, dword ptr [0x43469268]
433da20e push     eax
433da20f push     esi
433da210 push     eax
433da211 mov      edx, dword ptr [ecx]
433da213 push     eax
433da214 movsx    eax, word ptr [esp + 0x3d0]
433da21c push     eax
433da21d call     dword ptr [edx + 0x10]
433da220 movss    xmm0, dword ptr [esi]
433da224 mulss    xmm0, dword ptr [0x4347268c]
433da22c movss    xmm1, dword ptr [0x43470514]
433da234 comiss   xmm0, xmm1
433da237 movss    dword ptr [esi], xmm0
433da23b jbe      0x433da243
433da23d mov      dword ptr [esi], 0x3f800000
433da243 mov      ecx, dword ptr [esp + 0x20]
433da247 cmp      byte ptr [ecx + 0xcc], 8
433da24e je       0x433da25c
433da250 and      dword ptr [ecx + 0x18], 0
433da254 jmp      0x433da25c
433da256 and      eax, 0xfffffffe
433da259 mov      dword ptr [ecx + 0x1c], eax
433da25c cmp      byte ptr [esp + 0x17], 0
433da261 movss    xmm7, dword ptr [esp + 0x18]
433da267 je       0x433da2da
433da269 cmp      byte ptr [esp + 0x3b7], 0
433da271 jne      0x433da2da
433da273 movss    xmm0, dword ptr [esp + 0x3ac]
433da27c comiss   xmm0, xmm7
433da27f jbe      0x433da2da
433da281 comiss   xmm1, xmm0
433da284 movss    xmm5, dword ptr [0x43472980]
433da28c jbe      0x433da2e2
433da28e lea      esi, [esp + 0x38c]
433da295 lea      edi, [ecx + 4]
433da298 movsd    dword ptr es:[edi], dword ptr [esi]
433da299 movsd    dword ptr es:[edi], dword ptr [esi]
433da29a movsd    dword ptr es:[edi], dword ptr [esi]
433da29b jmp      0x433da2e2
433da29d mov      ecx, dword ptr [esp + 0x20]
433da2a1 movss    xmm7, dword ptr [esp + 0x18]
433da2a7 and      dword ptr [ecx + 0x1c], 0xfffffffe
433da2ab movss    xmm0, dword ptr [ecx + 0x18]
433da2b0 comiss   xmm0, xmm7
433da2b3 jbe      0x433da2da
433da2b5 cmp      byte ptr [ecx + 0xcc], 8
433da2bc movss    xmm5, dword ptr [0x43472980]
433da2c4 je       0x433da2e2
433da2c6 mov      dword ptr [ecx + 0xc8], 0x3e800000
433da2d0 jmp      0x433da2e2
433da2d2 and      edx, 0xfffffffe
433da2d5 mov      dword ptr [ecx + 0x1c], edx
433da2d8 jmp      0x433da2e2
433da2da movss    xmm5, dword ptr [0x43472980]
433da2e2 movss    xmm0, dword ptr [0x43470514]
433da2ea mov      dword ptr [ecx + 0x2c], 0x3f800000
433da2f1 movaps   xmm2, xmm0
433da2f4 comiss   xmm0, xmm5
433da2f7 jb       0x433da2fd
433da2f9 or       dword ptr [ecx + 0x1c], 4
433da2fd comiss   xmm7, xmm2
433da300 jb       0x433da306
433da302 and      dword ptr [ecx + 0x1c], 0xfffffffb
433da306 mov      dl, byte ptr [ecx + 0x108]
433da30c test     dl, 1
433da30f jne      0x433da39b
433da315 or       dl, 1
433da318 mov      byte ptr [ecx + 0x108], dl
433da31e test     byte ptr [ecx + 0x110], 4
433da325 jne      0x433da336
433da327 cmp      byte ptr [ecx + 0xc0], 0
433da32e jne      0x433da336
433da330 test     byte ptr [ecx + 0x1c], 2
433da334 je       0x433da39b
433da336 movss    xmm5, dword ptr [0x43470514]
433da33e lea      edi, [ecx + 0x114]
433da344 movaps   xmm1, xmm2
433da347 mulss    xmm1, dword ptr [0x43472144]
433da34f addss    xmm1, xmm5
433da353 subss    xmm1, xmm2
433da357 movaps   xmm0, xmm1
433da35a mulss    xmm0, dword ptr [edi]
433da35e movss    dword ptr [edi], xmm0
433da362 movaps   xmm0, xmm1
433da365 mulss    xmm0, dword ptr [edi + 4]
433da36a movss    dword ptr [edi + 4], xmm0
433da36f movaps   xmm0, xmm1
433da372 mulss    xmm0, dword ptr [edi + 8]
433da377 movss    dword ptr [edi + 8], xmm0
433da37c mulss    xmm1, dword ptr [ecx + 0x10c]
433da384 movss    dword ptr [ecx + 0x10c], xmm1
433da38c or       byte ptr [ecx + 0x108], 1
433da393 mov      dl, byte ptr [ecx + 0x108]
433da399 jmp      0x433da3a9
433da39b movss    xmm5, dword ptr [0x43470514]
433da3a3 lea      edi, [ecx + 0x114]
433da3a9 movzx    eax, byte ptr [ecx + 0xcc]
433da3b0 dec      eax
433da3b1 sub      eax, 1
433da3b4 jne      0x433df04e
433da3ba movss    xmm1, dword ptr [ecx + 0x100]
433da3c2 mulss    xmm1, dword ptr [ecx + 0xd4]
433da3ca movss    xmm3, dword ptr [0x43472240]
433da3d2 movss    xmm0, dword ptr [ecx + 0x18]
433da3d7 mulss    xmm1, xmm3
433da3db subss    xmm0, xmm1
433da3df movss    dword ptr [ecx + 0x18], xmm0
433da3e4 test     byte ptr [ecx + 0x110], 2
433da3eb je       0x433da565
433da3f1 and      dl, 0xbf
433da3f4 mov      byte ptr [ecx + 0x108], dl
433da3fa test     byte ptr [ecx + 0x1c], 1
433da3fe je       0x433dd368
433da404 mov      eax, dword ptr [0x43467fa0]
433da409 xor      eax, 0x4b52a9bf
433da40e jmp      0x433da412
433da410 mov      eax, edx
433da412 mov      edx, dword ptr [eax + 0x1c]
433da415 cmp      eax, edx
433da417 jne      0x433da410
433da419 cmp      dword ptr [eax + 0x30], eax
433da41c jne      0x433da497
433da41e movss    xmm4, dword ptr [ecx + 0x10c]
433da426 mulss    xmm4, dword ptr [0x4346f408]
433da42e comiss   xmm7, xmm4
433da431 jae      0x433da497
433da433 movss    xmm2, dword ptr [ecx + 0x10]
433da438 movaps   xmm1, xmm0
433da43b movss    xmm0, dword ptr [ecx + 0x14]
433da440 mulss    xmm2, xmm2
433da444 mulss    xmm0, xmm0
433da448 mulss    xmm1, xmm1
433da44c addss    xmm2, xmm0
433da450 addss    xmm2, xmm1
433da454 movaps   xmm0, xmm2
433da457 sqrtss   xmm0, xmm0
433da45b comiss   xmm0, xmm4
433da45e movss    dword ptr [esp + 0x580], xmm0
433da467 jbe      0x433da497
433da469 divss    xmm4, xmm0
433da46d movss    xmm0, dword ptr [ecx + 0x10]
433da472 mulss    xmm0, xmm4
433da476 movss    dword ptr [ecx + 0x10], xmm0
433da47b movss    xmm0, dword ptr [ecx + 0x14]
433da480 mulss    xmm0, xmm4
433da484 movss    dword ptr [ecx + 0x14], xmm0
433da489 movss    xmm0, dword ptr [ecx + 0x18]
433da48e mulss    xmm0, xmm4
433da492 movss    dword ptr [ecx + 0x18], xmm0
433da497 mov      eax, dword ptr [ecx + 0x1c]
433da49a and      eax, 0xfffffffe
433da49d mov      dword ptr [ecx + 0x1c], eax
433da4a0 cmp      byte ptr [ecx + 0xc0], 0
433da4a7 jne      0x433da4bc
433da4a9 test     al, 2
433da4ab jne      0x433da4bc
433da4ad movss    xmm4, dword ptr [ecx + 0xd8]
433da4b5 addss    xmm4, dword ptr [ecx + 0x18]
433da4ba jmp      0x433da4c4
433da4bc movss    xmm4, dword ptr [ecx + 0xd8]
433da4c4 movss    dword ptr [ecx + 0x18], xmm4
433da4c9 movss    xmm0, dword ptr [ecx + 0x34]
433da4ce comiss   xmm0, xmm7
433da4d1 movaps   xmm6, xmm0
433da4d4 jbe      0x433da50f
433da4d6 movaps   xmm0, xmm6
433da4d9 movaps   xmm1, xmm5
433da4dc divss    xmm0, dword ptr [0x434704a0]
433da4e4 xorps    xmm2, xmm2
433da4e7 subss    xmm1, xmm0
433da4eb xorps    xmm0, xmm0
433da4ee movss    xmm0, xmm7
433da4f2 movss    xmm2, xmm1
433da4f6 maxss    xmm2, xmm0
433da4fa xorps    xmm0, xmm0
433da4fd movss    xmm0, xmm5
433da501 minss    xmm2, xmm0
433da505 movss    dword ptr [esp + 0x64], xmm2
433da50b mulss    xmm4, xmm2
433da50f movss    xmm0, dword ptr [ecx + 0x100]
433da517 mulss    xmm0, dword ptr [ecx + 0xd4]
433da51f mulss    xmm0, xmm3
433da523 subss    xmm4, xmm0
433da527 movss    dword ptr [ecx + 0x18], xmm4
433da52c movss    xmm0, dword ptr [ecx + 0xe8]
433da534 mulss    xmm0, dword ptr [ecx + 0xd8]
433da53c movss    xmm1, dword ptr [ecx + 0xec]
433da544 addss    xmm0, xmm6
433da548 movaps   xmm2, xmm0
433da54b xorps    xmm0, xmm0
433da54e movss    xmm0, xmm7
433da552 maxss    xmm2, xmm0
433da556 minss    xmm2, xmm1
433da55a movss    dword ptr [esp + 0x38], xmm2
433da560 movss    dword ptr [ecx + 0x34], xmm2
433da565 test     byte ptr [ecx + 0x1c], 1
433da569 je       0x433dd368
433da56f and      dword ptr [ecx + 0x18], 0
433da573 lea      esi, [ecx + 0x10]
433da576 and      dword ptr [ecx + 0xc4], 0
433da57d movss    xmm0, dword ptr [esi + 4]
433da582 movss    xmm2, dword ptr [esi]
433da586 movss    xmm1, dword ptr [esi + 8]
433da58b mulss    xmm2, xmm2
433da58f mov      dword ptr [esp + 0x80], esi
433da596 mulss    xmm0, xmm0
433da59a mulss    xmm1, xmm1
433da59e addss    xmm2, xmm0
433da5a2 addss    xmm2, xmm1
433da5a6 movaps   xmm0, xmm2
433da5a9 sqrtss   xmm0, xmm0
433da5ad comiss   xmm0, dword ptr [0x43472980]
433da5b4 movups   xmmword ptr [esp + 0x310], xmm0
433da5bc movss    dword ptr [esp + 0x78], xmm0
433da5c2 jb       0x433da63e
433da5c4 movaps   xmm1, xmm0
433da5c7 movss    xmm0, dword ptr [ecx + 0xf0]
433da5cf call     0x4332fc35
433da5d4 mov      ecx, dword ptr [esp + 0x20]
433da5d8 movss    xmm1, dword ptr [ecx + 0xf4]
433da5e0 mulss    xmm1, xmm0
433da5e4 movss    xmm0, dword ptr [esp + 0x310]
433da5ed mulss    xmm1, dword ptr [ecx + 0x100]
433da5f5 subss    xmm0, xmm1
433da5f9 movss    xmm1, dword ptr [esp + 0x18]
433da5ff call     0x4332fc35
433da604 movaps   xmm1, xmm0
433da607 movups   xmm0, xmmword ptr [esp + 0x310]
433da60f ucomiss  xmm1, xmm0
433da612 lahf     
433da613 test     ah, 0x44
433da616 jnp      0x433da63e
433da618 divss    xmm1, xmm0
433da61c movaps   xmm0, xmm1
433da61f mulss    xmm0, dword ptr [esi]
433da623 movss    dword ptr [esi], xmm0
433da627 movaps   xmm0, xmm1
433da62a mulss    xmm0, dword ptr [esi + 4]
433da62f movss    dword ptr [esi + 4], xmm0
433da634 mulss    xmm1, dword ptr [esi + 8]
433da639 movss    dword ptr [esi + 8], xmm1
433da63e mov      ecx, dword ptr [ebp + 0xc]
433da641 lea      eax, [esp + 0xf8]
433da648 push     0
433da64a push     eax
433da64b add      ecx, 0xc
433da64e lea      edx, [esp + 0xf4]
433da655 call     0x43366128
433da65a mov      ecx, dword ptr [esp + 0x20]
433da65e movss    xmm0, dword ptr [esp + 0xf4]
433da667 movss    xmm4, dword ptr [esp + 0x18]
433da66d movss    xmm3, dword ptr [0x43472108]
433da675 mov      al, byte ptr [ecx + 0x1c]
433da678 movss    xmm2, dword ptr [0x43470514]
433da680 and      al, 1
433da682 ucomiss  xmm0, xmm4
433da685 mov      byte ptr [esp + 0x7f], al
433da689 lahf     
433da68a test     ah, 0x44
433da68d jnp      0x433da6ff
433da68f movss    xmm1, dword ptr [esp + 0xec]
433da698 movaps   xmm6, xmm2
433da69b movss    xmm0, dword ptr [esp + 0xf0]
433da6a4 mulss    xmm1, xmm1
433da6a8 and      dword ptr [esp + 0xf4], 0
433da6b0 mulss    xmm0, xmm0
433da6b4 addss    xmm1, xmm0
433da6b8 movaps   xmm0, xmm1
433da6bb sqrtss   xmm0, xmm0
433da6bf movss    dword ptr [esp + 0x5a0], xmm0
433da6c8 addss    xmm0, xmm3
433da6cc divss    xmm6, xmm0
433da6d0 movaps   xmm1, xmm6
433da6d3 mulss    xmm6, dword ptr [esp + 0xf0]
433da6dc mulss    xmm1, dword ptr [esp + 0xec]
433da6e5 movss    dword ptr [esp + 0xf0], xmm6
433da6ee movss    dword ptr [esp + 0x24], xmm1
433da6f4 movss    dword ptr [esp + 0xec], xmm1
433da6fd jmp      0x433da717
433da6ff movss    xmm0, dword ptr [esp + 0xec]
433da708 movss    xmm6, dword ptr [esp + 0xf0]
433da711 movss    dword ptr [esp + 0x24], xmm0
433da717 movss    xmm0, dword ptr [esp + 0x100]
433da720 ucomiss  xmm0, xmm4
433da723 lahf     
433da724 test     ah, 0x44
433da727 jnp      0x433da793
433da729 movss    xmm1, dword ptr [esp + 0xf8]
433da732 movaps   xmm5, xmm2
433da735 movss    xmm0, dword ptr [esp + 0xfc]
433da73e mulss    xmm0, xmm0
433da742 and      dword ptr [esp + 0x100], 0
433da74a mulss    xmm1, xmm1
433da74e addss    xmm1, xmm0
433da752 movaps   xmm0, xmm1
433da755 sqrtss   xmm0, xmm0
433da759 movss    dword ptr [esp + 0x59c], xmm0
433da762 addss    xmm0, xmm3
433da766 divss    xmm5, xmm0
433da76a movaps   xmm7, xmm5
433da76d mulss    xmm5, dword ptr [esp + 0xfc]
433da776 mulss    xmm7, dword ptr [esp + 0xf8]
433da77f movss    dword ptr [esp + 0xfc], xmm5
433da788 movss    dword ptr [esp + 0xf8], xmm7
433da791 jmp      0x433da7a5
433da793 movss    xmm5, dword ptr [esp + 0xfc]
433da79c movss    xmm7, dword ptr [esp + 0xf8]
433da7a5 movss    xmm1, dword ptr [ecx + 0x118]
433da7ad movss    xmm3, dword ptr [edi]
433da7b1 movaps   xmm0, xmm1
433da7b4 mulss    xmm0, xmm7
433da7b8 movaps   xmm2, xmm3
433da7bb mulss    xmm2, dword ptr [esp + 0x24]
433da7c1 mulss    xmm1, xmm5
433da7c5 addss    xmm2, xmm0
433da7c9 mulss    xmm3, xmm6
433da7cd movss    xmm6, dword ptr [0x43470514]
433da7d5 addss    xmm3, xmm1
433da7d9 movaps   xmm1, xmm2
433da7dc mulss    xmm1, xmm2
433da7e0 movaps   xmm0, xmm3
433da7e3 mulss    xmm0, xmm3
433da7e7 addss    xmm1, xmm0
433da7eb movaps   xmm0, xmm4
433da7ee mulss    xmm0, xmm4
433da7f2 addss    xmm1, xmm0
433da7f6 movaps   xmm5, xmm1
433da7f9 movaps   xmm1, xmm6
433da7fc sqrtss   xmm5, xmm5
433da800 movaps   xmm0, xmm5
433da803 movss    dword ptr [esp + 0x74], xmm5
433da809 addss    xmm0, dword ptr [0x43472108]
433da811 ucomiss  xmm5, xmm4
433da814 divss    xmm1, xmm0
433da818 lahf     
433da819 movaps   xmm7, xmm1
433da81c movaps   xmm0, xmm1
433da81f mulss    xmm7, xmm2
433da823 mulss    xmm0, xmm3
433da827 mulss    xmm1, xmm4
433da82b movss    dword ptr [esp + 0x50], xmm7
433da831 movss    dword ptr [esp + 0x24], xmm0
433da837 movss    dword ptr [esp + 0x34], xmm1
433da83d test     ah, 0x44
433da840 jnp      0x433da857
433da842 movss    xmm0, dword ptr [ecx + 0x10c]
433da84a minss    xmm0, xmm5
433da84e movaps   xmm5, xmm0
433da851 movss    xmm0, dword ptr [esp + 0x24]
433da857 and      dword ptr [ecx + 0x18], 0
433da85b mulss    xmm0, dword ptr [esi + 4]
433da860 movss    xmm2, dword ptr [esi]
433da864 mulss    xmm2, xmm7
433da868 addss    xmm2, xmm0
433da86c movaps   xmm0, xmm1
433da86f mulss    xmm0, dword ptr [esi + 8]
433da874 addss    xmm2, xmm0
433da878 movaps   xmm0, xmm5
433da87b subss    xmm0, xmm2
433da87f movss    dword ptr [esp + 0x30], xmm2
433da885 comiss   xmm4, xmm0
433da888 movss    dword ptr [esp + 0x44], xmm0
433da88e jae      0x433dabef
433da894 mov      eax, dword ptr [ebp + 0xc]
433da897 mov      edi, dword ptr [ebp + 8]
433da89a mov      byte ptr [esp + 0x17], 0
433da89f mov      edx, dword ptr [eax + 0x30]
433da8a2 shr      edx, 0x11
433da8a5 not      dl
433da8a7 and      dl, 1
433da8aa test     byte ptr [eax + 0x30], 4
433da8ae jne      0x433da8d2
433da8b0 mov      eax, dword ptr [0x4346a398]
433da8b5 mov      eax, dword ptr [eax]
433da8b7 xor      eax, dword ptr [0x4346a564]
433da8bd xor      eax, 0x6b1a59b5
433da8c2 cmp      byte ptr [eax + edi], 0
433da8c6 jne      0x433da8d2
433da8c8 test     byte ptr [ecx + 0x1c], 6
433da8cc jne      0x433da8d2
433da8ce xor      al, al
433da8d0 jmp      0x433da8d4
433da8d2 mov      al, 1
433da8d4 mov      byte ptr [esp + 0x2b], al
433da8d8 test     dl, dl
433da8da jne      0x433da8e5
433da8dc mov      byte ptr [esp + 0x4f], 1
433da8e1 test     al, al
433da8e3 je       0x433da8ea
433da8e5 mov      byte ptr [esp + 0x4f], 0
433da8ea movss    xmm0, dword ptr [ecx + 0xf8]
433da8f2 movss    xmm1, dword ptr [0x43472828]
433da8fa movss    dword ptr [esp + 0x54], xmm0
433da900 movaps   xmm0, xmm5
433da903 call     0x4332fc35
433da908 mov      eax, dword ptr [0x43467e28]
433da90d movaps   xmm1, xmm0
433da910 movss    dword ptr [esp + 0x2c], xmm0
433da916 xor      eax, 0xe80c95f9
433da91b movss    dword ptr [esp + 0x40], xmm1
433da921 jmp      0x433da925
433da923 mov      eax, ecx
433da925 mov      ecx, dword ptr [eax + 0x1c]
433da928 cmp      eax, ecx
433da92a jne      0x433da923
433da92c cmp      dword ptr [eax + 0x30], eax
433da92f je       0x433daa92
433da935 mov      eax, dword ptr [0x43467a74]
433da93a mov      eax, dword ptr [eax]
433da93c xor      eax, dword ptr [0x434678c0]
433da942 xor      eax, 0xcd812654
433da947 mov      ecx, dword ptr [eax + edi]
433da94a cmp      ecx, -1
433da94d je       0x433daa92
433da953 mov      eax, dword ptr [0x4346a890]
433da958 push     ecx
433da959 mov      eax, dword ptr [eax]
433da95b mov      edx, dword ptr [eax + 0x10]
433da95e mov      eax, esp
433da960 mov      dword ptr [eax], ecx
433da962 mov      ecx, dword ptr [0x4346a890]
433da968 call     edx
433da96a mov      edi, eax
433da96c test     edi, edi
433da96e je       0x433daa86
433da974 mov      dword ptr [esp + 0x1c], 0xc606305
433da97c mov      edx, dword ptr [esp + 0x1c]
433da980 mov      ecx, dword ptr [edi]
433da982 rol      edx, 0x1e
433da985 mov      ecx, dword ptr [edx + ecx - 0x431811d9]
433da98c mov      edx, edi
433da98e mov      dword ptr [esp + 0x598], ecx
433da995 call     0x433e533f
433da99a mov      dword ptr [esp + 0x1c], 0x3ee94f19
433da9a2 mov      edx, edi
433da9a4 mov      eax, dword ptr [esp + 0x1c]
433da9a8 mov      ecx, dword ptr [edi]
433da9aa ror      eax, 7
433da9ad fstp     dword ptr [esp + 0x3c]
433da9b1 mov      ecx, dword ptr [eax + ecx - 0x327dcb66]
433da9b8 mov      dword ptr [esp + 0x594], ecx
433da9bf call     0x433e533f
433da9c4 movss    xmm1, dword ptr [esp + 0x3c]
433da9ca test     eax, eax
433da9cc jle      0x433daa25
433da9ce mov      dword ptr [esp + 0x38], 0x734b1df2
433da9d6 mov      edx, edi
433da9d8 mov      eax, dword ptr [esp + 0x38]
433da9dc mov      ecx, dword ptr [edi]
433da9de rol      eax, 0x11
433da9e1 mov      ecx, dword ptr [eax + ecx - 0x3be4dfaa]
433da9e8 mov      dword ptr [esp + 0x58c], ecx
433da9ef call     0x433e533f
433da9f4 movss    xmm1, dword ptr [esp + 0x3c]
433da9fa movss    xmm3, dword ptr [0x43470830]
433daa02 cmp      eax, 1
433daa05 jle      0x433daa2d
433daa07 movss    xmm0, dword ptr [0x434707a8]
433daa0f mulss    xmm1, xmm3
433daa13 comiss   xmm0, xmm1
433daa16 movss    xmm1, dword ptr [esp + 0x3c]
433daa1c seta     cl
433daa1f mov      byte ptr [esp + 0x17], cl
433daa23 jmp      0x433daa31
433daa25 movss    xmm3, dword ptr [0x43470830]
433daa2d mov      cl, byte ptr [esp + 0x17]
433daa31 divss    xmm1, dword ptr [0x43472828]
433daa39 movss    xmm2, dword ptr [0x43470514]
433daa41 comiss   xmm2, xmm1
433daa44 jbe      0x433daa51
433daa46 movaps   xmm0, xmm1
433daa49 mulss    xmm0, dword ptr [esp + 0x2c]
433daa4f jmp      0x433daa57
433daa51 movss    xmm0, dword ptr [esp + 0x2c]
433daa57 mov      al, byte ptr [esp + 0x2b]
433daa5b mov      dl, byte ptr [esp + 0x4f]
433daa5f test     al, al
433daa61 jne      0x433daa67
433daa63 test     dl, dl
433daa65 je       0x433daa6f
433daa67 test     cl, cl
433daa69 je       0x433dab69
433daa6f comiss   xmm2, xmm1
433daa72 jb       0x433dab69
433daa78 mulss    xmm1, dword ptr [esp + 0x40]
433daa7e movss    dword ptr [esp + 0x40], xmm1
433daa84 jmp      0x433daaa2
433daa86 movss    xmm0, dword ptr [esp + 0x2c]
433daa8c movss    xmm1, dword ptr [esp + 0x40]
433daa92 movss    xmm3, dword ptr [0x43470830]
433daa9a mov      al, byte ptr [esp + 0x2b]
433daa9e mov      dl, byte ptr [esp + 0x4f]
433daaa2 test     al, al
433daaa4 mov      al, byte ptr [esp + 0x17]
433daaa8 je       0x433daac4
433daaaa test     al, al
433daaac jne      0x433daabc
433daaae mulss    xmm1, dword ptr [0x43472144]
433daab6 movss    dword ptr [esp + 0x40], xmm1
433daabc mulss    xmm0, dword ptr [0x43472144]
433daac4 test     dl, dl
433daac6 je       0x433dab74
433daacc test     al, al
433daace jne      0x433daada
433daad0 mulss    xmm1, xmm3
433daad4 movss    dword ptr [esp + 0x40], xmm1
433daada movss    xmm1, dword ptr [esp + 0x18]
433daae0 mulss    xmm0, xmm3
433daae4 movss    dword ptr [esp + 0x2c], xmm0
433daaea movss    xmm0, dword ptr [esp + 0x30]
433daaf0 call     0x4332fc35
433daaf5 movss    xmm2, dword ptr [esp + 0x2c]
433daafb movaps   xmm3, xmm0
433daafe movaps   xmm1, xmm2
433dab01 subss    xmm1, dword ptr [0x4346fd78]
433dab09 comiss   xmm3, xmm1
433dab0c jbe      0x433dab74
433dab0e movaps   xmm1, xmm3
433dab11 subss    xmm1, xmm2
433dab15 comiss   xmm1, dword ptr [0x43470650]
433dab1c jb       0x433dab74
433dab1e mulss    xmm3, dword ptr [0x43470058]
433dab26 movss    xmm4, dword ptr [0x43470514]
433dab2e mulss    xmm2, dword ptr [0x4346f868]
433dab36 movaps   xmm0, xmm4
433dab39 subss    xmm0, xmm3
433dab3d subss    xmm2, xmm0
433dab41 movss    xmm0, dword ptr [esp + 0x18]
433dab47 subss    xmm2, dword ptr [0x4346f858]
433dab4f movaps   xmm1, xmm2
433dab52 maxss    xmm1, xmm0
433dab56 movaps   xmm0, xmm4
433dab59 minss    xmm1, xmm0
433dab5d movss    xmm0, dword ptr [esp + 0x54]
433dab63 mulss    xmm0, xmm1
433dab67 jmp      0x433dab7a
433dab69 movss    xmm1, dword ptr [esp + 0x40]
433dab6f jmp      0x433daaa2
433dab74 movss    xmm0, dword ptr [esp + 0x54]
433dab7a mov      ecx, dword ptr [esp + 0x20]
433dab7e movss    xmm1, dword ptr [ecx + 0x100]
433dab86 mulss    xmm1, xmm0
433dab8a movss    xmm0, dword ptr [esp + 0x44]
433dab90 mulss    xmm1, dword ptr [esp + 0x40]
433dab96 mulss    xmm1, dword ptr [ecx + 0xc8]
433dab9e call     0x43367633
433daba3 movss    xmm1, dword ptr [esp + 0x50]
433daba9 mulss    xmm1, xmm0
433dabad mov      ecx, dword ptr [esp + 0x20]
433dabb1 movss    xmm4, dword ptr [esp + 0x18]
433dabb7 movss    xmm6, dword ptr [0x43470514]
433dabbf addss    xmm1, dword ptr [esi]
433dabc3 movss    dword ptr [esi], xmm1
433dabc7 movss    xmm1, dword ptr [esp + 0x24]
433dabcd mulss    xmm1, xmm0
433dabd1 addss    xmm1, dword ptr [esi + 4]
433dabd6 movss    dword ptr [esi + 4], xmm1
433dabdb movss    xmm1, dword ptr [esp + 0x34]
433dabe1 mulss    xmm1, xmm0
433dabe5 addss    xmm1, dword ptr [esi + 8]
433dabea movss    dword ptr [esi + 8], xmm1
433dabef and      dword ptr [ecx + 0x18], 0
433dabf3 movss    xmm5, dword ptr [esi]
433dabf7 movss    xmm2, dword ptr [esi + 4]
433dabfc movaps   xmm1, xmm5
433dabff movss    xmm0, dword ptr [esi + 8]
433dac04 movss    xmm3, dword ptr [ecx + 0x10c]
433dac0c mulss    xmm1, xmm5
433dac10 mulss    xmm2, xmm2
433dac14 mulss    xmm0, xmm0
433dac18 addss    xmm1, xmm2
433dac1c addss    xmm1, xmm0
433dac20 movaps   xmm0, xmm3
433dac23 mulss    xmm0, xmm3
433dac27 comiss   xmm1, xmm0
433dac2a jbe      0x433dac77
433dac2c movss    xmm2, dword ptr [esi + 8]
433dac31 movaps   xmm0, xmm5
433dac34 movss    xmm1, dword ptr [esi + 4]
433dac39 mulss    xmm0, xmm0
433dac3d mulss    xmm2, xmm2
433dac41 mulss    xmm1, xmm1
433dac45 addss    xmm2, xmm0
433dac49 addss    xmm2, xmm1
433dac4d movaps   xmm0, xmm2
433dac50 sqrtss   xmm0, xmm0
433dac54 divss    xmm3, xmm0
433dac58 mulss    xmm5, xmm3
433dac5c movaps   xmm0, xmm3
433dac5f movss    dword ptr [esi], xmm5
433dac63 mulss    xmm0, dword ptr [esi + 4]
433dac68 movss    dword ptr [esi + 4], xmm0
433dac6d mulss    xmm3, dword ptr [esi + 8]
433dac72 movss    dword ptr [esi + 8], xmm3
433dac77 movss    xmm0, dword ptr [esi + 4]
433dac7c movss    xmm2, dword ptr [esi]
433dac80 movss    xmm1, dword ptr [esi + 8]
433dac85 mulss    xmm2, xmm2
433dac89 mulss    xmm0, xmm0
433dac8d mulss    xmm1, xmm1
433dac91 addss    xmm2, xmm0
433dac95 addss    xmm2, xmm1
433dac99 movaps   xmm0, xmm2
433dac9c sqrtss   xmm0, xmm0
433daca0 comiss   xmm6, xmm0
433daca3 jbe      0x433dacc9
433daca5 movss    xmm7, dword ptr [esp + 0x18]
433dacab lea      edi, [esp + 0xbc]
433dacb2 xor      eax, eax
433dacb4 lea      esi, [esp + 0xbc]
433dacbb stosd    dword ptr es:[edi], eax
433dacbc stosd    dword ptr es:[edi], eax
433dacbd stosd    dword ptr es:[edi], eax
433dacbe lea      edi, [ecx + 0x10]
433dacc1 movsd    dword ptr es:[edi], dword ptr [esi]
433dacc2 movsd    dword ptr es:[edi], dword ptr [esi]
433dacc3 movsd    dword ptr es:[edi], dword ptr [esi]
433dacc4 jmp      0x433dd35c
433dacc9 movss    xmm2, dword ptr [esi]
433daccd lea      eax, [ecx + 4]
433dacd0 movss    xmm0, dword ptr [ecx + 0x100]
433dacd8 lea      edi, [esp + 0x68]
433dacdc movss    xmm1, dword ptr [ecx + 0x14]
433dace1 mov      esi, eax
433dace3 mov      edx, dword ptr [0x43468304]
433dace9 mulss    xmm1, xmm0
433daced mov      dword ptr [esp + 0x3c], eax
433dacf1 movsd    dword ptr es:[edi], dword ptr [esi]
433dacf2 mulss    xmm2, xmm0
433dacf6 addss    xmm1, dword ptr [ecx + 8]
433dacfb movss    xmm0, dword ptr [ecx + 0xc]
433dad00 addss    xmm2, dword ptr [eax]
433dad04 mov      eax, dword ptr [ecx]
433dad06 movsd    dword ptr es:[edi], dword ptr [esi]
433dad07 movss    dword ptr [esp + 0x44], xmm1
433dad0d movss    dword ptr [esp + 0x30], xmm0
433dad13 movss    dword ptr [esp + 0x50], xmm2
433dad19 movsd    dword ptr es:[edi], dword ptr [esi]
433dad1a and      dword ptr [esp + 0x504], 0
433dad22 subss    xmm1, dword ptr [esp + 0x6c]
433dad28 subss    xmm2, dword ptr [esp + 0x68]
433dad2e subss    xmm0, dword ptr [esp + 0x70]
433dad34 mov      dword ptr [esp + 0x4fc], eax
433dad3b mov      dword ptr [esp + 0x4f8], 0x4346edc0
433dad46 mov      dword ptr [esp + 0x500], 8
433dad51 mov      eax, dword ptr [edx]
433dad53 mov      edi, dword ptr [ecx + 0xd0]
433dad59 mov      esi, dword ptr [eax + 0x14]
433dad5c and      dword ptr [esp + 0x7e0], 0
433dad64 movss    dword ptr [esp + 0x7b4], xmm1
433dad6d movss    dword ptr [esp + 0x7b0], xmm2
433dad76 mulss    xmm1, xmm1
433dad7a mov      byte ptr [esp + 0x7e5], 1
433dad82 mulss    xmm2, xmm2
433dad86 movss    dword ptr [esp + 0x7b8], xmm0
433dad8f mulss    xmm0, xmm0
433dad93 addss    xmm1, xmm2
433dad97 addss    xmm1, xmm0
433dad9b ucomiss  xmm1, xmm4
433dad9e lahf     
433dad9f test     ah, 0x44
433dada2 jp       0x433dadac
433dada4 mov      byte ptr [esp + 0x7e5], 0
433dadac movss    xmm3, dword ptr [ecx + 0x44]
433dadb1 lea      eax, [ecx + 0x6c]
433dadb4 movss    xmm4, dword ptr [ecx + 0x48]
433dadb9 movaps   xmm2, xmm3
433dadbc movss    xmm6, dword ptr [ecx + 0x38]
433dadc1 movaps   xmm1, xmm4
433dadc4 movss    xmm7, dword ptr [ecx + 0x3c]
433dadc9 subss    xmm2, xmm6
433dadcd movss    xmm0, dword ptr [ecx + 0x40]
433dadd2 subss    xmm1, xmm7
433dadd6 movss    xmm5, dword ptr [ecx + 0x4c]
433daddb addss    xmm6, xmm3
433daddf movss    dword ptr [esp + 0x24], xmm0
433dade5 addss    xmm7, xmm4
433dade9 movaps   xmm0, xmm5
433dadec mov      ecx, edx
433dadee subss    xmm0, dword ptr [esp + 0x24]
433dadf4 mulss    xmm1, dword ptr [0x43472240]
433dadfc push     eax
433dadfd mulss    xmm2, dword ptr [0x43472240]
433dae05 mulss    xmm0, dword ptr [0x43472240]
433dae0d movss    dword ptr [esp + 0x7d8], xmm1
433dae16 mulss    xmm1, xmm1
433dae1a movss    dword ptr [esp + 0x7d4], xmm2
433dae23 movss    dword ptr [esp + 0x7dc], xmm0
433dae2c mulss    xmm2, xmm2
433dae30 mulss    xmm0, xmm0
433dae34 addss    xmm1, xmm2
433dae38 addss    xmm1, xmm0
433dae3c cvtps2pd xmm0, xmm1
433dae3f movsd    xmm1, qword ptr [esp + 0x94]
433dae48 comisd   xmm1, xmm0
433dae4c movss    xmm0, dword ptr [esp + 0x28]
433dae52 movss    xmm1, dword ptr [0x43472240]
433dae5a addss    xmm0, xmm5
433dae5e mulss    xmm6, xmm1
433dae62 seta     byte ptr [esp + 0x7e8]
433dae6a mov      dword ptr [esp + 0x28], eax
433dae6e lea      eax, [esp + 0x4fc]
433dae75 mulss    xmm7, xmm1
433dae79 push     eax
433dae7a mulss    xmm0, xmm1
433dae7e lea      eax, [esp + 0x7a8]
433dae85 push     edi
433dae86 movss    xmm1, dword ptr [esp + 0x74]
433dae8c addss    xmm1, xmm6
433dae90 push     eax
433dae91 movss    dword ptr [esp + 0x7b0], xmm1
433dae9a movss    xmm1, dword ptr [esp + 0x7c]
433daea0 addss    xmm1, xmm7
433daea4 movss    dword ptr [esp + 0x7b4], xmm1
433daead movss    xmm1, dword ptr [esp + 0x80]
433daeb6 addss    xmm1, xmm0
433daeba movss    dword ptr [esp + 0x7b8], xmm1
433daec3 movss    xmm1, dword ptr [0x4346f858]
433daecb mulss    xmm6, xmm1
433daecf mulss    xmm7, xmm1
433daed3 mulss    xmm0, xmm1
433daed7 movss    dword ptr [esp + 0x7d0], xmm6
433daee0 movss    dword ptr [esp + 0x7d4], xmm7
433daee9 movss    dword ptr [esp + 0x7d8], xmm0
433daef2 call     esi
433daef4 mov      ecx, dword ptr [esp + 0x20]
433daef8 movss    xmm6, dword ptr [0x43470514]
433daf00 movss    xmm0, dword ptr [ecx + 0x98]
433daf08 ucomiss  xmm0, xmm6
433daf0b lahf     
433daf0c test     ah, 0x44
433daf0f jp       0x433daf1e
433daf11 lea      eax, [ecx + 4]
433daf14 lea      esi, [ecx + 0x78]
433daf17 mov      edi, eax
433daf19 jmp      0x433dce5c
433daf1e cmp      byte ptr [esp + 0x7f], 0
433daf23 movss    xmm7, dword ptr [esp + 0x18]
433daf29 je       0x433dd35c
433daf2f lea      esi, [ecx + 4]
433daf32 movss    xmm0, dword ptr [esp + 0x50]
433daf38 lea      edi, [esp + 0xb0]
433daf3f movss    xmm5, dword ptr [ecx + 0x100]
433daf47 movsd    dword ptr es:[edi], dword ptr [esi]
433daf48 lea      edx, [ecx + 0x10]
433daf4b and      dword ptr [esp + 0x54], 0
433daf50 xor      eax, eax
433daf52 and      dword ptr [esp + 0x1c], 0
433daf57 movss    dword ptr [esp + 0x128], xmm0
433daf60 movsd    dword ptr es:[edi], dword ptr [esi]
433daf61 movss    xmm0, dword ptr [esp + 0x44]
433daf67 movss    dword ptr [esp + 0x12c], xmm0
433daf70 movss    xmm0, dword ptr [esp + 0x30]
433daf76 movsd    dword ptr es:[edi], dword ptr [esi]
433daf77 mov      esi, edx
433daf79 movss    dword ptr [esp + 0x130], xmm0
433daf82 lea      edi, [esp + 0x310]
433daf89 movss    dword ptr [esp + 0x78], xmm5
433daf8f movaps   xmm0, xmm7
433daf92 movss    dword ptr [esp + 0x34], xmm0
433daf98 movsd    dword ptr es:[edi], dword ptr [esi]
433daf99 movsd    dword ptr es:[edi], dword ptr [esi]
433daf9a movsd    dword ptr es:[edi], dword ptr [esi]
433daf9b mov      esi, edx
433daf9d lea      edi, [esp + 0xbc]
433dafa4 movsd    dword ptr es:[edi], dword ptr [esi]
433dafa5 movsd    dword ptr es:[edi], dword ptr [esi]
433dafa6 movsd    dword ptr es:[edi], dword ptr [esi]
433dafa7 mov      esi, edx
433dafa9 lea      edi, [esp + 0x98]
433dafb0 movsd    dword ptr es:[edi], dword ptr [esi]
433dafb1 movsd    dword ptr es:[edi], dword ptr [esi]
433dafb2 movsd    dword ptr es:[edi], dword ptr [esi]
433dafb3 movss    xmm3, dword ptr [esp + 0x9c]
433dafbc lea      edi, [esp + 0xd4]
433dafc3 movss    xmm4, dword ptr [esp + 0xa0]
433dafcc lea      esi, [esp + 0xd4]
433dafd3 stosd    dword ptr es:[edi], eax
433dafd4 movss    dword ptr [esp + 0x2c], xmm3
433dafda movss    xmm3, dword ptr [esp + 0x98]
433dafe3 movups   xmmword ptr [esp + 0x110], xmm4
433dafeb stosd    dword ptr es:[edi], eax
433dafec movss    dword ptr [esp + 0x40], xmm3
433daff2 stosd    dword ptr es:[edi], eax
433daff3 lea      edi, [esp + 0x84]
433daffa movsd    dword ptr es:[edi], dword ptr [esi]
433daffb movsd    dword ptr es:[edi], dword ptr [esi]
433daffc movsd    dword ptr es:[edi], dword ptr [esi]
433daffd movss    xmm0, dword ptr [edx + 4]
433db002 movss    xmm1, dword ptr [edx]
433db006 mulss    xmm0, xmm0
433db00a mulss    xmm1, xmm1
433db00e addss    xmm1, xmm0
433db012 movss    xmm0, dword ptr [edx + 8]
433db017 mulss    xmm0, xmm0
433db01b addss    xmm1, xmm0
433db01f ucomiss  xmm1, xmm7
433db022 lahf     
433db023 test     ah, 0x44
433db026 jnp      0x433dbc28
433db02c movss    xmm3, dword ptr [esp + 0x50]
433db032 lea      esi, [ecx + 4]
433db035 movaps   xmm2, xmm5
433db038 movaps   xmm0, xmm5
433db03b mulss    xmm2, dword ptr [edx]
433db03f movaps   xmm1, xmm5
433db042 mulss    xmm0, dword ptr [edx + 4]
433db047 addss    xmm2, dword ptr [esi]
433db04b mulss    xmm1, dword ptr [edx + 8]
433db050 addss    xmm0, dword ptr [esi + 4]
433db055 addss    xmm1, dword ptr [esi + 8]
433db05a ucomiss  xmm3, xmm2
433db05d lahf     
433db05e test     ah, 0x44
433db061 jp       0x433db091
433db063 movss    xmm3, dword ptr [esp + 0x44]
433db069 ucomiss  xmm3, xmm0
433db06c lahf     
433db06d test     ah, 0x44
433db070 jp       0x433db091
433db072 movss    xmm3, dword ptr [esp + 0x30]
433db078 ucomiss  xmm3, xmm1
433db07b lahf     
433db07c test     ah, 0x44
433db07f jp       0x433db091
433db081 mov      esi, dword ptr [esp + 0x24]
433db085 mov      edi, esi
433db087 push     0x15
433db089 pop      ecx
433db08a rep movsd dword ptr es:[edi], dword ptr [esi]
433db08c jmp      0x433db2bb
433db091 mov      eax, dword ptr [ecx]
433db093 lea      edi, [esp + 0x104]
433db09a mov      edx, dword ptr [0x43468304]
433db0a0 movsd    dword ptr es:[edi], dword ptr [esi]
433db0a1 movsd    dword ptr es:[edi], dword ptr [esi]
433db0a2 movsd    dword ptr es:[edi], dword ptr [esi]
433db0a3 movss    xmm3, dword ptr [esp + 0x104]
433db0ac and      dword ptr [esp + 0x514], 0
433db0b4 subss    xmm2, xmm3
433db0b8 mov      dword ptr [esp + 0x50c], eax
433db0bf movss    dword ptr [esp + 0x64], xmm3
433db0c5 movss    xmm3, dword ptr [esp + 0x108]
433db0ce subss    xmm0, xmm3
433db0d2 mov      dword ptr [esp + 0x508], 0x4346edc0
433db0dd mov      dword ptr [esp + 0x510], 8
433db0e8 mov      eax, dword ptr [edx]
433db0ea mov      edi, dword ptr [ecx + 0xd0]
433db0f0 movss    dword ptr [esp + 0x48], xmm3
433db0f6 movss    xmm3, dword ptr [esp + 0x10c]
433db0ff mov      esi, dword ptr [eax + 0x14]
433db102 subss    xmm1, xmm3
433db106 and      dword ptr [esp + 0x830], 0
433db10e movss    dword ptr [esp + 0x804], xmm0
433db117 movss    dword ptr [esp + 0x800], xmm2
433db120 mulss    xmm0, xmm0
433db124 mov      byte ptr [esp + 0x835], 1
433db12c mulss    xmm2, xmm2
433db130 movss    dword ptr [esp + 0x808], xmm1
433db139 mulss    xmm1, xmm1
433db13d addss    xmm0, xmm2
433db141 movss    dword ptr [esp + 0x74], xmm3
433db147 addss    xmm0, xmm1
433db14b ucomiss  xmm0, xmm7
433db14e lahf     
433db14f test     ah, 0x44
433db152 jp       0x433db15c
433db154 mov      byte ptr [esp + 0x835], 0
433db15c movss    xmm3, dword ptr [ecx + 0x44]
433db161 lea      eax, [ecx + 0x6c]
433db164 movss    xmm4, dword ptr [ecx + 0x48]
433db169 movaps   xmm2, xmm3
433db16c movss    xmm0, dword ptr [ecx + 0x38]
433db171 movaps   xmm1, xmm4
433db174 movss    xmm7, dword ptr [ecx + 0x3c]
433db179 subss    xmm2, xmm0
433db17d movss    xmm5, dword ptr [ecx + 0x4c]
433db182 subss    xmm1, xmm7
433db186 movss    xmm6, dword ptr [ecx + 0x40]
433db18b addss    xmm7, xmm4
433db18f movss    dword ptr [esp + 0x38], xmm0
433db195 mov      ecx, edx
433db197 movaps   xmm0, xmm5
433db19a mulss    xmm2, dword ptr [0x43472240]
433db1a2 subss    xmm0, xmm6
433db1a6 push     eax
433db1a7 mulss    xmm1, dword ptr [0x43472240]
433db1af addss    xmm6, xmm5
433db1b3 lea      eax, [esp + 0x50c]
433db1ba movss    dword ptr [esp + 0x824], xmm2
433db1c3 mulss    xmm0, dword ptr [0x43472240]
433db1cb push     eax
433db1cc movss    dword ptr [esp + 0x82c], xmm1
433db1d5 lea      eax, [esp + 0x7f8]
433db1dc mulss    xmm1, xmm1
433db1e0 push     edi
433db1e1 movss    dword ptr [esp + 0x834], xmm0
433db1ea mulss    xmm2, xmm2
433db1ee push     eax
433db1ef mulss    xmm0, xmm0
433db1f3 addss    xmm1, xmm2
433db1f7 addss    xmm1, xmm0
433db1fb cvtps2pd xmm0, xmm1
433db1fe movsd    xmm1, qword ptr [esp + 0xa0]
433db207 comisd   xmm1, xmm0
433db20b movss    xmm0, dword ptr [esp + 0x48]
433db211 movss    xmm1, dword ptr [0x43472240]
433db219 addss    xmm0, xmm3
433db21d mulss    xmm7, xmm1
433db221 seta     byte ptr [esp + 0x844]
433db229 mulss    xmm6, xmm1
433db22d mulss    xmm0, xmm1
433db231 movss    xmm1, dword ptr [esp + 0x74]
433db237 addss    xmm1, xmm0
433db23b movss    dword ptr [esp + 0x800], xmm1
433db244 movss    xmm1, dword ptr [esp + 0x58]
433db24a addss    xmm1, xmm7
433db24e movss    dword ptr [esp + 0x804], xmm1
433db257 movss    xmm1, dword ptr [esp + 0x84]
433db260 addss    xmm1, xmm6
433db264 movss    dword ptr [esp + 0x808], xmm1
433db26d movss    xmm1, dword ptr [0x4346f858]
433db275 mulss    xmm0, xmm1
433db279 mulss    xmm7, xmm1
433db27d mulss    xmm6, xmm1
433db281 movss    dword ptr [esp + 0x820], xmm0
433db28a movss    dword ptr [esp + 0x824], xmm7
433db293 movss    dword ptr [esp + 0x828], xmm6
433db29c call     esi
433db29e movss    xmm7, dword ptr [esp + 0x18]
433db2a4 movups   xmm4, xmmword ptr [esp + 0x110]
433db2ac mov      edx, dword ptr [esp + 0x80]
433db2b3 movss    xmm6, dword ptr [0x43470514]
433db2bb mov      ecx, dword ptr [esp + 0x20]
433db2bf movss    xmm0, dword ptr [ecx + 0x98]
433db2c7 comiss   xmm0, xmm7
433db2ca movaps   xmm1, xmm0
433db2cd movaps   xmm2, xmm0
433db2d0 jbe      0x433db2ec
433db2d2 movss    xmm3, dword ptr [0x434723ec]
433db2da comiss   xmm3, xmm0
433db2dd jbe      0x433db2ec
433db2df and      dword ptr [ecx + 0x98], 0
433db2e6 movaps   xmm1, xmm7
433db2e9 movaps   xmm2, xmm7
433db2ec cmp      byte ptr [ecx + 0xa2], 0
433db2f3 movss    xmm0, dword ptr [esp + 0x34]
433db2f9 addss    xmm0, xmm1
433db2fd movss    dword ptr [esp + 0x34], xmm0
433db303 jne      0x433dbc10
433db309 comiss   xmm1, xmm7
433db30c jbe      0x433db61a
433db312 ucomiss  xmm1, xmm6
433db315 lahf     
433db316 test     ah, 0x44
433db319 jp       0x433db5c3
433db31f or       dword ptr [esp + 0xbbc], 0xffffffff
433db327 lea      esi, [ecx + 0x78]
433db32a or       dword ptr [esp + 0xbc8], 0xffffffff
433db332 lea      edi, [esp + 0x2c4]
433db339 mov      dword ptr [esp + 0xba4], 0x3f800000
433db344 xor      edx, edx
433db346 mov      word ptr [esp + 0xbae], dx
433db34e mov      dword ptr [esp + 0xbc4], edx
433db355 movsd    dword ptr es:[edi], dword ptr [esi]
433db356 mov      eax, dword ptr [ecx]
433db358 movsd    dword ptr es:[edi], dword ptr [esi]
433db359 movsd    dword ptr es:[edi], dword ptr [esi]
433db35a movss    xmm2, dword ptr [esp + 0x2c4]
433db363 lea      esi, [ecx + 0x78]
433db366 movss    xmm1, dword ptr [esp + 0x2c8]
433db36f lea      edi, [esp + 0xd4]
433db376 movsd    dword ptr es:[edi], dword ptr [esi]
433db377 movsd    dword ptr es:[edi], dword ptr [esi]
433db378 movsd    dword ptr es:[edi], dword ptr [esi]
433db379 movss    xmm0, dword ptr [esp + 0xd4]
433db382 movss    xmm3, dword ptr [esp + 0xdc]
433db38b subss    xmm2, xmm0
433db38f mov      dword ptr [esp + 0x494], edx
433db396 mov      edx, dword ptr [0x43468304]
433db39c movss    dword ptr [esp + 0x64], xmm0
433db3a2 movss    xmm0, dword ptr [esp + 0xd8]
433db3ab subss    xmm1, xmm0
433db3af mov      dword ptr [esp + 0x48c], eax
433db3b6 mov      dword ptr [esp + 0x488], 0x4346edc0
433db3c1 mov      dword ptr [esp + 0x490], 8
433db3cc mov      eax, dword ptr [edx]
433db3ce mov      edi, dword ptr [ecx + 0xd0]
433db3d4 movss    dword ptr [esp + 0x48], xmm0
433db3da movss    xmm0, dword ptr [esp + 0x2cc]
433db3e3 mov      esi, dword ptr [eax + 0x14]
433db3e6 subss    xmm0, xmm3
433db3ea and      dword ptr [esp + 0x880], 0
433db3f2 movss    dword ptr [esp + 0x854], xmm1
433db3fb movss    dword ptr [esp + 0x850], xmm2
433db404 mulss    xmm1, xmm1
433db408 mov      byte ptr [esp + 0x885], 1
433db410 mulss    xmm2, xmm2
433db414 movss    dword ptr [esp + 0x858], xmm0
433db41d mulss    xmm0, xmm0
433db421 addss    xmm1, xmm2
433db425 movss    dword ptr [esp + 0x74], xmm3
433db42b addss    xmm1, xmm0
433db42f ucomiss  xmm1, xmm7
433db432 lahf     
433db433 test     ah, 0x44
433db436 jp       0x433db440
433db438 mov      byte ptr [esp + 0x885], 0
433db440 movss    xmm3, dword ptr [ecx + 0x44]
433db445 lea      eax, [esp + 0xb78]
433db44c movss    xmm4, dword ptr [ecx + 0x48]
433db451 movaps   xmm2, xmm3
433db454 movss    xmm0, dword ptr [ecx + 0x38]
433db459 movaps   xmm1, xmm4
433db45c movss    xmm7, dword ptr [ecx + 0x3c]
433db461 subss    xmm2, xmm0
433db465 movss    xmm5, dword ptr [ecx + 0x4c]
433db46a subss    xmm1, xmm7
433db46e movss    xmm6, dword ptr [ecx + 0x40]
433db473 addss    xmm7, xmm4
433db477 movss    dword ptr [esp + 0x38], xmm0
433db47d mov      ecx, edx
433db47f movaps   xmm0, xmm5
433db482 mulss    xmm2, dword ptr [0x43472240]
433db48a subss    xmm0, xmm6
433db48e push     eax
433db48f mulss    xmm1, dword ptr [0x43472240]
433db497 addss    xmm6, xmm5
433db49b lea      eax, [esp + 0x48c]
433db4a2 movss    dword ptr [esp + 0x874], xmm2
433db4ab mulss    xmm0, dword ptr [0x43472240]
433db4b3 push     eax
433db4b4 movss    dword ptr [esp + 0x87c], xmm1
433db4bd lea      eax, [esp + 0x848]
433db4c4 mulss    xmm1, xmm1
433db4c8 push     edi
433db4c9 movss    dword ptr [esp + 0x884], xmm0
433db4d2 mulss    xmm2, xmm2
433db4d6 push     eax
433db4d7 mulss    xmm0, xmm0
433db4db addss    xmm1, xmm2
433db4df addss    xmm1, xmm0
433db4e3 cvtps2pd xmm0, xmm1
433db4e6 movsd    xmm1, qword ptr [esp + 0xa0]
433db4ef comisd   xmm1, xmm0
433db4f3 movss    xmm0, dword ptr [esp + 0x48]
433db4f9 movss    xmm1, dword ptr [0x43472240]
433db501 addss    xmm0, xmm3
433db505 mulss    xmm7, xmm1
433db509 seta     byte ptr [esp + 0x894]
433db511 mulss    xmm6, xmm1
433db515 mulss    xmm0, xmm1
433db519 movss    xmm1, dword ptr [esp + 0x74]
433db51f addss    xmm1, xmm0
433db523 movss    dword ptr [esp + 0x850], xmm1
433db52c movss    xmm1, dword ptr [esp + 0x58]
433db532 addss    xmm1, xmm7
433db536 movss    dword ptr [esp + 0x854], xmm1
433db53f movss    xmm1, dword ptr [esp + 0x84]
433db548 addss    xmm1, xmm6
433db54c movss    dword ptr [esp + 0x858], xmm1
433db555 movss    xmm1, dword ptr [0x4346f858]
433db55d mulss    xmm0, xmm1
433db561 mulss    xmm7, xmm1
433db565 mulss    xmm6, xmm1
433db569 movss    dword ptr [esp + 0x870], xmm0
433db572 movss    dword ptr [esp + 0x874], xmm7
433db57b movss    dword ptr [esp + 0x878], xmm6
433db584 call     esi
433db586 cmp      byte ptr [esp + 0xbaf], 0
433db58e jne      0x433dbc05
433db594 movss    xmm0, dword ptr [esp + 0xba4]
433db59d movss    xmm6, dword ptr [0x43470514]
433db5a5 ucomiss  xmm0, xmm6
433db5a8 lahf     
433db5a9 test     ah, 0x44
433db5ac jp       0x433dbc05
433db5b2 movss    xmm7, dword ptr [esp + 0x18]
433db5b8 mov      ecx, dword ptr [esp + 0x20]
433db5bc mov      edx, dword ptr [esp + 0x80]
433db5c3 lea      esi, [ecx + 0x78]
433db5c6 lea      edi, [ecx + 4]
433db5c9 movsd    dword ptr es:[edi], dword ptr [esi]
433db5ca movsd    dword ptr es:[edi], dword ptr [esi]
433db5cb movsd    dword ptr es:[edi], dword ptr [esi]
433db5cc movss    xmm1, dword ptr [ecx + 0x98]
433db5d4 lea      edi, [esp + 0x98]
433db5db mov      esi, edx
433db5dd movaps   xmm2, xmm1
433db5e0 movsd    dword ptr es:[edi], dword ptr [esi]
433db5e1 movsd    dword ptr es:[edi], dword ptr [esi]
433db5e2 movsd    dword ptr es:[edi], dword ptr [esi]
433db5e3 movss    xmm0, dword ptr [esp + 0x9c]
433db5ec xor      edi, edi
433db5ee movss    xmm4, dword ptr [esp + 0xa0]
433db5f7 movss    dword ptr [esp + 0x2c], xmm0
433db5fd movss    xmm0, dword ptr [esp + 0x98]
433db606 mov      dword ptr [esp + 0x54], edi
433db60a movups   xmmword ptr [esp + 0x110], xmm4
433db612 movss    dword ptr [esp + 0x40], xmm0
433db618 jmp      0x433db61e
433db61a mov      edi, dword ptr [esp + 0x54]
433db61e ucomiss  xmm1, xmm6
433db621 lahf     
433db622 test     ah, 0x44
433db625 jnp      0x433dbc28
433db62b movss    xmm0, dword ptr [ecx + 0x8c]
433db633 movss    xmm3, dword ptr [0x43470340]
433db63b movss    xmm5, dword ptr [0x434723ec]
433db643 andps    xmm0, xmm3
433db646 comiss   xmm5, xmm0
433db649 jbe      0x433db655
433db64b and      dword ptr [ecx + 0x8c], 0
433db652 movaps   xmm1, xmm2
433db655 movss    xmm2, dword ptr [esp + 0x78]
433db65b movaps   xmm0, xmm2
433db65e mulss    xmm0, xmm1
433db662 subss    xmm2, xmm0
433db666 movss    dword ptr [esp + 0x78], xmm2
433db66c cmp      edi, 5
433db66f jge      0x433dbc10
433db675 imul     eax, edi, 0xc
433db678 lea      esi, [ecx + 0x84]
433db67e lea      edi, [esp + 0x61c]
433db685 add      edi, eax
433db687 mov      eax, dword ptr [esp + 0x54]
433db68b inc      eax
433db68c mov      dword ptr [esp + 0x54], eax
433db690 movsd    dword ptr es:[edi], dword ptr [esi]
433db691 movsd    dword ptr es:[edi], dword ptr [esi]
433db692 movsd    dword ptr es:[edi], dword ptr [esi]
433db693 cmp      eax, 1
433db696 jne      0x433db8a3
433db69c cmp      byte ptr [ecx + 0xcc], 2
433db6a3 jne      0x433db8a3
433db6a9 test     byte ptr [ecx + 0x1c], al
433db6ac jne      0x433db8a3
433db6b2 mov      al, byte ptr [ecx + 0x108]
433db6b8 lea      esi, [esp + 0x61c]
433db6bf lea      edi, [esp + 0x58]
433db6c3 mov      byte ptr [esp + 0x17], al
433db6c7 movsd    dword ptr es:[edi], dword ptr [esi]
433db6c8 or       al, 8
433db6ca movsd    dword ptr es:[edi], dword ptr [esi]
433db6cb movsd    dword ptr es:[edi], dword ptr [esi]
433db6cc movss    xmm5, dword ptr [esp + 0x60]
433db6d2 lea      edi, [ecx + 0x60]
433db6d5 comiss   xmm5, dword ptr [0x4346fd8c]
433db6dc mov      byte ptr [ecx + 0x108], al
433db6e2 lea      esi, [ecx + 4]
433db6e5 movsd    dword ptr es:[edi], dword ptr [esi]
433db6e6 movsd    dword ptr es:[edi], dword ptr [esi]
433db6e7 movsd    dword ptr es:[edi], dword ptr [esi]
433db6e8 jb       0x433db6f2
433db6ea mov      al, byte ptr [esp + 0x17]
433db6ee or       al, 0xc
433db6f0 jmp      0x433db70b
433db6f2 movss    xmm1, dword ptr [0x43472980]
433db6fa movaps   xmm0, xmm5
433db6fd andps    xmm0, xmm3
433db700 comiss   xmm1, xmm0
433db703 jbe      0x433db71b
433db705 mov      al, byte ptr [esp + 0x17]
433db709 or       al, 0xa
433db70b mov      byte ptr [ecx + 0x108], al
433db711 lea      edi, [ecx + 0x50]
433db714 lea      esi, [esp + 0x58]
433db718 movsd    dword ptr es:[edi], dword ptr [esi]
433db719 movsd    dword ptr es:[edi], dword ptr [esi]
433db71a movsd    dword ptr es:[edi], dword ptr [esi]
433db71b movss    xmm3, dword ptr [esp + 0x58]
433db721 movss    xmm2, dword ptr [esp + 0x5c]
433db727 movaps   xmm1, xmm3
433db72a mulss    xmm1, dword ptr [esp + 0x40]
433db730 movaps   xmm0, xmm2
433db733 movss    xmm6, dword ptr [esp + 0x2c]
433db739 movss    xmm7, dword ptr [esp + 0x40]
433db73f mulss    xmm0, xmm6
433db743 movss    dword ptr [esp + 0x64], xmm2
433db749 movss    dword ptr [esp + 0x38], xmm3
433db74f addss    xmm1, xmm0
433db753 movaps   xmm0, xmm4
433db756 mulss    xmm0, xmm5
433db75a addss    xmm1, xmm0
433db75e movaps   xmm0, xmm3
433db761 mulss    xmm0, xmm1
433db765 subss    xmm7, xmm0
433db769 movaps   xmm0, xmm7
433db76c movss    dword ptr [esp + 0x40], xmm7
433db772 movss    dword ptr [esp + 0x84], xmm0
433db77b movaps   xmm0, xmm2
433db77e mulss    xmm0, xmm1
433db782 subss    xmm6, xmm0
433db786 movaps   xmm0, xmm5
433db789 mulss    xmm0, xmm1
433db78d subss    xmm4, xmm0
433db791 mulss    xmm2, xmm6
433db795 movaps   xmm0, xmm3
433db798 movss    dword ptr [esp + 0x2c], xmm6
433db79e mulss    xmm0, xmm7
433db7a2 movss    xmm7, dword ptr [esp + 0x18]
433db7a8 movaps   xmm1, xmm4
433db7ab mulss    xmm1, xmm5
433db7af addss    xmm2, xmm0
433db7b3 movss    dword ptr [esp + 0x88], xmm6
433db7bc movups   xmmword ptr [esp + 0x110], xmm4
433db7c4 addss    xmm2, xmm1
433db7c8 comiss   xmm2, xmm7
433db7cb jae      0x433db83a
433db7cd movss    xmm1, dword ptr [0x43471d88]
433db7d5 movaps   xmm0, xmm2
433db7d8 call     0x43367633
433db7dd movss    xmm1, dword ptr [esp + 0x38]
433db7e3 movss    xmm2, dword ptr [esp + 0x40]
433db7e9 movups   xmm4, xmmword ptr [esp + 0x110]
433db7f1 mov      ecx, dword ptr [esp + 0x20]
433db7f5 movss    xmm7, dword ptr [esp + 0x18]
433db7fb mov      edx, dword ptr [esp + 0x80]
433db802 mulss    xmm1, xmm0
433db806 subss    xmm2, xmm1
433db80a movss    xmm1, dword ptr [esp + 0x64]
433db810 mulss    xmm1, xmm0
433db814 mulss    xmm0, dword ptr [esp + 0x60]
433db81a movss    dword ptr [esp + 0x84], xmm2
433db823 movss    xmm2, dword ptr [esp + 0x2c]
433db829 subss    xmm2, xmm1
433db82d subss    xmm4, xmm0
433db831 movss    dword ptr [esp + 0x88], xmm2
433db83a movq     xmm0, qword ptr [esp + 0x84]
433db843 movq     qword ptr [edx], xmm0
433db847 xorps    xmm0, xmm0
433db84a movss    xmm0, xmm4
433db84e movss    dword ptr [edx + 8], xmm0
433db853 movq     xmm0, qword ptr [esp + 0x84]
433db85c movq     qword ptr [esp + 0x98], xmm0
433db865 movaps   xmm0, xmm4
433db868 xorps    xmm4, xmm4
433db86b movss    xmm4, xmm0
433db86f movss    xmm0, dword ptr [esp + 0x9c]
433db878 movss    dword ptr [esp + 0x2c], xmm0
433db87e movss    xmm0, dword ptr [esp + 0x98]
433db887 movups   xmmword ptr [esp + 0x110], xmm4
433db88f movss    dword ptr [esp + 0xa0], xmm4
433db898 movss    dword ptr [esp + 0x40], xmm0
433db89e jmp      0x433dbbe4
433db8a3 xor      esi, esi
433db8a5 mov      dword ptr [esp + 0x74], esi
433db8a9 test     eax, eax
433db8ab jle      0x433dba9e
433db8b1 lea      edi, [esp + 0x61c]
433db8b8 mov      dword ptr [esp + 0x48], edi
433db8bc mov      al, byte ptr [ecx + 0x108]
433db8c2 mov      esi, edi
433db8c4 lea      edi, [esp + 0x68]
433db8c8 mov      byte ptr [esp + 0x17], al
433db8cc or       al, 8
433db8ce movsd    dword ptr es:[edi], dword ptr [esi]
433db8cf movsd    dword ptr es:[edi], dword ptr [esi]
433db8d0 movsd    dword ptr es:[edi], dword ptr [esi]
433db8d1 movss    xmm5, dword ptr [esp + 0x70]
433db8d7 lea      esi, [ecx + 4]
433db8da comiss   xmm5, dword ptr [0x4346fd8c]
433db8e1 mov      byte ptr [ecx + 0x108], al
433db8e7 lea      edi, [ecx + 0x60]
433db8ea movsd    dword ptr es:[edi], dword ptr [esi]
433db8eb movsd    dword ptr es:[edi], dword ptr [esi]
433db8ec movsd    dword ptr es:[edi], dword ptr [esi]
433db8ed jb       0x433db8f7
433db8ef mov      al, byte ptr [esp + 0x17]
433db8f3 or       al, 0xc
433db8f5 jmp      0x433db910
433db8f7 movss    xmm1, dword ptr [0x43472980]
433db8ff movaps   xmm0, xmm5
433db902 andps    xmm0, xmm3
433db905 comiss   xmm1, xmm0
433db908 jbe      0x433db920
433db90a mov      al, byte ptr [esp + 0x17]
433db90e or       al, 0xa
433db910 mov      byte ptr [ecx + 0x108], al
433db916 lea      edi, [ecx + 0x50]
433db919 lea      esi, [esp + 0x68]
433db91d movsd    dword ptr es:[edi], dword ptr [esi]
433db91e movsd    dword ptr es:[edi], dword ptr [esi]
433db91f movsd    dword ptr es:[edi], dword ptr [esi]
433db920 movss    xmm6, dword ptr [esp + 0x68]
433db926 movss    xmm2, dword ptr [esp + 0x6c]
433db92c movaps   xmm3, xmm6
433db92f mulss    xmm3, dword ptr [esp + 0x40]
433db935 movaps   xmm0, xmm2
433db938 mulss    xmm0, dword ptr [esp + 0x2c]
433db93e movaps   xmm1, xmm6
433db941 movss    dword ptr [esp + 0x64], xmm2
433db947 movss    dword ptr [esp + 0x38], xmm6
433db94d addss    xmm3, xmm0
433db951 movaps   xmm0, xmm4
433db954 mulss    xmm0, xmm5
433db958 addss    xmm3, xmm0
433db95c movss    xmm0, dword ptr [esp + 0x40]
433db962 mulss    xmm1, xmm3
433db966 subss    xmm0, xmm1
433db96a movaps   xmm1, xmm4
433db96d movss    dword ptr [edx], xmm0
433db971 movaps   xmm0, xmm2
433db974 movss    xmm2, dword ptr [esp + 0x2c]
433db97a mulss    xmm0, xmm3
433db97e mulss    xmm3, xmm5
433db982 subss    xmm2, xmm0
433db986 movaps   xmm0, xmm6
433db989 subss    xmm1, xmm3
433db98d movss    xmm3, dword ptr [esp + 0x6c]
433db993 movss    dword ptr [edx + 4], xmm2
433db998 mulss    xmm3, xmm2
433db99c movss    dword ptr [edx + 8], xmm1
433db9a1 mulss    xmm0, dword ptr [edx]
433db9a5 mulss    xmm1, xmm5
433db9a9 addss    xmm3, xmm0
433db9ad addss    xmm3, xmm1
433db9b1 comiss   xmm3, xmm7
433db9b4 jae      0x433dba24
433db9b6 movss    xmm1, dword ptr [0x43471d88]
433db9be movaps   xmm0, xmm3
433db9c1 call     0x43367633
433db9c6 mov      edx, dword ptr [esp + 0x80]
433db9cd movaps   xmm2, xmm0
433db9d0 movss    xmm0, dword ptr [esp + 0x38]
433db9d6 mulss    xmm0, xmm2
433db9da mov      ecx, dword ptr [esp + 0x20]
433db9de movss    xmm1, dword ptr [edx]
433db9e2 movss    xmm7, dword ptr [esp + 0x18]
433db9e8 movups   xmm4, xmmword ptr [esp + 0x110]
433db9f0 subss    xmm1, xmm0
433db9f4 movss    xmm0, dword ptr [esp + 0x64]
433db9fa mulss    xmm0, xmm2
433db9fe mulss    xmm2, dword ptr [esp + 0x70]
433dba04 movss    dword ptr [edx], xmm1
433dba08 movss    xmm1, dword ptr [edx + 4]
433dba0d subss    xmm1, xmm0
433dba11 movss    dword ptr [edx + 4], xmm1
433dba16 movss    xmm0, dword ptr [edx + 8]
433dba1b subss    xmm0, xmm2
433dba1f movss    dword ptr [edx + 8], xmm0
433dba24 movss    xmm2, dword ptr [edx]
433dba28 lea      edi, [esp + 0x624]
433dba2f mov      eax, dword ptr [esp + 0x54]
433dba33 xor      esi, esi
433dba35 cmp      esi, dword ptr [esp + 0x74]
433dba39 je       0x433dba66
433dba3b movss    xmm0, dword ptr [edi - 4]
433dba40 movss    xmm1, dword ptr [edi - 8]
433dba45 mulss    xmm0, dword ptr [edx + 4]
433dba4a mulss    xmm1, xmm2
433dba4e addss    xmm1, xmm0
433dba52 movss    xmm0, dword ptr [edx + 8]
433dba57 mulss    xmm0, dword ptr [edi]
433dba5b addss    xmm1, xmm0
433dba5f comiss   xmm1, xmm7
433dba62 jb       0x433dba72
433dba64 jmp      0x433dba6a
433dba66 movss    xmm2, dword ptr [edx]
433dba6a inc      esi
433dba6b add      edi, 0xc
433dba6e cmp      esi, eax
433dba70 jl       0x433dba35
433dba72 cmp      esi, eax
433dba74 je       0x433dbba6
433dba7a mov      esi, dword ptr [esp + 0x74]
433dba7e mov      edi, dword ptr [esp + 0x48]
433dba82 inc      esi
433dba83 movss    xmm3, dword ptr [0x43470340]
433dba8b add      edi, 0xc
433dba8e mov      dword ptr [esp + 0x74], esi
433dba92 mov      dword ptr [esp + 0x48], edi
433dba96 cmp      esi, eax
433dba98 jl       0x433db8bc
433dba9e cmp      esi, eax
433dbaa0 jne      0x433dbba6
433dbaa6 cmp      eax, 2
433dbaa9 jne      0x433dbc10
433dbaaf movss    xmm3, dword ptr [esp + 0x630]
433dbab8 mulss    xmm3, dword ptr [esp + 0x620]
433dbac1 movss    xmm0, dword ptr [esp + 0x62c]
433dbaca mulss    xmm0, dword ptr [esp + 0x624]
433dbad3 movss    xmm1, dword ptr [esp + 0x628]
433dbadc movss    xmm6, dword ptr [esp + 0x61c]
433dbae5 movaps   xmm5, xmm1
433dbae8 mulss    xmm1, dword ptr [esp + 0x620]
433dbaf1 subss    xmm3, xmm0
433dbaf5 mulss    xmm5, dword ptr [esp + 0x624]
433dbafe movaps   xmm0, xmm6
433dbb01 mulss    xmm0, dword ptr [esp + 0x630]
433dbb0a mulss    xmm6, dword ptr [esp + 0x62c]
433dbb13 subss    xmm5, xmm0
433dbb17 movss    xmm4, dword ptr [0x43470514]
433dbb1f subss    xmm6, xmm1
433dbb23 movaps   xmm1, xmm3
433dbb26 mulss    xmm1, xmm3
433dbb2a movaps   xmm0, xmm5
433dbb2d mulss    xmm0, xmm5
433dbb31 addss    xmm1, xmm0
433dbb35 movaps   xmm0, xmm6
433dbb38 mulss    xmm0, xmm6
433dbb3c addss    xmm1, xmm0
433dbb40 movaps   xmm0, xmm1
433dbb43 movss    xmm1, dword ptr [edx + 4]
433dbb48 sqrtss   xmm0, xmm0
433dbb4c addss    xmm0, dword ptr [0x43472108]
433dbb54 divss    xmm4, xmm0
433dbb58 movaps   xmm2, xmm4
433dbb5b mulss    xmm2, xmm3
433dbb5f movaps   xmm3, xmm4
433dbb62 mulss    xmm3, xmm5
433dbb66 movaps   xmm0, xmm2
433dbb69 mulss    xmm4, xmm6
433dbb6d mulss    xmm0, dword ptr [edx]
433dbb71 mulss    xmm1, xmm3
433dbb75 addss    xmm1, xmm0
433dbb79 movss    xmm0, dword ptr [edx + 8]
433dbb7e mulss    xmm0, xmm4
433dbb82 addss    xmm1, xmm0
433dbb86 movaps   xmm0, xmm1
433dbb89 mulss    xmm0, xmm2
433dbb8d movss    dword ptr [edx], xmm0
433dbb91 movaps   xmm0, xmm1
433dbb94 mulss    xmm0, xmm3
433dbb98 mulss    xmm1, xmm4
433dbb9c movss    dword ptr [edx + 4], xmm0
433dbba1 movss    dword ptr [edx + 8], xmm1
433dbba6 movss    xmm0, dword ptr [esp + 0xbc]
433dbbaf movss    xmm1, dword ptr [esp + 0xc0]
433dbbb8 mulss    xmm0, dword ptr [edx]
433dbbbc mulss    xmm1, dword ptr [edx + 4]
433dbbc1 addss    xmm1, xmm0
433dbbc5 movss    xmm0, dword ptr [esp + 0xc4]
433dbbce mulss    xmm0, dword ptr [edx + 8]
433dbbd3 addss    xmm1, xmm0
433dbbd7 comiss   xmm1, xmm7
433dbbda jbe      0x433dbc10
433dbbdc movups   xmm4, xmmword ptr [esp + 0x110]
433dbbe4 mov      esi, dword ptr [esp + 0x1c]
433dbbe8 inc      esi
433dbbe9 mov      dword ptr [esp + 0x1c], esi
433dbbed cmp      esi, 4
433dbbf0 jge      0x433dbc28
433dbbf2 movss    xmm6, dword ptr [0x43470514]
433dbbfa movss    xmm5, dword ptr [esp + 0x78]
433dbc00 jmp      0x433daffd
433dbc05 mov      edx, dword ptr [esp + 0x80]
433dbc0c mov      ecx, dword ptr [esp + 0x20]
433dbc10 xor      eax, eax
433dbc12 lea      edi, [esp + 0x284]
433dbc19 stosd    dword ptr es:[edi], eax
433dbc1a lea      esi, [esp + 0x284]
433dbc21 stosd    dword ptr es:[edi], eax
433dbc22 stosd    dword ptr es:[edi], eax
433dbc23 mov      edi, edx
433dbc25 movsd    dword ptr es:[edi], dword ptr [esi]
433dbc26 movsd    dword ptr es:[edi], dword ptr [esi]
433dbc27 movsd    dword ptr es:[edi], dword ptr [esi]
433dbc28 movss    xmm4, dword ptr [esp + 0x18]
433dbc2e movss    xmm0, dword ptr [esp + 0x34]
433dbc34 ucomiss  xmm0, xmm4
433dbc37 lahf     
433dbc38 test     ah, 0x44
433dbc3b jp       0x433dbc55
433dbc3d xor      eax, eax
433dbc3f lea      edi, [esp + 0xb6c]
433dbc46 stosd    dword ptr es:[edi], eax
433dbc47 lea      esi, [esp + 0xb6c]
433dbc4e stosd    dword ptr es:[edi], eax
433dbc4f stosd    dword ptr es:[edi], eax
433dbc50 mov      edi, edx
433dbc52 movsd    dword ptr es:[edi], dword ptr [esi]
433dbc53 movsd    dword ptr es:[edi], dword ptr [esi]
433dbc54 movsd    dword ptr es:[edi], dword ptr [esi]
433dbc55 lea      eax, [ecx + 4]
433dbc58 mov      esi, eax
433dbc5a lea      edi, [esp + 0x2c4]
433dbc61 movsd    dword ptr es:[edi], dword ptr [esi]
433dbc62 movsd    dword ptr es:[edi], dword ptr [esi]
433dbc63 movsd    dword ptr es:[edi], dword ptr [esi]
433dbc64 mov      esi, edx
433dbc66 lea      edi, [esp + 0x110]
433dbc6d movsd    dword ptr es:[edi], dword ptr [esi]
433dbc6e movsd    dword ptr es:[edi], dword ptr [esi]
433dbc6f movsd    dword ptr es:[edi], dword ptr [esi]
433dbc70 mov      edi, eax
433dbc72 lea      esi, [esp + 0xb0]
433dbc79 movsd    dword ptr es:[edi], dword ptr [esi]
433dbc7a movsd    dword ptr es:[edi], dword ptr [esi]
433dbc7b movsd    dword ptr es:[edi], dword ptr [esi]
433dbc7c mov      edi, edx
433dbc7e lea      esi, [esp + 0x310]
433dbc85 movsd    dword ptr es:[edi], dword ptr [esi]
433dbc86 movsd    dword ptr es:[edi], dword ptr [esi]
433dbc87 movsd    dword ptr es:[edi], dword ptr [esi]
433dbc88 movss    xmm0, dword ptr [ecx + 0xdc]
433dbc90 lea      edi, [esp + 0x128]
433dbc97 mov      esi, eax
433dbc99 mov      edx, dword ptr [0x43468304]
433dbc9f cvtps2pd xmm1, xmm0
433dbca2 movsd    dword ptr es:[edi], dword ptr [esi]
433dbca3 addsd    xmm1, qword ptr [0x4346fe70]
433dbcab movsd    dword ptr es:[edi], dword ptr [esi]
433dbcac movsd    dword ptr es:[edi], dword ptr [esi]
433dbcad movss    xmm0, dword ptr [esp + 0x130]
433dbcb6 lea      edi, [esp + 0x84]
433dbcbd movss    xmm3, dword ptr [esp + 0x128]
433dbcc6 mov      esi, eax
433dbcc8 mov      eax, dword ptr [ecx]
433dbcca movss    xmm2, dword ptr [esp + 0x12c]
433dbcd3 cvtps2pd xmm0, xmm0
433dbcd6 movsd    dword ptr es:[edi], dword ptr [esi]
433dbcd7 movsd    dword ptr es:[edi], dword ptr [esi]
433dbcd8 addsd    xmm1, xmm0
433dbcdc movsd    dword ptr es:[edi], dword ptr [esi]
433dbcdd and      dword ptr [esp + 0x524], 0
433dbce5 subss    xmm2, dword ptr [esp + 0x88]
433dbcee subss    xmm3, dword ptr [esp + 0x84]
433dbcf7 mov      dword ptr [esp + 0x51c], eax
433dbcfe mov      dword ptr [esp + 0x518], 0x4346edc0
433dbd09 mov      dword ptr [esp + 0x520], 8
433dbd14 mov      eax, dword ptr [edx]
433dbd16 mov      edi, dword ptr [ecx + 0xd0]
433dbd1c cvtpd2ps xmm0, xmm1
433dbd20 mov      esi, dword ptr [eax + 0x14]
433dbd23 and      dword ptr [esp + 0x8d0], 0
433dbd2b mov      byte ptr [esp + 0x8d5], 1
433dbd33 movss    dword ptr [esp + 0x8a4], xmm2
433dbd3c subss    xmm0, dword ptr [esp + 0x8c]
433dbd45 movss    dword ptr [esp + 0x8a0], xmm3
433dbd4e mulss    xmm2, xmm2
433dbd52 mulss    xmm3, xmm3
433dbd56 movss    dword ptr [esp + 0x8a8], xmm0
433dbd5f mulss    xmm0, xmm0
433dbd63 addss    xmm2, xmm3
433dbd67 addss    xmm2, xmm0
433dbd6b ucomiss  xmm2, xmm4
433dbd6e lahf     
433dbd6f test     ah, 0x44
433dbd72 jp       0x433dbd7c
433dbd74 mov      byte ptr [esp + 0x8d5], 0
433dbd7c movss    xmm3, dword ptr [ecx + 0x44]
433dbd81 lea      eax, [ecx + 0x6c]
433dbd84 movss    xmm4, dword ptr [ecx + 0x48]
433dbd89 movaps   xmm2, xmm3
433dbd8c movss    xmm6, dword ptr [ecx + 0x38]
433dbd91 movaps   xmm1, xmm4
433dbd94 movss    xmm7, dword ptr [ecx + 0x3c]
433dbd99 subss    xmm2, xmm6
433dbd9d movss    xmm0, dword ptr [ecx + 0x40]
433dbda2 subss    xmm1, xmm7
433dbda6 movss    xmm5, dword ptr [ecx + 0x4c]
433dbdab addss    xmm6, xmm3
433dbdaf movss    dword ptr [esp + 0x1c], xmm0
433dbdb5 addss    xmm7, xmm4
433dbdb9 movaps   xmm0, xmm5
433dbdbc mov      ecx, edx
433dbdbe subss    xmm0, dword ptr [esp + 0x1c]
433dbdc4 mulss    xmm1, dword ptr [0x43472240]
433dbdcc push     eax
433dbdcd mulss    xmm2, dword ptr [0x43472240]
433dbdd5 lea      eax, [esp + 0x51c]
433dbddc push     eax
433dbddd mulss    xmm0, dword ptr [0x43472240]
433dbde5 lea      eax, [esp + 0x898]
433dbdec push     edi
433dbded movss    dword ptr [esp + 0x8d0], xmm1
433dbdf6 mulss    xmm1, xmm1
433dbdfa push     eax
433dbdfb movss    dword ptr [esp + 0x8d0], xmm2
433dbe04 movss    dword ptr [esp + 0x8d8], xmm0
433dbe0d mulss    xmm2, xmm2
433dbe11 mulss    xmm0, xmm0
433dbe15 addss    xmm1, xmm2
433dbe19 addss    xmm1, xmm0
433dbe1d cvtps2pd xmm0, xmm1
433dbe20 movsd    xmm1, qword ptr [esp + 0xa0]
433dbe29 comisd   xmm1, xmm0
433dbe2d movss    xmm0, dword ptr [esp + 0x2c]
433dbe33 movss    xmm1, dword ptr [0x43472240]
433dbe3b addss    xmm0, xmm5
433dbe3f mulss    xmm6, xmm1
433dbe43 seta     byte ptr [esp + 0x8e4]
433dbe4b mulss    xmm7, xmm1
433dbe4f mulss    xmm0, xmm1
433dbe53 movss    xmm1, dword ptr [esp + 0x94]
433dbe5c addss    xmm1, xmm6
433dbe60 movss    dword ptr [esp + 0x8a0], xmm1
433dbe69 movss    xmm1, dword ptr [esp + 0x98]
433dbe72 addss    xmm1, xmm7
433dbe76 movss    dword ptr [esp + 0x8a4], xmm1
433dbe7f movss    xmm1, dword ptr [esp + 0x9c]
433dbe88 addss    xmm1, xmm0
433dbe8c movss    dword ptr [esp + 0x8a8], xmm1
433dbe95 movss    xmm1, dword ptr [0x4346f858]
433dbe9d mulss    xmm6, xmm1
433dbea1 mulss    xmm7, xmm1
433dbea5 mulss    xmm0, xmm1
433dbea9 movss    dword ptr [esp + 0x8c0], xmm6
433dbeb2 movss    dword ptr [esp + 0x8c4], xmm7
433dbebb movss    dword ptr [esp + 0x8c8], xmm0
433dbec4 call     esi
433dbec6 mov      eax, dword ptr [esp + 0x24]
433dbeca cmp      byte ptr [eax + 0x37], 0
433dbece jne      0x433dbee0
433dbed0 cmp      byte ptr [eax + 0x36], 0
433dbed4 jne      0x433dbee0
433dbed6 mov      edi, dword ptr [esp + 0x3c]
433dbeda lea      esi, [eax + 0xc]
433dbedd movsd    dword ptr es:[edi], dword ptr [esi]
433dbede movsd    dword ptr es:[edi], dword ptr [esi]
433dbedf movsd    dword ptr es:[edi], dword ptr [esi]
433dbee0 mov      ecx, dword ptr [esp + 0x20]
433dbee4 lea      edi, [esp + 0xd4]
433dbeeb movss    xmm7, dword ptr [esp + 0x18]
433dbef1 xor      eax, eax
433dbef3 and      dword ptr [esp + 0x54], 0
433dbef8 and      dword ptr [esp + 0x48], 0
433dbefd lea      edx, [ecx + 0x10]
433dbf00 movss    xmm6, dword ptr [ecx + 0x100]
433dbf08 mov      esi, edx
433dbf0a movss    dword ptr [esp + 0x78], xmm6
433dbf10 movss    dword ptr [esp + 0x74], xmm7
433dbf16 movsd    dword ptr es:[edi], dword ptr [esi]
433dbf17 movsd    dword ptr es:[edi], dword ptr [esi]
433dbf18 movsd    dword ptr es:[edi], dword ptr [esi]
433dbf19 mov      esi, edx
433dbf1b lea      edi, [esp + 0xa4]
433dbf22 movsd    dword ptr es:[edi], dword ptr [esi]
433dbf23 movsd    dword ptr es:[edi], dword ptr [esi]
433dbf24 movsd    dword ptr es:[edi], dword ptr [esi]
433dbf25 movss    xmm0, dword ptr [esp + 0xac]
433dbf2e lea      edi, [esp + 0x2b0]
433dbf35 stosd    dword ptr es:[edi], eax
433dbf36 lea      esi, [esp + 0x2b0]
433dbf3d movss    xmm2, dword ptr [esp + 0xa8]
433dbf46 movss    dword ptr [esp + 0x40], xmm2
433dbf4c stosd    dword ptr es:[edi], eax
433dbf4d stosd    dword ptr es:[edi], eax
433dbf4e lea      edi, [esp + 0x68]
433dbf52 movsd    dword ptr es:[edi], dword ptr [esi]
433dbf53 movsd    dword ptr es:[edi], dword ptr [esi]
433dbf54 movsd    dword ptr es:[edi], dword ptr [esi]
433dbf55 movups   xmmword ptr [esp + 0x2b0], xmm0
433dbf5d movss    xmm0, dword ptr [esp + 0xa4]
433dbf66 movss    dword ptr [esp + 0x2c], xmm0
433dbf6c movss    xmm3, dword ptr [edx + 4]
433dbf71 movss    xmm4, dword ptr [edx]
433dbf75 movaps   xmm0, xmm3
433dbf78 movss    xmm5, dword ptr [edx + 8]
433dbf7d movaps   xmm1, xmm4
433dbf80 mulss    xmm0, xmm3
433dbf84 mulss    xmm1, xmm4
433dbf88 addss    xmm1, xmm0
433dbf8c movaps   xmm0, xmm5
433dbf8f mulss    xmm0, xmm5
433dbf93 addss    xmm1, xmm0
433dbf97 ucomiss  xmm1, xmm7
433dbf9a lahf     
433dbf9b test     ah, 0x44
433dbf9e jnp      0x433dcb15
433dbfa4 movss    xmm0, dword ptr [ecx + 4]
433dbfa9 lea      esi, [ecx + 4]
433dbfac movss    xmm1, dword ptr [ecx + 8]
433dbfb1 lea      edi, [esp + 0x104]
433dbfb8 movss    xmm2, dword ptr [ecx + 0xc]
433dbfbd mov      eax, dword ptr [ecx]
433dbfbf mov      edx, dword ptr [0x43468304]
433dbfc5 movsd    dword ptr es:[edi], dword ptr [esi]
433dbfc6 mulss    xmm4, xmm6
433dbfca mulss    xmm3, xmm6
433dbfce movsd    dword ptr es:[edi], dword ptr [esi]
433dbfcf addss    xmm4, xmm0
433dbfd3 mulss    xmm5, xmm6
433dbfd7 addss    xmm3, xmm1
433dbfdb movsd    dword ptr es:[edi], dword ptr [esi]
433dbfdc movss    xmm0, dword ptr [esp + 0x104]
433dbfe5 addss    xmm5, xmm2
433dbfe9 and      dword ptr [esp + 0x534], 0
433dbff1 subss    xmm4, xmm0
433dbff5 mov      dword ptr [esp + 0x52c], eax
433dbffc mov      dword ptr [esp + 0x528], 0x4346edc0
433dc007 mov      dword ptr [esp + 0x530], 8
433dc012 mov      eax, dword ptr [edx]
433dc014 mov      edi, dword ptr [ecx + 0xd0]
433dc01a subss    xmm5, dword ptr [esp + 0x10c]
433dc023 movss    dword ptr [esp + 0x64], xmm0
433dc029 movss    xmm0, dword ptr [esp + 0x108]
433dc032 mov      esi, dword ptr [eax + 0x14]
433dc035 subss    xmm3, xmm0
433dc039 and      dword ptr [esp + 0x920], 0
433dc041 movss    dword ptr [esp + 0x8f0], xmm4
433dc04a mulss    xmm4, xmm4
433dc04e mov      byte ptr [esp + 0x925], 1
433dc056 movss    dword ptr [esp + 0x8f4], xmm3
433dc05f mulss    xmm3, xmm3
433dc063 movss    dword ptr [esp + 0x8f8], xmm5
433dc06c mulss    xmm5, xmm5
433dc070 addss    xmm3, xmm4
433dc074 movss    dword ptr [esp + 0x1c], xmm0
433dc07a addss    xmm3, xmm5
433dc07e ucomiss  xmm3, xmm7
433dc081 lahf     
433dc082 test     ah, 0x44
433dc085 jp       0x433dc08f
433dc087 mov      byte ptr [esp + 0x925], 0
433dc08f movss    xmm3, dword ptr [ecx + 0x44]
433dc094 lea      eax, [ecx + 0x6c]
433dc097 movss    xmm4, dword ptr [ecx + 0x48]
433dc09c movaps   xmm2, xmm3
433dc09f movss    xmm0, dword ptr [ecx + 0x38]
433dc0a4 movaps   xmm1, xmm4
433dc0a7 movss    xmm7, dword ptr [ecx + 0x3c]
433dc0ac subss    xmm2, xmm0
433dc0b0 movss    xmm5, dword ptr [ecx + 0x4c]
433dc0b5 subss    xmm1, xmm7
433dc0b9 movss    xmm6, dword ptr [ecx + 0x40]
433dc0be addss    xmm7, xmm4
433dc0c2 movss    dword ptr [esp + 0x38], xmm0
433dc0c8 mov      ecx, edx
433dc0ca movaps   xmm0, xmm5
433dc0cd mulss    xmm2, dword ptr [0x43472240]
433dc0d5 subss    xmm0, xmm6
433dc0d9 push     eax
433dc0da mulss    xmm1, dword ptr [0x43472240]
433dc0e2 addss    xmm6, xmm5
433dc0e6 lea      eax, [esp + 0x52c]
433dc0ed movss    dword ptr [esp + 0x914], xmm2
433dc0f6 mulss    xmm0, dword ptr [0x43472240]
433dc0fe push     eax
433dc0ff movss    dword ptr [esp + 0x91c], xmm1
433dc108 lea      eax, [esp + 0x8e8]
433dc10f mulss    xmm1, xmm1
433dc113 push     edi
433dc114 movss    dword ptr [esp + 0x924], xmm0
433dc11d mulss    xmm0, xmm0
433dc121 push     eax
433dc122 mulss    xmm2, xmm2
433dc126 addss    xmm1, xmm2
433dc12a addss    xmm1, xmm0
433dc12e cvtps2pd xmm0, xmm1
433dc131 movsd    xmm1, qword ptr [esp + 0xa0]
433dc13a comisd   xmm1, xmm0
433dc13e movss    xmm1, dword ptr [esp + 0x48]
433dc144 movss    xmm0, dword ptr [0x43472240]
433dc14c addss    xmm1, xmm3
433dc150 mulss    xmm7, xmm0
433dc154 seta     byte ptr [esp + 0x934]
433dc15c mulss    xmm6, xmm0
433dc160 mulss    xmm1, xmm0
433dc164 movss    xmm0, dword ptr [esp + 0x74]
433dc16a addss    xmm0, xmm1
433dc16e movss    dword ptr [esp + 0x8f0], xmm0
433dc177 movss    xmm0, dword ptr [esp + 0x2c]
433dc17d addss    xmm0, xmm7
433dc181 movss    dword ptr [esp + 0x8f4], xmm0
433dc18a movaps   xmm0, xmm6
433dc18d addss    xmm0, dword ptr [esp + 0x11c]
433dc196 movss    dword ptr [esp + 0x8f8], xmm0
433dc19f movss    xmm0, dword ptr [0x4346f858]
433dc1a7 mulss    xmm1, xmm0
433dc1ab mulss    xmm7, xmm0
433dc1af mulss    xmm6, xmm0
433dc1b3 movss    dword ptr [esp + 0x910], xmm1
433dc1bc movss    dword ptr [esp + 0x914], xmm7
433dc1c5 movss    dword ptr [esp + 0x918], xmm6
433dc1ce call     esi
433dc1d0 mov      ecx, dword ptr [esp + 0x20]
433dc1d4 movss    xmm7, dword ptr [esp + 0x18]
433dc1da movss    xmm0, dword ptr [ecx + 0x98]
433dc1e2 comiss   xmm0, xmm7
433dc1e5 movaps   xmm1, xmm0
433dc1e8 movaps   xmm4, xmm0
433dc1eb jbe      0x433dc207
433dc1ed movss    xmm2, dword ptr [0x434723ec]
433dc1f5 comiss   xmm2, xmm0
433dc1f8 jbe      0x433dc207
433dc1fa and      dword ptr [ecx + 0x98], 0
433dc201 movaps   xmm1, xmm7
433dc204 movaps   xmm4, xmm7
433dc207 cmp      byte ptr [ecx + 0xa2], 0
433dc20e movaps   xmm0, xmm1
433dc211 addss    xmm0, dword ptr [esp + 0x74]
433dc217 movss    dword ptr [esp + 0x74], xmm0
433dc21d jne      0x433dcafa
433dc223 comiss   xmm1, xmm7
433dc226 jbe      0x433dc515
433dc22c ucomiss  xmm1, dword ptr [0x43470514]
433dc233 lahf     
433dc234 test     ah, 0x44
433dc237 jp       0x433dc4bb
433dc23d or       dword ptr [esp + 0xc14], 0xffffffff
433dc245 lea      esi, [ecx + 0x78]
433dc248 or       dword ptr [esp + 0xc20], 0xffffffff
433dc250 lea      edi, [esp + 0xbc]
433dc257 mov      dword ptr [esp + 0xbfc], 0x3f800000
433dc262 xor      edx, edx
433dc264 mov      word ptr [esp + 0xc06], dx
433dc26c mov      dword ptr [esp + 0xc1c], edx
433dc273 movsd    dword ptr es:[edi], dword ptr [esi]
433dc274 mov      eax, dword ptr [ecx]
433dc276 movsd    dword ptr es:[edi], dword ptr [esi]
433dc277 movsd    dword ptr es:[edi], dword ptr [esi]
433dc278 movss    xmm2, dword ptr [esp + 0xbc]
433dc281 lea      esi, [ecx + 0x78]
433dc284 movss    xmm1, dword ptr [esp + 0xc0]
433dc28d lea      edi, [esp + 0x84]
433dc294 movsd    dword ptr es:[edi], dword ptr [esi]
433dc295 movss    xmm0, dword ptr [esp + 0xc4]
433dc29e movsd    dword ptr es:[edi], dword ptr [esi]
433dc29f movsd    dword ptr es:[edi], dword ptr [esi]
433dc2a0 subss    xmm1, dword ptr [esp + 0x88]
433dc2a9 subss    xmm2, dword ptr [esp + 0x84]
433dc2b2 subss    xmm0, dword ptr [esp + 0x8c]
433dc2bb mov      dword ptr [esp + 0x544], edx
433dc2c2 mov      edx, dword ptr [0x43468304]
433dc2c8 mov      dword ptr [esp + 0x53c], eax
433dc2cf mov      dword ptr [esp + 0x538], 0x4346edc0
433dc2da mov      dword ptr [esp + 0x540], 8
433dc2e5 mov      eax, dword ptr [edx]
433dc2e7 mov      edi, dword ptr [ecx + 0xd0]
433dc2ed mov      esi, dword ptr [eax + 0x14]
433dc2f0 and      dword ptr [esp + 0x970], 0
433dc2f8 movss    dword ptr [esp + 0x944], xmm1
433dc301 movss    dword ptr [esp + 0x940], xmm2
433dc30a mulss    xmm1, xmm1
433dc30e mov      byte ptr [esp + 0x975], 1
433dc316 mulss    xmm2, xmm2
433dc31a movss    dword ptr [esp + 0x948], xmm0
433dc323 mulss    xmm0, xmm0
433dc327 addss    xmm1, xmm2
433dc32b addss    xmm1, xmm0
433dc32f ucomiss  xmm1, xmm7
433dc332 lahf     
433dc333 test     ah, 0x44
433dc336 jp       0x433dc340
433dc338 mov      byte ptr [esp + 0x975], 0
433dc340 movss    xmm3, dword ptr [ecx + 0x44]
433dc345 lea      eax, [esp + 0xbd0]
433dc34c movss    xmm4, dword ptr [ecx + 0x48]
433dc351 movaps   xmm2, xmm3
433dc354 movss    xmm0, dword ptr [ecx + 0x38]
433dc359 movaps   xmm1, xmm4
433dc35c movss    xmm7, dword ptr [ecx + 0x3c]
433dc361 subss    xmm2, xmm0
433dc365 movss    xmm5, dword ptr [ecx + 0x4c]
433dc36a subss    xmm1, xmm7
433dc36e movss    xmm6, dword ptr [ecx + 0x40]
433dc373 addss    xmm7, xmm4
433dc377 movss    dword ptr [esp + 0x38], xmm0
433dc37d mov      ecx, edx
433dc37f movaps   xmm0, xmm5
433dc382 mulss    xmm2, dword ptr [0x43472240]
433dc38a subss    xmm0, xmm6
433dc38e push     eax
433dc38f mulss    xmm1, dword ptr [0x43472240]
433dc397 addss    xmm6, xmm5
433dc39b lea      eax, [esp + 0x53c]
433dc3a2 movss    dword ptr [esp + 0x964], xmm2
433dc3ab mulss    xmm0, dword ptr [0x43472240]
433dc3b3 push     eax
433dc3b4 movss    dword ptr [esp + 0x96c], xmm1
433dc3bd lea      eax, [esp + 0x938]
433dc3c4 mulss    xmm1, xmm1
433dc3c8 push     edi
433dc3c9 movss    dword ptr [esp + 0x974], xmm0
433dc3d2 mulss    xmm0, xmm0
433dc3d6 push     eax
433dc3d7 mulss    xmm2, xmm2
433dc3db addss    xmm1, xmm2
433dc3df addss    xmm1, xmm0
433dc3e3 cvtps2pd xmm0, xmm1
433dc3e6 movsd    xmm1, qword ptr [esp + 0xa0]
433dc3ef comisd   xmm1, xmm0
433dc3f3 movss    xmm1, dword ptr [esp + 0x48]
433dc3f9 movss    xmm0, dword ptr [0x43472240]
433dc401 addss    xmm1, xmm3
433dc405 mulss    xmm7, xmm0
433dc409 seta     byte ptr [esp + 0x984]
433dc411 mulss    xmm6, xmm0
433dc415 mulss    xmm1, xmm0
433dc419 movaps   xmm0, xmm1
433dc41c addss    xmm0, dword ptr [esp + 0x94]
433dc425 movss    dword ptr [esp + 0x940], xmm0
433dc42e movaps   xmm0, xmm7
433dc431 addss    xmm0, dword ptr [esp + 0x98]
433dc43a movss    dword ptr [esp + 0x944], xmm0
433dc443 movaps   xmm0, xmm6
433dc446 addss    xmm0, dword ptr [esp + 0x9c]
433dc44f movss    dword ptr [esp + 0x948], xmm0
433dc458 movss    xmm0, dword ptr [0x4346f858]
433dc460 mulss    xmm1, xmm0
433dc464 mulss    xmm7, xmm0
433dc468 mulss    xmm6, xmm0
433dc46c movss    dword ptr [esp + 0x960], xmm1
433dc475 movss    dword ptr [esp + 0x964], xmm7
433dc47e movss    dword ptr [esp + 0x968], xmm6
433dc487 call     esi
433dc489 cmp      byte ptr [esp + 0xc07], 0
433dc491 jne      0x433dcae7
433dc497 movss    xmm0, dword ptr [esp + 0xbfc]
433dc4a0 ucomiss  xmm0, dword ptr [0x43470514]
433dc4a7 lahf     
433dc4a8 test     ah, 0x44
433dc4ab jp       0x433dcae7
433dc4b1 movss    xmm7, dword ptr [esp + 0x18]
433dc4b7 mov      ecx, dword ptr [esp + 0x20]
433dc4bb lea      esi, [ecx + 0x78]
433dc4be lea      edi, [ecx + 4]
433dc4c1 movsd    dword ptr es:[edi], dword ptr [esi]
433dc4c2 lea      edx, [ecx + 0x10]
433dc4c5 movsd    dword ptr es:[edi], dword ptr [esi]
433dc4c6 movsd    dword ptr es:[edi], dword ptr [esi]
433dc4c7 movss    xmm1, dword ptr [ecx + 0x98]
433dc4cf lea      edi, [esp + 0xa4]
433dc4d6 mov      esi, edx
433dc4d8 movaps   xmm4, xmm1
433dc4db movsd    dword ptr es:[edi], dword ptr [esi]
433dc4dc movsd    dword ptr es:[edi], dword ptr [esi]
433dc4dd movsd    dword ptr es:[edi], dword ptr [esi]
433dc4de movss    xmm3, dword ptr [esp + 0xac]
433dc4e7 xor      edi, edi
433dc4e9 movss    xmm6, dword ptr [esp + 0xa8]
433dc4f2 movss    xmm5, dword ptr [esp + 0xa4]
433dc4fb mov      dword ptr [esp + 0x54], edi
433dc4ff movups   xmmword ptr [esp + 0x2b0], xmm3
433dc507 movss    dword ptr [esp + 0x40], xmm6
433dc50d movss    dword ptr [esp + 0x2c], xmm5
433dc513 jmp      0x433dc530
433dc515 movups   xmm3, xmmword ptr [esp + 0x2b0]
433dc51d lea      edx, [ecx + 0x10]
433dc520 mov      edi, dword ptr [esp + 0x54]
433dc524 movss    xmm6, dword ptr [esp + 0x40]
433dc52a movss    xmm5, dword ptr [esp + 0x2c]
433dc530 movss    xmm2, dword ptr [0x43470514]
433dc538 ucomiss  xmm1, xmm2
433dc53b lahf     
433dc53c test     ah, 0x44
433dc53f jnp      0x433dcb15
433dc545 movss    xmm0, dword ptr [ecx + 0x8c]
433dc54d movss    xmm7, dword ptr [0x434723ec]
433dc555 andps    xmm0, xmmword ptr [0x43470340]
433dc55c comiss   xmm7, xmm0
433dc55f movss    xmm7, dword ptr [esp + 0x18]
433dc565 jbe      0x433dc571
433dc567 and      dword ptr [ecx + 0x8c], 0
433dc56e movaps   xmm1, xmm4
433dc571 movss    xmm0, dword ptr [esp + 0x78]
433dc577 mulss    xmm1, xmm0
433dc57b subss    xmm0, xmm1
433dc57f movss    dword ptr [esp + 0x78], xmm0
433dc585 cmp      edi, 5
433dc588 jge      0x433dcafd
433dc58e imul     eax, edi, 0xc
433dc591 lea      esi, [ecx + 0x84]
433dc597 lea      edi, [esp + 0x5e0]
433dc59e add      edi, eax
433dc5a0 mov      eax, dword ptr [esp + 0x54]
433dc5a4 inc      eax
433dc5a5 mov      dword ptr [esp + 0x54], eax
433dc5a9 movsd    dword ptr es:[edi], dword ptr [esi]
433dc5aa movsd    dword ptr es:[edi], dword ptr [esi]
433dc5ab movsd    dword ptr es:[edi], dword ptr [esi]
433dc5ac cmp      eax, 1
433dc5af jne      0x433dc7b0
433dc5b5 cmp      byte ptr [ecx + 0xcc], 2
433dc5bc jne      0x433dc7b0
433dc5c2 test     byte ptr [ecx + 0x1c], al
433dc5c5 jne      0x433dc7b0
433dc5cb mov      al, byte ptr [ecx + 0x108]
433dc5d1 lea      esi, [esp + 0x5e0]
433dc5d8 lea      edi, [esp + 0x98]
433dc5df mov      byte ptr [esp + 0x17], al
433dc5e3 movsd    dword ptr es:[edi], dword ptr [esi]
433dc5e4 or       al, 8
433dc5e6 movsd    dword ptr es:[edi], dword ptr [esi]
433dc5e7 movsd    dword ptr es:[edi], dword ptr [esi]
433dc5e8 movss    xmm4, dword ptr [esp + 0xa0]
433dc5f1 lea      edi, [ecx + 0x60]
433dc5f4 comiss   xmm4, dword ptr [0x4346fd8c]
433dc5fb mov      byte ptr [ecx + 0x108], al
433dc601 lea      esi, [ecx + 4]
433dc604 movsd    dword ptr es:[edi], dword ptr [esi]
433dc605 movsd    dword ptr es:[edi], dword ptr [esi]
433dc606 movsd    dword ptr es:[edi], dword ptr [esi]
433dc607 jb       0x433dc611
433dc609 mov      al, byte ptr [esp + 0x17]
433dc60d or       al, 0xc
433dc60f jmp      0x433dc62e
433dc611 movss    xmm1, dword ptr [0x43472980]
433dc619 movaps   xmm0, xmm4
433dc61c andps    xmm0, xmmword ptr [0x43470340]
433dc623 comiss   xmm1, xmm0
433dc626 jbe      0x433dc641
433dc628 mov      al, byte ptr [esp + 0x17]
433dc62c or       al, 0xa
433dc62e mov      byte ptr [ecx + 0x108], al
433dc634 lea      edi, [ecx + 0x50]
433dc637 lea      esi, [esp + 0x98]
433dc63e movsd    dword ptr es:[edi], dword ptr [esi]
433dc63f movsd    dword ptr es:[edi], dword ptr [esi]
433dc640 movsd    dword ptr es:[edi], dword ptr [esi]
433dc641 movaps   xmm1, xmm5
433dc644 movaps   xmm0, xmm6
433dc647 mulss    xmm0, dword ptr [esp + 0x9c]
433dc650 mulss    xmm1, dword ptr [esp + 0x98]
433dc659 addss    xmm1, xmm0
433dc65d movaps   xmm0, xmm4
433dc660 mulss    xmm0, xmm3
433dc664 addss    xmm1, xmm0
433dc668 movaps   xmm0, xmm1
433dc66b mulss    xmm0, dword ptr [esp + 0x98]
433dc674 subss    xmm5, xmm0
433dc678 movaps   xmm0, xmm1
433dc67b mulss    xmm0, dword ptr [esp + 0x9c]
433dc684 subss    xmm6, xmm0
433dc688 movss    dword ptr [esp + 0x2c], xmm5
433dc68e movaps   xmm0, xmm4
433dc691 movss    dword ptr [esp + 0x68], xmm5
433dc697 mulss    xmm0, xmm1
433dc69b movaps   xmm2, xmm6
433dc69e movss    dword ptr [esp + 0x40], xmm6
433dc6a4 mulss    xmm2, dword ptr [esp + 0x9c]
433dc6ad subss    xmm3, xmm0
433dc6b1 movaps   xmm0, xmm5
433dc6b4 movss    dword ptr [esp + 0x6c], xmm6
433dc6ba mulss    xmm0, dword ptr [esp + 0x98]
433dc6c3 movaps   xmm1, xmm3
433dc6c6 mulss    xmm1, xmm4
433dc6ca addss    xmm2, xmm0
433dc6ce movups   xmmword ptr [esp + 0x2b0], xmm3
433dc6d6 addss    xmm2, xmm1
433dc6da comiss   xmm2, xmm7
433dc6dd jae      0x433dc74d
433dc6df movss    xmm1, dword ptr [0x43471d88]
433dc6e7 movaps   xmm0, xmm2
433dc6ea call     0x43367633
433dc6ef movss    xmm2, dword ptr [esp + 0x2c]
433dc6f5 movaps   xmm1, xmm0
433dc6f8 mulss    xmm1, dword ptr [esp + 0x98]
433dc701 mov      ecx, dword ptr [esp + 0x20]
433dc705 movups   xmm3, xmmword ptr [esp + 0x2b0]
433dc70d mov      edx, dword ptr [esp + 0x80]
433dc714 movss    xmm7, dword ptr [esp + 0x18]
433dc71a subss    xmm2, xmm1
433dc71e movaps   xmm1, xmm0
433dc721 mulss    xmm0, dword ptr [esp + 0xa0]
433dc72a mulss    xmm1, dword ptr [esp + 0x9c]
433dc733 movss    dword ptr [esp + 0x68], xmm2
433dc739 subss    xmm3, xmm0
433dc73d movss    xmm2, dword ptr [esp + 0x40]
433dc743 subss    xmm2, xmm1
433dc747 movss    dword ptr [esp + 0x6c], xmm2
433dc74d movq     xmm0, qword ptr [esp + 0x68]
433dc753 movq     qword ptr [edx], xmm0
433dc757 xorps    xmm0, xmm0
433dc75a movss    xmm0, xmm3
433dc75e movss    dword ptr [edx + 8], xmm0
433dc763 movq     xmm0, qword ptr [esp + 0x68]
433dc769 movq     qword ptr [esp + 0xa4], xmm0
433dc772 movaps   xmm0, xmm3
433dc775 movss    xmm2, dword ptr [esp + 0xa8]
433dc77e xorps    xmm3, xmm3
433dc781 movss    xmm3, xmm0
433dc785 movss    dword ptr [esp + 0x40], xmm2
433dc78b movss    xmm0, dword ptr [esp + 0xa4]
433dc794 movups   xmmword ptr [esp + 0x2b0], xmm3
433dc79c movss    dword ptr [esp + 0xac], xmm3
433dc7a5 movss    dword ptr [esp + 0x2c], xmm0
433dc7ab jmp      0x433dcace
433dc7b0 xor      esi, esi
433dc7b2 mov      dword ptr [esp + 0x34], esi
433dc7b6 test     eax, eax
433dc7b8 jle      0x433dc994
433dc7be lea      edi, [esp + 0x5e0]
433dc7c5 mov      dword ptr [esp + 0x1c], edi
433dc7c9 mov      al, byte ptr [ecx + 0x108]
433dc7cf mov      esi, edi
433dc7d1 lea      edi, [esp + 0x58]
433dc7d5 mov      byte ptr [esp + 0x17], al
433dc7d9 or       al, 8
433dc7db movsd    dword ptr es:[edi], dword ptr [esi]
433dc7dc movsd    dword ptr es:[edi], dword ptr [esi]
433dc7dd movsd    dword ptr es:[edi], dword ptr [esi]
433dc7de movss    xmm5, dword ptr [esp + 0x60]
433dc7e4 lea      esi, [ecx + 4]
433dc7e7 comiss   xmm5, dword ptr [0x4346fd8c]
433dc7ee mov      byte ptr [ecx + 0x108], al
433dc7f4 lea      edi, [ecx + 0x60]
433dc7f7 movsd    dword ptr es:[edi], dword ptr [esi]
433dc7f8 movsd    dword ptr es:[edi], dword ptr [esi]
433dc7f9 movsd    dword ptr es:[edi], dword ptr [esi]
433dc7fa jb       0x433dc804
433dc7fc mov      al, byte ptr [esp + 0x17]
433dc800 or       al, 0xc
433dc802 jmp      0x433dc821
433dc804 movss    xmm1, dword ptr [0x43472980]
433dc80c movaps   xmm0, xmm5
433dc80f andps    xmm0, xmmword ptr [0x43470340]
433dc816 comiss   xmm1, xmm0
433dc819 jbe      0x433dc831
433dc81b mov      al, byte ptr [esp + 0x17]
433dc81f or       al, 0xa
433dc821 mov      byte ptr [ecx + 0x108], al
433dc827 lea      edi, [ecx + 0x50]
433dc82a lea      esi, [esp + 0x58]
433dc82e movsd    dword ptr es:[edi], dword ptr [esi]
433dc82f movsd    dword ptr es:[edi], dword ptr [esi]
433dc830 movsd    dword ptr es:[edi], dword ptr [esi]
433dc831 movss    xmm2, dword ptr [esp + 0x2c]
433dc837 movaps   xmm0, xmm6
433dc83a mulss    xmm0, dword ptr [esp + 0x5c]
433dc840 movaps   xmm4, xmm6
433dc843 mulss    xmm2, dword ptr [esp + 0x58]
433dc849 addss    xmm2, xmm0
433dc84d movaps   xmm0, xmm5
433dc850 mulss    xmm0, xmm3
433dc854 addss    xmm2, xmm0
433dc858 movss    xmm0, dword ptr [esp + 0x2c]
433dc85e movaps   xmm1, xmm2
433dc861 mulss    xmm1, dword ptr [esp + 0x58]
433dc867 subss    xmm0, xmm1
433dc86b movaps   xmm1, xmm3
433dc86e movss    dword ptr [edx], xmm0
433dc872 movaps   xmm0, xmm2
433dc875 mulss    xmm0, dword ptr [esp + 0x5c]
433dc87b mulss    xmm2, xmm5
433dc87f subss    xmm4, xmm0
433dc883 subss    xmm1, xmm2
433dc887 movss    dword ptr [edx + 4], xmm4
433dc88c mulss    xmm4, dword ptr [esp + 0x5c]
433dc892 movss    dword ptr [edx + 8], xmm1
433dc897 movss    xmm0, dword ptr [edx]
433dc89b mulss    xmm0, dword ptr [esp + 0x58]
433dc8a1 mulss    xmm1, xmm5
433dc8a5 addss    xmm4, xmm0
433dc8a9 addss    xmm4, xmm1
433dc8ad comiss   xmm4, xmm7
433dc8b0 jae      0x433dc924
433dc8b2 movss    xmm1, dword ptr [0x43471d88]
433dc8ba movaps   xmm0, xmm4
433dc8bd call     0x43367633
433dc8c2 mov      edx, dword ptr [esp + 0x80]
433dc8c9 movaps   xmm3, xmm0
433dc8cc movaps   xmm2, xmm3
433dc8cf movss    xmm7, dword ptr [esp + 0x18]
433dc8d5 mulss    xmm2, dword ptr [esp + 0x58]
433dc8db mov      ecx, dword ptr [esp + 0x20]
433dc8df movss    xmm1, dword ptr [edx]
433dc8e3 movss    xmm6, dword ptr [esp + 0x40]
433dc8e9 subss    xmm1, xmm2
433dc8ed movaps   xmm2, xmm3
433dc8f0 mulss    xmm2, dword ptr [esp + 0x5c]
433dc8f6 mulss    xmm3, dword ptr [esp + 0x60]
433dc8fc movss    dword ptr [edx], xmm1
433dc900 movss    xmm1, dword ptr [edx + 4]
433dc905 subss    xmm1, xmm2
433dc909 movss    dword ptr [edx + 4], xmm1
433dc90e movss    xmm0, dword ptr [edx + 8]
433dc913 subss    xmm0, xmm3
433dc917 movups   xmm3, xmmword ptr [esp + 0x2b0]
433dc91f movss    dword ptr [edx + 8], xmm0
433dc924 mov      eax, dword ptr [esp + 0x54]
433dc928 lea      edi, [esp + 0x5e8]
433dc92f xor      esi, esi
433dc931 cmp      esi, dword ptr [esp + 0x34]
433dc935 je       0x433dc960
433dc937 movss    xmm0, dword ptr [edi - 4]
433dc93c movss    xmm1, dword ptr [edi - 8]
433dc941 mulss    xmm0, dword ptr [edx + 4]
433dc946 mulss    xmm1, dword ptr [edx]
433dc94a addss    xmm1, xmm0
433dc94e movss    xmm0, dword ptr [edi]
433dc952 mulss    xmm0, dword ptr [edx + 8]
433dc957 addss    xmm1, xmm0
433dc95b comiss   xmm1, xmm7
433dc95e jb       0x433dc968
433dc960 inc      esi
433dc961 add      edi, 0xc
433dc964 cmp      esi, eax
433dc966 jl       0x433dc931
433dc968 cmp      esi, eax
433dc96a je       0x433dca98
433dc970 mov      esi, dword ptr [esp + 0x34]
433dc974 mov      edi, dword ptr [esp + 0x1c]
433dc978 inc      esi
433dc979 add      edi, 0xc
433dc97c mov      dword ptr [esp + 0x34], esi
433dc980 mov      dword ptr [esp + 0x1c], edi
433dc984 cmp      esi, eax
433dc986 jl       0x433dc7c9
433dc98c movss    xmm2, dword ptr [0x43470514]
433dc994 cmp      esi, eax
433dc996 jne      0x433dca98
433dc99c cmp      eax, 2
433dc99f jne      0x433dcafd
433dc9a5 movss    xmm3, dword ptr [esp + 0x5f4]
433dc9ae movaps   xmm4, xmm2
433dc9b1 mulss    xmm3, dword ptr [esp + 0x5e4]
433dc9ba movss    xmm0, dword ptr [esp + 0x5f0]
433dc9c3 mulss    xmm0, dword ptr [esp + 0x5e8]
433dc9cc movss    xmm1, dword ptr [esp + 0x5ec]
433dc9d5 movss    xmm6, dword ptr [esp + 0x5e0]
433dc9de movaps   xmm5, xmm1
433dc9e1 mulss    xmm1, dword ptr [esp + 0x5e4]
433dc9ea subss    xmm3, xmm0
433dc9ee mulss    xmm5, dword ptr [esp + 0x5e8]
433dc9f7 movaps   xmm0, xmm6
433dc9fa mulss    xmm0, dword ptr [esp + 0x5f4]
433dca03 mulss    xmm6, dword ptr [esp + 0x5f0]
433dca0c subss    xmm5, xmm0
433dca10 subss    xmm6, xmm1
433dca14 movaps   xmm1, xmm3
433dca17 mulss    xmm1, xmm3
433dca1b movaps   xmm0, xmm5
433dca1e mulss    xmm0, xmm5
433dca22 addss    xmm1, xmm0
433dca26 movaps   xmm0, xmm6
433dca29 mulss    xmm0, xmm6
433dca2d addss    xmm1, xmm0
433dca31 movaps   xmm0, xmm1
433dca34 movss    xmm1, dword ptr [edx + 4]
433dca39 sqrtss   xmm0, xmm0
433dca3d addss    xmm0, dword ptr [0x43472108]
433dca45 divss    xmm4, xmm0
433dca49 movss    xmm0, dword ptr [edx]
433dca4d movaps   xmm2, xmm4
433dca50 mulss    xmm2, xmm3
433dca54 movaps   xmm3, xmm4
433dca57 mulss    xmm3, xmm5
433dca5b mulss    xmm0, xmm2
433dca5f mulss    xmm1, xmm3
433dca63 mulss    xmm4, xmm6
433dca67 addss    xmm1, xmm0
433dca6b movss    xmm0, dword ptr [edx + 8]
433dca70 mulss    xmm0, xmm4
433dca74 addss    xmm1, xmm0
433dca78 movaps   xmm0, xmm1
433dca7b mulss    xmm0, xmm2
433dca7f movss    dword ptr [edx], xmm0
433dca83 movaps   xmm0, xmm1
433dca86 mulss    xmm0, xmm3
433dca8a mulss    xmm1, xmm4
433dca8e movss    dword ptr [edx + 4], xmm0
433dca93 movss    dword ptr [edx + 8], xmm1
433dca98 movss    xmm0, dword ptr [esp + 0xd8]
433dcaa1 movss    xmm1, dword ptr [edx]
433dcaa5 mulss    xmm0, dword ptr [edx + 4]
433dcaaa mulss    xmm1, dword ptr [esp + 0xd4]
433dcab3 addss    xmm1, xmm0
433dcab7 movss    xmm0, dword ptr [esp + 0xdc]
433dcac0 mulss    xmm0, dword ptr [edx + 8]
433dcac5 addss    xmm1, xmm0
433dcac9 comiss   xmm1, xmm7
433dcacc jbe      0x433dcafd
433dcace mov      esi, dword ptr [esp + 0x48]
433dcad2 inc      esi
433dcad3 mov      dword ptr [esp + 0x48], esi
433dcad7 cmp      esi, 4
433dcada jge      0x433dcb15
433dcadc movss    xmm6, dword ptr [esp + 0x78]
433dcae2 jmp      0x433dbf6c
433dcae7 mov      edx, dword ptr [esp + 0x80]
433dcaee movss    xmm7, dword ptr [esp + 0x18]
433dcaf4 mov      ecx, dword ptr [esp + 0x20]
433dcaf8 jmp      0x433dcafd
433dcafa lea      edx, [ecx + 0x10]
433dcafd xor      eax, eax
433dcaff lea      edi, [esp + 0xc8]
433dcb06 stosd    dword ptr es:[edi], eax
433dcb07 lea      esi, [esp + 0xc8]
433dcb0e stosd    dword ptr es:[edi], eax
433dcb0f stosd    dword ptr es:[edi], eax
433dcb10 mov      edi, edx
433dcb12 movsd    dword ptr es:[edi], dword ptr [esi]
433dcb13 movsd    dword ptr es:[edi], dword ptr [esi]
433dcb14 movsd    dword ptr es:[edi], dword ptr [esi]
433dcb15 movss    xmm2, dword ptr [esp + 0x74]
433dcb1b ucomiss  xmm2, xmm7
433dcb1e lahf     
433dcb1f test     ah, 0x44
433dcb22 jp       0x433dcb3c
433dcb24 xor      eax, eax
433dcb26 lea      edi, [esp + 0x290]
433dcb2d stosd    dword ptr es:[edi], eax
433dcb2e lea      esi, [esp + 0x290]
433dcb35 stosd    dword ptr es:[edi], eax
433dcb36 stosd    dword ptr es:[edi], eax
433dcb37 mov      edi, edx
433dcb39 movsd    dword ptr es:[edi], dword ptr [esi]
433dcb3a movsd    dword ptr es:[edi], dword ptr [esi]
433dcb3b movsd    dword ptr es:[edi], dword ptr [esi]
433dcb3c movss    xmm0, dword ptr [ecx + 0xdc]
433dcb44 lea      esi, [ecx + 4]
433dcb47 mov      eax, dword ptr [ecx]
433dcb49 lea      edi, [esp + 0x128]
433dcb50 movsd    dword ptr es:[edi], dword ptr [esi]
433dcb51 mov      edx, dword ptr [0x43468304]
433dcb57 cvtps2pd xmm0, xmm0
433dcb5a movsd    dword ptr es:[edi], dword ptr [esi]
433dcb5b movsd    dword ptr es:[edi], dword ptr [esi]
433dcb5c movss    xmm1, dword ptr [esp + 0x130]
433dcb65 lea      esi, [ecx + 4]
433dcb68 addsd    xmm0, qword ptr [0x4346fe70]
433dcb70 movss    xmm3, dword ptr [esp + 0x128]
433dcb79 lea      edi, [esp + 0x84]
433dcb80 movss    xmm2, dword ptr [esp + 0x12c]
433dcb89 movsd    dword ptr es:[edi], dword ptr [esi]
433dcb8a cvtps2pd xmm1, xmm1
433dcb8d movsd    dword ptr es:[edi], dword ptr [esi]
433dcb8e movsd    dword ptr es:[edi], dword ptr [esi]
433dcb8f subsd    xmm1, xmm0
433dcb93 and      dword ptr [esp + 0x554], 0
433dcb9b subss    xmm2, dword ptr [esp + 0x88]
433dcba4 subss    xmm3, dword ptr [esp + 0x84]
433dcbad mov      dword ptr [esp + 0x54c], eax
433dcbb4 mov      dword ptr [esp + 0x548], 0x4346edc0
433dcbbf mov      dword ptr [esp + 0x550], 8
433dcbca mov      eax, dword ptr [edx]
433dcbcc mov      edi, dword ptr [ecx + 0xd0]
433dcbd2 cvtpd2ps xmm0, xmm1
433dcbd6 mov      esi, dword ptr [eax + 0x14]
433dcbd9 and      dword ptr [esp + 0x9c0], 0
433dcbe1 mov      byte ptr [esp + 0x9c5], 1
433dcbe9 movss    dword ptr [esp + 0x994], xmm2
433dcbf2 subss    xmm0, dword ptr [esp + 0x8c]
433dcbfb movss    dword ptr [esp + 0x990], xmm3
433dcc04 mulss    xmm2, xmm2
433dcc08 mulss    xmm3, xmm3
433dcc0c movss    dword ptr [esp + 0x998], xmm0
433dcc15 mulss    xmm0, xmm0
433dcc19 addss    xmm2, xmm3
433dcc1d addss    xmm2, xmm0
433dcc21 ucomiss  xmm2, xmm7
433dcc24 lahf     
433dcc25 test     ah, 0x44
433dcc28 jp       0x433dcc32
433dcc2a mov      byte ptr [esp + 0x9c5], 0
433dcc32 movss    xmm3, dword ptr [ecx + 0x44]
433dcc37 lea      eax, [ecx + 0x6c]
433dcc3a movss    xmm4, dword ptr [ecx + 0x48]
433dcc3f movaps   xmm2, xmm3
433dcc42 movss    xmm6, dword ptr [ecx + 0x38]
433dcc47 movaps   xmm1, xmm4
433dcc4a movss    xmm7, dword ptr [ecx + 0x3c]
433dcc4f subss    xmm2, xmm6
433dcc53 movss    xmm0, dword ptr [ecx + 0x40]
433dcc58 subss    xmm1, xmm7
433dcc5c movss    xmm5, dword ptr [ecx + 0x4c]
433dcc61 addss    xmm6, xmm3
433dcc65 movss    dword ptr [esp + 0x1c], xmm0
433dcc6b addss    xmm7, xmm4
433dcc6f movaps   xmm0, xmm5
433dcc72 mov      ecx, edx
433dcc74 subss    xmm0, dword ptr [esp + 0x1c]
433dcc7a mulss    xmm1, dword ptr [0x43472240]
433dcc82 push     eax
433dcc83 mulss    xmm2, dword ptr [0x43472240]
433dcc8b lea      eax, [esp + 0x54c]
433dcc92 push     eax
433dcc93 mulss    xmm0, dword ptr [0x43472240]
433dcc9b lea      eax, [esp + 0x988]
433dcca2 push     edi
433dcca3 movss    dword ptr [esp + 0x9c0], xmm1
433dccac mulss    xmm1, xmm1
433dccb0 push     eax
433dccb1 movss    dword ptr [esp + 0x9c8], xmm0
433dccba mulss    xmm0, xmm0
433dccbe movss    dword ptr [esp + 0x9c0], xmm2
433dccc7 mulss    xmm2, xmm2
433dcccb addss    xmm1, xmm2
433dcccf addss    xmm1, xmm0
433dccd3 cvtps2pd xmm0, xmm1
433dccd6 movsd    xmm1, qword ptr [esp + 0xa0]
433dccdf comisd   xmm1, xmm0
433dcce3 movss    xmm0, dword ptr [0x43472240]
433dcceb movss    xmm1, dword ptr [esp + 0x2c]
433dccf1 mulss    xmm6, xmm0
433dccf5 addss    xmm1, xmm5
433dccf9 mulss    xmm7, xmm0
433dccfd seta     byte ptr [esp + 0x9d4]
433dcd05 mulss    xmm1, xmm0
433dcd09 movaps   xmm0, xmm6
433dcd0c addss    xmm0, dword ptr [esp + 0x94]
433dcd15 movss    dword ptr [esp + 0x990], xmm0
433dcd1e movaps   xmm0, xmm7
433dcd21 addss    xmm0, dword ptr [esp + 0x98]
433dcd2a movss    dword ptr [esp + 0x994], xmm0
433dcd33 movaps   xmm0, xmm1
433dcd36 addss    xmm0, dword ptr [esp + 0x9c]
433dcd3f movss    dword ptr [esp + 0x998], xmm0
433dcd48 movss    xmm0, dword ptr [0x4346f858]
433dcd50 mulss    xmm6, xmm0
433dcd54 mulss    xmm7, xmm0
433dcd58 mulss    xmm1, xmm0
433dcd5c movss    dword ptr [esp + 0x9b0], xmm6
433dcd65 movss    dword ptr [esp + 0x9b4], xmm7
433dcd6e movss    dword ptr [esp + 0x9b8], xmm1
433dcd77 call     esi
433dcd79 mov      eax, dword ptr [esp + 0x24]
433dcd7d movsd    xmm1, qword ptr [0x4346fe68]
433dcd85 movss    xmm0, dword ptr [eax + 0x20]
433dcd8a cvtps2pd xmm0, xmm0
433dcd8d comisd   xmm1, xmm0
433dcd91 ja       0x433dce3a
433dcd97 cmp      byte ptr [eax + 0x37], 0
433dcd9b jne      0x433dcdb1
433dcd9d cmp      byte ptr [eax + 0x36], 0
433dcda1 jne      0x433dcdb1
433dcda3 lea      esi, [eax + 0xc]
433dcda6 mov      eax, dword ptr [esp + 0x3c]
433dcdaa mov      edi, eax
433dcdac movsd    dword ptr es:[edi], dword ptr [esi]
433dcdad movsd    dword ptr es:[edi], dword ptr [esi]
433dcdae movsd    dword ptr es:[edi], dword ptr [esi]
433dcdaf jmp      0x433dcdb5
433dcdb1 mov      eax, dword ptr [esp + 0x3c]
433dcdb5 movss    xmm2, dword ptr [esp + 0x2c4]
433dcdbe lea      edi, [esp + 0xbc]
433dcdc5 movss    xmm3, dword ptr [esp + 0x2c8]
433dcdce mov      esi, eax
433dcdd0 subss    xmm3, dword ptr [esp + 0xb4]
433dcdd9 subss    xmm2, dword ptr [esp + 0xb0]
433dcde2 movsd    dword ptr es:[edi], dword ptr [esi]
433dcde3 mulss    xmm3, xmm3
433dcde7 movsd    dword ptr es:[edi], dword ptr [esi]
433dcde8 mulss    xmm2, xmm2
433dcdec movsd    dword ptr es:[edi], dword ptr [esi]
433dcded movss    xmm1, dword ptr [esp + 0xc0]
433dcdf6 addss    xmm3, xmm2
433dcdfa movss    xmm0, dword ptr [esp + 0xbc]
433dce03 subss    xmm0, dword ptr [esp + 0xb0]
433dce0c subss    xmm1, dword ptr [esp + 0xb4]
433dce15 mulss    xmm0, xmm0
433dce19 mulss    xmm1, xmm1
433dce1d addss    xmm0, xmm1
433dce21 comiss   xmm3, xmm0
433dce24 ja       0x433dce3e
433dce26 mov      ecx, dword ptr [esp + 0x20]
433dce2a movss    xmm0, dword ptr [esp + 0x118]
433dce33 movss    dword ptr [ecx + 0x18], xmm0
433dce38 jmp      0x433dce5f
433dce3a mov      eax, dword ptr [esp + 0x3c]
433dce3e mov      ecx, dword ptr [esp + 0x20]
433dce42 lea      esi, [esp + 0x2c4]
433dce49 mov      edi, eax
433dce4b movsd    dword ptr es:[edi], dword ptr [esi]
433dce4c movsd    dword ptr es:[edi], dword ptr [esi]
433dce4d movsd    dword ptr es:[edi], dword ptr [esi]
433dce4e mov      edi, dword ptr [esp + 0x80]
433dce55 lea      esi, [esp + 0x110]
433dce5c movsd    dword ptr es:[edi], dword ptr [esi]
433dce5d movsd    dword ptr es:[edi], dword ptr [esi]
433dce5e movsd    dword ptr es:[edi], dword ptr [esi]
433dce5f or       dword ptr [esp + 0x69c], 0xffffffff
433dce67 lea      edi, [esp + 0xbc]
433dce6e or       dword ptr [esp + 0x6a8], 0xffffffff
433dce76 xor      edx, edx
433dce78 mov      word ptr [esp + 0x68e], dx
433dce80 mov      esi, eax
433dce82 mov      dword ptr [esp + 0x6a4], edx
433dce89 mov      dword ptr [esp + 0x684], 0x3f800000
433dce94 movsd    dword ptr es:[edi], dword ptr [esi]
433dce95 movsd    dword ptr es:[edi], dword ptr [esi]
433dce96 movsd    dword ptr es:[edi], dword ptr [esi]
433dce97 mov      esi, eax
433dce99 movss    xmm2, dword ptr [esp + 0xbc]
433dcea2 lea      edi, [esp + 0xd4]
433dcea9 movss    xmm1, dword ptr [esp + 0xc0]
433dceb2 movsd    dword ptr es:[edi], dword ptr [esi]
433dceb3 movsd    dword ptr es:[edi], dword ptr [esi]
433dceb4 movsd    dword ptr es:[edi], dword ptr [esi]
433dceb5 movss    xmm0, dword ptr [esp + 0xdc]
433dcebe lea      edi, [esp + 0x84]
433dcec5 subss    xmm0, dword ptr [ecx + 0xdc]
433dcecd mov      esi, eax
433dcecf mov      eax, dword ptr [ecx]
433dced1 movsd    dword ptr es:[edi], dword ptr [esi]
433dced2 movss    dword ptr [esp + 0x38], xmm0
433dced8 movss    xmm0, dword ptr [esp + 0xc4]
433dcee1 addss    xmm0, dword ptr [0x4347259c]
433dcee9 movsd    dword ptr es:[edi], dword ptr [esi]
433dceea movsd    dword ptr es:[edi], dword ptr [esi]
433dceeb subss    xmm1, dword ptr [esp + 0x88]
433dcef4 subss    xmm2, dword ptr [esp + 0x84]
433dcefd subss    xmm0, dword ptr [esp + 0x8c]
433dcf06 mov      dword ptr [esp + 0x564], edx
433dcf0d mov      edx, dword ptr [0x43468304]
433dcf13 mov      dword ptr [esp + 0x55c], eax
433dcf1a mov      dword ptr [esp + 0x558], 0x4346edc0
433dcf25 mov      dword ptr [esp + 0x560], 8
433dcf30 mov      eax, dword ptr [edx]
433dcf32 mov      edi, dword ptr [ecx + 0xd0]
433dcf38 mov      esi, dword ptr [eax + 0x14]
433dcf3b and      dword ptr [esp + 0xb50], 0
433dcf43 movss    dword ptr [esp + 0xb24], xmm1
433dcf4c movss    dword ptr [esp + 0xb20], xmm2
433dcf55 mulss    xmm1, xmm1
433dcf59 mov      byte ptr [esp + 0xb55], 1
433dcf61 mulss    xmm2, xmm2
433dcf65 movss    dword ptr [esp + 0xb28], xmm0
433dcf6e mulss    xmm0, xmm0
433dcf72 addss    xmm1, xmm2
433dcf76 addss    xmm1, xmm0
433dcf7a ucomiss  xmm1, dword ptr [esp + 0x18]
433dcf7f lahf     
433dcf80 test     ah, 0x44
433dcf83 jp       0x433dcf8d
433dcf85 mov      byte ptr [esp + 0xb55], 0
433dcf8d movss    xmm3, dword ptr [ecx + 0x44]
433dcf92 lea      eax, [esp + 0x658]
433dcf99 movss    xmm4, dword ptr [ecx + 0x48]
433dcf9e movaps   xmm2, xmm3
433dcfa1 movss    xmm6, dword ptr [ecx + 0x38]
433dcfa6 movaps   xmm1, xmm4
433dcfa9 movss    xmm7, dword ptr [ecx + 0x3c]
433dcfae subss    xmm2, xmm6
433dcfb2 movss    xmm0, dword ptr [ecx + 0x40]
433dcfb7 subss    xmm1, xmm7
433dcfbb movss    xmm5, dword ptr [ecx + 0x4c]
433dcfc0 addss    xmm6, xmm3
433dcfc4 movss    dword ptr [esp + 0x1c], xmm0
433dcfca addss    xmm7, xmm4
433dcfce movaps   xmm0, xmm5
433dcfd1 mov      ecx, edx
433dcfd3 subss    xmm0, dword ptr [esp + 0x1c]
433dcfd9 mulss    xmm1, dword ptr [0x43472240]
433dcfe1 push     eax
433dcfe2 mulss    xmm2, dword ptr [0x43472240]
433dcfea lea      eax, [esp + 0x55c]
433dcff1 push     eax
433dcff2 mulss    xmm0, dword ptr [0x43472240]
433dcffa lea      eax, [esp + 0xb18]
433dd001 push     edi
433dd002 movss    dword ptr [esp + 0xb50], xmm1
433dd00b mulss    xmm1, xmm1
433dd00f push     eax
433dd010 movss    dword ptr [esp + 0xb58], xmm0
433dd019 mulss    xmm0, xmm0
433dd01d movss    dword ptr [esp + 0xb50], xmm2
433dd026 mulss    xmm2, xmm2
433dd02a addss    xmm1, xmm2
433dd02e addss    xmm1, xmm0
433dd032 cvtps2pd xmm0, xmm1
433dd035 movsd    xmm1, qword ptr [esp + 0xa0]
433dd03e comisd   xmm1, xmm0
433dd042 movss    xmm0, dword ptr [0x43472240]
433dd04a movss    xmm1, dword ptr [esp + 0x2c]
433dd050 mulss    xmm6, xmm0
433dd054 addss    xmm1, xmm5
433dd058 mulss    xmm7, xmm0
433dd05c seta     byte ptr [esp + 0xb64]
433dd064 mulss    xmm1, xmm0
433dd068 movaps   xmm0, xmm6
433dd06b addss    xmm0, dword ptr [esp + 0x94]
433dd074 movss    dword ptr [esp + 0xb20], xmm0
433dd07d movaps   xmm0, xmm7
433dd080 addss    xmm0, dword ptr [esp + 0x98]
433dd089 movss    dword ptr [esp + 0xb24], xmm0
433dd092 movaps   xmm0, xmm1
433dd095 addss    xmm0, dword ptr [esp + 0x9c]
433dd09e movss    dword ptr [esp + 0xb28], xmm0
433dd0a7 movss    xmm0, dword ptr [0x4346f858]
433dd0af mulss    xmm6, xmm0
433dd0b3 mulss    xmm7, xmm0
433dd0b7 mulss    xmm1, xmm0
433dd0bb movss    dword ptr [esp + 0xb40], xmm6
433dd0c4 movss    dword ptr [esp + 0xb44], xmm7
433dd0cd movss    dword ptr [esp + 0xb48], xmm1
433dd0d6 call     esi
433dd0d8 mov      ecx, dword ptr [esp + 0x20]
433dd0dc mov      edx, dword ptr [0x43468304]
433dd0e2 movss    xmm1, dword ptr [esp + 0xd4]
433dd0eb movss    xmm0, dword ptr [esp + 0xd8]
433dd0f4 mov      eax, dword ptr [ecx]
433dd0f6 and      dword ptr [esp + 0x574], 0
433dd0fe movss    xmm2, dword ptr [esp + 0x38]
433dd104 subss    xmm1, dword ptr [esp + 0x664]
433dd10d subss    xmm0, dword ptr [esp + 0x668]
433dd116 subss    xmm2, dword ptr [esp + 0x66c]
433dd11f mov      dword ptr [esp + 0x568], 0x4346edc0
433dd12a mov      dword ptr [esp + 0x56c], eax
433dd131 mov      dword ptr [esp + 0x570], 8
433dd13c mov      eax, dword ptr [edx]
433dd13e mov      edi, dword ptr [ecx + 0xd0]
433dd144 mov      esi, dword ptr [eax + 0x14]
433dd147 and      dword ptr [esp + 0xa10], 0
433dd14f movss    dword ptr [esp + 0x9e0], xmm1
433dd158 movss    dword ptr [esp + 0x9e4], xmm0
433dd161 movss    dword ptr [esp + 0x9e8], xmm2
433dd16a mulss    xmm0, xmm0
433dd16e mov      byte ptr [esp + 0xa15], 1
433dd176 mulss    xmm1, xmm1
433dd17a mulss    xmm2, xmm2
433dd17e addss    xmm0, xmm1
433dd182 addss    xmm0, xmm2
433dd186 ucomiss  xmm0, dword ptr [esp + 0x18]
433dd18b lahf     
433dd18c test     ah, 0x44
433dd18f jp       0x433dd199
433dd191 mov      byte ptr [esp + 0xa15], 0
433dd199 movss    xmm3, dword ptr [ecx + 0x44]
433dd19e lea      eax, [esp + 0x658]
433dd1a5 movss    xmm4, dword ptr [ecx + 0x48]
433dd1aa movaps   xmm2, xmm3
433dd1ad movss    xmm6, dword ptr [ecx + 0x38]
433dd1b2 movaps   xmm1, xmm4
433dd1b5 movss    xmm7, dword ptr [ecx + 0x3c]
433dd1ba subss    xmm2, xmm6
433dd1be movss    xmm0, dword ptr [ecx + 0x40]
433dd1c3 subss    xmm1, xmm7
433dd1c7 movss    xmm5, dword ptr [ecx + 0x4c]
433dd1cc addss    xmm6, xmm3
433dd1d0 movss    dword ptr [esp + 0x1c], xmm0
433dd1d6 addss    xmm7, xmm4
433dd1da movaps   xmm0, xmm5
433dd1dd mov      ecx, edx
433dd1df subss    xmm0, dword ptr [esp + 0x1c]
433dd1e5 mulss    xmm1, dword ptr [0x43472240]
433dd1ed push     eax
433dd1ee mulss    xmm2, dword ptr [0x43472240]
433dd1f6 lea      eax, [esp + 0x56c]
433dd1fd push     eax
433dd1fe mulss    xmm0, dword ptr [0x43472240]
433dd206 lea      eax, [esp + 0x9d8]
433dd20d push     edi
433dd20e movss    dword ptr [esp + 0xa10], xmm1
433dd217 mulss    xmm1, xmm1
433dd21b push     eax
433dd21c movss    dword ptr [esp + 0xa18], xmm0
433dd225 mulss    xmm0, xmm0
433dd229 movss    dword ptr [esp + 0xa10], xmm2
433dd232 mulss    xmm2, xmm2
433dd236 addss    xmm1, xmm2
433dd23a addss    xmm1, xmm0
433dd23e cvtps2pd xmm0, xmm1
433dd241 movsd    xmm1, qword ptr [esp + 0xa0]
433dd24a comisd   xmm1, xmm0
433dd24e movss    xmm0, dword ptr [0x43472240]
433dd256 movss    xmm1, dword ptr [esp + 0x2c]
433dd25c mulss    xmm6, xmm0
433dd260 addss    xmm1, xmm5
433dd264 mulss    xmm7, xmm0
433dd268 seta     byte ptr [esp + 0xa24]
433dd270 mulss    xmm1, xmm0
433dd274 movaps   xmm0, xmm6
433dd277 addss    xmm0, dword ptr [esp + 0x674]
433dd280 movss    dword ptr [esp + 0x9e0], xmm0
433dd289 movss    xmm0, dword ptr [esp + 0x678]
433dd292 addss    xmm0, xmm7
433dd296 movss    dword ptr [esp + 0x9e4], xmm0
433dd29f movss    xmm0, dword ptr [esp + 0x67c]
433dd2a8 addss    xmm0, xmm1
433dd2ac movss    dword ptr [esp + 0x9e8], xmm0
433dd2b5 movss    xmm0, dword ptr [0x4346f858]
433dd2bd mulss    xmm6, xmm0
433dd2c1 mulss    xmm7, xmm0
433dd2c5 mulss    xmm1, xmm0
433dd2c9 movss    dword ptr [esp + 0xa00], xmm6
433dd2d2 movss    dword ptr [esp + 0xa04], xmm7
433dd2db movss    dword ptr [esp + 0xa08], xmm1
433dd2e4 call     esi
433dd2e6 movss    xmm1, dword ptr [esp + 0x684]
433dd2ef movss    xmm7, dword ptr [esp + 0x18]
433dd2f5 comiss   xmm1, xmm7
433dd2f8 jbe      0x433dd358
433dd2fa movss    xmm0, dword ptr [0x43470514]
433dd302 comiss   xmm0, xmm1
433dd305 jbe      0x433dd358
433dd307 cmp      byte ptr [esp + 0x68f], 0
433dd30f mov      ecx, dword ptr [esp + 0x20]
433dd313 jne      0x433dd35c
433dd315 movss    xmm0, dword ptr [esp + 0x678]
433dd31e cvtps2pd xmm0, xmm0
433dd321 comisd   xmm0, xmmword ptr [0x4346fe68]
433dd329 jb       0x433dd35c
433dd32b movss    xmm0, dword ptr [ecx + 0xc]
433dd330 subss    xmm0, dword ptr [esp + 0x66c]
433dd339 andps    xmm0, xmmword ptr [0x43470340]
433dd340 comiss   xmm0, dword ptr [0x4346f468]
433dd347 jbe      0x433dd35c
433dd349 lea      esi, [esp + 0x664]
433dd350 lea      edi, [ecx + 4]
433dd353 movsd    dword ptr es:[edi], dword ptr [esi]
433dd354 movsd    dword ptr es:[edi], dword ptr [esi]
433dd355 movsd    dword ptr es:[edi], dword ptr [esi]
433dd356 jmp      0x433dd35c
433dd358 mov      ecx, dword ptr [esp + 0x20]
433dd35c or       byte ptr [ecx + 0x108], 0x40
433dd363 jmp      0x433de269
433dd368 mov      esi, dword ptr [ebp + 0xc]
433dd36b lea      eax, [esp + 0x134]
433dd372 push     0
433dd374 push     eax
433dd375 lea      edx, [esp + 0xe8]
433dd37c lea      ecx, [esi + 0xc]
433dd37f call     0x43366128
433dd384 movss    xmm1, dword ptr [esp + 0xe0]
433dd38d movss    xmm0, dword ptr [esp + 0xe4]
433dd396 movss    xmm7, dword ptr [esp + 0x18]
433dd39c mulss    xmm0, xmm0
433dd3a0 mulss    xmm1, xmm1
433dd3a4 movss    xmm3, dword ptr [0x43470514]
433dd3ac movaps   xmm5, xmm3
433dd3af movss    dword ptr [esp + 0x13c], xmm7
433dd3b8 addss    xmm1, xmm0
433dd3bc movaps   xmm0, xmm7
433dd3bf mulss    xmm0, xmm7
433dd3c3 addss    xmm1, xmm0
433dd3c7 movaps   xmm0, xmm1
433dd3ca movss    xmm1, dword ptr [esp + 0x134]
433dd3d3 sqrtss   xmm0, xmm0
433dd3d7 mulss    xmm1, xmm1
433dd3db addss    xmm0, dword ptr [0x43472108]
433dd3e3 divss    xmm5, xmm0
433dd3e7 movss    xmm0, dword ptr [esp + 0x138]
433dd3f0 mulss    xmm0, xmm0
433dd3f4 movaps   xmm2, xmm5
433dd3f7 mulss    xmm2, dword ptr [esp + 0xe0]
433dd400 movaps   xmm4, xmm5
433dd403 addss    xmm1, xmm0
433dd407 mulss    xmm4, dword ptr [esp + 0xe4]
433dd410 movaps   xmm0, xmm7
433dd413 mulss    xmm5, xmm7
433dd417 mulss    xmm0, xmm7
433dd41b movss    dword ptr [esp + 0xe0], xmm2
433dd424 movss    dword ptr [esp + 0xe4], xmm4
433dd42d addss    xmm1, xmm0
433dd431 movss    dword ptr [esp + 0xe8], xmm5
433dd43a movaps   xmm0, xmm1
433dd43d sqrtss   xmm0, xmm0
433dd441 addss    xmm0, dword ptr [0x43472108]
433dd449 divss    xmm3, xmm0
433dd44d movss    xmm0, dword ptr [esi + 0x24]
433dd452 movaps   xmm6, xmm0
433dd455 mulss    xmm6, xmm2
433dd459 movaps   xmm2, xmm0
433dd45c mulss    xmm0, xmm5
433dd460 mulss    xmm2, xmm4
433dd464 movaps   xmm4, xmm3
433dd467 mulss    xmm4, dword ptr [esp + 0x138]
433dd470 movss    dword ptr [esp + 0xe8], xmm0
433dd479 movaps   xmm0, xmm3
433dd47c mulss    xmm0, dword ptr [esp + 0x134]
433dd485 movss    dword ptr [esp + 0xe4], xmm2
433dd48e movss    dword ptr [esp + 0xe0], xmm6
433dd497 movss    xmm1, dword ptr [esi + 0x28]
433dd49c mulss    xmm0, xmm1
433dd4a0 mulss    xmm4, xmm1
433dd4a4 addss    xmm6, xmm0
433dd4a8 movss    dword ptr [esp + 0x134], xmm0
433dd4b1 mulss    xmm3, xmm7
433dd4b5 movss    dword ptr [esp + 0x138], xmm4
433dd4be addss    xmm4, xmm2
433dd4c2 mulss    xmm3, xmm1
433dd4c6 movaps   xmm1, xmm6
433dd4c9 mulss    xmm1, xmm6
433dd4cd movaps   xmm0, xmm4
433dd4d0 movss    dword ptr [esp + 0x13c], xmm3
433dd4d9 mulss    xmm0, xmm4
433dd4dd addss    xmm1, xmm0
433dd4e1 movaps   xmm0, xmm7
433dd4e4 mulss    xmm0, xmm7
433dd4e8 addss    xmm1, xmm0
433dd4ec movaps   xmm2, xmm1
433dd4ef movss    xmm1, dword ptr [0x43470514]
433dd4f7 sqrtss   xmm2, xmm2
433dd4fb movaps   xmm0, xmm2
433dd4fe addss    xmm0, dword ptr [0x43472108]
433dd506 movups   xmmword ptr [esp + 0x310], xmm2
433dd50e divss    xmm1, xmm0
433dd512 movaps   xmm0, xmm1
433dd515 mulss    xmm0, xmm6
433dd519 ucomiss  xmm2, xmm7
433dd51c movss    dword ptr [esp + 0x1c], xmm0
433dd522 movaps   xmm0, xmm1
433dd525 mulss    xmm0, xmm4
433dd529 mulss    xmm1, xmm7
433dd52d lahf     
433dd52e movss    dword ptr [esp + 0x48], xmm0
433dd534 movss    dword ptr [esp + 0x30], xmm1
433dd53a test     ah, 0x44
433dd53d jnp      0x433dd55a
433dd53f mov      ecx, dword ptr [esp + 0x20]
433dd543 movss    xmm0, dword ptr [ecx + 0x10c]
433dd54b minss    xmm0, xmm2
433dd54f movaps   xmm2, xmm0
433dd552 movups   xmmword ptr [esp + 0x310], xmm2
433dd55a movss    xmm0, dword ptr [0x4346ee8c]
433dd562 movaps   xmm1, xmm2
433dd565 call     0x43367633
433dd56a mov      ecx, dword ptr [esp + 0x20]
433dd56e movaps   xmm2, xmm0
433dd571 movss    xmm0, dword ptr [esp + 0x1c]
433dd577 movss    xmm7, dword ptr [esp + 0x18]
433dd57d lea      edx, [ecx + 0x10]
433dd580 movss    xmm1, dword ptr [edx + 4]
433dd585 mulss    xmm0, dword ptr [edx]
433dd589 mov      dword ptr [esp + 0x40], edx
433dd58d mulss    xmm1, dword ptr [esp + 0x48]
433dd593 addss    xmm1, xmm0
433dd597 movss    xmm0, dword ptr [edx + 8]
433dd59c mulss    xmm0, dword ptr [esp + 0x30]
433dd5a2 addss    xmm1, xmm0
433dd5a6 subss    xmm2, xmm1
433dd5aa comiss   xmm7, xmm2
433dd5ad jae      0x433dd61a
433dd5af movss    xmm1, dword ptr [ecx + 0xfc]
433dd5b7 movaps   xmm0, xmm2
433dd5ba mulss    xmm1, dword ptr [esp + 0x310]
433dd5c3 mulss    xmm1, dword ptr [ecx + 0x100]
433dd5cb mulss    xmm1, dword ptr [ecx + 0xc8]
433dd5d3 call     0x43367633
433dd5d8 mov      edx, dword ptr [esp + 0x40]
433dd5dc movaps   xmm1, xmm0
433dd5df mulss    xmm1, dword ptr [esp + 0x1c]
433dd5e5 mov      ecx, dword ptr [esp + 0x20]
433dd5e9 movss    xmm7, dword ptr [esp + 0x18]
433dd5ef addss    xmm1, dword ptr [edx]
433dd5f3 movss    dword ptr [edx], xmm1
433dd5f7 movaps   xmm1, xmm0
433dd5fa mulss    xmm1, dword ptr [esp + 0x48]
433dd600 mulss    xmm0, dword ptr [esp + 0x30]
433dd606 addss    xmm1, dword ptr [edx + 4]
433dd60b movss    dword ptr [edx + 4], xmm1
433dd610 addss    xmm0, dword ptr [edx + 8]
433dd615 movss    dword ptr [edx + 8], xmm0
433dd61a mov      esi, edx
433dd61c movss    xmm0, dword ptr [ecx + 0x100]
433dd624 lea      edi, [esp + 0xd4]
433dd62b and      dword ptr [esp + 0x3c], 0
433dd630 xor      eax, eax
433dd632 movss    dword ptr [esp + 0x54], xmm0
433dd638 and      dword ptr [esp + 0x48], 0
433dd63d movsd    dword ptr es:[edi], dword ptr [esi]
433dd63e movss    dword ptr [esp + 0x34], xmm7
433dd644 movsd    dword ptr es:[edi], dword ptr [esi]
433dd645 movsd    dword ptr es:[edi], dword ptr [esi]
433dd646 mov      esi, edx
433dd648 lea      edi, [esp + 0xa4]
433dd64f movsd    dword ptr es:[edi], dword ptr [esi]
433dd650 movsd    dword ptr es:[edi], dword ptr [esi]
433dd651 movsd    dword ptr es:[edi], dword ptr [esi]
433dd652 movss    xmm2, dword ptr [esp + 0xa8]
433dd65b lea      edi, [esp + 0x290]
433dd662 movss    xmm0, dword ptr [esp + 0xac]
433dd66b lea      esi, [esp + 0x290]
433dd672 stosd    dword ptr es:[edi], eax
433dd673 movss    dword ptr [esp + 0x80], xmm2
433dd67c movss    xmm2, dword ptr [esp + 0xa4]
433dd685 movss    dword ptr [esp + 0x2c], xmm2
433dd68b stosd    dword ptr es:[edi], eax
433dd68c stosd    dword ptr es:[edi], eax
433dd68d lea      edi, [esp + 0x84]
433dd694 movsd    dword ptr es:[edi], dword ptr [esi]
433dd695 movsd    dword ptr es:[edi], dword ptr [esi]
433dd696 movsd    dword ptr es:[edi], dword ptr [esi]
433dd697 movaps   xmmword ptr [esp + 0x290], xmm0
433dd69f movss    xmm5, dword ptr [edx + 4]
433dd6a4 movss    xmm6, dword ptr [edx]
433dd6a8 movaps   xmm0, xmm5
433dd6ab movss    xmm2, dword ptr [edx + 8]
433dd6b0 movaps   xmm1, xmm6
433dd6b3 mulss    xmm0, xmm5
433dd6b7 mulss    xmm1, xmm6
433dd6bb movss    dword ptr [esp + 0x38], xmm2
433dd6c1 addss    xmm1, xmm0
433dd6c5 movaps   xmm0, xmm2
433dd6c8 mulss    xmm0, xmm2
433dd6cc addss    xmm1, xmm0
433dd6d0 ucomiss  xmm1, xmm7
433dd6d3 lahf     
433dd6d4 test     ah, 0x44
433dd6d7 jnp      0x433de242
433dd6dd movss    xmm0, dword ptr [ecx + 4]
433dd6e2 lea      esi, [ecx + 4]
433dd6e5 movss    xmm2, dword ptr [esp + 0x54]
433dd6eb lea      edi, [esp + 0xb0]
433dd6f2 movss    xmm3, dword ptr [ecx + 8]
433dd6f7 movsd    dword ptr es:[edi], dword ptr [esi]
433dd6f8 movss    xmm4, dword ptr [ecx + 0xc]
433dd6fd mov      eax, dword ptr [ecx]
433dd6ff mov      edx, dword ptr [0x43468304]
433dd705 movsd    dword ptr es:[edi], dword ptr [esi]
433dd706 mulss    xmm2, xmm6
433dd70a movsd    dword ptr es:[edi], dword ptr [esi]
433dd70b and      dword ptr [esp + 0x4a4], 0
433dd713 addss    xmm2, xmm0
433dd717 movss    xmm0, dword ptr [esp + 0xb0]
433dd720 movss    dword ptr [esp + 0x64], xmm0
433dd726 mov      dword ptr [esp + 0x49c], eax
433dd72d mov      dword ptr [esp + 0x498], 0x4346edc0
433dd738 subss    xmm2, xmm0
433dd73c mov      dword ptr [esp + 0x4a0], 8
433dd747 movss    xmm0, dword ptr [esp + 0x54]
433dd74d mov      eax, dword ptr [edx]
433dd74f movaps   xmm1, xmm0
433dd752 mulss    xmm0, dword ptr [esp + 0x38]
433dd758 mov      edi, dword ptr [ecx + 0xd0]
433dd75e mulss    xmm1, xmm5
433dd762 mov      esi, dword ptr [eax + 0x14]
433dd765 and      dword ptr [esp + 0xa60], 0
433dd76d addss    xmm0, xmm4
433dd771 movss    dword ptr [esp + 0xa30], xmm2
433dd77a addss    xmm1, xmm3
433dd77e mulss    xmm2, xmm2
433dd782 mov      byte ptr [esp + 0xa65], 1
433dd78a subss    xmm0, dword ptr [esp + 0xb8]
433dd793 subss    xmm1, dword ptr [esp + 0xb4]
433dd79c movss    dword ptr [esp + 0xa38], xmm0
433dd7a5 mulss    xmm0, xmm0
433dd7a9 movss    dword ptr [esp + 0xa34], xmm1
433dd7b2 mulss    xmm1, xmm1
433dd7b6 addss    xmm1, xmm2
433dd7ba addss    xmm1, xmm0
433dd7be ucomiss  xmm1, xmm7
433dd7c1 lahf     
433dd7c2 test     ah, 0x44
433dd7c5 jp       0x433dd7cf
433dd7c7 mov      byte ptr [esp + 0xa65], 0
433dd7cf movss    xmm3, dword ptr [ecx + 0x44]
433dd7d4 lea      eax, [ecx + 0x6c]
433dd7d7 movss    xmm4, dword ptr [ecx + 0x48]
433dd7dc movaps   xmm2, xmm3
433dd7df movss    xmm0, dword ptr [ecx + 0x38]
433dd7e4 movaps   xmm1, xmm4
433dd7e7 movss    xmm7, dword ptr [ecx + 0x3c]
433dd7ec subss    xmm2, xmm0
433dd7f0 movss    xmm5, dword ptr [ecx + 0x4c]
433dd7f5 subss    xmm1, xmm7
433dd7f9 movss    xmm6, dword ptr [ecx + 0x40]
433dd7fe addss    xmm7, xmm4
433dd802 movss    dword ptr [esp + 0x38], xmm0
433dd808 mov      ecx, edx
433dd80a movaps   xmm0, xmm5
433dd80d mulss    xmm2, dword ptr [0x43472240]
433dd815 subss    xmm0, xmm6
433dd819 push     eax
433dd81a mulss    xmm1, dword ptr [0x43472240]
433dd822 addss    xmm6, xmm5
433dd826 lea      eax, [esp + 0x49c]
433dd82d movss    dword ptr [esp + 0xa54], xmm2
433dd836 mulss    xmm0, dword ptr [0x43472240]
433dd83e push     eax
433dd83f movss    dword ptr [esp + 0xa5c], xmm1
433dd848 lea      eax, [esp + 0xa28]
433dd84f mulss    xmm1, xmm1
433dd853 push     edi
433dd854 movss    dword ptr [esp + 0xa64], xmm0
433dd85d mulss    xmm0, xmm0
433dd861 push     eax
433dd862 mulss    xmm2, xmm2
433dd866 addss    xmm1, xmm2
433dd86a addss    xmm1, xmm0
433dd86e cvtps2pd xmm0, xmm1
433dd871 movsd    xmm1, qword ptr [esp + 0xa0]
433dd87a comisd   xmm1, xmm0
433dd87e movss    xmm1, dword ptr [esp + 0x48]
433dd884 movss    xmm0, dword ptr [0x43472240]
433dd88c addss    xmm1, xmm3
433dd890 mulss    xmm7, xmm0
433dd894 seta     byte ptr [esp + 0xa74]
433dd89c mulss    xmm6, xmm0
433dd8a0 mulss    xmm1, xmm0
433dd8a4 movss    xmm0, dword ptr [esp + 0x74]
433dd8aa addss    xmm0, xmm1
433dd8ae movss    dword ptr [esp + 0xa30], xmm0
433dd8b7 movaps   xmm0, xmm7
433dd8ba addss    xmm0, dword ptr [esp + 0xc4]
433dd8c3 movss    dword ptr [esp + 0xa34], xmm0
433dd8cc movaps   xmm0, xmm6
433dd8cf addss    xmm0, dword ptr [esp + 0xc8]
433dd8d8 movss    dword ptr [esp + 0xa38], xmm0
433dd8e1 movss    xmm0, dword ptr [0x4346f858]
433dd8e9 mulss    xmm1, xmm0
433dd8ed mulss    xmm7, xmm0
433dd8f1 mulss    xmm6, xmm0
433dd8f5 movss    dword ptr [esp + 0xa50], xmm1
433dd8fe movss    dword ptr [esp + 0xa54], xmm7
433dd907 movss    dword ptr [esp + 0xa58], xmm6
433dd910 call     esi
433dd912 mov      ecx, dword ptr [esp + 0x20]
433dd916 movss    xmm7, dword ptr [esp + 0x18]
433dd91c movss    xmm0, dword ptr [ecx + 0x98]
433dd924 comiss   xmm0, xmm7
433dd927 movaps   xmm1, xmm0
433dd92a movaps   xmm3, xmm0
433dd92d jbe      0x433dd949
433dd92f movss    xmm2, dword ptr [0x434723ec]
433dd937 comiss   xmm2, xmm0
433dd93a jbe      0x433dd949
433dd93c and      dword ptr [ecx + 0x98], 0
433dd943 movaps   xmm1, xmm7
433dd946 movaps   xmm3, xmm7
433dd949 cmp      byte ptr [ecx + 0xa2], 0
433dd950 movaps   xmm0, xmm1
433dd953 addss    xmm0, dword ptr [esp + 0x34]
433dd959 movss    dword ptr [esp + 0x34], xmm0
433dd95f jne      0x433de227
433dd965 comiss   xmm1, xmm7
433dd968 jbe      0x433ddc53
433dd96e ucomiss  xmm1, dword ptr [0x43470514]
433dd975 lahf     
433dd976 test     ah, 0x44
433dd979 jp       0x433ddbf6
433dd97f or       dword ptr [esp + 0xc6c], 0xffffffff
433dd987 lea      esi, [ecx + 0x78]
433dd98a or       dword ptr [esp + 0xc78], 0xffffffff
433dd992 lea      edi, [esp + 0xbc]
433dd999 mov      dword ptr [esp + 0xc54], 0x3f800000
433dd9a4 xor      edx, edx
433dd9a6 mov      word ptr [esp + 0xc5e], dx
433dd9ae mov      dword ptr [esp + 0xc74], edx
433dd9b5 movsd    dword ptr es:[edi], dword ptr [esi]
433dd9b6 mov      eax, dword ptr [ecx]
433dd9b8 movsd    dword ptr es:[edi], dword ptr [esi]
433dd9b9 movsd    dword ptr es:[edi], dword ptr [esi]
433dd9ba movss    xmm2, dword ptr [esp + 0xbc]
433dd9c3 lea      esi, [ecx + 0x78]
433dd9c6 movss    xmm1, dword ptr [esp + 0xc0]
433dd9cf lea      edi, [esp + 0x68]
433dd9d3 movsd    dword ptr es:[edi], dword ptr [esi]
433dd9d4 movsd    dword ptr es:[edi], dword ptr [esi]
433dd9d5 movsd    dword ptr es:[edi], dword ptr [esi]
433dd9d6 movss    xmm0, dword ptr [esp + 0x68]
433dd9dc subss    xmm1, dword ptr [esp + 0x6c]
433dd9e2 mov      dword ptr [esp + 0x4b4], edx
433dd9e9 subss    xmm2, xmm0
433dd9ed mov      edx, dword ptr [0x43468304]
433dd9f3 mov      dword ptr [esp + 0x4ac], eax
433dd9fa mov      dword ptr [esp + 0x4a8], 0x4346edc0
433dda05 mov      dword ptr [esp + 0x4b0], 8
433dda10 mov      eax, dword ptr [edx]
433dda12 mov      edi, dword ptr [ecx + 0xd0]
433dda18 movss    dword ptr [esp + 0x64], xmm0
433dda1e movss    xmm0, dword ptr [esp + 0xc4]
433dda27 mov      esi, dword ptr [eax + 0x14]
433dda2a subss    xmm0, dword ptr [esp + 0x70]
433dda30 and      dword ptr [esp + 0xab0], 0
433dda38 movss    dword ptr [esp + 0xa84], xmm1
433dda41 movss    dword ptr [esp + 0xa80], xmm2
433dda4a mulss    xmm1, xmm1
433dda4e mov      byte ptr [esp + 0xab5], 1
433dda56 mulss    xmm2, xmm2
433dda5a movss    dword ptr [esp + 0xa88], xmm0
433dda63 mulss    xmm0, xmm0
433dda67 addss    xmm1, xmm2
433dda6b addss    xmm1, xmm0
433dda6f ucomiss  xmm1, xmm7
433dda72 lahf     
433dda73 test     ah, 0x44
433dda76 jp       0x433dda80
433dda78 mov      byte ptr [esp + 0xab5], 0
433dda80 movss    xmm3, dword ptr [ecx + 0x44]
433dda85 lea      eax, [esp + 0xc28]
433dda8c movss    xmm4, dword ptr [ecx + 0x48]
433dda91 movaps   xmm2, xmm3
433dda94 movss    xmm0, dword ptr [ecx + 0x38]
433dda99 movaps   xmm1, xmm4
433dda9c movss    xmm7, dword ptr [ecx + 0x3c]
433ddaa1 subss    xmm2, xmm0
433ddaa5 movss    xmm5, dword ptr [ecx + 0x4c]
433ddaaa subss    xmm1, xmm7
433ddaae movss    xmm6, dword ptr [ecx + 0x40]
433ddab3 addss    xmm7, xmm4
433ddab7 movss    dword ptr [esp + 0x38], xmm0
433ddabd mov      ecx, edx
433ddabf movaps   xmm0, xmm5
433ddac2 mulss    xmm2, dword ptr [0x43472240]
433ddaca subss    xmm0, xmm6
433ddace push     eax
433ddacf mulss    xmm1, dword ptr [0x43472240]
433ddad7 addss    xmm6, xmm5
433ddadb lea      eax, [esp + 0x4ac]
433ddae2 movss    dword ptr [esp + 0xaa4], xmm2
433ddaeb mulss    xmm0, dword ptr [0x43472240]
433ddaf3 push     eax
433ddaf4 movss    dword ptr [esp + 0xaac], xmm1
433ddafd lea      eax, [esp + 0xa78]
433ddb04 mulss    xmm1, xmm1
433ddb08 push     edi
433ddb09 movss    dword ptr [esp + 0xab4], xmm0
433ddb12 mulss    xmm0, xmm0
433ddb16 push     eax
433ddb17 mulss    xmm2, xmm2
433ddb1b addss    xmm1, xmm2
433ddb1f addss    xmm1, xmm0
433ddb23 cvtps2pd xmm0, xmm1
433ddb26 movsd    xmm1, qword ptr [esp + 0xa0]
433ddb2f comisd   xmm1, xmm0
433ddb33 movss    xmm1, dword ptr [esp + 0x48]
433ddb39 movss    xmm0, dword ptr [0x43472240]
433ddb41 addss    xmm1, xmm3
433ddb45 mulss    xmm7, xmm0
433ddb49 seta     byte ptr [esp + 0xac4]
433ddb51 mulss    xmm6, xmm0
433ddb55 mulss    xmm1, xmm0
433ddb59 movss    xmm0, dword ptr [esp + 0x74]
433ddb5f addss    xmm0, xmm1
433ddb63 movss    dword ptr [esp + 0xa80], xmm0
433ddb6c movaps   xmm0, xmm7
433ddb6f addss    xmm0, dword ptr [esp + 0x7c]
433ddb75 movss    dword ptr [esp + 0xa84], xmm0
433ddb7e movaps   xmm0, xmm6
433ddb81 addss    xmm0, dword ptr [esp + 0x80]
433ddb8a movss    dword ptr [esp + 0xa88], xmm0
433ddb93 movss    xmm0, dword ptr [0x4346f858]
433ddb9b mulss    xmm1, xmm0
433ddb9f mulss    xmm7, xmm0
433ddba3 mulss    xmm6, xmm0
433ddba7 movss    dword ptr [esp + 0xaa0], xmm1
433ddbb0 movss    dword ptr [esp + 0xaa4], xmm7
433ddbb9 movss    dword ptr [esp + 0xaa8], xmm6
433ddbc2 call     esi
433ddbc4 cmp      byte ptr [esp + 0xc5f], 0
433ddbcc jne      0x433de217
433ddbd2 movss    xmm0, dword ptr [esp + 0xc54]
433ddbdb ucomiss  xmm0, dword ptr [0x43470514]
433ddbe2 lahf     
433ddbe3 test     ah, 0x44
433ddbe6 jp       0x433de217
433ddbec movss    xmm7, dword ptr [esp + 0x18]
433ddbf2 mov      ecx, dword ptr [esp + 0x20]
433ddbf6 lea      esi, [ecx + 0x78]
433ddbf9 lea      edi, [ecx + 4]
433ddbfc movsd    dword ptr es:[edi], dword ptr [esi]
433ddbfd lea      edx, [ecx + 0x10]
433ddc00 movsd    dword ptr es:[edi], dword ptr [esi]
433ddc01 movsd    dword ptr es:[edi], dword ptr [esi]
433ddc02 movss    xmm1, dword ptr [ecx + 0x98]
433ddc0a lea      edi, [esp + 0xa4]
433ddc11 mov      esi, edx
433ddc13 movaps   xmm3, xmm1
433ddc16 movsd    dword ptr es:[edi], dword ptr [esi]
433ddc17 movsd    dword ptr es:[edi], dword ptr [esi]
433ddc18 movsd    dword ptr es:[edi], dword ptr [esi]
433ddc19 movss    xmm4, dword ptr [esp + 0xac]
433ddc22 xor      edi, edi
433ddc24 movss    xmm2, dword ptr [esp + 0xa8]
433ddc2d movss    xmm5, dword ptr [esp + 0xa4]
433ddc36 mov      dword ptr [esp + 0x3c], edi
433ddc3a movaps   xmmword ptr [esp + 0x290], xmm4
433ddc42 movss    dword ptr [esp + 0x80], xmm2
433ddc4b movss    dword ptr [esp + 0x2c], xmm5
433ddc51 jmp      0x433ddc71
433ddc53 movaps   xmm4, xmmword ptr [esp + 0x290]
433ddc5b lea      edx, [ecx + 0x10]
433ddc5e movss    xmm2, dword ptr [esp + 0x80]
433ddc67 movss    xmm5, dword ptr [esp + 0x2c]
433ddc6d mov      edi, dword ptr [esp + 0x3c]
433ddc71 ucomiss  xmm1, dword ptr [0x43470514]
433ddc78 lahf     
433ddc79 test     ah, 0x44
433ddc7c jnp      0x433de242
433ddc82 movss    xmm0, dword ptr [ecx + 0x8c]
433ddc8a movss    xmm6, dword ptr [0x43470340]
433ddc92 movss    xmm7, dword ptr [0x434723ec]
433ddc9a andps    xmm0, xmm6
433ddc9d comiss   xmm7, xmm0
433ddca0 movss    xmm7, dword ptr [esp + 0x18]
433ddca6 jbe      0x433ddcb2
433ddca8 and      dword ptr [ecx + 0x8c], 0
433ddcaf movaps   xmm1, xmm3
433ddcb2 movss    xmm0, dword ptr [esp + 0x54]
433ddcb8 mulss    xmm1, xmm0
433ddcbc subss    xmm0, xmm1
433ddcc0 movss    dword ptr [esp + 0x54], xmm0
433ddcc6 cmp      edi, 5
433ddcc9 jge      0x433de22a
433ddccf imul     eax, edi, 0xc
433ddcd2 lea      esi, [ecx + 0x84]
433ddcd8 lea      edi, [esp + 0x5a4]
433ddcdf add      edi, eax
433ddce1 mov      eax, dword ptr [esp + 0x3c]
433ddce5 inc      eax
433ddce6 mov      dword ptr [esp + 0x3c], eax
433ddcea movsd    dword ptr es:[edi], dword ptr [esi]
433ddceb movsd    dword ptr es:[edi], dword ptr [esi]
433ddcec movsd    dword ptr es:[edi], dword ptr [esi]
433ddced cmp      eax, 1
433ddcf0 jne      0x433dded6
433ddcf6 cmp      byte ptr [ecx + 0xcc], 2
433ddcfd jne      0x433dded6
433ddd03 test     byte ptr [ecx + 0x1c], al
433ddd06 jne      0x433dded6
433ddd0c mov      ah, byte ptr [ecx + 0x108]
433ddd12 lea      esi, [esp + 0x5a4]
433ddd19 lea      edi, [esp + 0x58]
433ddd1d mov      al, ah
433ddd1f movsd    dword ptr es:[edi], dword ptr [esi]
433ddd20 or       al, 8
433ddd22 movsd    dword ptr es:[edi], dword ptr [esi]
433ddd23 movsd    dword ptr es:[edi], dword ptr [esi]
433ddd24 movss    xmm3, dword ptr [esp + 0x60]
433ddd2a lea      edi, [ecx + 0x60]
433ddd2d comiss   xmm3, dword ptr [0x4346fd8c]
433ddd34 mov      byte ptr [ecx + 0x108], al
433ddd3a lea      esi, [ecx + 4]
433ddd3d movsd    dword ptr es:[edi], dword ptr [esi]
433ddd3e movsd    dword ptr es:[edi], dword ptr [esi]
433ddd3f movsd    dword ptr es:[edi], dword ptr [esi]
433ddd40 jb       0x433ddd47
433ddd42 or       ah, 0xc
433ddd45 jmp      0x433ddd5d
433ddd47 movss    xmm1, dword ptr [0x43472980]
433ddd4f movaps   xmm0, xmm3
433ddd52 andps    xmm0, xmm6
433ddd55 comiss   xmm1, xmm0
433ddd58 jbe      0x433ddd6d
433ddd5a or       ah, 0xa
433ddd5d mov      byte ptr [ecx + 0x108], ah
433ddd63 lea      edi, [ecx + 0x50]
433ddd66 lea      esi, [esp + 0x58]
433ddd6a movsd    dword ptr es:[edi], dword ptr [esi]
433ddd6b movsd    dword ptr es:[edi], dword ptr [esi]
433ddd6c movsd    dword ptr es:[edi], dword ptr [esi]
433ddd6d movaps   xmm0, xmm2
433ddd70 movaps   xmm1, xmm5
433ddd73 mulss    xmm0, dword ptr [esp + 0x5c]
433ddd79 mulss    xmm1, dword ptr [esp + 0x58]
433ddd7f addss    xmm1, xmm0
433ddd83 movaps   xmm0, xmm3
433ddd86 mulss    xmm0, xmm4
433ddd8a addss    xmm1, xmm0
433ddd8e movaps   xmm0, xmm1
433ddd91 mulss    xmm0, dword ptr [esp + 0x58]
433ddd97 subss    xmm5, xmm0
433ddd9b movaps   xmm0, xmm1
433ddd9e mulss    xmm0, dword ptr [esp + 0x5c]
433ddda4 subss    xmm2, xmm0
433ddda8 movss    dword ptr [esp + 0x2c], xmm5
433dddae movaps   xmm0, xmm3
433dddb1 movss    dword ptr [esp + 0x84], xmm5
433dddba mulss    xmm0, xmm1
433dddbe movaps   xmm1, xmm3
433dddc1 movss    dword ptr [esp + 0x80], xmm2
433dddca subss    xmm4, xmm0
433dddce movss    dword ptr [esp + 0x88], xmm2
433dddd7 mulss    xmm2, dword ptr [esp + 0x5c]
433ddddd movaps   xmm0, xmm5
433ddde0 mulss    xmm0, dword ptr [esp + 0x58]
433ddde6 mulss    xmm1, xmm4
433dddea addss    xmm2, xmm0
433dddee movaps   xmmword ptr [esp + 0x290], xmm4
433dddf6 addss    xmm2, xmm1
433dddfa comiss   xmm2, xmm7
433dddfd jae      0x433dde6a
433dddff movss    xmm1, dword ptr [0x43471d88]
433dde07 movaps   xmm0, xmm2
433dde0a call     0x43367633
433dde0f movss    xmm2, dword ptr [esp + 0x2c]
433dde15 movaps   xmm1, xmm0
433dde18 mulss    xmm1, dword ptr [esp + 0x58]
433dde1e mov      ecx, dword ptr [esp + 0x20]
433dde22 movaps   xmm4, xmmword ptr [esp + 0x290]
433dde2a movss    xmm7, dword ptr [esp + 0x18]
433dde30 mov      edx, dword ptr [esp + 0x40]
433dde34 subss    xmm2, xmm1
433dde38 movaps   xmm1, xmm0
433dde3b mulss    xmm0, dword ptr [esp + 0x60]
433dde41 mulss    xmm1, dword ptr [esp + 0x5c]
433dde47 movss    dword ptr [esp + 0x84], xmm2
433dde50 subss    xmm4, xmm0
433dde54 movss    xmm2, dword ptr [esp + 0x80]
433dde5d subss    xmm2, xmm1
433dde61 movss    dword ptr [esp + 0x88], xmm2
433dde6a movq     xmm0, qword ptr [esp + 0x84]
433dde73 movq     qword ptr [edx], xmm0
433dde77 xorps    xmm0, xmm0
433dde7a movss    xmm0, xmm4
433dde7e movss    dword ptr [edx + 8], xmm0
433dde83 movq     xmm0, qword ptr [esp + 0x84]
433dde8c movq     qword ptr [esp + 0xa4], xmm0
433dde95 movaps   xmm0, xmm4
433dde98 movss    xmm2, dword ptr [esp + 0xa8]
433ddea1 xorps    xmm4, xmm4
433ddea4 movss    xmm4, xmm0
433ddea8 movss    dword ptr [esp + 0x80], xmm2
433ddeb1 movss    xmm2, dword ptr [esp + 0xa4]
433ddeba movaps   xmmword ptr [esp + 0x290], xmm4
433ddec2 movss    dword ptr [esp + 0xac], xmm4
433ddecb movss    dword ptr [esp + 0x2c], xmm2
433dded1 jmp      0x433de203
433dded6 xor      esi, esi
433dded8 mov      dword ptr [esp + 0x24], esi
433ddedc test     eax, eax
433ddede jle      0x433de0c8
433ddee4 lea      edi, [esp + 0x5a4]
433ddeeb mov      dword ptr [esp + 0x1c], edi
433ddeef mov      ah, byte ptr [ecx + 0x108]
433ddef5 mov      esi, edi
433ddef7 lea      edi, [esp + 0x98]
433ddefe mov      al, ah
433ddf00 or       al, 8
433ddf02 movsd    dword ptr es:[edi], dword ptr [esi]
433ddf03 movsd    dword ptr es:[edi], dword ptr [esi]
433ddf04 movsd    dword ptr es:[edi], dword ptr [esi]
433ddf05 movss    xmm6, dword ptr [esp + 0xa0]
433ddf0e lea      esi, [ecx + 4]
433ddf11 comiss   xmm6, dword ptr [0x4346fd8c]
433ddf18 mov      byte ptr [ecx + 0x108], al
433ddf1e lea      edi, [ecx + 0x60]
433ddf21 movsd    dword ptr es:[edi], dword ptr [esi]
433ddf22 movsd    dword ptr es:[edi], dword ptr [esi]
433ddf23 movsd    dword ptr es:[edi], dword ptr [esi]
433ddf24 jb       0x433ddf2b
433ddf26 or       ah, 0xc
433ddf29 jmp      0x433ddf45
433ddf2b movss    xmm1, dword ptr [0x43472980]
433ddf33 movaps   xmm0, xmm6
433ddf36 andps    xmm0, xmmword ptr [0x43470340]
433ddf3d comiss   xmm1, xmm0
433ddf40 jbe      0x433ddf58
433ddf42 or       ah, 0xa
433ddf45 mov      byte ptr [ecx + 0x108], ah
433ddf4b lea      edi, [ecx + 0x50]
433ddf4e lea      esi, [esp + 0x98]
433ddf55 movsd    dword ptr es:[edi], dword ptr [esi]
433ddf56 movsd    dword ptr es:[edi], dword ptr [esi]
433ddf57 movsd    dword ptr es:[edi], dword ptr [esi]
433ddf58 movaps   xmm0, xmm2
433ddf5b movaps   xmm3, xmm5
433ddf5e mulss    xmm0, dword ptr [esp + 0x9c]
433ddf67 mulss    xmm3, dword ptr [esp + 0x98]
433ddf70 addss    xmm3, xmm0
433ddf74 movaps   xmm0, xmm6
433ddf77 mulss    xmm0, xmm4
433ddf7b addss    xmm3, xmm0
433ddf7f movaps   xmm0, xmm5
433ddf82 movaps   xmm1, xmm3
433ddf85 mulss    xmm1, dword ptr [esp + 0x98]
433ddf8e subss    xmm0, xmm1
433ddf92 movaps   xmm1, xmm4
433ddf95 movss    dword ptr [edx], xmm0
433ddf99 movaps   xmm0, xmm3
433ddf9c mulss    xmm0, dword ptr [esp + 0x9c]
433ddfa5 mulss    xmm3, xmm6
433ddfa9 subss    xmm2, xmm0
433ddfad movss    xmm0, dword ptr [esp + 0x98]
433ddfb6 subss    xmm1, xmm3
433ddfba movss    dword ptr [edx + 4], xmm2
433ddfbf mulss    xmm2, dword ptr [esp + 0x9c]
433ddfc8 movss    dword ptr [edx + 8], xmm1
433ddfcd mulss    xmm0, dword ptr [edx]
433ddfd1 mulss    xmm1, xmm6
433ddfd5 addss    xmm0, xmm2
433ddfd9 addss    xmm0, xmm1
433ddfdd comiss   xmm0, xmm7
433ddfe0 jae      0x433de057
433ddfe2 movss    xmm1, dword ptr [0x43471d88]
433ddfea call     0x43367633
433ddfef mov      edx, dword ptr [esp + 0x40]
433ddff3 movaps   xmm3, xmm0
433ddff6 movaps   xmm2, xmm3
433ddff9 movss    xmm7, dword ptr [esp + 0x18]
433ddfff mulss    xmm2, dword ptr [esp + 0x98]
433de008 mov      ecx, dword ptr [esp + 0x20]
433de00c movss    xmm1, dword ptr [edx]
433de010 movaps   xmm4, xmmword ptr [esp + 0x290]
433de018 movss    xmm5, dword ptr [esp + 0x2c]
433de01e subss    xmm1, xmm2
433de022 movaps   xmm2, xmm3
433de025 mulss    xmm3, dword ptr [esp + 0xa0]
433de02e mulss    xmm2, dword ptr [esp + 0x9c]
433de037 movss    dword ptr [edx], xmm1
433de03b movss    xmm1, dword ptr [edx + 4]
433de040 subss    xmm1, xmm2
433de044 movss    dword ptr [edx + 4], xmm1
433de049 movss    xmm0, dword ptr [edx + 8]
433de04e subss    xmm0, xmm3
433de052 movss    dword ptr [edx + 8], xmm0
433de057 mov      eax, dword ptr [esp + 0x3c]
433de05b lea      edi, [esp + 0x5ac]
433de062 xor      esi, esi
433de064 cmp      esi, dword ptr [esp + 0x24]
433de068 je       0x433de093
433de06a movss    xmm0, dword ptr [edi - 8]
433de06f movss    xmm1, dword ptr [edi - 4]
433de074 mulss    xmm0, dword ptr [edx]
433de078 mulss    xmm1, dword ptr [edx + 4]
433de07d addss    xmm1, xmm0
433de081 movss    xmm0, dword ptr [edx + 8]
433de086 mulss    xmm0, dword ptr [edi]
433de08a addss    xmm1, xmm0
433de08e comiss   xmm1, xmm7
433de091 jb       0x433de09b
433de093 inc      esi
433de094 add      edi, 0xc
433de097 cmp      esi, eax
433de099 jl       0x433de064
433de09b cmp      esi, eax
433de09d je       0x433de1cd
433de0a3 mov      esi, dword ptr [esp + 0x24]
433de0a7 mov      edi, dword ptr [esp + 0x1c]
433de0ab inc      esi
433de0ac movss    xmm2, dword ptr [esp + 0x80]
433de0b5 add      edi, 0xc
433de0b8 mov      dword ptr [esp + 0x24], esi
433de0bc mov      dword ptr [esp + 0x1c], edi
433de0c0 cmp      esi, eax
433de0c2 jl       0x433ddeef
433de0c8 cmp      esi, eax
433de0ca jne      0x433de1cd
433de0d0 cmp      eax, 2
433de0d3 jne      0x433de22a
433de0d9 movss    xmm3, dword ptr [esp + 0x5b8]
433de0e2 mulss    xmm3, dword ptr [esp + 0x5a8]
433de0eb movss    xmm0, dword ptr [esp + 0x5b4]
433de0f4 mulss    xmm0, dword ptr [esp + 0x5ac]
433de0fd movss    xmm1, dword ptr [esp + 0x5b0]
433de106 movss    xmm6, dword ptr [esp + 0x5a4]
433de10f movaps   xmm5, xmm1
433de112 mulss    xmm1, dword ptr [esp + 0x5a8]
433de11b subss    xmm3, xmm0
433de11f mulss    xmm5, dword ptr [esp + 0x5ac]
433de128 movaps   xmm0, xmm6
433de12b mulss    xmm0, dword ptr [esp + 0x5b8]
433de134 mulss    xmm6, dword ptr [esp + 0x5b4]
433de13d subss    xmm5, xmm0
433de141 movss    xmm4, dword ptr [0x43470514]
433de149 subss    xmm6, xmm1
433de14d movaps   xmm1, xmm3
433de150 mulss    xmm1, xmm3
433de154 movaps   xmm0, xmm5
433de157 mulss    xmm0, xmm5
433de15b addss    xmm1, xmm0
433de15f movaps   xmm0, xmm6
433de162 mulss    xmm0, xmm6
433de166 addss    xmm1, xmm0
433de16a movaps   xmm0, xmm1
433de16d movss    xmm1, dword ptr [edx + 4]
433de172 sqrtss   xmm0, xmm0
433de176 addss    xmm0, dword ptr [0x43472108]
433de17e divss    xmm4, xmm0
433de182 movaps   xmm2, xmm4
433de185 mulss    xmm2, xmm3
433de189 movaps   xmm3, xmm4
433de18c mulss    xmm3, xmm5
433de190 movaps   xmm0, xmm2
433de193 mulss    xmm4, xmm6
433de197 mulss    xmm0, dword ptr [edx]
433de19b mulss    xmm1, xmm3
433de19f addss    xmm1, xmm0
433de1a3 movss    xmm0, dword ptr [edx + 8]
433de1a8 mulss    xmm0, xmm4
433de1ac addss    xmm1, xmm0
433de1b0 movaps   xmm0, xmm1
433de1b3 mulss    xmm3, xmm1
433de1b7 mulss    xmm0, xmm2
433de1bb mulss    xmm4, xmm1
433de1bf movss    dword ptr [edx], xmm0
433de1c3 movss    dword ptr [edx + 4], xmm3
433de1c8 movss    dword ptr [edx + 8], xmm4
433de1cd movss    xmm0, dword ptr [edx]
433de1d1 movss    xmm1, dword ptr [edx + 4]
433de1d6 mulss    xmm0, dword ptr [esp + 0xd4]
433de1df mulss    xmm1, dword ptr [esp + 0xd8]
433de1e8 addss    xmm1, xmm0
433de1ec movss    xmm0, dword ptr [edx + 8]
433de1f1 mulss    xmm0, dword ptr [esp + 0xdc]
433de1fa addss    xmm1, xmm0
433de1fe comiss   xmm1, xmm7
433de201 jbe      0x433de22a
433de203 mov      esi, dword ptr [esp + 0x48]
433de207 inc      esi
433de208 mov      dword ptr [esp + 0x48], esi
433de20c cmp      esi, 4
433de20f jl       0x433dd69f
433de215 jmp      0x433de242
433de217 mov      edx, dword ptr [esp + 0x40]
433de21b movss    xmm7, dword ptr [esp + 0x18]
433de221 mov      ecx, dword ptr [esp + 0x20]
433de225 jmp      0x433de22a
433de227 lea      edx, [ecx + 0x10]
433de22a xor      eax, eax
433de22c lea      edi, [esp + 0xc8]
433de233 stosd    dword ptr es:[edi], eax
433de234 lea      esi, [esp + 0xc8]
433de23b stosd    dword ptr es:[edi], eax
433de23c stosd    dword ptr es:[edi], eax
433de23d mov      edi, edx
433de23f movsd    dword ptr es:[edi], dword ptr [esi]
433de240 movsd    dword ptr es:[edi], dword ptr [esi]
433de241 movsd    dword ptr es:[edi], dword ptr [esi]
433de242 movss    xmm2, dword ptr [esp + 0x34]
433de248 ucomiss  xmm2, xmm7
433de24b lahf     
433de24c test     ah, 0x44
433de24f jp       0x433de269
433de251 xor      eax, eax
433de253 lea      edi, [esp + 0x2b0]
433de25a stosd    dword ptr es:[edi], eax
433de25b lea      esi, [esp + 0x2b0]
433de262 stosd    dword ptr es:[edi], eax
433de263 stosd    dword ptr es:[edi], eax
433de264 mov      edi, edx
433de266 movsd    dword ptr es:[edi], dword ptr [esi]
433de267 movsd    dword ptr es:[edi], dword ptr [esi]
433de268 movsd    dword ptr es:[edi], dword ptr [esi]
433de269 movss    xmm2, dword ptr [0x434720b0]
433de271 lea      eax, [ecx + 0xc8]
433de277 mov      dword ptr [eax], 0x3f800000
433de27d lea      edi, [esp + 0xa4]
433de284 or       dword ptr [esp + 0x41c], 0xffffffff
433de28c or       dword ptr [esp + 0x428], 0xffffffff
433de294 mov      dword ptr [esp + 0x44], eax
433de298 xor      eax, eax
433de29a mov      word ptr [esp + 0x40e], ax
433de2a2 mov      dword ptr [esp + 0x424], eax
433de2a9 lea      eax, [ecx + 4]
433de2ac mov      dword ptr [esp + 0x404], 0x3f800000
433de2b7 mov      esi, eax
433de2b9 movss    xmm1, dword ptr [ecx + 0x18]
433de2be comiss   xmm1, xmm7
433de2c1 mov      dword ptr [esp + 0x30], eax
433de2c5 movsd    dword ptr es:[edi], dword ptr [esi]
433de2c6 movsd    dword ptr es:[edi], dword ptr [esi]
433de2c7 seta     byte ptr [esp + 0x7f]
433de2cc movsd    dword ptr es:[edi], dword ptr [esi]
433de2cd movss    xmm0, dword ptr [esp + 0xac]
433de2d6 subss    xmm0, dword ptr [0x4347259c]
433de2de comiss   xmm1, xmm2
433de2e1 movss    dword ptr [esp + 0x3c], xmm0
433de2e7 seta     dl
433de2ea test     dl, dl
433de2ec je       0x433de2fe
433de2ee test     byte ptr [ecx + 0x1c], 1
433de2f2 je       0x433de2fe
433de2f4 subss    xmm1, xmm1
433de2f8 comiss   xmm1, xmm2
433de2fb seta     dl
433de2fe mov      dh, byte ptr [ecx + 0xcc]
433de304 mov      byte ptr [esp + 0x17], 0
433de309 cmp      dh, 2
433de30c jne      0x433de327
433de30e test     byte ptr [ecx + 0x1c], 1
433de312 je       0x433de327
433de314 subss    xmm0, dword ptr [ecx + 0xdc]
433de31c mov      byte ptr [esp + 0x17], 1
433de321 movss    dword ptr [esp + 0x3c], xmm0
433de327 test     dl, dl
433de329 jne      0x433defa7
433de32f cmp      byte ptr [esp + 0x7f], dl
433de333 je       0x433de33e
433de335 cmp      dh, 9
433de338 je       0x433defa7
433de33e movss    xmm2, dword ptr [esp + 0xa4]
433de347 lea      edi, [esp + 0x84]
433de34e movss    xmm1, dword ptr [esp + 0xa8]
433de357 mov      esi, eax
433de359 mov      eax, dword ptr [ecx]
433de35b movsd    dword ptr es:[edi], dword ptr [esi]
433de35c movsd    dword ptr es:[edi], dword ptr [esi]
433de35d movsd    dword ptr es:[edi], dword ptr [esi]
433de35e and      dword ptr [esp + 0x4c4], 0
433de366 mov      esi, dword ptr [0x43468304]
433de36c subss    xmm1, dword ptr [esp + 0x88]
433de375 subss    xmm2, dword ptr [esp + 0x84]
433de37e subss    xmm0, dword ptr [esp + 0x8c]
433de387 mov      dword ptr [esp + 0x4bc], eax
433de38e mov      dword ptr [esp + 0x4b8], 0x4346edc0
433de399 mov      dword ptr [esp + 0x4c0], 8
433de3a4 mov      eax, dword ptr [esi]
433de3a6 mov      edi, dword ptr [eax + 0x14]
433de3a9 mov      eax, dword ptr [ecx + 0xd0]
433de3af and      dword ptr [esp + 0xb00], 0
433de3b7 movss    dword ptr [esp + 0xad4], xmm1
433de3c0 movss    dword ptr [esp + 0xad0], xmm2
433de3c9 mulss    xmm1, xmm1
433de3cd mov      dword ptr [esp + 0x38], eax
433de3d1 mulss    xmm2, xmm2
433de3d5 mov      byte ptr [esp + 0xb05], 1
433de3dd movss    dword ptr [esp + 0xad8], xmm0
433de3e6 mulss    xmm0, xmm0
433de3ea addss    xmm1, xmm2
433de3ee addss    xmm1, xmm0
433de3f2 ucomiss  xmm1, xmm7
433de3f5 lahf     
433de3f6 test     ah, 0x44
433de3f9 jp       0x433de403
433de3fb mov      byte ptr [esp + 0xb05], 0
433de403 movss    xmm3, dword ptr [ecx + 0x44]
433de408 lea      eax, [esp + 0x3d8]
433de40f movss    xmm4, dword ptr [ecx + 0x48]
433de414 movaps   xmm2, xmm3
433de417 movss    xmm6, dword ptr [ecx + 0x38]
433de41c movaps   xmm1, xmm4
433de41f movss    xmm7, dword ptr [ecx + 0x3c]
433de424 subss    xmm2, xmm6
433de428 movss    xmm0, dword ptr [ecx + 0x40]
433de42d subss    xmm1, xmm7
433de431 movss    xmm5, dword ptr [ecx + 0x4c]
433de436 addss    xmm6, xmm3
433de43a movss    dword ptr [esp + 0x1c], xmm0
433de440 addss    xmm7, xmm4
433de444 movaps   xmm0, xmm5
433de447 mov      ecx, esi
433de449 subss    xmm0, dword ptr [esp + 0x1c]
433de44f mulss    xmm1, dword ptr [0x43472240]
433de457 push     eax
433de458 mulss    xmm2, dword ptr [0x43472240]
433de460 lea      eax, [esp + 0x4bc]
433de467 push     eax
433de468 mulss    xmm0, dword ptr [0x43472240]
433de470 lea      eax, [esp + 0xac8]
433de477 movss    dword ptr [esp + 0xafc], xmm1
433de480 mulss    xmm1, xmm1
433de484 movss    dword ptr [esp + 0xb00], xmm0
433de48d mulss    xmm0, xmm0
433de491 movss    dword ptr [esp + 0xaf8], xmm2
433de49a mulss    xmm2, xmm2
433de49e push     dword ptr [esp + 0x40]
433de4a2 addss    xmm1, xmm2
433de4a6 push     eax
433de4a7 addss    xmm1, xmm0
433de4ab cvtps2pd xmm0, xmm1
433de4ae movsd    xmm1, qword ptr [esp + 0xa0]
433de4b7 comisd   xmm1, xmm0
433de4bb movss    xmm0, dword ptr [0x43472240]
433de4c3 movss    xmm1, dword ptr [esp + 0x2c]
433de4c9 mulss    xmm6, xmm0
433de4cd addss    xmm1, xmm5
433de4d1 mulss    xmm7, xmm0
433de4d5 seta     byte ptr [esp + 0xb14]
433de4dd mulss    xmm1, xmm0
433de4e1 movaps   xmm0, xmm6
433de4e4 addss    xmm0, dword ptr [esp + 0x94]
433de4ed movss    dword ptr [esp + 0xad0], xmm0
433de4f6 movaps   xmm0, xmm7
433de4f9 addss    xmm0, dword ptr [esp + 0x98]
433de502 movss    dword ptr [esp + 0xad4], xmm0
433de50b movaps   xmm0, xmm1
433de50e addss    xmm0, dword ptr [esp + 0x9c]
433de517 movss    dword ptr [esp + 0xad8], xmm0
433de520 movss    xmm0, dword ptr [0x4346f858]
433de528 mulss    xmm6, xmm0
433de52c mulss    xmm7, xmm0
433de530 mulss    xmm1, xmm0
433de534 movss    dword ptr [esp + 0xaf0], xmm6
433de53d movss    dword ptr [esp + 0xaf4], xmm7
433de546 movss    dword ptr [esp + 0xaf8], xmm1
433de54f call     edi
433de551 movss    xmm1, dword ptr [esp + 0x404]
433de55a movss    xmm0, dword ptr [0x43470514]
433de562 comiss   xmm0, xmm1
433de565 movss    dword ptr [esp + 0x34], xmm1
433de56b ja       0x433de581
433de56d cmp      byte ptr [esp + 0x40e], 0
433de575 jne      0x433de581
433de577 cmp      byte ptr [esp + 0x40f], 0
433de57f je       0x433de5a1
433de581 cmp      dword ptr [esp + 0x424], 0
433de589 je       0x433de5a1
433de58b movss    xmm0, dword ptr [esp + 0x3f8]
433de594 comiss   xmm0, dword ptr [0x4346fd8c]
433de59b jae      0x433deee7
433de5a1 mov      ecx, dword ptr [esp + 0x20]
433de5a5 lea      esi, [esp + 0x3e4]
433de5ac lea      edi, [esp + 0x290]
433de5b3 movsd    dword ptr es:[edi], dword ptr [esi]
433de5b4 mov      eax, dword ptr [ecx]
433de5b6 and      dword ptr [esp + 0x30c], 0
433de5be movsd    dword ptr es:[edi], dword ptr [esi]
433de5bf mov      dword ptr [esp + 0x300], 0x4346edc0
433de5ca mov      dword ptr [esp + 0x304], eax
433de5d1 mov      dword ptr [esp + 0x308], 8
433de5dc movsd    dword ptr es:[edi], dword ptr [esi]
433de5dd lea      esi, [ecx + 0x38]
433de5e0 lea      edi, [esp + 0xb0]
433de5e7 movsd    dword ptr es:[edi], dword ptr [esi]
433de5e8 movsd    dword ptr es:[edi], dword ptr [esi]
433de5e9 movsd    dword ptr es:[edi], dword ptr [esi]
433de5ea mov      esi, ecx
433de5ec movss    xmm0, dword ptr [esi + 0x4c]
433de5f1 movss    xmm1, dword ptr [esi + 0x48]
433de5f6 movss    dword ptr [esp + 0x64], xmm0
433de5fc movss    xmm0, dword ptr [esp + 0x18]
433de602 call     0x43367633
433de607 movss    xmm1, dword ptr [esi + 0x44]
433de60c movss    dword ptr [esp + 0x38], xmm0
433de612 movss    xmm0, dword ptr [esp + 0x18]
433de618 call     0x43367633
433de61d and      dword ptr [esp + 0x220], 0
433de625 movaps   xmm3, xmm0
433de628 movss    xmm7, dword ptr [esi + 4]
433de62d movss    xmm2, dword ptr [esp + 0xa4]
433de636 movss    xmm1, dword ptr [esp + 0xa8]
433de63f subss    xmm2, xmm7
433de643 movss    dword ptr [esp + 0x58], xmm3
433de649 movss    dword ptr [esp + 0x1f0], xmm2
433de652 movss    xmm0, dword ptr [esi + 8]
433de657 subss    xmm1, xmm0
433de65b movss    dword ptr [esp + 0x1c], xmm0
433de661 movss    xmm0, dword ptr [esp + 0x3c]
433de667 mulss    xmm2, xmm2
433de66b movss    dword ptr [esp + 0x1f4], xmm1
433de674 movss    xmm4, dword ptr [esi + 0xc]
433de679 subss    xmm0, xmm4
433de67d mulss    xmm1, xmm1
433de681 mov      byte ptr [esp + 0x225], 1
433de689 movss    dword ptr [esp + 0x48], xmm4
433de68f addss    xmm1, xmm2
433de693 movss    dword ptr [esp + 0x1f8], xmm0
433de69c mulss    xmm0, xmm0
433de6a0 addss    xmm1, xmm0
433de6a4 ucomiss  xmm1, dword ptr [esp + 0x18]
433de6a9 lahf     
433de6aa test     ah, 0x44
433de6ad jp       0x433de6b7
433de6af mov      byte ptr [esp + 0x225], 0
433de6b7 movss    xmm5, dword ptr [esp + 0x38]
433de6bd lea      edx, [esp + 0x3d8]
433de6c4 movss    xmm4, dword ptr [0x43472240]
433de6cc movaps   xmm2, xmm3
433de6cf movss    xmm3, dword ptr [esp + 0xb0]
433de6d8 movaps   xmm1, xmm5
433de6db subss    xmm1, dword ptr [esp + 0xb4]
433de6e4 movss    xmm6, dword ptr [esp + 0x64]
433de6ea subss    xmm2, xmm3
433de6ee addss    xmm5, dword ptr [esp + 0xb4]
433de6f7 movaps   xmm0, xmm6
433de6fa mov      ecx, dword ptr [0x43468304]
433de700 subss    xmm0, dword ptr [esp + 0xb8]
433de709 mulss    xmm1, xmm4
433de70d push     edx
433de70e addss    xmm6, dword ptr [esp + 0xbc]
433de717 mulss    xmm2, xmm4
433de71b lea      edx, [esp + 0x304]
433de722 push     edx
433de723 mulss    xmm0, xmm4
433de727 lea      edx, [esp + 0x1e8]
433de72e movss    dword ptr [esp + 0x21c], xmm1
433de737 movss    dword ptr [esp + 0x218], xmm2
433de740 movss    dword ptr [esp + 0x220], xmm0
433de749 mulss    xmm1, xmm1
433de74d mulss    xmm2, xmm2
433de751 mulss    xmm0, xmm0
433de755 addss    xmm3, dword ptr [esp + 0x60]
433de75b addss    xmm1, xmm2
433de75f mulss    xmm5, xmm4
433de763 mulss    xmm6, xmm4
433de767 mulss    xmm3, xmm4
433de76b addss    xmm1, xmm0
433de76f addss    xmm7, xmm3
433de773 cvtps2pd xmm0, xmm1
433de776 movsd    xmm1, qword ptr [esp + 0x98]
433de77f comisd   xmm1, xmm0
433de783 movss    xmm0, dword ptr [esp + 0x24]
433de789 addss    xmm0, xmm5
433de78d movss    dword ptr [esp + 0x1e8], xmm7
433de796 seta     byte ptr [esp + 0x22c]
433de79e movss    dword ptr [esp + 0x1ec], xmm0
433de7a7 movaps   xmm0, xmm6
433de7aa addss    xmm0, dword ptr [esp + 0x50]
433de7b0 movss    dword ptr [esp + 0x1f0], xmm0
433de7b9 movss    xmm0, dword ptr [0x4346f858]
433de7c1 mulss    xmm3, xmm0
433de7c5 mulss    xmm5, xmm0
433de7c9 mulss    xmm6, xmm0
433de7cd movss    dword ptr [esp + 0x208], xmm3
433de7d6 movss    dword ptr [esp + 0x20c], xmm5
433de7df movss    dword ptr [esp + 0x210], xmm6
433de7e8 push     dword ptr [esi + 0xd0]
433de7ee mov      eax, dword ptr [ecx]
433de7f0 push     edx
433de7f1 call     dword ptr [eax + 0x14]
433de7f4 cmp      dword ptr [esp + 0x424], 0
433de7fc je       0x433de818
433de7fe movss    xmm0, dword ptr [esp + 0x3f8]
433de807 movss    xmm2, dword ptr [0x4346fd8c]
433de80f comiss   xmm0, xmm2
433de812 jae      0x433dee82
433de818 movss    xmm0, dword ptr [esi + 0x40]
433de81d movss    xmm1, dword ptr [esi + 0x3c]
433de822 movss    dword ptr [esp + 0x64], xmm0
433de828 movss    xmm0, dword ptr [esp + 0x18]
433de82e call     0x4332fc35
433de833 movss    xmm1, dword ptr [esi + 0x38]
433de838 movss    dword ptr [esp + 0x38], xmm0
433de83e movss    xmm0, dword ptr [esp + 0x18]
433de844 call     0x4332fc35
433de849 movss    xmm2, dword ptr [esp + 0xa4]
433de852 lea      esi, [esi + 0x44]
433de855 movss    xmm1, dword ptr [esp + 0xa8]
433de85e lea      edi, [esp + 0x58]
433de862 movsd    dword ptr es:[edi], dword ptr [esi]
433de863 movaps   xmm4, xmm0
433de866 movsd    dword ptr es:[edi], dword ptr [esi]
433de867 movsd    dword ptr es:[edi], dword ptr [esi]
433de868 mov      edi, dword ptr [esp + 0x30]
433de86c and      dword ptr [esp + 0x220], 0
433de874 movss    xmm7, dword ptr [edi]
433de878 subss    xmm2, xmm7
433de87c movss    dword ptr [esp + 0x1f0], xmm2
433de885 movss    xmm0, dword ptr [edi + 4]
433de88a subss    xmm1, xmm0
433de88e movss    dword ptr [esp + 0x1c], xmm0
433de894 movss    xmm0, dword ptr [esp + 0x3c]
433de89a mulss    xmm2, xmm2
433de89e movss    dword ptr [esp + 0x1f4], xmm1
433de8a7 movss    xmm3, dword ptr [edi + 8]
433de8ac subss    xmm0, xmm3
433de8b0 mulss    xmm1, xmm1
433de8b4 mov      byte ptr [esp + 0x225], 1
433de8bc movss    dword ptr [esp + 0x48], xmm3
433de8c2 addss    xmm1, xmm2
433de8c6 movss    dword ptr [esp + 0x1f8], xmm0
433de8cf mulss    xmm0, xmm0
433de8d3 addss    xmm1, xmm0
433de8d7 ucomiss  xmm1, dword ptr [esp + 0x18]
433de8dc lahf     
433de8dd test     ah, 0x44
433de8e0 jp       0x433de8ea
433de8e2 mov      byte ptr [esp + 0x225], 0
433de8ea movss    xmm1, dword ptr [esp + 0x5c]
433de8f0 lea      edx, [esp + 0x3d8]
433de8f7 movss    xmm5, dword ptr [esp + 0x38]
433de8fd movss    xmm2, dword ptr [esp + 0x58]
433de903 subss    xmm1, xmm5
433de907 movss    xmm3, dword ptr [0x43472240]
433de90f subss    xmm2, xmm4
433de913 movss    xmm6, dword ptr [esp + 0x64]
433de919 movss    xmm0, dword ptr [esp + 0x60]
433de91f subss    xmm0, xmm6
433de923 mov      ecx, dword ptr [0x43468304]
433de929 addss    xmm5, dword ptr [esp + 0x5c]
433de92f mulss    xmm1, xmm3
433de933 mov      esi, dword ptr [esp + 0x20]
433de937 addss    xmm6, dword ptr [esp + 0x60]
433de93d mulss    xmm2, xmm3
433de941 push     edx
433de942 mulss    xmm0, xmm3
433de946 lea      edx, [esp + 0x304]
433de94d push     edx
433de94e movss    dword ptr [esp + 0x21c], xmm1
433de957 lea      edx, [esp + 0x1e8]
433de95e movss    dword ptr [esp + 0x218], xmm2
433de967 movss    dword ptr [esp + 0x220], xmm0
433de970 mulss    xmm1, xmm1
433de974 mulss    xmm2, xmm2
433de978 mulss    xmm0, xmm0
433de97c addss    xmm4, dword ptr [esp + 0x60]
433de982 addss    xmm1, xmm2
433de986 mulss    xmm5, xmm3
433de98a mulss    xmm6, xmm3
433de98e mulss    xmm4, xmm3
433de992 addss    xmm1, xmm0
433de996 addss    xmm7, xmm4
433de99a cvtps2pd xmm0, xmm1
433de99d movsd    xmm1, qword ptr [esp + 0x98]
433de9a6 comisd   xmm1, xmm0
433de9aa movss    xmm0, dword ptr [esp + 0x24]
433de9b0 addss    xmm0, xmm5
433de9b4 movss    dword ptr [esp + 0x1e8], xmm7
433de9bd seta     byte ptr [esp + 0x22c]
433de9c5 movss    dword ptr [esp + 0x1ec], xmm0
433de9ce movaps   xmm0, xmm6
433de9d1 addss    xmm0, dword ptr [esp + 0x50]
433de9d7 movss    dword ptr [esp + 0x1f0], xmm0
433de9e0 movss    xmm0, dword ptr [0x4346f858]
433de9e8 mulss    xmm4, xmm0
433de9ec mulss    xmm5, xmm0
433de9f0 mulss    xmm6, xmm0
433de9f4 movss    dword ptr [esp + 0x208], xmm4
433de9fd movss    dword ptr [esp + 0x20c], xmm5
433dea06 movss    dword ptr [esp + 0x210], xmm6
433dea0f push     dword ptr [esi + 0xd0]
433dea15 mov      eax, dword ptr [ecx]
433dea17 push     edx
433dea18 call     dword ptr [eax + 0x14]
433dea1b cmp      dword ptr [esp + 0x424], 0
433dea23 je       0x433dea3f
433dea25 movss    xmm0, dword ptr [esp + 0x3f8]
433dea2e movss    xmm2, dword ptr [0x4346fd8c]
433dea36 comiss   xmm0, xmm2
433dea39 jae      0x433dee82
433dea3f movss    xmm0, dword ptr [esi + 0x40]
433dea44 movss    xmm1, dword ptr [esi + 0x3c]
433dea49 movss    dword ptr [esp + 0x30], xmm0
433dea4f movss    xmm0, dword ptr [esp + 0x18]
433dea55 call     0x4332fc35
433dea5a movss    xmm1, dword ptr [esi + 0x44]
433dea5f movss    dword ptr [esp + 0x38], xmm0
433dea65 movss    xmm0, dword ptr [esi + 0x38]
433dea6a movss    dword ptr [esp + 0x1c], xmm0
433dea70 movss    xmm0, dword ptr [esi + 0x4c]
433dea75 movss    dword ptr [esp + 0x64], xmm0
433dea7b movss    xmm0, dword ptr [esi + 0x48]
433dea80 movss    dword ptr [esp + 0x48], xmm0
433dea86 movss    xmm0, dword ptr [esp + 0x18]
433dea8c call     0x43367633
433dea91 and      dword ptr [esp + 0x220], 0
433dea99 movaps   xmm4, xmm0
433dea9c movss    xmm7, dword ptr [edi]
433deaa0 movss    xmm2, dword ptr [esp + 0xa4]
433deaa9 movss    xmm1, dword ptr [esp + 0xa8]
433deab2 subss    xmm2, xmm7
433deab6 movss    dword ptr [esp + 0x1f0], xmm2
433deabf movss    xmm0, dword ptr [edi + 4]
433deac4 subss    xmm1, xmm0
433deac8 movss    dword ptr [esp + 0x50], xmm0
433deace movss    xmm0, dword ptr [esp + 0x3c]
433dead4 mulss    xmm2, xmm2
433dead8 movss    dword ptr [esp + 0x1f4], xmm1
433deae1 movss    xmm3, dword ptr [edi + 8]
433deae6 subss    xmm0, xmm3
433deaea mulss    xmm1, xmm1
433deaee mov      byte ptr [esp + 0x225], 1
433deaf6 movss    dword ptr [esp + 0x24], xmm3
433deafc addss    xmm1, xmm2
433deb00 movss    dword ptr [esp + 0x1f8], xmm0
433deb09 mulss    xmm0, xmm0
433deb0d addss    xmm1, xmm0
433deb11 ucomiss  xmm1, dword ptr [esp + 0x18]
433deb16 lahf     
433deb17 test     ah, 0x44
433deb1a jp       0x433deb24
433deb1c mov      byte ptr [esp + 0x225], 0
433deb24 movss    xmm1, dword ptr [esp + 0x48]
433deb2a lea      edx, [esp + 0x3d8]
433deb31 movss    xmm5, dword ptr [esp + 0x38]
433deb37 movaps   xmm2, xmm4
433deb3a subss    xmm2, dword ptr [esp + 0x1c]
433deb40 movss    xmm3, dword ptr [0x43472240]
433deb48 subss    xmm1, xmm5
433deb4c movss    xmm6, dword ptr [esp + 0x64]
433deb52 addss    xmm5, dword ptr [esp + 0x48]
433deb58 movaps   xmm0, xmm6
433deb5b mov      ecx, dword ptr [0x43468304]
433deb61 subss    xmm0, dword ptr [esp + 0x30]
433deb67 mulss    xmm1, xmm3
433deb6b push     edx
433deb6c mulss    xmm2, xmm3
433deb70 lea      edx, [esp + 0x304]
433deb77 push     edx
433deb78 mulss    xmm0, xmm3
433deb7c lea      edx, [esp + 0x1e8]
433deb83 addss    xmm6, dword ptr [esp + 0x38]
433deb89 movss    dword ptr [esp + 0x21c], xmm1
433deb92 movss    dword ptr [esp + 0x218], xmm2
433deb9b movss    dword ptr [esp + 0x220], xmm0
433deba4 mulss    xmm1, xmm1
433deba8 mulss    xmm2, xmm2
433debac mulss    xmm0, xmm0
433debb0 addss    xmm4, dword ptr [esp + 0x24]
433debb6 addss    xmm1, xmm2
433debba mulss    xmm5, xmm3
433debbe mulss    xmm6, xmm3
433debc2 mulss    xmm4, xmm3
433debc6 addss    xmm1, xmm0
433debca addss    xmm7, xmm4
433debce cvtps2pd xmm0, xmm1
433debd1 movsd    xmm1, qword ptr [esp + 0x98]
433debda comisd   xmm1, xmm0
433debde movss    xmm0, dword ptr [esp + 0x58]
433debe4 addss    xmm0, xmm5
433debe8 movss    dword ptr [esp + 0x1e8], xmm7
433debf1 seta     byte ptr [esp + 0x22c]
433debf9 movss    dword ptr [esp + 0x1ec], xmm0
433dec02 movss    xmm0, dword ptr [esp + 0x2c]
433dec08 addss    xmm0, xmm6
433dec0c movss    dword ptr [esp + 0x1f0], xmm0
433dec15 movss    xmm0, dword ptr [0x4346f858]
433dec1d mulss    xmm4, xmm0
433dec21 mulss    xmm5, xmm0
433dec25 mulss    xmm6, xmm0
433dec29 movss    dword ptr [esp + 0x208], xmm4
433dec32 movss    dword ptr [esp + 0x20c], xmm5
433dec3b movss    dword ptr [esp + 0x210], xmm6
433dec44 push     dword ptr [esi + 0xd0]
433dec4a mov      eax, dword ptr [ecx]
433dec4c push     edx
433dec4d call     dword ptr [eax + 0x14]
433dec50 cmp      dword ptr [esp + 0x424], 0
433dec58 je       0x433dec74
433dec5a movss    xmm0, dword ptr [esp + 0x3f8]
433dec63 movss    xmm2, dword ptr [0x4346fd8c]
433dec6b comiss   xmm0, xmm2
433dec6e jae      0x433dee82
433dec74 movss    xmm0, dword ptr [esi + 0x40]
433dec79 movss    xmm1, dword ptr [esi + 0x38]
433dec7e movss    dword ptr [esp + 0x30], xmm0
433dec84 movss    xmm0, dword ptr [esi + 0x3c]
433dec89 movss    dword ptr [esp + 0x48], xmm0
433dec8f movss    xmm0, dword ptr [esp + 0x18]
433dec95 call     0x4332fc35
433dec9a movss    xmm1, dword ptr [esi + 0x4c]
433dec9f movss    dword ptr [esp + 0x1c], xmm0
433deca5 movss    xmm0, dword ptr [esp + 0x18]
433decab movss    dword ptr [esp + 0x38], xmm1
433decb1 movss    xmm1, dword ptr [esi + 0x48]
433decb6 call     0x43367633
433decbb movss    xmm4, dword ptr [esi + 0x44]
433decc0 movaps   xmm5, xmm0
433decc3 and      dword ptr [esp + 0x220], 0
433deccb movss    xmm0, dword ptr [edi]
433deccf movss    xmm2, dword ptr [esp + 0xa4]
433decd8 movss    xmm1, dword ptr [esp + 0xa8]
433dece1 subss    xmm2, xmm0
433dece5 movss    dword ptr [esp + 0x64], xmm0
433deceb movss    dword ptr [esp + 0x1f0], xmm2
433decf4 movss    xmm0, dword ptr [edi + 4]
433decf9 subss    xmm1, xmm0
433decfd movss    dword ptr [esp + 0x50], xmm0
433ded03 movss    xmm0, dword ptr [esp + 0x3c]
433ded09 mulss    xmm2, xmm2
433ded0d movss    dword ptr [esp + 0x1f4], xmm1
433ded16 movss    xmm7, dword ptr [edi + 8]
433ded1b subss    xmm0, xmm7
433ded1f mulss    xmm1, xmm1
433ded23 mov      byte ptr [esp + 0x225], 1
433ded2b addss    xmm1, xmm2
433ded2f movss    dword ptr [esp + 0x1f8], xmm0
433ded38 mulss    xmm0, xmm0
433ded3c addss    xmm1, xmm0
433ded40 ucomiss  xmm1, dword ptr [esp + 0x18]
433ded45 lahf     
433ded46 test     ah, 0x44
433ded49 jp       0x433ded53
433ded4b mov      byte ptr [esp + 0x225], 0
433ded53 movss    xmm3, dword ptr [0x43472240]
433ded5b lea      edx, [esp + 0x3d8]
433ded62 movss    xmm6, dword ptr [esp + 0x38]
433ded68 movaps   xmm1, xmm5
433ded6b subss    xmm1, dword ptr [esp + 0x48]
433ded71 movaps   xmm2, xmm4
433ded74 mov      ecx, dword ptr [0x43468304]
433ded7a subss    xmm2, dword ptr [esp + 0x1c]
433ded80 addss    xmm4, dword ptr [esp + 0x1c]
433ded86 movaps   xmm0, xmm6
433ded89 subss    xmm0, dword ptr [esp + 0x30]
433ded8f addss    xmm5, dword ptr [esp + 0x48]
433ded95 mulss    xmm1, xmm3
433ded99 push     edx
433ded9a mulss    xmm2, xmm3
433ded9e lea      edx, [esp + 0x304]
433deda5 push     edx
433deda6 mulss    xmm0, xmm3
433dedaa lea      edx, [esp + 0x1e8]
433dedb1 movss    dword ptr [esp + 0x21c], xmm1
433dedba movss    dword ptr [esp + 0x218], xmm2
433dedc3 movss    dword ptr [esp + 0x220], xmm0
433dedcc mulss    xmm1, xmm1
433dedd0 mulss    xmm0, xmm0
433dedd4 mulss    xmm2, xmm2
433dedd8 addss    xmm6, dword ptr [esp + 0x38]
433dedde mulss    xmm4, xmm3
433dede2 addss    xmm1, xmm2
433dede6 mulss    xmm5, xmm3
433dedea mulss    xmm6, xmm3
433dedee addss    xmm1, xmm0
433dedf2 xorps    xmm0, xmm0
433dedf5 addss    xmm7, xmm6
433dedf9 cvtss2sd xmm0, xmm1
433dedfd movsd    xmm1, qword ptr [esp + 0x98]
433dee06 comisd   xmm1, xmm0
433dee0a movaps   xmm0, xmm4
433dee0d movss    dword ptr [esp + 0x1f0], xmm7
433dee16 addss    xmm0, dword ptr [esp + 0x6c]
433dee1c seta     byte ptr [esp + 0x22c]
433dee24 movss    dword ptr [esp + 0x1e8], xmm0
433dee2d movaps   xmm0, xmm5
433dee30 addss    xmm0, dword ptr [esp + 0x58]
433dee36 movss    dword ptr [esp + 0x1ec], xmm0
433dee3f movss    xmm0, dword ptr [0x4346f858]
433dee47 mulss    xmm4, xmm0
433dee4b mulss    xmm5, xmm0
433dee4f mulss    xmm6, xmm0
433dee53 movss    dword ptr [esp + 0x208], xmm4
433dee5c movss    dword ptr [esp + 0x20c], xmm5
433dee65 movss    dword ptr [esp + 0x210], xmm6
433dee6e push     dword ptr [esi + 0xd0]
433dee74 mov      eax, dword ptr [ecx]
433dee76 push     edx
433dee77 call     dword ptr [eax + 0x14]
433dee7a movss    xmm2, dword ptr [0x4346fd8c]
433dee82 movss    xmm1, dword ptr [esp + 0x34]
433dee88 lea      esi, [esp + 0x290]
433dee8f movss    xmm0, dword ptr [0x43470514]
433dee97 lea      edi, [esp + 0x3e4]
433dee9e comiss   xmm0, xmm1
433deea1 movss    dword ptr [esp + 0x404], xmm1
433deeaa movsd    dword ptr es:[edi], dword ptr [esi]
433deeab movsd    dword ptr es:[edi], dword ptr [esi]
433deeac movsd    dword ptr es:[edi], dword ptr [esi]
433deead ja       0x433deec7
433deeaf cmp      byte ptr [esp + 0x40e], 0
433deeb7 jne      0x433deec7
433deeb9 cmp      byte ptr [esp + 0x40f], 0
433deec1 je       0x433def7a
433deec7 cmp      dword ptr [esp + 0x424], 0
433deecf je       0x433def7a
433deed5 movss    xmm0, dword ptr [esp + 0x3f8]
433deede comiss   xmm0, xmm2
433deee1 jb       0x433def7a
433deee7 mov      ecx, dword ptr [esp + 0x20]
433deeeb xor      eax, eax
433deeed mov      esi, dword ptr [esp + 0x44]
433deef1 push     eax
433deef2 push     esi
433deef3 or       dword ptr [ecx + 0x1c], 1
433deef7 mov      ecx, dword ptr [0x43469268]
433deefd push     eax
433deefe push     eax
433deeff movsx    eax, word ptr [esp + 0x428]
433def07 mov      edx, dword ptr [ecx]
433def09 push     eax
433def0a call     dword ptr [edx + 0x10]
433def0d movss    xmm0, dword ptr [esi]
433def11 mulss    xmm0, dword ptr [0x4347268c]
433def19 movss    xmm1, dword ptr [0x43470514]
433def21 comiss   xmm0, xmm1
433def24 movss    dword ptr [esi], xmm0
433def28 jbe      0x433def30
433def2a mov      dword ptr [esi], 0x3f800000
433def30 mov      ecx, dword ptr [esp + 0x20]
433def34 cmp      byte ptr [ecx + 0xcc], 8
433def3b je       0x433def41
433def3d and      dword ptr [ecx + 0x18], 0
433def41 cmp      byte ptr [esp + 0x17], 0
433def46 movss    xmm7, dword ptr [esp + 0x18]
433def4c je       0x433defab
433def4e cmp      byte ptr [esp + 0x40f], 0
433def56 jne      0x433defab
433def58 movss    xmm0, dword ptr [esp + 0x404]
433def61 comiss   xmm0, xmm7
433def64 jbe      0x433defab
433def66 comiss   xmm1, xmm0
433def69 jbe      0x433defab
433def6b lea      esi, [esp + 0x3e4]
433def72 lea      edi, [ecx + 4]
433def75 movsd    dword ptr es:[edi], dword ptr [esi]
433def76 movsd    dword ptr es:[edi], dword ptr [esi]
433def77 movsd    dword ptr es:[edi], dword ptr [esi]
433def78 jmp      0x433defab
433def7a mov      ecx, dword ptr [esp + 0x20]
433def7e movss    xmm7, dword ptr [esp + 0x18]
433def84 and      dword ptr [ecx + 0x1c], 0xfffffffe
433def88 movss    xmm0, dword ptr [ecx + 0x18]
433def8d comiss   xmm0, xmm7
433def90 jbe      0x433defab
433def92 cmp      byte ptr [ecx + 0xcc], 8
433def99 je       0x433defab
433def9b mov      dword ptr [ecx + 0xc8], 0x3e800000
433defa5 jmp      0x433defab
433defa7 and      dword ptr [ecx + 0x1c], 0xfffffffe
433defab test     byte ptr [ecx + 0x1c], 1
433defaf je       0x433df00b
433defb1 and      dword ptr [ecx + 0x18], 0
433defb5 comiss   xmm7, dword ptr [ecx + 0xc4]
433defbc jae      0x433df04e
433defc2 mov      eax, dword ptr [0x43468f4c]
433defc7 xor      eax, 0xb0cf25e8
433defcc je       0x433df002
433defce movss    xmm0, dword ptr [ecx + 0xe4]
433defd6 mulss    xmm0, dword ptr [ecx + 0xc4]
433defde movss    xmm1, dword ptr [ecx + 0xec]
433defe6 addss    xmm0, dword ptr [ecx + 0x34]
433defeb movaps   xmm2, xmm0
433defee xorps    xmm0, xmm0
433deff1 movss    xmm0, xmm7
433deff5 maxss    xmm2, xmm0
433deff9 minss    xmm2, xmm1
433deffd movss    dword ptr [ecx + 0x34], xmm2
433df002 and      dword ptr [ecx + 0xc4], 0
433df009 jmp      0x433df04e
433df00b movss    xmm0, dword ptr [ecx + 0x100]
433df013 mulss    xmm0, dword ptr [ecx + 0xd4]
433df01b movss    xmm1, dword ptr [ecx + 0x18]
433df020 mulss    xmm0, dword ptr [0x43472240]
433df028 subss    xmm1, xmm0
433df02c movss    xmm0, dword ptr [0x4346f6bc]
433df034 movss    dword ptr [ecx + 0x18], xmm1
433df039 comiss   xmm0, dword ptr [ecx + 0x104]
433df040 jbe      0x433df04e
433df042 comiss   xmm1, xmm0
433df045 jb       0x433df04e
433df047 or       byte ptr [ecx + 0x108], 0x10
433df04e test     byte ptr [ecx + 0x1c], 1
433df052 je       0x433df09c
433df054 movss    xmm3, dword ptr [0x43470514]
433df05c comiss   xmm3, dword ptr [ecx + 0x24]
433df060 jbe      0x433df095
433df062 movss    xmm0, dword ptr [ecx + 0x100]
433df06a mulss    xmm0, dword ptr [0x434702f0]
433df072 movss    xmm1, dword ptr [ecx + 0x24]
433df077 subss    xmm1, xmm0
433df07b xorps    xmm0, xmm0
433df07e movss    xmm0, xmm7
433df082 movaps   xmm2, xmm1
433df085 maxss    xmm2, xmm0
433df089 movaps   xmm0, xmm3
433df08c minss    xmm2, xmm0
433df090 movss    dword ptr [ecx + 0x24], xmm2
433df095 and      dword ptr [ecx + 0xc4], 0
433df09c inc      dword ptr [ecx + 0x20]
433df09f lea      ecx, [esp + 0x584]
433df0a6 call     0x4341873d
433df0ab pop      edi
433df0ac pop      esi
433df0ad mov      esp, ebp
433df0af pop      ebp
433df0b0 ret      8
