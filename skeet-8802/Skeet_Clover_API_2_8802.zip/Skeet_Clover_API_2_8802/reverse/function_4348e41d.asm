4348e41d push     esi
4348e41e push     edi
4348e41f xor      edi, edi
4348e421 mov      esi, ecx
4348e423 push     edi
4348e424 push     1
4348e426 push     dword ptr [esp + 0x18]
4348e42a push     edi
4348e42b call     0x43383d2b
4348e430 mov      edx, dword ptr [esp + 0x14]
4348e434 mov      eax, dword ptr [esp + 0xc]
4348e438 mov      dword ptr [esi], 0x4346f9c8
4348e43e mov      dword ptr [esi + 0x60], eax
4348e441 or       eax, 0xffffffff
4348e444 mov      dword ptr [esi + 0x64], eax
4348e447 mov      dword ptr [esi + 0x68], eax
4348e44a mov      dword ptr [esi + 0x6c], eax
4348e44d mov      dword ptr [esi + 0x80], eax
4348e453 mov      dword ptr [esi + 0x70], edi
4348e456 mov      dword ptr [esi + 0x74], edi
4348e459 mov      dword ptr [esi + 0x78], edi
4348e45c mov      dword ptr [esi + 0x54], edi
4348e45f mov      dword ptr [esi + 0x94], 0xa
4348e469 mov      ecx, dword ptr [edx + 4]
4348e46c mov      eax, dword ptr [edx]
4348e46e push     0x4b
4348e470 mov      dword ptr [esi + 0x20], eax
4348e473 pop      eax
4348e474 push     0x40
4348e476 mov      dword ptr [esi + 0x24], ecx
4348e479 pop      ecx
4348e47a mov      dword ptr [esi + 0x28], eax
4348e47d mov      dword ptr [esi + 0x30], eax
4348e480 mov      eax, ecx
4348e482 mov      dword ptr [esi + 0x2c], ecx
4348e485 mov      dword ptr [esi + 0x34], ecx
4348e488 add      dword ptr [edx + 4], eax
4348e48b mov      eax, esi
4348e48d pop      edi
4348e48e pop      esi
4348e48f ret      0xc
