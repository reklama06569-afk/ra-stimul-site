43406ed3 push     edx
43406ed4 call     0x43320347
43406ed9 ret      
