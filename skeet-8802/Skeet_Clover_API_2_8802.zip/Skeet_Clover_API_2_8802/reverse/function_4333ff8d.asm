4333ff8d push     esi
4333ff8e mov      esi, dword ptr [esp + 8]
4333ff92 push     edi
4333ff93 mov      edi, ecx
4333ff95 test     esi, esi
4333ff97 jle      0x43340032
4333ff9d cmp      esi, 0x41
4333ffa0 jl       0x4333ffc6
4333ffa2 lea      eax, [esi - 0x1f4]
4333ffa8 cmp      eax, 0x19
4333ffab ja       0x43340032
4333ffb1 cmp      dword ptr [esp + 0x10], 3
4333ffb6 push     0x2a
4333ffb8 pop      esi
4333ffb9 je       0x4333ffc6
4333ffbb cmp      dword ptr [esp + 0x10], 2
4333ffc0 push     0x3b
4333ffc2 pop      eax
4333ffc3 cmove    esi, eax
4333ffc6 mov      ecx, dword ptr [edi + 0x11c]
4333ffcc shl      esi, 4
4333ffcf add      esi, dword ptr [edi + 0x130]
4333ffd5 mov      eax, dword ptr [ecx]
4333ffd7 mov      dword ptr [ecx + 0x5c], esi
4333ffda call     dword ptr [eax + 0x14]
4333ffdd mov      ecx, dword ptr [edi + 0x120]
4333ffe3 lea      eax, [esi + 1]
4333ffe6 mov      dword ptr [ecx + 0x5c], eax
4333ffe9 mov      eax, dword ptr [ecx]
4333ffeb call     dword ptr [eax + 0x14]
4333ffee mov      eax, dword ptr [edi + 0x120]
4333fff4 mov      byte ptr [eax + 0x14], 1
4333fff8 lea      eax, [esi + 4]
4333fffb mov      ecx, dword ptr [edi + 0x124]
43340001 mov      dword ptr [ecx + 0x5c], eax
43340004 mov      eax, dword ptr [ecx]
43340006 call     dword ptr [eax + 0x14]
43340009 mov      ecx, dword ptr [edi + 0x128]
4334000f lea      eax, [esi + 8]
43340012 mov      dword ptr [ecx + 0x5c], eax
43340015 mov      eax, dword ptr [ecx]
43340017 call     dword ptr [eax + 0x14]
4334001a mov      ecx, dword ptr [edi + 0x12c]
43340020 lea      eax, [esi + 0xc]
43340023 mov      dword ptr [ecx + 0x5c], eax
43340026 mov      eax, dword ptr [ecx]
43340028 call     dword ptr [eax + 0x14]
4334002b mov      ecx, edi
4334002d call     0x434084f0
43340032 pop      edi
43340033 pop      esi
43340034 ret      8
