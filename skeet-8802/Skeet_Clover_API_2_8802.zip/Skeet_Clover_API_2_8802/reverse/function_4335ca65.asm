4335ca65 push     edx
4335ca66 call     0x4332fbf1
4335ca6b ret      
