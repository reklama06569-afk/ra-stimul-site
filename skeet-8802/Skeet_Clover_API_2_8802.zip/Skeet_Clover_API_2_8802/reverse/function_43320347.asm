43320347 mov      eax, dword ptr [ecx + 0x11c]
4332034d mov      eax, dword ptr [eax + 0x5c]
43320350 test     eax, eax
43320352 je       0x43320378
43320354 mov      al, byte ptr [eax]
43320356 test     al, al
43320358 je       0x43320378
4332035a call     0x4334d9e5
4332035f mov      eax, dword ptr [0x4346a334]
43320364 movss    xmm0, dword ptr [eax]
43320368 addss    xmm0, dword ptr [0x4346dd4c]
43320370 movss    dword ptr [0x4346a8a0], xmm0
43320378 ret      4
