433fd925 jmp      0x434084f0
434084f0 push     ebp
434084f1 mov      ebp, esp
434084f3 and      esp, 0xfffffff8
434084f6 sub      esp, 0x2c
434084f9 push     ebx
434084fa push     esi
434084fb mov      esi, ecx
434084fd xor      ecx, ecx
434084ff push     edi
43408500 mov      dword ptr [esp + 0x18], esi
43408504 cmp      dword ptr [esi + 0x12c], ecx
4340850a je       0x4340871d
43408510 mov      ecx, dword ptr [0x43476424]
43408516 test     ecx, ecx
43408518 jne      0x43408535
4340851a mov      eax, dword ptr [0x43468b9c]
4340851f test     eax, eax
43408521 je       0x4340852d
43408523 call     eax
43408525 mov      ecx, eax
43408527 mov      dword ptr [0x43476424], ecx
4340852d test     ecx, ecx
4340852f je       0x4340871d
43408535 mov      eax, dword ptr [ecx]
43408537 call     dword ptr [eax]
43408539 mov      ecx, eax
4340853b mov      dword ptr [esp + 0x10], ecx
4340853f test     ecx, ecx
43408541 je       0x4340871d
43408547 xor      eax, eax
43408549 mov      ebx, eax
4340854b mov      edi, eax
4340854d mov      dword ptr [esp + 0x28], ebx
43408551 mov      dword ptr [esp + 0x2c], edi
43408555 mov      dword ptr [esp + 0x30], eax
43408559 cmp      byte ptr [0x4346a498], al
4340855f jne      0x434085d5
43408561 mov      ebx, dword ptr [esp + 0x18]
43408565 mov      esi, eax
43408567 mov      dword ptr [esp + 0x14], esi
4340856b mov      eax, dword ptr [0x43467040]
43408570 test     eax, eax
43408572 je       0x434085c3
43408574 push     esi
43408575 call     eax
43408577 test     eax, eax
43408579 je       0x434085bf
4340857b push     dword ptr [eax + 0x24]
4340857e call     0x43397087
43408583 mov      dword ptr [esp + 0x1c], eax
43408587 test     eax, eax
43408589 je       0x434085bf
4340858b cmp      edi, dword ptr [esp + 0x30]
4340858f jae      0x434085a8
43408591 push     ecx
43408592 push     eax
43408593 lea      ecx, [edi + 4]
43408596 mov      dword ptr [edi], esi
43408598 call     0x433d2786
4340859d push     0x14
4340859f pop      eax
434085a0 add      edi, eax
434085a2 mov      dword ptr [esp + 0x2c], edi
434085a6 jmp      0x434085bf
434085a8 lea      eax, [esp + 0x14]
434085ac push     eax
434085ad lea      eax, [esp + 0x20]
434085b1 push     eax
434085b2 lea      ecx, [esp + 0x30]
434085b6 call     0x4338264f
434085bb mov      edi, dword ptr [esp + 0x2c]
434085bf mov      ecx, dword ptr [esp + 0x10]
434085c3 inc      esi
434085c4 mov      dword ptr [esp + 0x14], esi
434085c8 cmp      esi, dword ptr [ebx + 0x134]
434085ce jbe      0x4340856b
434085d0 jmp      0x4340868d
434085d5 movzx    eax, word ptr [esi + 0xe0]
434085dc lea      ecx, [esi + 0x138]
434085e2 mov      dword ptr [esp + 0x1c], eax
434085e6 lea      eax, [esp + 0x1c]
434085ea push     eax
434085eb lea      eax, [esp + 0x24]
434085ef push     eax
434085f0 call     0x4338a4c7
434085f5 mov      ecx, dword ptr [esi + 0x140]
434085fb mov      eax, dword ptr [esi + 0x13c]
43408601 mov      esi, dword ptr [esp + 0x20]
43408605 cmp      esi, dword ptr [eax + ecx*4]
43408608 je       0x43408691
4340860e mov      eax, dword ptr [esi + 8]
43408611 mov      esi, dword ptr [esi + 4]
43408614 cmp      esi, eax
43408616 je       0x43408691
43408618 mov      ebx, eax
4340861a movzx    ecx, word ptr [esi]
4340861d mov      eax, ecx
4340861f mov      dword ptr [esp + 0x14], eax
43408623 mov      eax, dword ptr [0x43467040]
43408628 test     eax, eax
4340862a je       0x43408686
4340862c movsx    ecx, cx
4340862f mov      dword ptr [esp + 0x1c], ecx
43408633 push     ecx
43408634 mov      ecx, dword ptr [esp + 0x14]
43408638 call     eax
4340863a test     eax, eax
4340863c je       0x43408686
4340863e push     dword ptr [eax + 0x24]
43408641 call     0x43397087
43408646 mov      dword ptr [esp + 0x20], eax
4340864a test     eax, eax
4340864c je       0x43408686
4340864e cmp      edi, dword ptr [esp + 0x30]
43408652 jae      0x4340866f
43408654 mov      ecx, dword ptr [esp + 0x1c]
43408658 push     ecx
43408659 mov      dword ptr [edi], ecx
4340865b lea      ecx, [edi + 4]
4340865e push     eax
4340865f call     0x433d2786
43408664 push     0x14
43408666 pop      eax
43408667 add      edi, eax
43408669 mov      dword ptr [esp + 0x2c], edi
4340866d jmp      0x43408686
4340866f lea      eax, [esp + 0x14]
43408673 push     eax
43408674 lea      eax, [esp + 0x24]
43408678 push     eax
43408679 lea      ecx, [esp + 0x30]
4340867d call     0x43346f60
43408682 mov      edi, dword ptr [esp + 0x2c]
43408686 add      esi, 2
43408689 cmp      esi, ebx
4340868b jne      0x4340861a
4340868d mov      ebx, dword ptr [esp + 0x28]
43408691 xor      ecx, ecx
43408693 mov      byte ptr [esp + 0x10], cl
43408697 cmp      ebx, edi
43408699 je       0x434086f5
4340869b mov      eax, edi
4340869d sub      eax, ebx
4340869f push     0x14
434086a1 pop      esi
434086a2 cdq      
434086a3 idiv     esi
434086a5 mov      esi, eax
434086a7 mov      edx, eax
434086a9 test     edx, edx
434086ab je       0x434086b2
434086ad inc      ecx
434086ae sar      edx, 1
434086b0 jne      0x434086ad
434086b2 push     dword ptr [esp + 0x10]
434086b6 lea      eax, [ecx*2 - 2]
434086bd mov      edx, edi
434086bf push     eax
434086c0 mov      ecx, ebx
434086c2 call     0x433e9f7d
434086c7 mov      ecx, ebx
434086c9 push     dword ptr [esp + 0x10]
434086cd cmp      esi, 0x1c
434086d0 jle      0x434086ee
434086d2 lea      esi, [ebx + 0x230]
434086d8 mov      edx, esi
434086da call     0x433e30f3
434086df push     dword ptr [esp + 0x10]
434086e3 mov      edx, edi
434086e5 mov      ecx, esi
434086e7 call     0x433e09a6
434086ec jmp      0x434086f5
434086ee mov      edx, edi
434086f0 call     0x433e30f3
434086f5 mov      ebx, dword ptr [esp + 0x18]
434086f9 lea      eax, [esp + 0x28]
434086fd push     eax
434086fe mov      ecx, dword ptr [ebx + 0x12c]
43408704 call     0x433c9fbf
43408709 mov      ecx, dword ptr [ebx + 0x12c]
4340870f mov      eax, dword ptr [ecx]
43408711 call     dword ptr [eax + 0x14]
43408714 lea      ecx, [esp + 0x28]
43408718 call     0x433fa343
4340871d pop      edi
4340871e pop      esi
4340871f pop      ebx
43408720 mov      esp, ebp
43408722 pop      ebp
43408723 ret      
