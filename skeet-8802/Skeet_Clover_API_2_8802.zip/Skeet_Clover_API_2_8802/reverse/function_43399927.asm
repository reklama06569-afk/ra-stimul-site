43399927 push     esi
43399928 push     edi
43399929 push     dword ptr [esp + 0x14]
4339992d mov      esi, ecx
4339992f push     4
43399931 push     dword ptr [esp + 0x18]
43399935 push     dword ptr [esp + 0x18]
43399939 call     0x43383d2b
4339993e or       dword ptr [esi + 0x74], 0xffffffff
43399942 xor      ecx, ecx
43399944 push     0x14
43399946 pop      edi
43399947 mov      dword ptr [esi], 0x4346dd00
4339994d push     0xf
4339994f pop      eax
43399950 mov      dword ptr [esi + 0x68], eax
43399953 mov      dword ptr [esi + 0x6c], eax
43399956 lea      eax, [esi + 0x8c]
4339995c mov      dword ptr [esi + 0x7c], ecx
4339995f mov      dword ptr [esi + 0x80], ecx
43399965 mov      dword ptr [esi + 0x84], ecx
4339996b mov      dword ptr [eax], ecx
4339996d mov      word ptr [esi + 0x70], cx
43399971 mov      dword ptr [esi + 0x78], ecx
43399974 mov      dword ptr [esi + 0x90], eax
4339997a mov      al, byte ptr [esp + 0x18]
4339997e mov      word ptr [esi + 0x94], cx
43399985 mov      dword ptr [esi + 0x60], edi
43399988 mov      dword ptr [esi + 0x64], edi
4339998b mov      dword ptr [esi + 0x98], ecx
43399991 mov      dword ptr [esi + 0x9c], ecx
43399997 mov      dword ptr [esi + 0xa0], ecx
4339999d mov      dword ptr [esi + 0xa4], ecx
433999a3 mov      dword ptr [esi + 0x1c], ecx
433999a6 lea      ecx, [esi + 0x38]
433999a9 mov      byte ptr [esi + 0x18], al
433999ac call     0x4334d0a8
433999b1 test     eax, eax
433999b3 je       0x433999c4
433999b5 cmp      byte ptr [esi + 0x18], 0
433999b9 jne      0x433999c4
433999bb mov      dword ptr [esi + 0x2c], 0x23
433999c2 jmp      0x433999c7
433999c4 mov      dword ptr [esi + 0x2c], edi
433999c7 mov      dword ptr [esi + 0x28], 0x9e
433999ce mov      ecx, esi
433999d0 mov      eax, dword ptr [esi + 0x28]
433999d3 mov      dword ptr [esi + 0x30], eax
433999d6 mov      eax, dword ptr [esi + 0x2c]
433999d9 mov      dword ptr [esi + 0x34], eax
433999dc call     0x433b09e2
433999e1 pop      edi
433999e2 mov      eax, esi
433999e4 pop      esi
433999e5 ret      0x10
