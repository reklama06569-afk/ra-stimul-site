43384c8d push     edx
43384c8e call     0x433821b6
43384c93 ret      
