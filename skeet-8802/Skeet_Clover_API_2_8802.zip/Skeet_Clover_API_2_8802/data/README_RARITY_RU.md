# Источник цветов редкости

Факты каталога получены из исторических данных Valve, опубликованных
SteamDatabase/GameTracking-CS2, commit `e63fc7fdb8dfb4f1873f0db214c0cc16613d5beb`.
Это дерево старой CS:GO, а не новые предметы CS2.

- Схема: https://github.com/SteamDatabase/GameTracking-CS2/blob/e63fc7fdb8dfb4f1873f0db214c0cc16613d5beb/csgo/scripts/items/items_game.txt
- Английские названия: https://github.com/SteamDatabase/GameTracking-CS2/blob/e63fc7fdb8dfb4f1873f0db214c0cc16613d5beb/csgo/resource/csgo_english.txt
- Русские названия: https://github.com/SteamDatabase/GameTracking-CS2/blob/e63fc7fdb8dfb4f1873f0db214c0cc16613d5beb/csgo/resource/csgo_russian.txt

Схема SHA256: `469cf0ef8a2c53503f0845b60d3c0dc576625dfbbfb9aff885ee8282b45beaec`.
Названия предметов принадлежат их правообладателям. В архиве находятся
извлечённые факты, необходимые для отображения, и ссылки на происхождение.

`skin_rarity_catalog.json` содержит ID, внутренний ранг раскраски, допустимые
комбинации с предметами, итоговые ранги и локализованные имена.
Скрипт учитывает наследование prefab и объединение повторных блоков KeyValues.
Комбинации взяты из `alternate_icons2.weapon_icons`, а не угаданы по именам.
Итоговый ранг — ранг предмета плюс ранг раскраски минус один, с пределами
схемы. Цвета также берутся из схемы Valve.

Для повторной генерации сохраните три исходных файла в один каталог:
`items_game_2023_08.txt`, `csgo_english.txt`, `csgo_russian.txt`, затем запустите
`python tools/build_skin_rarity.py /путь/к/каталогу`.
Обычной сборке уже сгенерированного исходника доступ к сети не нужен.
