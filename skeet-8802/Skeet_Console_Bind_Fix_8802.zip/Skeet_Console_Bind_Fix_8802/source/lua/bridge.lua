local ffi = require('ffi')
pcall(ffi.cdef,[[
 typedef struct { unsigned int size,valid; float cpu_percent,cpu_ghz,ram_used_gib,ram_total_gib,process_mib; } CloverTelemetry8802;
 typedef struct { int id; float wear,scale,rotation; } CloverSticker8802;
 void clover_ui_heartbeat(void);
 void clover_ui_module(unsigned int);
 void clover_night(int,unsigned int,unsigned int,unsigned int);
 void clover_night_reset(void);
 int clover_telemetry(void*,unsigned int);
 int clover_selected_weapon(void);
 int clover_sticker_set(int,unsigned int,int,float,float,float);
 int clover_sticker_get(int,unsigned int,void*);
 int clover_sky(const char*);
 int clover_sky_tint(const char*,unsigned int);
]])
-- Only this DLL's fixed bridge functions are bound by bootstrap. No ffi.load required.
local native = {
 clover_ui_heartbeat=ffi.cast('void(__cdecl*)(void)',tonumber('__CLOVER_UI_HEARTBEAT__',16)),
 clover_ui_module=ffi.cast('void(__cdecl*)(unsigned int)',tonumber('__CLOVER_UI_MODULE__',16)),
 clover_night=ffi.cast('void(__cdecl*)(int,unsigned int,unsigned int,unsigned int)',tonumber('__CLOVER_NIGHT__',16)),
 clover_night_reset=ffi.cast('void(__cdecl*)(void)',tonumber('__CLOVER_NIGHT_RESET__',16)),
 clover_telemetry=ffi.cast('int(__cdecl*)(void*,unsigned int)',tonumber('__CLOVER_TELEMETRY__',16)),
 clover_selected_weapon=ffi.cast('int(__cdecl*)(void)',tonumber('__CLOVER_SELECTED_WEAPON__',16)),
 clover_sticker_set=ffi.cast('int(__cdecl*)(int,unsigned int,int,float,float,float)',tonumber('__CLOVER_STICKER_SET__',16)),
 clover_sticker_get=ffi.cast('int(__cdecl*)(int,unsigned int,void*)',tonumber('__CLOVER_STICKER_GET__',16)),
 clover_sky=ffi.cast('int(__cdecl*)(const char*)',tonumber('__CLOVER_SKY__',16)),
 clover_sky_tint=ffi.cast('int(__cdecl*)(const char*,unsigned int)',tonumber('__CLOVER_SKY_TINT__',16)),
}
client.set_event_callback('paint_ui',function() native.clover_ui_heartbeat() end)
local hw = ffi.new('CloverTelemetry8802[1]')
local hw_time = -10
local function hardware()
 local now=globals.realtime()
 if now-hw_time>=1 then hw_time=now;native.clover_telemetry(hw,ffi.sizeof(hw[0])) end
 return hw[0]
end
