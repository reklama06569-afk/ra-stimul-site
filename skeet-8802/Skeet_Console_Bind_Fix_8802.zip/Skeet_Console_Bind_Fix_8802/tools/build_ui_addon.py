"""Bundle the supplied Lua visuals and the reviewed Legacy integration.
No uploaded Lua is executed by this build tool. Output is embedded in the DLL.
"""
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1];F=ROOT/'source/lua'
def write(path,text):
 if not path.exists() or path.read_text(encoding="utf-8")!=text:path.write_text(text,encoding="utf-8")
def build():
 compat=(F/'compat.lua').read_text(encoding="utf-8");bridge=(F/'bridge.lua').read_text(encoding="utf-8")
 notify=(F/'notify.original.lua').read_text(encoding="utf-8").replace("menu.dpi_scale = '100%'","menu.dpi_scale = ui.get(menu.dpi_scale_ref)").replace("'LUA', 'A'","'MISC', 'Miscellaneous'")
 for a,b in [('Notifications','CS2 logs'),("'Events'","'Log events'")]:notify=notify.replace(a,b)
 watermark=(F/'watermark.original.lua').read_text(encoding="utf-8").replace("menu.dpi_scale = '100%'","menu.dpi_scale = ui.get(menu.dpi_scale_ref)").replace("'LUA', 'A'","'MISC', 'Miscellaneous'")
 watermark=watermark.replace("'Watermark'","'CS2 watermark'").replace("'Color'","'Watermark accent'").replace("'Elements'","'Watermark elements'")
 watermark=watermark.replace("'Clock', 'Clock (24h)'","'Clock', 'Clock (24h)', 'CPU usage', 'CPU frequency', 'RAM', 'Game memory'")
 insert="""        local stats=hardware()
        if menu.has('CPU usage') and bit.band(stats.valid,1)~=0 then self:separator();self:push(string.format('%.0f%%',stats.cpu_percent));self:push('CPU',nil,true) end
        if menu.has('CPU frequency') and bit.band(stats.valid,2)~=0 then self:separator();self:push(string.format('%.2f GHz',stats.cpu_ghz)) end
        if menu.has('RAM') and bit.band(stats.valid,4)~=0 then self:separator();self:push(string.format('%.1f/%.1f GB',stats.ram_used_gib,stats.ram_total_gib));self:push('RAM',nil,true) end
        if menu.has('Game memory') and bit.band(stats.valid,8)~=0 then self:separator();self:push(string.format('%.0f MB',stats.process_mib));self:push('GAME',nil,true) end
"""
 watermark=watermark.replace("        if menu.has('Clock') or menu.has('Clock (24h)') then",insert+"        if menu.has('Clock') or menu.has('Clock (24h)') then")
 watermark=watermark.replace("ffi.cdef[[", "pcall(ffi.cdef,[[").replace("]]\n\nlocal rawivengineclient", "]])\n\nlocal rawivengineclient")
 # Default selection is useful as soon as the user enables a new watermark.
 watermark=watermark.replace('    update_elements(menu.watermark_elements)','    if #ui.get(menu.watermark_elements)==0 then ui.set(menu.watermark_elements,\'Logo\',\'Username\',\'FPS\',\'Ping\',\'Clock (24h)\',\'CPU frequency\',\'RAM\') end\n    update_elements(menu.watermark_elements)',1)
 notify=notify.replace('    update_events(menu.events)',"    if #ui.get(menu.events)==0 then ui.set(menu.events,'Hit','Miss','Purchase') end\n    update_events(menu.events)",1)
 meta=json.loads((ROOT/'data/sticker_catalog.json').read_text(encoding="utf-8"));kits=[[0,'None']]+[[k['id'],k['name']] for k in meta['kits']]
 catalog='local CLOVER_LEGACY_STICKERS={'+','.join('{%d,%s}'%(i,json.dumps(n,ensure_ascii=False)) for i,n in kits)+'}\n'
 # Separate closures avoid local-menu collisions between the uploaded scripts.
 body=compat+'\n'+bridge+'\n'+catalog+'\n'
 for name,s in [('world',(F/'world.lua').read_text(encoding="utf-8")),('stickers',(F/'stickers.lua').read_text(encoding="utf-8")),('notifications',notify),('watermark',watermark)]:
  mask={'world':1,'stickers':2,'notifications':4,'watermark':8}[name]
  body+='\ndo\n local ok,err=pcall(function()\n'+s+'\n end)\n if ok then native.clover_ui_module('+str(mask)+') else client.error_log("Clover '+name+': "..tostring(err)) end\nend\n'
 script=F/'clover_cs2_ui_8802.lua';write(script,body)
 # Raw string ASCII delimiter is checked before embedding, UTF-8 stays intact.
 assert ')CLOVER8802"' not in body
 write(ROOT/'source/skeet/ui_addon_embedded.h','#pragma once\ninline constexpr char ui_addon_script[]=R"CLOVER8802('+body+')CLOVER8802";\n')
 report={'source_notify_sha256':hashlib.sha256((F/'notify.original.lua').read_bytes()).hexdigest(),'source_watermark_sha256':hashlib.sha256((F/'watermark.original.lua').read_bytes()).hexdigest(),'generated_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'legacy_stickers':len(kits)-1,'third_party_dependencies':False,'cpu_sample_interval_seconds':1,'game_tested':False}
 write(ROOT/'data/ui_addon_provenance.json',json.dumps(report,indent=2)+'\n');print('Bundled',len(body.encode()),'bytes')
if __name__=='__main__':build()
