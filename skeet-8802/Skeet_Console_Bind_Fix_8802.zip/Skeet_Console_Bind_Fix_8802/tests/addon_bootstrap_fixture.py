"""Test DLL-managed Lua installation with file and loader calls fully stubbed."""
def check_addon_bootstrap(ns):
 globals().update(ns)
 u=fixture();ticks=[4000];writes=[];loaded=[]
 unsafe_value=MEM+0x28000
 def current_directory(u,sp):
  out=word(u,sp+8);u.mem_write(out,'C:\\CS\0'.encode('utf-16le'));return 5,12
 def create(u,sp):
  assert wide(u,word(u,sp+4))=='C:\\CS\\clover_cs2_ui_8802.lua';return 123,32
 def write(u,sp):
  handle,ptr,n,out=[word(u,sp+i) for i in [4,8,12,16]];assert handle==123
  payload=bytes(u.mem_read(ptr,n));expected=(ROOT/'source/lua/clover_cs2_ui_8802.lua').read_text()
  import re
  for token in re.findall(r'__CLOVER_[A-Z_]+__',expected):expected=expected.replace(token,format(exp(token[2:-2].lower()),'x').rjust(len(token),'0'))
  assert payload==expected.encode();writes.append(n);store(u,out,n);return 1,24
 handlers={'GetTickCount':lambda u,sp:(ticks[0],4),'GetCurrentDirectoryW':current_directory,'CreateFileW':create,'WriteFile':write,'CloseHandle':lambda u,sp:(1,8),'wcscat':lambda u,sp:(append_wide(u,word(u,sp+4),word(u,sp+8)),4)}
 def append_wide(u,out,src):
  left,right=wide(u,out),wide(u,src);u.mem_write(out,(left+right+'\0').encode('utf-16le'));return out
 pe,exp=load(u,'visuals_binding_probe.dll',handlers)
 menu,tabs,config,children,child,elements,unsafe,nm=[MEM+0x20000+i*0x1000 for i in range(8)]
 store(u,menu+0x54,tabs);store(u,menu+0x58,tabs+36);store(u,tabs+7*4,config);store(u,config+0x70,children);store(u,config+0x74,children+8);store(u,children+4,child)
 store(u,child+0x80,elements);store(u,child+0x84,elements+8);store(u,elements+4,unsafe)
 u.mem_write(unsafe+0x19,b'\3');store(u,unsafe+0x5c,unsafe_value);store(u,unsafe+0x38,nm)
 title='Allow unsafe scripts'.encode('utf-16le');u.mem_write(nm,struct.pack('<HH',0,len(title))+title)
 def loader(u,a,size,user):
  if a!=0x43419b27:return
  sp=u.reg_read(UC_X86_REG_ESP);assert wide(u,u.reg_read(UC_X86_REG_ECX))=='clover_cs2_ui_8802'
  assert bytes(u.mem_read(unsafe_value,1))==b'\1';loaded.append(True)
  u.reg_write(UC_X86_REG_EAX,1);u.reg_write(UC_X86_REG_EIP,word(u,sp));u.reg_write(UC_X86_REG_ESP,sp+4)
 u.hook_add(UC_HOOK_CODE,loader)
 call(u,exp('addon_reset_probe'));assert call(u,exp('addon_bootstrap_probe'),[menu])==0 and not writes
 ticks[0]=4001;assert call(u,exp('addon_bootstrap_probe'),[menu])==0 and not writes
 ticks[0]=6000;assert call(u,exp('addon_bootstrap_probe'),[menu])==3
 assert len(writes)==len(loaded)==1 and bytes(u.mem_read(unsafe_value,1))==b'\0'
 assert call(u,exp('addon_bootstrap_probe'),[menu])==3 and len(writes)==1
 call(u,exp('addon_heartbeat_probe'));ticks[0]=20000
 for _ in range(180):assert call(u,exp('addon_bootstrap_probe'),[menu])==3 and len(writes)==1
 assert call(u,exp('addon_bootstrap_probe'),[menu])==3 and len(writes)==2
 assert bytes(u.mem_read(unsafe_value,1))==b'\0'
 return {'passed':True,'warmup_delay_ms':1500,'exact_embedded_script_written_once':True,'native_loader_filename_abi':True,'reload_after_lua_unload_detected':True,'minimized_resume_does_not_reload_immediately':True,'loader_permission_scoped_and_restored':True,'filesystem_and_lua_loader_mocked':True,'game_tested':False}
